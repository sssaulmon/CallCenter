package com.isban.gcb.ic.commons.balance.cache.dto;

import com.isban.gcb.ic.commons.model.ClosingAvailableBalance;
import com.isban.gcb.ic.commons.model.Extract;
import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import static com.isban.gcb.ic.commons.balance.cache.dto.BalanceType.END_OF_DAY;
import static com.isban.gcb.ic.commons.balance.cache.dto.BalanceType.INTRA_DAY;
import static java.time.Month.JANUARY;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class ExtractDtoTest {

  @Test
  public void giveFromExtract_whenExtract940_thenReturnExtractDto() {
    assertThat(ExtractDto.fromExtract(buildExtract940(), false)).isEqualToComparingFieldByField(buildExtractDto940());
  }

  @Test
  public void giveFromExtract_whenExtract941_thenReturnExtractDto() {
    assertThat(ExtractDto.fromExtract(buildExtract941(), false)).isEqualToComparingFieldByField(buildExtractDto941());
  }

  @Test
  public void giveFromExtract_whenExtract942_thenReturnExtractDto() {
    assertThat(ExtractDto.fromExtract(buildExtract942(), true)).isEqualToComparingFieldByField(buildExtractDto942());
  }

  @Test
  public void testEqualsExtractDTO() {
    ExtractDto extractMT942 = buildExtractDto942();
    ExtractDto extractMT940 = buildExtractDto940();
    assertNotEquals(extractMT940, extractMT942);
  }

  @Test
  public void equals_KO() {
    ExtractDto expected = buildExtractDto942();

    assertNotEquals(expected, "Not Equals");
  }

  @Test
  public void testHashCodeExtractDTO() {
    ExtractDto extractMT942 = buildExtractDto942();
    ExtractDto extractMT940 = buildExtractDto940();
    assertNotEquals(extractMT940.hashCode(), extractMT942.hashCode());
  }

  @Test
  public void testToStringExtractDTO() {
    ExtractDto extract1 = buildExtractDto942();
    ExtractDto extract2 = buildExtractDto942();
    assertEquals(extract1.toString(), extract2.toString());
  }

  private Extract buildExtract940() {
    LocalDate date = LocalDate.of(2020, JANUARY, 1);
    Extract extract = new Extract();
    extract.setAccountIdentification("ABCDEF");
    extract.setClosingAvailableBalance(buildClosingAvailable());
    extract.setClosingBalanceAmount(200d);
    extract.setClosingBalanceDate(date);
    extract.setClosingBalanceMark('C');
    extract.setCurrency("EUR");
    extract.setDateTimeIndication(null);
    extract.setId(1L);
    extract.setEntityAccountBic("BIC");
    extract.setOpeningBalanceAmount(50d);
    extract.setOpeningBalanceDate(date);
    extract.setOpeningBalanceMark('C');
    extract.setType("MT940");
    extract.setValid(true);
    return extract;
  }

  private Extract buildExtract941() {
    Extract extract = new Extract();
    extract.setAccountIdentification("ABCDEF");
    extract.setClosingAvailableBalance(null);
    extract.setClosingBalanceAmount(null);
    extract.setClosingBalanceDate(null);
    extract.setClosingBalanceMark(null);
    extract.setCurrency("EUR");
    extract.setDateTimeIndication(LocalDateTime.of(2020, JANUARY, 1, 10, 10));
    extract.setId(1L);
    extract.setEntityAccountBic("BIC");
    extract.setOpeningBalanceAmount(null);
    extract.setOpeningBalanceDate(null);
    extract.setOpeningBalanceMark(null);
    extract.setType("MT941");
    extract.setValid(true);
    return extract;
  }

  private Extract buildExtract942() {
    Extract extract = new Extract();
    extract.setAccountIdentification("ABCDEF");
    extract.setClosingAvailableBalance(null);
    extract.setClosingBalanceAmount(null);
    extract.setClosingBalanceDate(null);
    extract.setClosingBalanceMark(null);
    extract.setCurrency("EUR");
    extract.setDateTimeIndication(LocalDateTime.of(2020, JANUARY, 1, 10, 10));
    extract.setId(1L);
    extract.setEntityAccountBic("BIC");
    extract.setOpeningBalanceAmount(null);
    extract.setOpeningBalanceDate(null);
    extract.setOpeningBalanceMark(null);
    extract.setType("MT942");
    extract.setValid(true);
    return extract;
  }

  private ClosingAvailableBalance buildClosingAvailable() {
    ClosingAvailableBalance closingAvailableBalance = new ClosingAvailableBalance();
    closingAvailableBalance.setAmount(100d);
    closingAvailableBalance.setDate(LocalDate.of(2020, JANUARY, 1));
    closingAvailableBalance.setMark('C');
    return closingAvailableBalance;
  }

  private ExtractDto buildExtractDto942() {
    return ExtractDto.builder()
      .accountingDate(LocalDateTime.of(2020, JANUARY, 1, 10, 10))
      .accountAlias("ABCDEF")
      .availableBalanceAmount(null)
      .availableBalanceDate(null)
      .availableBalanceMark(null)
      .balanceType(INTRA_DAY.toString())
      .bic("BIC")
      .closingBalanceAmount(null)
      .closingBalanceDate(null)
      .closingBalanceMark(null)
      .currency("EUR")
      .id(1L)
      .formatType("MT942")
      .openingBalanceAmount(null)
      .openingBalanceDate(null)
      .openingBalanceMark(null)
      .valid(true)
      .transactions(true)
      .bestTransactions(true)
      .information(null)
      .build();
  }

  private ExtractDto buildExtractDto941() {
    return ExtractDto.builder(ExtractDto.builder()
      .accountingDate(LocalDateTime.of(2020, JANUARY, 1, 10, 10))
      .accountAlias("ABCDEF")
      .availableBalanceAmount(null)
      .availableBalanceDate(null)
      .availableBalanceMark(null)
      .balanceType(INTRA_DAY.toString())
      .bic("BIC")
      .closingBalanceAmount(null)
      .closingBalanceDate(null)
      .closingBalanceMark(null)
      .currency("EUR")
      .id(1L)
      .formatType("MT941")
      .openingBalanceAmount(null)
      .openingBalanceDate(null)
      .openingBalanceMark(null)
      .valid(true)
      .transactions(false)
      .bestTransactions(false)
      .information(null)
      .build())
      .build();
  }

  private ExtractDto buildExtractDto940() {
    LocalDateTime dateTime = LocalDateTime.of(LocalDate.of(2020, JANUARY, 1), LocalTime.MIDNIGHT);
    return ExtractDto.builder()
      .accountingDate(LocalDateTime.of(2020, JANUARY, 1, 0, 0))
      .accountAlias("ABCDEF")
      .availableBalanceAmount(100d)
      .availableBalanceDate(dateTime)
      .availableBalanceMark("C")
      .balanceType(END_OF_DAY.toString())
      .bic("BIC")
      .closingBalanceAmount(200d)
      .closingBalanceDate(dateTime)
      .closingBalanceMark("C")
      .currency("EUR")
      .id(1L)
      .formatType("MT940")
      .openingBalanceAmount(50d)
      .openingBalanceDate(dateTime)
      .openingBalanceMark("C")
      .valid(true)
      .transactions(false)
      .bestTransactions(false)
      .information(null)
      .build();
  }
}