package com.isban.gcb.ic.commons.balance.cache.dto;

import org.junit.Test;

import static com.isban.gcb.ic.commons.balance.cache.dto.BalanceType.END_OF_DAY;
import static com.isban.gcb.ic.commons.balance.cache.dto.BalanceType.INTRA_DAY;
import static org.junit.Assert.assertEquals;

public class BalanceTypeTest {

  @Test
  public void givenGetBalanceType_whenLookingForMT942_thenReturnINT() {
    assertEquals(BalanceType.getBalanceType("MT942"), INTRA_DAY);
  }

  @Test
  public void givenGetBalanceType_whenLookingForMT941_thenReturnINT() {
    assertEquals(BalanceType.getBalanceType("MT941"), INTRA_DAY);
  }

  @Test
  public void givenGetBalanceType_whenLookingForMT940_thenReturnEOD() {
    assertEquals(BalanceType.getBalanceType("MT940"), END_OF_DAY);
  }

  @Test
  public void givenGetBalanceType_whenLookingForMT950_thenReturnEOD() {
    assertEquals(BalanceType.getBalanceType("MT950"), END_OF_DAY);
  }

  @Test(expected = RuntimeException.class)
  public void givenGetBalanceType_whenLookingForUnknown_thenReturnNID() {
    BalanceType.getBalanceType("XXX");
  }
}