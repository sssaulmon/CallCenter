package com.isban.gcb.ic.commons.converter.model;

import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

public class AccountTransactionDtoTest {
  private AccountTransactionDto dto;

  @Before
  public void setUp() {
    AccountSummaryDto summaryDto = buildSummary();


    dto = new AccountTransactionDto("uuid", null, summaryDto, "00001", "1", false, "", 1L, true,
      false, null, new ArrayList<>(), new ArrayList<>(), "", "test".getBytes(), null);
  }

  private AccountSummaryDto buildSummary() {
    AccountSummaryDto summaryDto = new AccountSummaryDto();
    summaryDto.setProductCode("2");
    summaryDto.setSubProductCode("0002");
    summaryDto.setIndicatorMotherAccount("");
    summaryDto.setInitialExtractBalance(BigDecimal.ZERO);
    summaryDto.setFinalExtractBalance(BigDecimal.ZERO);
    summaryDto.setRegType("1");
    summaryDto.setCountryCode("ES");
    summaryDto.setCurrency("EUR");
    summaryDto.setIndicatorActivePassive("");
    summaryDto.setAccountOpeningDate(LocalDate.of(2020, 1, 1));
    summaryDto.setIndicatorExtractionPeriodicity("");
    summaryDto.setExtractionStartDate(LocalDate.of(2020, 1, 1));
    summaryDto.setExtractionEndDate(LocalDate.of(2020, 1, 1));
    summaryDto.setSequenceExtractNumber(1);
    summaryDto.setExtractionProcessDate(LocalDate.of(2020, 1, 1));
    summaryDto.setExtractionNextDate(LocalDate.of(2020, 1, 1));
    summaryDto.setBalanceAvailableAtClosingDate(BigDecimal.ZERO);
    summaryDto.setOperationBalance(BigDecimal.ZERO);
    summaryDto.setFiller("");
    return summaryDto;
  }

  @Test
  public void hasError_OK() {
    dto.addError(new MonitoringError());

    assertTrue(dto.hasErrors());
  }

  @Test
  public void serialize_OK() {
    String expected = "1ESnullEUR20002200101200101200101+00000000000000+0000000000000000001200101200101+00000000000000+00000000000000";
    String result = dto.serialize(false);

    assertEquals(expected, result);
  }

  @Test
  public void equalsHasCodeAndToString_OK() {
    AccountSummaryDto summaryDto = buildSummary();

    AccountTransactionDto expected = new AccountTransactionDto("uuid", null, summaryDto, "00001", "1", false, "", 1L, true,
      false, null, new ArrayList<>(), new ArrayList<>(), "", "test".getBytes(), null);

    assertEquals(expected, dto);
    assertEquals(expected.hashCode(), dto.hashCode());
    assertEquals(expected.toString(), dto.toString());

    assertEquals(summaryDto, dto.getAccountSummary());
    assertEquals(summaryDto, summaryDto);
    assertEquals(summaryDto.hashCode(), dto.getAccountSummary().hashCode());
    assertEquals(summaryDto.toString(), dto.getAccountSummary().toString());
    assertNotEquals(summaryDto.toString(), "Not Equals");
  }
}
