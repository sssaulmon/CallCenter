package com.isban.gcb.ic.commons.constants;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class S3DirectoriesTest {

  @Test
  public void toPath_shouldReturn_mt940() {
    assertEquals("/mt940/", S3Directories.MT940.getDirectory());

    String input = "/mt940/";
    assertEquals("/mt940/", S3Directories.getDirectory(input));
  }
}
