package com.isban.gcb.ic.commons.converter.model;

import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

public class ConverterDtoTest {
  private ConverterDto converterDto;

  @Before
  public void setUp() {
    converterDto = bulidConverterDto();
  }

  private ConverterDto bulidConverterDto() {
    return new ConverterDto(buildSummaryHeaderSwf0(), new ArrayList<>());
  }

  private SummaryHeaderSwf0 buildSummaryHeaderSwf0() {
    return new SummaryHeaderSwf0("1", "PRI", new AccountDto(), "EUR", buildRegistryDto());
  }

  private RegistryDto buildRegistryDto() {
    return new RegistryDto(LocalDate.now(), LocalTime.of(0, 0, 0), 1, 1, 1, 1, BigDecimal.ZERO,
      BigDecimal.ZERO, BigDecimal.ZERO, "N", "Filler");
  }

  @Test
  public void equals_hashCode_toString_OK() {
    ConverterDto expected = bulidConverterDto();

    assertEquals(expected, converterDto);
    assertEquals(expected, expected);
    assertEquals(expected.hashCode(), converterDto.hashCode());
    assertEquals(expected.toString(), converterDto.toString());

    assertEquals(expected.getSummaryHeaderSwf0(), converterDto.getSummaryHeaderSwf0());
    assertEquals(expected.getSummaryHeaderSwf0(), expected.getSummaryHeaderSwf0());
    assertEquals(expected.getSummaryHeaderSwf0().hashCode(), converterDto.getSummaryHeaderSwf0().hashCode());
    assertEquals(expected.getSummaryHeaderSwf0().toString(), converterDto.getSummaryHeaderSwf0().toString());
  }
}
