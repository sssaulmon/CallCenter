package com.isban.gcb.ic.commons.channels;

import com.isban.gcb.ic.commons.channels.model.ChannelFileNames;
import com.isban.gcb.ic.commons.channels.model.RequestChannelAppend;
import com.isban.gcb.ic.commons.channels.model.RequestChannelComplete;
import com.isban.gcb.ic.commons.channels.model.RequestChannelFileName;
import com.isban.gcb.ic.commons.channels.model.RequestChannelNoAppend;
import com.isban.gcb.ic.commons.channels.model.RequestChannels;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class ChannelTest {
  private Channel channel;

  @Before
  public void setUp() {
    RequestChannels requestChannels = new RequestChannels();
    requestChannels.setChannelSwiftFin("SWIFT");
    requestChannels.setChannelEditran("EDITRAN");
    requestChannels.setChannelFileact("FILEACT");
    requestChannels.setChannelH2H("H2H");
    requestChannels.setChannelEbic("EBIC");
    requestChannels.setChannelEmail("EMAIL");
    channel = new Channel(requestChannels);
  }

  @Test
  public void resolvePathSwiftFin() {
    RequestChannelFileName request = new RequestChannelFileName()
      .outputChannel("SWIFT")
      .account("1234567890")
      .contract("TEST")
      .fileName("20200101")
      .format("PDF")
      .frequency("1")
      .version("00001");

    String expected = "Global_Report/1234567890/1/PDF/TEST/SWIFT/version/00001/COMPLETE/";
    String result = channel.resolvePath(request);

    Assert.assertEquals(expected, result);
  }

  @Test
  public void resolvePathH2H() {
    RequestChannelFileName request = new RequestChannelFileName();
    request.setOutputChannel("H2H");
    request.setAccount("1234567890");
    request.setContract("TEST");
    request.setFileName("20200101");
    request.setFormat("PDF");
    request.setFrequency("1");
    request.setVersion("00001");

    String expected = "Global_Report/1234567890/1/PDF/TEST/H2H/version/00001/";
    String result = channel.resolvePath(request);

    Assert.assertEquals(expected, result);
  }

  @Test
  public void resolveFileNamePathSwiftFin() {
    RequestChannelFileName request = new RequestChannelFileName();
    request.setOutputChannel("SWIFT");
    request.setAccount("1234567890");
    request.setContract("TEST");
    request.setFileName("SWIFT20200101.PDF");
    request.setFormat("PDF");
    request.setFrequency("1");
    request.setVersion("00001");

    String expected = "Global_Report/1234567890/1/PDF/TEST/SWIFT/version/00001/COMPLETE/SWIFT20200101.SWIFT";
    String result = channel.resolveFileNamePath(request);

    Assert.assertEquals(expected, result);
  }

  @Test
  public void resolveFileNamePathEditTran() {
    RequestChannelFileName request = new RequestChannelFileName();
    request.setOutputChannel("EDITRAN");
    request.setAccount("1234567890");
    request.setContract("TEST");
    request.setFileName("EDITRAN20200101.0001.PDF");
    request.setFormat("PDF");
    request.setFrequency("1");
    request.setVersion("00001");

    String expected = "Global_Report/1234567890/1/PDF/TEST/EDITRAN/version/00001/EDITRAN20200101.0001.EDITRAN";
    String result = channel.resolveFileNamePath(request);

    Assert.assertEquals(expected, result);
  }

  @Test
  public void resolveFileNamePathEmail() {
    RequestChannelFileName request = new RequestChannelFileName();
    request.setOutputChannel("EMAIL");
    request.setAccount("1234567890");
    request.setContract("TEST");
    request.setFileName("EMAIL20200101.0001.PDF");
    request.setFormat("PDF");
    request.setFrequency("1");
    request.setVersion("00001");

    String expected = "Global_Report/1234567890/1/PDF/TEST/EMAIL/version/00001/EMAIL20200101.0001.PDF";
    String result = channel.resolveFileNamePath(request);

    Assert.assertEquals(expected, result);
  }

  @Test
  public void testAppendGetNames() {
    RequestChannelAppend request = new RequestChannelAppend();
    request.setOutputChannel("EMAIL");
    request.setContract("TEST");
    request.setFrequency("1");
    request.setFormat("PDF");
    request.setStp(false);
    request.setGlobalReportVersion("00001");
    request.setZonedDateTime(ZonedDateTime.of(LocalDateTime.of(2020, 1, 1, 0, 0), ZoneId.systemDefault()));

    String expected = "SICSAN.EMAIL.PDF.D200101.H000000.CAPPEND";
    ChannelFileNames names = channel.getNames(request);

    Assert.assertEquals(expected, names.getFileName());
  }

  @Test
  public void testNoAppendGetNames() {
    RequestChannelNoAppend request = new RequestChannelNoAppend();
    request.setOutputChannel("EMAIL");
    request.setContract("TEST");
    request.setFrequency("1");
    request.setFormat("PDF");
    request.setStp(false);
    request.setGlobalReportVersion("00001");
    request.setZonedDateTime(ZonedDateTime.of(LocalDateTime.of(2020, 1, 1, 0, 0), ZoneId.systemDefault()));
    request.setAccount("1234567890");
    request.setAliasAccount("1234567890");
    request.setAccountPageNumber(1);
    request.setVersion("00001");

    String expected = "SICSAN.EMAIL.PDF.D200101.H000000.C567890";
    ChannelFileNames names = channel.getNames(request);

    Assert.assertEquals(expected, names.getFileName());
  }

  @Test
  public void testCompleteGetNames() {
    RequestChannelComplete request = new RequestChannelComplete();
    request.setOutputChannel("EMAIL");
    request.setContract("TEST");
    request.setFrequency("1");
    request.setFormat("PDF");
    request.setStp(false);
    request.setGlobalReportVersion("00001");
    request.setZonedDateTime(ZonedDateTime.of(LocalDateTime.of(2020, 1, 1, 0, 0), ZoneId.systemDefault()));
    request.setAccount("1234567890");
    request.setAliasAccount("1234567890");
    request.setAccountPageNumber(1);
    request.setVersion("00001");

    String expected = "SICSAN.EMAIL.PDF.D200101.H000000.C567890";
    ChannelFileNames names = channel.getNames(request);

    Assert.assertEquals(expected, names.getFileName());
  }

  @Test
  public void testCompleteGetNamesWithEditran() {
    RequestChannelComplete request = new RequestChannelComplete();
    request.setOutputChannel("EDITRAN");
    request.setContract("TEST");
    request.setFrequency("1");
    request.setFormat("PDF");
    request.setStp(false);
    request.setGlobalReportVersion("00001");
    request.setZonedDateTime(ZonedDateTime.of(LocalDateTime.of(2020, 1, 1, 0, 0), ZoneId.systemDefault()));
    request.setAccount("1234567890");
    request.setAliasAccount("1234567890");
    request.setAccountPageNumber(1);
    request.setVersion("00001");

    String expected = "null.JF.EDITRAN.PDF.ED.C567890.D01.H000000";
    ChannelFileNames names = channel.getNames(request);

    Assert.assertEquals(expected, names.getFileName());
  }

  @Test
  public void testCompleteGetNamesWithSwift() {
    RequestChannelComplete request = new RequestChannelComplete();
    request.setOutputChannel("SWIFT");
    request.setContract("TEST");
    request.setFrequency("1");
    request.setFormat("PDF");
    request.setStp(false);
    request.setGlobalReportVersion("00001");
    request.setZonedDateTime(ZonedDateTime.of(LocalDateTime.of(2020, 1, 1, 0, 0), ZoneId.systemDefault()));
    request.setAccount("1234567890");
    request.setAliasAccount("1234567890");
    request.setAccountPageNumber(1);
    request.setVersion("00001");

    String expected = "SICSAN.SWIFT.PDF.D200101.H000000.C567890";
    ChannelFileNames names = channel.getNames(request);

    Assert.assertEquals(expected, names.getFileName());
  }

  @Test
  public void testCompleteGetNamesWithH2H() {
    RequestChannelComplete request = new RequestChannelComplete();
    request.setOutputChannel("H2H");
    request.setContract("TEST");
    request.setFrequency("1");
    request.setFormat("PDF");
    request.setStp(false);
    request.setGlobalReportVersion("00001");
    request.setZonedDateTime(ZonedDateTime.of(LocalDateTime.of(2020, 1, 1, 0, 0), ZoneId.systemDefault()));
    request.setAccount("1234567890");
    request.setAliasAccount("1234567890");
    request.setAccountPageNumber(1);
    request.setVersion("00001");

    String expected = "Global_Report/1234567890/1/PDF/TEST/H2H/version/00001/COMPLETE/";
    ChannelFileNames names = channel.getNames(request);

    Assert.assertEquals(expected, names.getBasePath());
  }
}
