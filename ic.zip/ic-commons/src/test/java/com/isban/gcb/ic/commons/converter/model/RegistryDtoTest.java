package com.isban.gcb.ic.commons.converter.model;

import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.Assert.assertEquals;

public class RegistryDtoTest {
  private RegistryDto registryDto;

  @Before
  public void setUp() {
    registryDto = buildRegistryDto();
  }

  private RegistryDto buildRegistryDto() {
    return new RegistryDto(LocalDate.now(), LocalTime.of(0, 0, 0), 1, 1, 1, 1, BigDecimal.ZERO,
      BigDecimal.ZERO, BigDecimal.ZERO, "N", "Filler");
  }

  @Test
  public void equals_hashCode_toString_OK() {
    RegistryDto expected = buildRegistryDto();

    assertEquals(expected, registryDto);
    assertEquals(expected, expected);
    assertEquals(expected.hashCode(), registryDto.hashCode());
    assertEquals(expected.toString(), registryDto.toString());
  }
}
