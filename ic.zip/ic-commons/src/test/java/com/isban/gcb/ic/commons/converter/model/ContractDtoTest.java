package com.isban.gcb.ic.commons.converter.model;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class ContractDtoTest {
  private ContractDto contractDto;

  @Before
  public void setUp() {
    contractDto = new ContractDto("contractNumber", "sendChannel", "outputFormat", "outputFormatSubtype",
      "outputChannelUuid", "customization", "activationDate",
      "serviceSendFrequency", "aliasEntity", "aliasClientAccount", "aliasClientGroup",
      "uuidStructureAcc", "accountUuid", "accountInternational", false, false, false,
      false, false, "uuidBusinessGroup", true, true, null, new ArrayList<>(), false);
  }

  @Test
  public void clone_OK() {
    ContractDto expected = contractDto.clone();

    assertEquals(expected.getContractNumber(), contractDto.getContractNumber());
  }
  
  @Test
  public void givenContractDtoWithCamt053StandardCodesTrue_whenIsCamt053StandardCodes_thenReturnTrue() {
    ContractDto dto = new ContractDto().camt053StandardCodes(true);
    assertTrue(dto.isCamt053StandardCodes());
  }

  @Test
  public void givenContractDtoWithCamt053StandardCodesFalse_whenIsCamt053StandardCodes_thenReturnTrue() {
    ContractDto dto = new ContractDto().camt053StandardCodes(false);
    assertFalse(dto.isCamt053StandardCodes());
  }

  @Test
  public void givenContractDtoWithCamt053StandardCodes_whenIsCamt053StandardCodes_thenReturnTrue() {
    assertNull(contractDto.isCamt053StandardCodes());
  }
}
