package com.isban.gcb.ic.commons.constants;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CountryCodeTest {

  @Test
  public void toCountry_shouldReturn_Albania() {
    assertEquals("Albania", CountryCode.AL.getCountry());
    assertEquals("AL", CountryCode.AL.getCountryISO2());
    assertEquals("ALB", CountryCode.AL.getCountryISO3());
  }
}
