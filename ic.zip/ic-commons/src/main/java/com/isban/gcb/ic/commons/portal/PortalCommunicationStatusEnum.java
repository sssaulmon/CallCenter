package com.isban.gcb.ic.commons.portal;

public enum PortalCommunicationStatusEnum {
  GENERATING_MOVEMENTS("Generating movements file"),
  GENERATE_MOVEMENTS_KO("Error when generating movements file."),
  GENERATE_MOVEMENTS_OK("Success when generating movements file"),
  GENERATING_BALANCES("Generating balances file"),
  GENERATE_BALANCES_KO("Error when generating balances file."),
  GENERATE_BALANCES_OK("Success when generating balances file"),
  SENDING_FILE("Sending file"),
  SEND_KO("Error when sending file."),
  SEND_OK("Success when sending file");

  String message;

  PortalCommunicationStatusEnum(String message) {
    this.message = message;
  }

  public String getMessage() {
    return message;
  }
}
