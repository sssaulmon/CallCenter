package com.isban.gcb.ic.commons.util;

public class UncheckedException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public UncheckedException(Throwable throwable) {
    super(throwable);
  }
}
