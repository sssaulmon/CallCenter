package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(ServiceType.class)
public abstract class ServiceType_ extends com.isban.gcb.ic.commons.model.AuditableLocalDate_ {

	public static volatile SetAttribute<ServiceType, Service> idServiceTypes;
	public static volatile SingularAttribute<ServiceType, LocalDate> endDate;
	public static volatile SingularAttribute<ServiceType, String> description;
	public static volatile SingularAttribute<ServiceType, Long> id;
	public static volatile SingularAttribute<ServiceType, String> uuid;

	public static final String ID_SERVICE_TYPES = "idServiceTypes";
	public static final String END_DATE = "endDate";
	public static final String DESCRIPTION = "description";
	public static final String ID = "id";
	public static final String UUID = "uuid";

}

