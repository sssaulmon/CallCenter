package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(MovementCrossReference.class)
public abstract class MovementCrossReference_ extends com.isban.gcb.ic.commons.model.AuditableLocalDate_ {

	public static volatile SingularAttribute<MovementCrossReference, String> clientMovementCode;
	public static volatile SingularAttribute<MovementCrossReference, String> localMovementCode;
	public static volatile SingularAttribute<MovementCrossReference, LocalDate> endDate;
	public static volatile SingularAttribute<MovementCrossReference, String> uuidCorporate;
	public static volatile SingularAttribute<MovementCrossReference, String> lastModifiedUser;
	public static volatile SingularAttribute<MovementCrossReference, Subproduct> subproduct;
	public static volatile SingularAttribute<MovementCrossReference, Long> id;
	public static volatile SingularAttribute<MovementCrossReference, String> uuid;

	public static final String CLIENT_MOVEMENT_CODE = "clientMovementCode";
	public static final String LOCAL_MOVEMENT_CODE = "localMovementCode";
	public static final String END_DATE = "endDate";
	public static final String UUID_CORPORATE = "uuidCorporate";
	public static final String LAST_MODIFIED_USER = "lastModifiedUser";
	public static final String SUBPRODUCT = "subproduct";
	public static final String ID = "id";
	public static final String UUID = "uuid";

}

