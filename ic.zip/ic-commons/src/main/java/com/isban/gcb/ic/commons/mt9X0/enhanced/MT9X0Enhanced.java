package com.isban.gcb.ic.commons.mt9X0.enhanced;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.prowidesoftware.swift.model.field.Field61;
import com.prowidesoftware.swift.model.field.Field62M;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static com.isban.gcb.ic.commons.util.function.FunctionalUtils.not;
import static java.lang.Integer.parseInt;
import static java.lang.Math.abs;
import static org.apache.commons.lang.StringUtils.rightPad;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
  "metaKey",
  "kafkaMetadata",
  "messageType2",
  "entitySender",
  "generalInfo",
  "closingBalanceM",
  "m",
  "type"
})
@Slf4j
public class MT9X0Enhanced implements Serializable {

  private static final int SWIFT_MAX_LENGTH = 1800;
  private static final String FIRST_PAGE_SEQUENCE = "/00001";
  private static final String STATEMENT_NUMBER_SEQUENCE_NUMBER = "28C";
  private static final String INITIAL_BALANCE_TAG_NAME = "60F";
  private static final String INTERMEDIATE_INITIAL_BALANCE_TAG_NAME = "60M";
  private static final String INTERMEDIATE_FINAL_BALANCE_TAG_NAME = "62M";
  private static final String FINAL_BALANCE_TAG_NAME = "62F";
  private static final String TRANSACTION_TAG_NAME = "61";
  private static final String TRANSACTION_TAG_DESCRIPTION = "86";
  private static final String MUR_TAG_NAME = "108";
  private static final String CREDIT_MARK = "C";
  private static final String DEBIT_MARK = "D";

  private static final long serialVersionUID = -3021377607176269686L;

  @JsonProperty("metaKey")
  private String metaKey;

  @JsonProperty("kafkaMetadata")
  private KafkaMetadata kafkaMetadata;

  @JsonProperty("messageType2")
  private MessageType2 messageType2;

  @JsonProperty("entitySender")
  private EntitySender entitySender;

  @JsonProperty("generalInfo")
  private GeneralInfo generalInfo;

  @JsonProperty("closingBalanceM")
  private ClosingBalanceM closingBalanceM;

  @JsonProperty("m")
  private Message m;

  @JsonProperty("type")
  private String type;

  @JsonIgnore
  private Map<String, Object> additionalProperties = new HashMap<>();

  @JsonIgnore
  @Getter
  @Setter
  private String pageMetaKey;

  /**
   * No args constructor for use in serialization
   */
  public MT9X0Enhanced() {
    /*Empty Constructor*/
  }

  /**
   * @param metaKey
   * @param closingBalanceM
   * @param generalInfo
   * @param m
   * @param type
   * @param messageType2
   * @param entitySender
   * @param kafkaMetadata
   */
  public MT9X0Enhanced(String metaKey, KafkaMetadata kafkaMetadata, MessageType2 messageType2,
                       EntitySender entitySender, GeneralInfo generalInfo, ClosingBalanceM closingBalanceM,
                       Message m, String type) {
    super();
    this.metaKey = metaKey;
    this.kafkaMetadata = kafkaMetadata;
    this.messageType2 = messageType2;
    this.entitySender = entitySender;
    this.generalInfo = generalInfo;
    this.closingBalanceM = closingBalanceM;
    this.m = m;
    this.type = type;
  }

  @JsonProperty("metaKey")
  public String getMetaKey() {
    return metaKey;
  }

  @JsonProperty("metaKey")
  public void setMetaKey(String metaKey) {
    this.metaKey = metaKey;
  }

  @JsonProperty("kafkaMetadata")
  public KafkaMetadata getKafkaMetadata() {
    return kafkaMetadata;
  }

  @JsonProperty("kafkaMetadata")
  public void setKafkaMetadata(KafkaMetadata kafkaMetadata) {
    this.kafkaMetadata = kafkaMetadata;
  }

  @JsonProperty("messageType2")
  public MessageType2 getMessageType2() {
    return messageType2;
  }

  @JsonProperty("messageType2")
  public void setMessageType2(MessageType2 messageType2) {
    this.messageType2 = messageType2;
  }

  @JsonProperty("entitySender")
  public EntitySender getEntitySender() {
    return entitySender;
  }

  @JsonProperty("entitySender")
  public void setEntitySender(EntitySender entitySender) {
    this.entitySender = entitySender;
  }

  @JsonProperty("generalInfo")
  public GeneralInfo getGeneralInfo() {
    return generalInfo;
  }

  @JsonProperty("generalInfo")
  public void setGeneralInfo(GeneralInfo generalInfo) {
    this.generalInfo = generalInfo;
  }

  @JsonProperty("closingBalanceM")
  public ClosingBalanceM getClosingBalanceM() {
    return closingBalanceM;
  }

  @JsonProperty("closingBalanceM")
  public void setClosingBalanceM(ClosingBalanceM closingBalanceM) {
    this.closingBalanceM = closingBalanceM;
  }

  @JsonProperty("m")
  public Message getM() {
    return m;
  }

  @JsonProperty("m")
  public void setM(Message m) {
    this.m = m;
  }

  @JsonProperty("type")
  public String getType() {
    return type;
  }

  @JsonProperty("type")
  public void setType(String type) {
    this.type = type;
  }

  @JsonAnyGetter
  public Map<String, Object> getAdditionalProperties() {
    return this.additionalProperties;
  }

  @JsonAnySetter
  public void setAdditionalProperty(String name, Object value) {
    this.additionalProperties.put(name, value);
  }

  public String toSwiftMessage() {
    return this.getM().toSwiftMessage();
  }

  public int swiftLength() {
    return this.toSwiftMessage().length();
  }

  public String toSwiftFinMessage() {
    return this.getM().toSwiftFinMessage();
  }

  public String getTagValueByName(String tagName) {
    return getM().getBlock4().findByName(tagName).getValue();
  }

  public int getTagPositionByName(String tagName) {
    return getM().getBlock4().findTagPosition(tagName);
  }

  public void removeTagByName(String tagName) {
    getM().getBlock4().removeTagByPosition(getTagPositionByName(tagName));
  }

  public void modifyTagValueByName(String tagName, String newValue) {
    getM().getBlock4().modifyByName(tagName, newValue);
  }

  public List<Tag> extractClosingTags() {
    return getM().getBlock4().extractClosingTags();
  }

  public void removeOptionalTagsFromIntermediatePage() {
    getM().getBlock4().removeOptionalTagsFromIntermediatePage();
  }

  private void addNewTagByPosition(Tag tag, int position) {
    getM().getBlock4().addNewTagByPosition(tag, position);
  }

  @JsonIgnore
  public boolean isSwiftTooLong() {

    final int first61Index = findTag61Index();

    List<Tag> block4Tags = this.getM().getBlock4().getTags();

    List<Tag> headerTags = Optional.of(block4Tags)
      .filter(tags -> first61Index > -1)
      .map(tags -> tags.subList(0, first61Index))
      .orElse(block4Tags.subList(0, block4Tags.size()));

    List<Tag> interTags = Optional.of(this.getM().getBlock4().getTags())
      .filter(tags -> first61Index > 0 && first61Index < tags.size())
      .map(tags -> new ArrayList<Tag>(tags.subList(first61Index, tags.size())))
      .orElseGet(ArrayList::new);

    this.getM().getBlock4().setTags(headerTags);

    int swiftLength = this.getM().toSwiftMessage().length();

    int breakIndex = findExceededSwiftLengthIndex(interTags, 0, true, swiftLength);

    headerTags.addAll(interTags);
    this.getM().getBlock4().setTags(headerTags);

    return breakIndex < interTags.size();
  }

  @JsonIgnore
  public boolean isSwiftTooLongWithoutClosingBalance() {
    return swiftLength() > SWIFT_MAX_LENGTH;
  }

  @JsonIgnore
  public String getPageClosingBalance() {
    if (isLastPage()) {
      return getFinalBalance();
    }
    return getIntermediateFinalBalance();
  }

  public void addNewTransactionsOnTop(List<Tag> transactions, String newStartBalance) {
    modifyTagValueByName(INTERMEDIATE_INITIAL_BALANCE_TAG_NAME, newStartBalance);
    int tagIndex = getTagPositionByName(INTERMEDIATE_INITIAL_BALANCE_TAG_NAME) + 1;
    for (Tag transaction : transactions) {
      addNewTagByPosition(transaction, tagIndex++);
    }
  }

  public void setMur(int sequence) {
    Tag block3 = new Tag(MUR_TAG_NAME, "ICSW" + (String.format("%012d", sequence)).replace(' ', '0'));
    getM().setBlock3(new Block3(Collections.singletonList(block3)));
  }

  public void setNewPageHeaderWithClosingBalance(ClosingBalanceM closingBalanceM) {
    increaseMetaKey();
    increasePageNumber();
    setClosingBalanceM(closingBalanceM);
  }

  private void increaseMetaKey() {
    String metaKey = getMetaKey();
    final int separator_index = metaKey.lastIndexOf("_") + 1;
    int nextMetaKeyVersion = parseInt(metaKey.substring(separator_index)) + 1;
    setMetaKey(metaKey.substring(0, separator_index) + (String.format("%08d", nextMetaKeyVersion)).replace(' ', '0'));
  }

  private void increasePageNumber() {
    getGeneralInfo().setPageNum(getGeneralInfo().getPageNum() + 1);
  }

  public void setBlock4ForNewPage(List<Tag> closingTags, List<Tag> transactionList, String intermediateBalance) {
    removeInitialBalance();
    getM().getBlock4().addToBlock(closingTags, transactionList, intermediateBalance);
  }

  private void removeInitialBalance() {
    String firstTagToRemove = isFirstPage() ? INITIAL_BALANCE_TAG_NAME : INTERMEDIATE_INITIAL_BALANCE_TAG_NAME;
    getM().getBlock4().removeTagsFromIndex(getTagPositionByName(firstTagToRemove));
  }

  public List<Tag> fixPageLength(String originalFinalBalance) {

    List<Tag> transactionList = removeExceedingTransactions();

    String newIntermediateBalance = calculateNewFinalBalance(originalFinalBalance, transactionList);

    getM().getBlock4().addNewTag(new Tag(INTERMEDIATE_FINAL_BALANCE_TAG_NAME, newIntermediateBalance));

    return transactionList;
  }

  private List<Tag> removeExceedingTransactions() {

    final int first61Index = findTag61Index();

    List<Tag> block4Tags = this.getM().getBlock4().getTags();

    List<Tag> headerTags = Optional.of(block4Tags)
      .filter(tags -> first61Index > -1)
      .map(tags -> tags.subList(0, first61Index))
      .orElse(block4Tags.subList(0, block4Tags.size()));

    List<Tag> interTags = Optional.of(this.getM().getBlock4().getTags())
      .filter(tags -> first61Index > 0 && first61Index < tags.size())
      .map(tags -> new ArrayList<Tag>(tags.subList(first61Index, tags.size())))
      .orElseGet(ArrayList::new);

    this.getM().getBlock4().setTags(headerTags);

    int swiftLength = this.getM().toSwiftMessage().length();

    int breakIndex = Optional.of(interTags)
      .filter(tags -> first61Index >= 0)
      .map(tags -> findExceededSwiftLengthIndex(tags, 0, false, swiftLength))
      .orElse(0);

    headerTags.addAll(interTags.subList(0, breakIndex));

    return interTags.subList(breakIndex, interTags.size());
  }

  private int findExceededSwiftLengthIndex(List<Tag> tags, int tagIndex, boolean with62M, int swiftLength) {
    final int tag62MLength = with62M ? 0 : 30;

    return Optional.of(tags)
      .filter(list -> tagIndex < list.size())
      .map(list -> list.get(tagIndex))
      .map(tag -> new String(":" + tag.getName() + ":" + tag.getValue() + "\r\n").length())
      .filter(tagLength -> SWIFT_MAX_LENGTH > swiftLength + tagLength + tag62MLength)
      .map(tagLength -> findExceededSwiftLengthIndex(tags, tagIndex + 1, with62M, swiftLength + tagLength))
      .orElse(Optional.of(tagIndex)
        .filter(index -> index < tags.size())
        .map(tags::get)
        .map(Tag::getName)
        .filter("86"::equals)
        .map(tagName -> tagIndex - 1)
        .orElse(tagIndex)
      );
  }

  private int findTag61Index() {
    List<Tag> tags = this.getM().getBlock4().getTags();
    return IntStream.range(0, tags.size())
      .boxed()
      .filter(index -> "61".equals(tags.get(index).getName()))
      .findFirst()
      .orElse(-1);
  }

  private String calculateNewFinalBalance(String originalFinalBalance, List<Tag> transactionList) {

    List<Tag> tags = this.getM().getBlock4().getTags();

    String openBalance = tags.stream()
      .filter(tag -> "60F".equals(tag.getName()) || "60M".equals(tag.getName()))
      .findFirst()
      .map(Tag::getValue)
      .orElseThrow(() -> new RuntimeException("Tag 60F or 60M not found in MT9X0"));

    return Optional.of(tags)
      .filter(not(List::isEmpty))
      .map(this::getTransactionSum)
      .map(pageAmount -> this.toDouble(openBalance) + pageAmount)
      .map(value -> this.doubleTo62MValue(value, originalFinalBalance))
      .orElse(openBalance);
  }

  private String doubleTo62MValue(double value, String value60M) {
    Field62M result = new Field62M(value60M);

    result.setDCMark(getDCMarkFromIntermediateValue(value));

    String amount = Optional.of(value60M)
      .map(val -> val.split(","))
      .filter(elems -> elems.length > 1)
      .map(elems -> this.doubleToAbsString(value, elems[1].length()))
      .orElse(this.doubleToAbsString(value, 0));

    result.setAmount(amount);

    return result.getValue();
  }

  private String doubleToAbsString(Double value, int numDecimals) {

    DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols();
    decimalFormatSymbols.setDecimalSeparator(',');

    return Optional.of(numDecimals)
      .filter(decimals -> decimals >= 0)
      .map(decimals -> "0." + rightPad("", numDecimals, '0'))
      .map(pattern -> new DecimalFormat(pattern, decimalFormatSymbols))
      .map(formatter -> formatter.format(abs(value)))
      .orElse(String.valueOf(abs(value)));
  }

  private double toDouble(String balance) {
    Field62M field62M = new Field62M(balance);

    return Optional.of(field62M)
      .filter(field -> DEBIT_MARK.equals(field.getDCMark()))
      .map(field -> field.getAmountAsNumber().doubleValue() * -1)
      .orElse(field62M.getAmountAsNumber().doubleValue());
  }

  private double getTransactionSum(List<Tag> transactionList) {

    return transactionList.stream()
      .parallel()
      .filter(t -> TRANSACTION_TAG_NAME.equals(t.getName()))
      .map(Tag::getValue)
      .map(Field61::new)
      .mapToDouble(field61 -> Optional.of(field61)
        .filter(f -> !CREDIT_MARK.equals(f.getDCMark()))
        .map(f -> f.getAmountAsNumber().doubleValue() * -1)
        .orElse(field61.getAmountAsNumber().doubleValue())
      )
      .sum();
  }

  public ClosingBalanceM extractAndRebaseClosingBalanceM() {
    ClosingBalanceM oldClosingBalance = getClosingBalanceM().clone();

    final ClosingBalanceM newClosingBalance = new ClosingBalanceM();
    newClosingBalance.setCurrency(oldClosingBalance.getCurrency());
    setClosingBalanceM(newClosingBalance);
    return oldClosingBalance;
  }

  private String getDCMarkFromIntermediateValue(Double intermediateValue) {
    return intermediateValue >= 0 ? CREDIT_MARK : DEBIT_MARK;
  }

  public void setPageNumberOnBlock4IfMissing() {
    final String pageInfo = getTagValueByName(STATEMENT_NUMBER_SEQUENCE_NUMBER);
    if (pageInfo.split("/").length == 1)
      modifyTagValueByName(STATEMENT_NUMBER_SEQUENCE_NUMBER, pageInfo + FIRST_PAGE_SEQUENCE);
  }

  public void setPaddingToStatementNumberAndPageNumber(Integer padding) {
    setPageNumberOnBlock4IfMissing();
    final String pageInfo = getTagValueByName(STATEMENT_NUMBER_SEQUENCE_NUMBER);
    String statementNumber = String.format("%1$" + padding + "s", pageInfo.split("/")[0]).replace(' ', '0');
    String pageNumber = String.format("%1$" + padding + "s", pageInfo.split("/")[1]).replace(' ', '0');
    getM().getBlock4().findByName(STATEMENT_NUMBER_SEQUENCE_NUMBER).setValue(statementNumber + "/" + pageNumber);
  }

  public List<Field61> concatTransactionsByMark(List<Field61> transactions, String markCD) {
    return Stream.concat(
      transactions.stream(), getTransactionWithMarker(markCD).stream())
      .collect(Collectors.toList());
  }

  public void createTag86Final(String tag86Value) {
    getM().getBlock4().addNewTag(new Tag(TRANSACTION_TAG_DESCRIPTION, tag86Value));
  }

  private List<Field61> getTransactionWithMarker(String markCD) {
    return getM().getBlock4().getTransactionsFromMarker(markCD);
  }

  @JsonIgnore
  private String getFinalBalance() {
    return getTagValueByName(FINAL_BALANCE_TAG_NAME);
  }

  @JsonIgnore
  public String getIntermediateFinalBalance() {
    return getTagValueByName(INTERMEDIATE_FINAL_BALANCE_TAG_NAME);
  }

  public void removeIntermediateFinalBalance() {
    removeTagByName(INTERMEDIATE_FINAL_BALANCE_TAG_NAME);
  }

  @JsonIgnore
  public boolean isFirstPage() {
    return getTagPositionByName(INITIAL_BALANCE_TAG_NAME) != -1;
  }

  @JsonIgnore
  public boolean isLastPage() {
    return getTagPositionByName(FINAL_BALANCE_TAG_NAME) != -1;
  }

  @JsonIgnore
  public boolean hasMovements() {
    return getTagPositionByName("61") != -1;
  }

  @JsonIgnore
  public boolean hasFinalTag86() {
    List<Tag> tagsBlock4 = this.getM().getBlock4().getTags();
    return !tagsBlock4.isEmpty() && "86".equals(tagsBlock4.get(tagsBlock4.size() - 1).getName());
  }
}
