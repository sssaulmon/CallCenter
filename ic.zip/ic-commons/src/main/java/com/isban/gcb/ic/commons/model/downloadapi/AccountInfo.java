package com.isban.gcb.ic.commons.model.downloadapi;


public class AccountInfo {
  private String bic;
  private String currency;
  private String localAccount;
  private String internationalAccount;
  private String aliasAccount;
  private String corporate;
  private String enterpriseGroup;

  public AccountInfo() {
  }

  public String getBic() {
    return bic;
  }

  public void setBic(String bic) {
    this.bic = bic;
  }

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public String getLocalAccount() {
    return localAccount;
  }

  public void setLocalAccount(String localAccount) {
    this.localAccount = localAccount;
  }

  public String getInternationalAccount() {
    return internationalAccount;
  }

  public void setInternationalAccount(String internationalAccount) {
    this.internationalAccount = internationalAccount;
  }

  public String getAliasAccount() {
    return aliasAccount;
  }

  public void setAliasAccount(String aliasAccount) {
    this.aliasAccount = aliasAccount;
  }

  public String getCorporate() {
    return corporate;
  }

  public void setCorporate(String corporate) {
    this.corporate = corporate;
  }

  public String getEnterpriseGroup() {
    return enterpriseGroup;
  }

  public void setEnterpriseGroup(String enterpriseGroup) {
    this.enterpriseGroup = enterpriseGroup;
  }

  @Override
  public String toString() {
    return "AccountInfo{" +
      "bic='" + bic + '\'' +
      ", currency='" + currency + '\'' +
      ", localAccount='" + localAccount + '\'' +
      ", internationalAccount='" + internationalAccount + '\'' +
      ", aliasAccount='" + aliasAccount + '\'' +
      ", corporate='" + corporate + '\'' +
      ", enterpriseGroup='" + enterpriseGroup + '\'' +
      '}';
  }
}
