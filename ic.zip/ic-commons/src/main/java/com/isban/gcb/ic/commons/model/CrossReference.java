package com.isban.gcb.ic.commons.model;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * A CrossReference.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "cross_ref", indexes = {@Index(columnList = "uuid", name = "uuid_cross_ref")})
public class CrossReference extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cross_ref_gen")
    @SequenceGenerator(name = "cross_ref_gen", sequenceName = "cross_ref_generator", allocationSize = 1)
    private Long id;

    @NotNull
    @Size(max = 40)
    @Column(name = "uuid", length = 40, nullable = false)
    private String uuid;

    @Size(max = 4)
    @Column(name = "local_movement_code", length = 3)
    private String localMovementCode;

    @Size(max = 3)
    @Column(name = "swift_code", length = 4)
    private String swiftCode;

    @Column(name = "end_date")
    private LocalDateTime endDate;

    @Size(max = 20)
    @Column(name = "last_modified_user", length = 20)
    private String lastModifiedUser;

    @ManyToOne
    @JoinColumn(name = "SUBPRODUCT_ID", referencedColumnName = "ID")
    private Subproduct subproduct;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public CrossReference uuid(String uuid) {
        this.uuid = uuid;
        return this;
    }

    public String getLocalMovementCode() {
        return localMovementCode;
    }

    public void setLocalMovementCode(String localMovementCode) {
        this.localMovementCode = localMovementCode;
    }

    public CrossReference localMovementCode(String localMovementCode) {
        this.localMovementCode = localMovementCode;
        return this;
    }

    public String getSwiftCode() {
        return swiftCode;
    }

    public void setSwiftCode(String swiftCode) {
        this.swiftCode = swiftCode;
    }

    public CrossReference swiftCode(String swiftCode) {
        this.swiftCode = swiftCode;
        return this;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public CrossReference endDate(LocalDateTime endDate) {
        this.endDate = endDate;
        return this;
    }

    private String getLastModifiedUser() {
        return lastModifiedUser;
    }

    public void setLastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
    }

    public CrossReference lastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
        return this;
    }

    public Subproduct getSubproduct() {
        return subproduct;
    }

    public void setSubproduct(Subproduct subproduct) {
        this.subproduct = subproduct;
    }

    public CrossReference subproduct(Subproduct subproduct) {
        this.subproduct = subproduct;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CrossReference crossReference = (CrossReference) o;
        if (crossReference.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), crossReference.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "CrossReference{" +
                "id=" + getId() +
                ", uuid='" + getUuid() + "'" +
                ", localMovementCode='" + getLocalMovementCode() + "'" +
                ", swiftCode='" + getSwiftCode() + "'" +
                ", createDate='" + getCreateDate() + "'" +
                ", endDate='" + getEndDate() + "'" +
                ", lastModifiedDate='" + getLastModifiedDate() + "'" +
                ", lastModifiedUser='" + getLastModifiedUser() + "'" +
                "}";
    }
}
