package com.isban.gcb.ic.commons.mt9X0;

import com.prowidesoftware.swift.model.SwiftMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MT9X0 extends com.prowidesoftware.swift.model.mt.mt9xx.MT940 implements Serializable {

  private static final Logger log = LoggerFactory.getLogger(MT9X0.class);

    private static final String FORMAT_DATE = "yyMMdd";

    private String metaKey;
    private KafkaMetadata kafkaMetadata; //Metadatos de Kafka
    private MessageType messageType2; //Formato del Mensaje
    private EntitySender entitySender; //Entidad BIC Emisora
    private ExtractGeneralInfo generalInfo; // Infomacion general del Extracto
    private OpeningBalanceMandatory openingBalanceM; // Informacion Obligatoria del Opening Balance 
    private Map<String, Movement> movements; // Movimientos realizados
    private ClosingBalanceMandatory closingBalanceM; // Informacion Obligatoria del Closing Balance
    private ClosingBalanceOptional closingBalanceO; // Informacion Opcional del Closing Balance
    private Map<String, ForwardAvBalance> forwardBalances; // Saldos Intermedios
    private ExtractGeneralInfoOptional generalInfoOptional; // Infomracion Opcional del Extracto 

    /**
     * Constructor with all parameters
     *
     * @param kafkaMetadata       Metadata from Kafka
     * @param messageType         Mesage Format
     * @param entitySender        Entity sender
     * @param generalInfo         General Info of the Extract
     * @param openingBalanceM     Mandatory Opening Balance Info
     * @param movements           All the movements contained int the extract MT9X0
     * @param closingBalanceM     Mandatory Closing Balance Info
     * @param openingBalanceO     Optional Closing Balance Info
     * @param forwardBalances     Forward Balances
     * @param generalInfoOptional Optional Info of the Extract
     * @author Eduardo Rodriguez
     */
    public MT9X0(KafkaMetadata kafkaMetadata, MessageType messageType, EntitySender entitySender, ExtractGeneralInfo generalInfo, OpeningBalanceMandatory openingBalanceM, Map<String, Movement> movements, ClosingBalanceMandatory closingBalanceM, ClosingBalanceOptional openingBalanceO, Map<String, ForwardAvBalance> forwardBalances, ExtractGeneralInfoOptional generalInfoOptional) {
        this.kafkaMetadata = kafkaMetadata;
        this.messageType2 = messageType;
        this.entitySender = entitySender;
        this.generalInfo = generalInfo;
        this.openingBalanceM = openingBalanceM;
        this.movements = movements;
        this.closingBalanceM = closingBalanceM;
        this.closingBalanceO = openingBalanceO;
        this.forwardBalances = forwardBalances;
        this.generalInfoOptional = generalInfoOptional;
    }

    /**
     * Constructor empty
     *
     * @author Eduardo Rodriguez
     */
    public MT9X0() {
        this.kafkaMetadata = null;
        this.messageType2 = null;
        this.entitySender = null;
        this.generalInfo = null;
        this.openingBalanceM = null;
        this.movements = null;
        this.closingBalanceM = null;
        this.closingBalanceO = null;
        this.forwardBalances = null;
        this.generalInfoOptional = null;
    }

    /**
     * Constructor empty
     *
     * @param message MT9X0 message
     * @author Eduardo Rodriguez
     */
    public MT9X0(String message) {
        super(message);
        this.parseStringMessage();
    }

  public MT9X0(String metaKey, KafkaMetadata kafkaMetadata, MessageType messageType, EntitySender entitySender, ExtractGeneralInfo generalInfo, OpeningBalanceMandatory openingBalanceM, ClosingBalanceMandatory closingBalanceM, ClosingBalanceOptional openingBalanceO, ExtractGeneralInfoOptional generalInfoOptional, SwiftMessage oldMT9X0) {
    super(oldMT9X0);
        this.metaKey = metaKey;
        this.kafkaMetadata = kafkaMetadata;
        this.messageType2 = messageType;
        this.entitySender = entitySender;
        this.generalInfo = generalInfo;
        this.openingBalanceM = openingBalanceM;
        this.closingBalanceM = closingBalanceM;
        this.closingBalanceO = openingBalanceO;
        this.generalInfoOptional = generalInfoOptional;
    }

    /**
     * Parses a message that contains all the info of a MT9X0 document
     * and ONLY EXTRACTS BASIC INFO
     *
     * @author Eduardo Rodriguez
     */
    private void parseStringMessage() {

        MessageType obtainedMT = new MessageType();
        EntitySender obtainedES = new EntitySender();
        ExtractGeneralInfo obtainedEGI = new ExtractGeneralInfo();
        ClosingBalanceMandatory obtainedCBM = new ClosingBalanceMandatory();

      //Extraemos los datos de la clase MT9X0 para meterlos en la nuestra
        obtainedMT.obtainMessageTypeBasic(this);
        obtainedES.obtainEntitySenderBasic(this);
        obtainedEGI.obtainExtractGeneralInfoBasic(this);
        obtainedCBM.obtainClosingBalanceMandatoryBasic(this);
      this.setMessageType(new MessageType(getSwiftType()));
        this.setEntitySender(obtainedES);
        this.setGeneralInfo(obtainedEGI);
        this.setClosingBalanceM(obtainedCBM);

        this.setMetaKey(this.obtainMetaKeyByType("Swift"));
    }

    /**
     * Pass to null some MT9X0 attributes
     *
     * @author Eduardo Rodriguez
     */
    public void parseStringMessageReduced() {
        /*Completar a futuro*/
    }

    /*
    * Setter metakey
    */
    public void setMetaKey(String metaKey) {
        this.metaKey = metaKey;
    }

    /*
    * Getter metakey
    */
    public String getMetaKey() {
        return metaKey;
    }

    public void setMetakeyVersion(Long version) {

        SimpleDateFormat sdf = new SimpleDateFormat(FORMAT_DATE); //To give format to Date
        DateFormat formatter;
        formatter = new SimpleDateFormat(FORMAT_DATE);
        Date fechaContable = null;

        if (this.getClosingBalanceM().getDate() == null) {
            try {
                fechaContable = formatter.parse(this.getField62M().getDate());
            } catch (ParseException e) {
                log.error("ERROR: --> setMetakeyVersion(), ERROR: {}, MESSAGE: {}", e, e.getMessage());
            }
        } else {
            fechaContable = this.getClosingBalanceM().getDate();
        }

      setMetaKey((getSwiftType() +               //Message Type: 9X0
                "Swift" +                                              //Format: Swift
                this.getEntitySender().getBic() +                      //Bic
                this.getGeneralInfo().getAccountId().replace('/', '_') +                 //AccountId
                this.getClosingBalanceM().getCurrency() +              //Currency
                sdf.format(fechaContable) +                            // Date (yyMMdd)
                this.getGeneralInfo().getStatementNum().toString() +
                "/" + String.format("%08d", version) +
                "_PAGE_" + String.format("%08d", this.generalInfo.getPageNum())         //_PageNum
        ).replace("\n", "").replace("\r", ""));

    }

    /*
     * Obtain metakey depending of type
     */
    public String obtainMetaKeyByType(String type) {

        SimpleDateFormat sdf = new SimpleDateFormat(FORMAT_DATE); //To give format to Date
        DateFormat formatter;
        formatter = new SimpleDateFormat(FORMAT_DATE);
        Date fechaContable = null;

        if (this.getClosingBalanceM().getDate() == null) {
            try {
                fechaContable = formatter.parse(this.getField62M().getDate());
            } catch (ParseException e) {
                log.error("ERROR: --> setMetakeyVersion(), ERROR: {}, MESSAGE: {}", e, e.getMessage());
            }
        } else {
            fechaContable = this.getClosingBalanceM().getDate();
        }

      return (getSwiftType() +                   //Message Type: 9X0
                type +                                                 //Format: Swift
                this.getEntitySender().getBic() +                      //Bic
                this.getGeneralInfo().getAccountId().replace('/', '_') +                 //AccountId
                this.getClosingBalanceM().getCurrency() +              //Currency
                sdf.format(fechaContable) +                            // Date (yyMMdd)
                this.getGeneralInfo().getStatementNum().toString() +
                "_PAGE_" + String.format("%08d", this.generalInfo.getPageNum())         //_PageNum
        ).replace("\n", "").replace("\r", "");
    }

    /*
    * Getters
    */

    public KafkaMetadata getKafkaMetadata() {
        return kafkaMetadata;
    }
    public MessageType getMessageType2() {
        return messageType2;
    }

    public EntitySender getEntitySender() {
        return entitySender;
    }

    public ExtractGeneralInfo getGeneralInfo() {
        return generalInfo;
    }

    public OpeningBalanceMandatory getOpeningBalanceM() {
        return openingBalanceM;
    }

    public Map<String, Movement> getMovements() {
        return movements;
    }

    public ClosingBalanceMandatory getClosingBalanceM() {
        return closingBalanceM;
    }

    public ClosingBalanceOptional getClosingBalanceO() {
        return closingBalanceO;
    }

    public Map<String, ForwardAvBalance> getForwardBalances() {
        return forwardBalances;
    }

    public ExtractGeneralInfoOptional getGeneralInfoOptional() {
        return generalInfoOptional;
    }


  /*
    * Setters
    */
    public void setKafkaMetadata(KafkaMetadata kafkaMetadata) {
        this.kafkaMetadata = kafkaMetadata;
    }

    public void setMessageType(MessageType messageType) {
        this.messageType2 = messageType;
    }

    public void setEntitySender(EntitySender entitySender) {
        this.entitySender = entitySender;
    }

    public void setGeneralInfo(ExtractGeneralInfo generalInfo) {
        this.generalInfo = generalInfo;
    }

    public void setOpeningBalanceM(OpeningBalanceMandatory openingBalanceM) {
        this.openingBalanceM = openingBalanceM;
    }

    public void setMovements(Map<String, Movement> movements) {
        this.movements = movements;
    }

    public void setClosingBalanceM(ClosingBalanceMandatory closingBalanceM) {
        this.closingBalanceM = closingBalanceM;
    }

    public void setClosingBalanceO(ClosingBalanceOptional closingBalanceO) {
        this.closingBalanceO = closingBalanceO;
    }

    public void setForwardBalances(Map<String, ForwardAvBalance> forwardBalances) {
        this.forwardBalances = forwardBalances;
    }

    public void setGeneralInfoOptional(ExtractGeneralInfoOptional generalInfoOptional) {
        this.generalInfoOptional = generalInfoOptional;
    }

    /**
     * Splits in pages a complete MT9X0 message (with 1 or more pages)
     *
     * @param message The message we are going to split
     * @return A list with al the pages contained in the MT9X0 message
     * */
    public static List<String> splitPages(String message){

      ArrayList<String> mt9X0pages = new ArrayList<>();

        //Super Regex para buscar 1 página
        String regex = "(\\{1\\:[\\w\\s]*\\}\\{2\\:[\\w\\s]*\\}(\\{3\\:(\\{[\\:\\w\\s]*\\})*\\})?\\{4\\:[\\w\\s\\/\\:\\,\\+\\-\\'\\?\\(\\.\\)]*-\\}(\\{5\\:(\\{[\\:\\w\\s]*\\})*\\})?)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(message);

        while(matcher.find())
          mt9X0pages.add(matcher.group(0));

      return mt9X0pages;
    }

  private String getSwiftType() {
    return "MT".concat(this.getSwiftMessage().getBlock2().getMessageType());
    }
}
