package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(ClosingAvailableBalance.class)
public abstract class ClosingAvailableBalance_ extends com.isban.gcb.ic.commons.model.AuditableLocalDateTime_ {

	public static volatile SingularAttribute<ClosingAvailableBalance, LocalDate> date;
	public static volatile SingularAttribute<ClosingAvailableBalance, Double> amount;
	public static volatile SingularAttribute<ClosingAvailableBalance, Extract> extract;
	public static volatile SingularAttribute<ClosingAvailableBalance, Long> id;
	public static volatile SingularAttribute<ClosingAvailableBalance, Character> mark;

	public static final String DATE = "date";
	public static final String AMOUNT = "amount";
	public static final String EXTRACT = "extract";
	public static final String ID = "id";
	public static final String MARK = "mark";

}

