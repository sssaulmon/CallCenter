package com.isban.gcb.ic.commons.model.internetapi;

import com.isban.gcb.ic.commons.model.downloadapi.DownloadZipInfoDto;
import com.isban.gcb.ic.commons.model.downloadapi.GlobalReportInfo;

import java.util.List;

public class GlobalReportsAndZip {
  private List<GlobalReportInfo> reports;
  private DownloadZipInfoDto zip;

  public GlobalReportsAndZip reports(List<GlobalReportInfo> reports) {
    this.setReports(reports);
    return this;
  }

  public GlobalReportsAndZip zip(DownloadZipInfoDto zip) {
    this.setZip(zip);
    return this;
  }

  public List<GlobalReportInfo> getReports() {
    return reports;
  }

  public void setReports(List<GlobalReportInfo> reports) {
    this.reports = reports;
  }

  public DownloadZipInfoDto getZip() {
    return zip;
  }

  public void setZip(DownloadZipInfoDto zip) {
    this.zip = zip;
  }
}