package com.isban.gcb.ic.commons.model.report.record;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.isban.gcb.ic.commons.model.report.global.GlobalMetadata;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "globalMetadata",
        "metadata",
        "metadataSend",
        "text"
})
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Record implements Serializable {

    @JsonProperty("globalMetadata")
    private GlobalMetadata globalMetadata;

    @JsonProperty("metadata")
    private Metadata metadata;

    @JsonProperty("metadataSend")
    private MetadataSend metadataSend;

    @JsonProperty("text")
    private String text;

    @JsonProperty("data")
    private byte[] data;

    @JsonProperty("fileExtension")
    private String fileExtension;
}