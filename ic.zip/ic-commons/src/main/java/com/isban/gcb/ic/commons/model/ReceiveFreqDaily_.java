package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(ReceiveFreqDaily.class)
public abstract class ReceiveFreqDaily_ extends com.isban.gcb.ic.commons.model.AuditableLocalDate_ {

	public static volatile SingularAttribute<ReceiveFreqDaily, String> receiveDays;
	public static volatile SingularAttribute<ReceiveFreqDaily, Boolean> plannable;
	public static volatile SingularAttribute<ReceiveFreqDaily, Boolean> accumulatedInformation;
	public static volatile SingularAttribute<ReceiveFreqDaily, ReceiveFreqType> receiveFreqType;
	public static volatile SingularAttribute<ReceiveFreqDaily, LocalDate> endDate;
	public static volatile SingularAttribute<ReceiveFreqDaily, Boolean> nextDayAfterWeekend;
	public static volatile SingularAttribute<ReceiveFreqDaily, Boolean> reciveFestive;
	public static volatile SingularAttribute<ReceiveFreqDaily, Boolean> nextBusinessDay;
	public static volatile SingularAttribute<ReceiveFreqDaily, String> threshold;
	public static volatile SingularAttribute<ReceiveFreqDaily, ReceiveFreqSendDate> receiveFreqSendDate;
	public static volatile SingularAttribute<ReceiveFreqDaily, String> uuid;
	public static volatile SetAttribute<ReceiveFreqDaily, Subproduct> subproducts;
	public static volatile SingularAttribute<ReceiveFreqDaily, Boolean> receiveMonitoring;
	public static volatile SingularAttribute<ReceiveFreqDaily, String> lastModifiedUser;
	public static volatile SingularAttribute<ReceiveFreqDaily, Long> id;
	public static volatile SingularAttribute<ReceiveFreqDaily, String> receiveHour;

	public static final String RECEIVE_DAYS = "receiveDays";
	public static final String PLANNABLE = "plannable";
	public static final String ACCUMULATED_INFORMATION = "accumulatedInformation";
	public static final String RECEIVE_FREQ_TYPE = "receiveFreqType";
	public static final String END_DATE = "endDate";
	public static final String NEXT_DAY_AFTER_WEEKEND = "nextDayAfterWeekend";
	public static final String RECIVE_FESTIVE = "reciveFestive";
	public static final String NEXT_BUSINESS_DAY = "nextBusinessDay";
	public static final String THRESHOLD = "threshold";
	public static final String RECEIVE_FREQ_SEND_DATE = "receiveFreqSendDate";
	public static final String UUID = "uuid";
	public static final String SUBPRODUCTS = "subproducts";
	public static final String RECEIVE_MONITORING = "receiveMonitoring";
	public static final String LAST_MODIFIED_USER = "lastModifiedUser";
	public static final String ID = "id";
	public static final String RECEIVE_HOUR = "receiveHour";

}

