package com.isban.gcb.ic.commons.converter.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountDto {

  /**
   * Codigo de la cuenta (04)
   */
  private String entity;

  /**
   * Centro de alta de la cuenta (04)
   */
  private String branch;

  /**
   * Numero de la cuenta (12)
   */
  private String number;


  @Override
  public String toString() {
    return entity + branch + number;
  }

  @Override
  public boolean equals(Object o) {

    if (o == this) return true;
    if (!(o instanceof AccountDto)) {
      return false;
    }
    AccountDto instance2 = (AccountDto) o;

    return Objects.equals(entity, instance2.getEntity())
      && Objects.equals(branch, instance2.getBranch())
      && Objects.equals(number, instance2.getNumber());

  }

  @Override
  public int hashCode() {

    return Objects.hash(entity, branch, number);
  }
}
