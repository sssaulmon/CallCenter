package com.isban.gcb.ic.commons.mt9X0.enhanced;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "dcMark",
        "date",
        "currency",
        "amount"
})
public class ClosingBalanceM implements Serializable {

    private static final long serialVersionUID = -1503749231907776769L;

    @JsonProperty("dcMark")
    private String dcMark;
    @JsonProperty("date")
    private String date;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("amount")
    private Double amount;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();

    /**
     * No args constructor for use in serialization
     */
    public ClosingBalanceM() {
        /*Empty Constructor*/
    }

    /**
     * @param amount
     * @param dcMark
     * @param date
     * @param currency
     */
    public ClosingBalanceM(String dcMark, String date, String currency, Double amount) {
        super();
        this.dcMark = dcMark;
        this.date = date;
        this.currency = currency;
        this.amount = amount;
    }

    public ClosingBalanceM clone(){
        ClosingBalanceM closingBalanceM = new ClosingBalanceM();
        closingBalanceM.setCurrency(getCurrency());
        closingBalanceM.setAmount(getAmount());
        closingBalanceM.setDate(getDate());
        closingBalanceM.setDcMark(getDcMark());
        return closingBalanceM;
    }

    @JsonProperty("dcMark")
    public String getDcMark() {
        return dcMark;
    }

    @JsonProperty("dcMark")
    public void setDcMark(String dcMark) {
        this.dcMark = dcMark;
    }

    @JsonProperty("date")
    public String getDate() {
        return date;
    }

    @JsonProperty("date")
    public void setDate(String date) {
        this.date = date;
    }

    @JsonProperty("currency")
    public String getCurrency() {
        return currency;
    }

    @JsonProperty("currency")
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @JsonProperty("amount")
    public Double getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(Double amount) {
        this.amount = amount;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClosingBalanceM that = (ClosingBalanceM) o;
        return Objects.equals(dcMark, that.dcMark) &&
                Objects.equals(date, that.date) &&
                Objects.equals(currency, that.currency) &&
                Objects.equals(amount, that.amount) &&
                Objects.equals(additionalProperties, that.additionalProperties);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dcMark, date, currency, amount, additionalProperties);
    }
}
