package com.isban.gcb.ic.commons.converter.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ConverterDto {

  /**
   * Resumen tipo 0
   */
  private SummaryHeaderSwf0 summaryHeaderSwf0;

  /**
   * Listado de cuentas con movimientos
   */
  private List<AccountTransactionDto> accountTransactions;

  @Override
  public String toString() {
    String line = summaryHeaderSwf0 + "\n";
    line += accountTransactions.stream().map(AccountTransactionDto::toString).collect(Collectors.joining(""));
    return line;
  }

  @Override
  public boolean equals(Object o) {

    if (o == this) return true;
    if (!(o instanceof ConverterDto)) {
      return false;
    }
    ConverterDto instance2 = (ConverterDto) o;

    return Objects.equals(summaryHeaderSwf0, instance2.getSummaryHeaderSwf0())
      && accountTransactions.equals(instance2.getAccountTransactions());

  }

  @Override
  public int hashCode() {

    return Objects.hash(summaryHeaderSwf0, accountTransactions);
  }
}