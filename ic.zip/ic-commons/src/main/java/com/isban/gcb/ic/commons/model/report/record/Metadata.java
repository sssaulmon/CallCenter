package com.isban.gcb.ic.commons.model.report.record;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "account",
        "aliasAccount",
        "version",
        "sequenceNumber",
        "accountPageNumber",
        "totalPagesPerAccount"
})
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Metadata implements Serializable {

    private static final long serialVersionUID = -6013486330942281266L;

    @JsonProperty("account")
    private String account;

    @JsonProperty("aliasAccount")
    private String aliasAccount;

    @JsonProperty("version")
    private String version;

    @JsonProperty("sequenceNumber")
    private String sequenceNumber;

    @JsonProperty("accountPageNumber")
    private Integer accountPageNumber;

    @JsonProperty("totalPagesPerAccount")
    private Integer totalPagesPerAccount;

}