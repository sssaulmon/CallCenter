package com.isban.gcb.ic.commons.mt9X0;


public interface MTIface {

    String getMetadato(String clave);

    void setMetadato(String clave, String valor);

}
