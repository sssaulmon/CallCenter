package com.isban.gcb.ic.commons.model.internetapi;

public class CorporateResponse {

  private String corporate;

  public CorporateResponse() {
  }

  public CorporateResponse(String corporate) {
    this.corporate = corporate;
  }

  public CorporateResponse corporate(String corporate) {
    this.corporate = corporate;
    return this;
  }

  public String getCorporate() {
    return corporate;
  }

  public void setCorporate(String corporate) {
    this.corporate = corporate;
  }
}
