package com.isban.gcb.ic.commons.mt9X0;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author eduardo.rodriguezllo
 */
public class ClosingBalanceOptional implements Balance, Serializable {

    private String dcMark; // D/C Mark
    private Date date; // Date (YYMMDD)
    private String currency; //Currency (código ISO)
    private Double amount; // Amount

    /*
    * Constructor Empty
    */
    public ClosingBalanceOptional() {
        this.dcMark = null;
        this.date = null;
        this.currency = null;
        this.amount = null;
    }

    /*
    * Constructor Full
    */
    public ClosingBalanceOptional(String dcMark, Date date, String currency, Double amount) {
        this.dcMark = dcMark;
        this.date = date;
        this.currency = currency;
        this.amount = amount;
    }

    /*
    * Constructor Full 2
    */
    public ClosingBalanceOptional(String dcMark, String date, String currency, Double amount) throws ParseException {
        this.dcMark = dcMark;
        DateFormat formatter;
        formatter = new SimpleDateFormat("dd/MM/yyyy");
        this.date = formatter.parse(date);
        this.currency = currency;
        this.amount = amount;
    }

    /*
    * Getters
    */
    @Override
    public String getDcMark() {
        return dcMark;
    }

    @Override
    public Date getDate() {
        return date;
    }

    @Override
    public String getCurrency() {
        return currency;
    }

    @Override
    public Double getAmount() {
        return amount;
    }

    /*
    * Setters
    */
    @Override
    public void setDcMark(String dcMark) {
        this.dcMark = dcMark;
    }

    @Override
    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @Override
    public void setAmount(Double amount) {
        this.amount = amount;
    }

    /**
     * Extracts fields from a MT940 class to ClosingBalanceOptional class (ONLY
     * BASIC INFO)
     *
     * @param mt940 MT940 Class
     * @author Eduardo Rodriguez
     */
    public void obtainClosingBalanceOptionalBasic(com.prowidesoftware.swift.model.mt.mt9xx.MT940 mt940) {
        this.obtainDCMark(mt940);
        try {
            this.obtainDate(mt940);
        } catch (ParseException ignored) {
        }
        this.obtainCurrency(mt940);
        this.obtainAmount(mt940);
    }

    /**
     * Takes a MT940 Object and extracts the field of 64 : DCMark
     *
     * @param mt940 MT940
     * @author Eduardo Rodriguez
     */
    private void obtainDCMark(com.prowidesoftware.swift.model.mt.mt9xx.MT940 mt940) {
        this.setDcMark(mt940.getField64().getComponent1());
    }

    /**
     * Takes a MT940 Object and extracts the field of 64 : Date
     *
     * @param mt940 MT940
     * @author Eduardo Rodriguez
     */
    private void obtainDate(com.prowidesoftware.swift.model.mt.mt9xx.MT940 mt940) throws ParseException {
        DateFormat formatter;
        formatter = new SimpleDateFormat("yyMMdd");
        this.setDate(formatter.parse(mt940.getField64().getComponent2()));
    }

    /**
     * Takes a MT940 Object and extracts the field of 64 : Currency
     *
     * @param mt940 MT940
     * @author Eduardo Rodriguez
     */
    private void obtainCurrency(com.prowidesoftware.swift.model.mt.mt9xx.MT940 mt940) {
        this.setCurrency(mt940.getField64().getComponent3());
    }

    /**
     * Takes a MT940 Object and extracts the field of 64 : Amount
     *
     * @param mt940 MT940
     * @author Eduardo Rodriguez
     */
    private void obtainAmount(com.prowidesoftware.swift.model.mt.mt9xx.MT940 mt940) {
        this.setAmount(mt940.getField64().getComponent4AsNumber().doubleValue());
    }
}
