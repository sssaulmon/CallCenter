package com.isban.gcb.ic.commons.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Set;
import java.util.stream.Collectors;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "sla_entity", indexes = {@Index(columnList = "uuid", name = "uuid_sla_entity")})
public class AssoCorpSubProductAcc extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sla_entity_gen")
    @SequenceGenerator(name = "sla_entity_gen", sequenceName = "sla_entity_generator",
            allocationSize = 1)
    private Long id;

    @NotNull
    @Size(max = 40)
    @Column(name = "uuid", nullable = false)
    private String uuid;

    @NotNull
    @Size(max = 40)
    @Column(name = "uuid_corporate", nullable = false)
    private String uuidCorporate;

    @NotNull
    @Size(max = 255)
    @Column(name = "alias_account", nullable = false)
    private String alias;

    @NotNull
    @Size(max = 40)
    @Column(name = "uuid_structure_acc", nullable = false, length = 40)
    private String uuidStructureAcc;

    @Size(max = 3)
    @Column(name = "currency", length = 3)
    private String currency;

    @NotNull
    @Size(max = 11)
    @Column(name = "bic_entity_acc", length = 11, nullable = false)
    private String bicEntityAcc;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Size(max = 20)
    @Column(name = "last_modified_user", length = 20)
    private String lastModifiedUser;

    @Column(name = "ind_gts", nullable = false, columnDefinition = "NUMBER(1,0) DEFAULT 0")
    private Boolean gtsIndicator;

    @Column(name = "ind_gts_date")
    private OffsetDateTime gtsIndicatorDate;

    @ManyToOne
    @JoinColumn(name = "subproduct_id", referencedColumnName = "id")
    private Subproduct subproduct;

    @OneToMany(mappedBy = "assoCorpSubProductAcc", fetch = FetchType.LAZY)
    private Set<ServiceAccount> accountSet;

    @Size(max = 255)
    @Column(name = "account_international_number")
    private String accountInternationalNumber;

    @Size(max = 255)
    @Column(name = "account_local_number")
    private String accountLocalNumber;

    @Override
    public String toString() {
        String resp = "AssoCorpSubProductAcc{" + "id=" + id + ", uuid='" + uuid + '\''
                + ", uuidCorporate='" + uuidCorporate + '\'' + ", alias='" + alias + '\''
                + ", uuidStructureAcc='" + uuidStructureAcc + '\'' + ", currency='" + currency
                + '\'' + ", bicEntityAcc='" + bicEntityAcc + '\'' + ", createDate="
                + getCreateDate() + ", endDate=" + endDate + ", lastModifiedDate="
                + getLastModifiedDate() + ", lastModifiedUser='" + lastModifiedUser + '\''
          + ", subproduct=" + (subproduct != null ? subproduct.getUuid() : null)
          + ", gtsIndicator=" + gtsIndicator + ", gtsIndicatorDate='" + gtsIndicatorDate + '\'';
        if (accountSet != null && !accountSet.isEmpty()) {
            resp += ", accountSet=[";
            resp += accountSet.stream().map(s -> s.getId().toString())
                    .collect(Collectors.joining(", "));
            resp += "]";
        }
        resp += ", accountInternationalNumber='" + accountInternationalNumber + '\''
          + ", accountLocalNumber='" + accountLocalNumber + '\''
          + "}";
        return resp;
    }
}
