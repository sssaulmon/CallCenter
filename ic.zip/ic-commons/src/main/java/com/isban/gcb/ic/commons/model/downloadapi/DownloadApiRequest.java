package com.isban.gcb.ic.commons.model.downloadapi;

import java.util.List;

public class DownloadApiRequest {

  private List<String> accounts;
  private List<String> products;
  private List<String> formats;
  private List<String> channels;
  private String startDate;
  private String endDate;
  private String specificDate;
  private int reportsNumber;
  private boolean lastReport;
  private boolean zipRequest;

  public DownloadApiRequest() {
  }

  public List<String> getAccounts() {
    return this.accounts;
  }

  public List<String> getProducts() {
    return this.products;
  }

  public List<String> getFormats() {
    return this.formats;
  }

  public List<String> getChannels() {
    return this.channels;
  }

  public String getStartDate() {
    return this.startDate;
  }

  public String getEndDate() {
    return this.endDate;
  }

  public String getSpecificDate() {
    return this.specificDate;
  }

  public int getReportsNumber() {
    return this.reportsNumber;
  }

  public boolean isLastReport() {
    return this.lastReport;
  }

  public boolean isZipRequest() {
    return this.zipRequest;
  }

  public void setAccounts(List<String> accounts) {
    this.accounts = accounts;
  }

  public void setProducts(List<String> products) {
    this.products = products;
  }

  public void setFormats(List<String> formats) {
    this.formats = formats;
  }

  public void setChannels(List<String> channels) {
    this.channels = channels;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public void setSpecificDate(String specificDate) {
    this.specificDate = specificDate;
  }

  public void setReportsNumber(int reportsNumber) {
    this.reportsNumber = reportsNumber;
  }

  public void setLastReport(boolean lastReport) {
    this.lastReport = lastReport;
  }

  public void setZipRequest(boolean zipRequest) {
    this.zipRequest = zipRequest;
  }

  public DownloadApiRequest accounts(List<String> accounts) {
    this.accounts = accounts;
    return this;
  }

  public DownloadApiRequest products(List<String> products) {
    this.products = products;
    return this;
  }

  public DownloadApiRequest formats(List<String> formats) {
    this.formats = formats;
    return this;
  }

  public DownloadApiRequest channels(List<String> channels) {
    this.channels = channels;
    return this;
  }

  public DownloadApiRequest startDate(String startDate) {
    this.startDate = startDate;
    return this;
  }

  public DownloadApiRequest endDate(String endDate) {
    this.endDate = endDate;
    return this;
  }

  public DownloadApiRequest specificDate(String specificDate) {
    this.specificDate = specificDate;
    return this;
  }

  public DownloadApiRequest reportsNumber(int reportsNumber) {
    this.reportsNumber = reportsNumber;
    return this;
  }

  public DownloadApiRequest lastReport(boolean lastReport) {
    this.lastReport = lastReport;
    return this;
  }

  public DownloadApiRequest zipRequest(boolean zipRequest) {
    this.zipRequest = zipRequest;
    return this;
  }

  public String toString() {
    return "DownloadApiRequest(accounts=" + this.getAccounts() + ", products=" + this.getProducts() + ", formats=" + this.getFormats() +
      ", channels=" + this.getChannels() + ", startDate=" + this.getStartDate() + ", endDate=" + this.getEndDate() + ", specificDate=" + this.getSpecificDate() +
      ", reportsNumber=" + this.getReportsNumber() + ", lastReport=" + this.isLastReport() + ", zipRequest=" + this.isZipRequest() + ")";
  }
}