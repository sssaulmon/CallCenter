package com.isban.gcb.ic.commons.util;

import java.util.stream.Stream;

public enum CountryCodeEnum {

  CHILE("997", "BSCHCLRMXXX"),
  MEXICO("052", "BMSXMXMMXXX"),
  RIO("080", "BSCHARBAXXX"),
  PUERTO_RICO("PRI", "BSCHPRSXXXX"),
  LONDRES("LON", "BSCHGB2LXXX"),
  PARIS("PAR", "BSCHFRPPXXX"),
  MILAN("MIL", "BSCHITMMXXX"),
  FRANKFURT("FRA", "BSCHDEFFXXX"),
  HONG_KONG("HKG", "BSCHHKHHXXX"),
  SHANGHAI("SHG", "BSCHCNSHXXX"),
  BEIJING("BJN", "BSCHCNBJXXX"),
  SINGAPUR("SGP", "BSCHSGSGXXX"),
  NY("NYB", "BSCHUS33XXX"),
  DEFAULT("", "");

  String countryCode;
  String bic;

  CountryCodeEnum(String countryCode, String bic) {
    this.countryCode = countryCode;
    this.bic = bic;
  }

  public static String toBic(String countryCode) {
    return Stream.of(CountryCodeEnum.values())
      .filter(countryCodeEnum -> countryCode.equals(countryCodeEnum.countryCode))
      .map(countryCodeEnum -> countryCodeEnum.bic)
      .findFirst()
      .orElse(DEFAULT.bic);
  }
}
