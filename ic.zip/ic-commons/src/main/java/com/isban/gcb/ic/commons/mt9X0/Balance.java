package com.isban.gcb.ic.commons.mt9X0;

import java.util.Date;

/**
 * @author eduardo.rodriguezllo
 */
public interface Balance {

    /*
    * Getters
    */
    String getDcMark();

    Date getDate();

    String getCurrency();

    Double getAmount();

    /*
    * Setters
    */
    void setDcMark(String dcMark);

    void setDate(Date date);

    void setCurrency(String currency);

    void setAmount(Double amount);
}
