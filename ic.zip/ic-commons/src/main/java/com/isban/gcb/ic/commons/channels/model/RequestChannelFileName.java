package com.isban.gcb.ic.commons.channels.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RequestChannelFileName {

  private String fileName;
  private String contract;
  private String outputChannel;
  private String frequency;
  private String format;
  private String version;
  private String account;

  public RequestChannelFileName fileName(String fileName) {
    this.fileName = fileName;
    return this;
  }

  public RequestChannelFileName contract(String contract) {
    this.contract = contract;
    return this;
  }

  public RequestChannelFileName outputChannel(String outputChannel) {
    this.outputChannel = outputChannel;
    return this;
  }

  public RequestChannelFileName frequency(String frequency) {
    this.frequency = frequency;
    return this;
  }

  public RequestChannelFileName format(String format) {
    this.format = format;
    return this;
  }

  public RequestChannelFileName version(String version) {
    this.version = version;
    return this;
  }

  public RequestChannelFileName account(String account) {
    this.account = account;
    return this;
  }
}
