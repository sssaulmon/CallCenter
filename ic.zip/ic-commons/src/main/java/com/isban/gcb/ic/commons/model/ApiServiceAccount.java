package com.isban.gcb.ic.commons.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.time.LocalDateTime;

@Getter
@Setter
@EqualsAndHashCode(exclude = "apiService", callSuper = false)
@Entity(name = "API_SERVICE_ACCOUNT")
public class ApiServiceAccount extends AuditableLocalDateTime {

  @Id
  @Column(name = "UUID")
  private String uuid;

  @ManyToOne
  @JoinColumn(name = "API_SERVICE_UUID")
  private ApiService apiService;

  @Column(name = "ALIAS_TYPE")
  private String aliasType;

  @Column(name = "ALIAS_ACC_CLIENT")
  private String aliasAccClient;

  @Column(name = "UUID_STRUCTURE_ACC")
  private String uuidStructureAcc;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;
}
