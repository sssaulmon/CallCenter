package com.isban.gcb.ic.commons.model.outputformat.record;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.*;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "s3Path",
        "fileName"
})
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class OutputFormatMetadataSend implements Serializable {

    private static final long serialVersionUID = -1519291270333043227L;

    @JsonProperty("s3Path")
    private String s3Path;

    @JsonProperty("fileName")
    private String fileName;

}