package com.isban.gcb.ic.commons.util;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Tag86Utils {

  public static final String REPLACING_CHARACTER = "";
  private static final String FORBIDDEN_CHARACTERS = "[-: ]";
  
  private Tag86Utils() {
  }
  
  public static String sanitizeField86(String field86) {
    String result;
    List<String> lines = Arrays.asList(field86.split("\r?\n"));
    
    if (lines.size() > 1) {
      lines = lines.stream().filter(Tag86Utils::forbiddenCharacterLine).collect(Collectors.toList());
      List<String> transformedLines = lines.subList(1, lines.size()).stream()
          .map(Tag86Utils::sanitizeSingleLine)
          .collect(Collectors.toList());
      
      transformedLines.add(0, lines.get(0));
      
      result = String.join("\r\n", transformedLines);
    } else {
      result = field86;
    }
    return result;
  }

  private static String sanitizeSingleLine(String line) {
    while (!line.isEmpty() && FORBIDDEN_CHARACTERS.contains("" + line.charAt(0))) {
      line = line.replaceAll("^" + FORBIDDEN_CHARACTERS + "(.*)", REPLACING_CHARACTER + "$1");
    }
    return line;
  }

  private static boolean forbiddenCharacterLine(String line){
    return !" ".equals(line) && !"".equals(line) && !"-".equals(line);
  }
}
