package com.isban.gcb.ic.commons.channels;

import com.isban.gcb.ic.commons.channels.model.BaseRequestChannelFileNames;
import com.isban.gcb.ic.commons.channels.model.ChannelData;
import com.isban.gcb.ic.commons.channels.model.ChannelFileNames;
import com.isban.gcb.ic.commons.channels.model.RequestChannelAppend;
import com.isban.gcb.ic.commons.channels.model.RequestChannelComplete;
import com.isban.gcb.ic.commons.channels.model.RequestChannelFileName;
import com.isban.gcb.ic.commons.channels.model.RequestChannelNoAppend;
import com.isban.gcb.ic.commons.channels.model.RequestChannels;
import com.isban.gcb.ic.commons.model.report.global.Address;

import java.security.SecureRandom;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.apache.commons.lang.StringUtils.isNotBlank;
import static org.apache.commons.lang.StringUtils.substring;

// TODO El cambio está pendiente de definir en: https://jira.ci.gsnet.corp/projects/GCBINFCENT/issues/GCBINFCENT-2635
// Se tiene que refactorizar en com.isban.gcb.ic.intradiatransform.service.globalreport.GlobalReportServiceImpl:
// En el ticker Jira se explica su nueva implementacion de gestion de nombres de ficheros por canal-address
// en base a alias en tablas de bases de datos.
public class Channel {

  private static final String PATH_DELIMITER = "/";

  private static final String DIR_APPEND = "APPEND";
  private static final String DIR_COMPLETE = "COMPLETE";
  private static final String DIR_VERSION = "version";
  private static final String DIR_GLOBAL_REPORT = "Global_Report";

  private static final String PART_FILENAME_EDITRAN = "EDITRAN";
  private static final String PART_FILENAME_CHANNELING = "CHANNELING";
  private static final String PART_FILENAME_SWIFT = "SWIFT";

  private static final String ALIAS_ACCOUNT_APPEND = "APPEND";

  private String channelEditran;
  private String channelFileact;
  private String channelEbic;
  private String channelH2H;
  private String channelSwiftFin;
  private String channelEmail;
  private String editranPrefix;

  public Channel(RequestChannels channels) {
    this.channelEditran = channels.getChannelEditran();
    this.channelFileact = channels.getChannelFileact();
    this.channelEbic = channels.getChannelEbic();
    this.channelH2H = channels.getChannelH2H();
    this.channelSwiftFin = channels.getChannelSwiftFin();
    this.channelEmail = channels.getChannelEmail();
    this.editranPrefix = channels.getEditranPrefix();
  }

  public String resolvePath(RequestChannelFileName request) {

    String pathFileName = DIR_GLOBAL_REPORT + PATH_DELIMITER;

    if (channelSwiftFin.equals(request.getOutputChannel())) {
      pathFileName += request.getAccount()
        + PATH_DELIMITER + request.getFrequency()
        + PATH_DELIMITER + request.getFormat()
        + PATH_DELIMITER + request.getContract()
        + PATH_DELIMITER + request.getOutputChannel()
        + PATH_DELIMITER + DIR_VERSION + PATH_DELIMITER + request.getVersion()
        + PATH_DELIMITER + DIR_COMPLETE + PATH_DELIMITER;
    } else {
      pathFileName += request.getAccount()
        + PATH_DELIMITER + request.getFrequency()
        + PATH_DELIMITER + request.getFormat()
        + PATH_DELIMITER + request.getContract()
        + PATH_DELIMITER + request.getOutputChannel()
        + PATH_DELIMITER + DIR_VERSION + PATH_DELIMITER + request.getVersion()
        + PATH_DELIMITER;
    }
    return pathFileName;
  }

  public String resolveFileNamePath(RequestChannelFileName request) {

    String path = resolvePath(request);

    String globalFileName = resolveFileName(request.getFileName(), request.getOutputChannel());

    return path + globalFileName;
  }

  private String resolveFileName(String fileName, String outputChannel) {
    String[] parts = fileName.split("\\.");

    if (channelEditran.equals(outputChannel) && parts.length >= 2) {
      return fileName.replaceFirst(parts[2], PART_FILENAME_EDITRAN);
    } else if (channelFileact.equals(outputChannel) || channelEbic.equals(outputChannel)
      || channelH2H.equals(outputChannel) && (parts.length >= 1)) {
      return fileName.replaceFirst(parts[1], PART_FILENAME_CHANNELING);
    } else if (channelSwiftFin.equals(outputChannel) && (parts.length >= 1)) {
      return fileName.replaceFirst(parts[1], PART_FILENAME_SWIFT);
    }
    return fileName;
  }

  public ChannelFileNames getNames(RequestChannelAppend request) {

    String basePath = generateGlobalPath(request);
    String aliasAccount = generateDefaultAliasAccount();

    ChannelFileNames channelFileNames = getNamesAppend(request, aliasAccount);
    channelFileNames.setBasePath(basePath);

    return channelFileNames;
  }

  public ChannelFileNames getNames(RequestChannelNoAppend request) {

    String basePath = generateGlobalPath(request);
    String aliasAccount = generateAliasAccount(request);

    ChannelFileNames channelFileNames = getNamesNoAppend(request, aliasAccount, request.getAccountPageNumber());
    channelFileNames.setBasePath(basePath);

    return channelFileNames;
  }

  public ChannelFileNames getNames(RequestChannelComplete request) {

    String basePath = generateGlobalPath(request);
    String aliasAccount = generateAliasAccount(request);

    ChannelFileNames channelFileNames = getNamesComplete(request, aliasAccount, request.getAccountPageNumber());
    channelFileNames.setBasePath(basePath);

    return channelFileNames;
  }

  private ChannelFileNames getNamesAppend(BaseRequestChannelFileNames request, String aliasAccount) {
    return getNames(request, aliasAccount, null, false, true);
  }

  private ChannelFileNames getNamesNoAppend(BaseRequestChannelFileNames request, String aliasAccount, Integer accountPageNumber) {
    return getNames(request, aliasAccount, accountPageNumber, false, false);
  }

  private ChannelFileNames getNamesComplete(BaseRequestChannelFileNames request, String aliasAccount, Integer accountPageNumber) {
    return getNames(request, aliasAccount, accountPageNumber, true, false);
  }

  private ChannelFileNames getNames(BaseRequestChannelFileNames request, String aliasAccount, Integer accountPageNumber,
                                    Boolean complete, Boolean append) {

    ChannelFileNames channelFileNames = new ChannelFileNames();

    // Por cada canal calculamos el nombre del fichero global y el especifico por cada direccion
    List<Address> addresses = new ArrayList<>();
    if (channelEditran.equals(request.getOutputChannel())) {
      // Nombre global
      ChannelData globalChannelData = generateFileNameForEditran(null, request.getFormat(), aliasAccount, request.getZonedDateTime());
      channelFileNames.setFileName(globalChannelData.getFileName());
      // Nombre por direccion
      request.getAddresses().forEach(address -> {
        ChannelData channelData = generateFileNameForEditran(address, request.getFormat(), aliasAccount, request.getZonedDateTime());
        addresses.add(new Address().address(address).fileName(channelData.getFileName()));
      });
    } else if (channelEmail.equals(request.getOutputChannel())) {
      // Nombre global
      ChannelData globalChannelData = generateFilenameForEmail(request.getFormat(), aliasAccount, request.getZonedDateTime());
      channelFileNames.setFileName(globalChannelData.getFileName());
      // Nombre por direccion (en el caso de EMAIL todos tienen el mismo nombre)
      request.getAddresses().forEach(address ->
        addresses.add(new Address().address(address).fileName(globalChannelData.getFileName()))
      );
    } else if (channelH2H.equals(request.getOutputChannel())
      || channelEbic.equals(request.getOutputChannel())
      || channelFileact.equals(request.getOutputChannel())) {

      String dateRandomSeconds = formatTimeToHHmmssRandomSeconds(request.getZonedDateTime());

      ChannelData globalChannelData;
      if (append) {
        globalChannelData = generateFilenameForChanneling(PART_FILENAME_CHANNELING, null,
          request.getFormat(), request.getContract(), request.getZonedDateTime(), true, dateRandomSeconds);
      } else {
        globalChannelData = generateFilenameForChanneling(PART_FILENAME_CHANNELING, null,
          request.getFormat(), aliasAccount, request.getZonedDateTime(), false, dateRandomSeconds);
      }

      channelFileNames.setFileName(globalChannelData.getFileName());
      // Nombre por direccion
      request.getAddresses().forEach(address -> {
        ChannelData channelData;
        if (append) { // solo en caso de append ponemos el contrato
          channelData = generateFilenameForChanneling(null, address, request.getFormat(),
            request.getContract(), request.getZonedDateTime(), true, dateRandomSeconds);

        } else {
          channelData = generateFilenameForChanneling(null, address, request.getFormat(),
            aliasAccount, request.getZonedDateTime(), false, dateRandomSeconds);
        }
        addresses.add(new Address().address(address).fileName(channelData.getFileName()).bamClientId(channelData.getBamClientId()));
      });
    } else if (channelSwiftFin.equals(request.getOutputChannel())) {
      // Nombre global
      ChannelData globalChannelData;
      if (append) {
        globalChannelData = generateFilenameForSwift(PART_FILENAME_SWIFT, null, request.getFormat(),
          request.getContract(), request.getZonedDateTime(), true);
      } else {
        globalChannelData = generateFilenameForSwift(PART_FILENAME_SWIFT, null, request.getFormat(),
          aliasAccount, request.getZonedDateTime(), false);
      }

      String globalFileName = globalChannelData.getFileName();
      if (!complete) {
        globalFileName += "_" + accountPageNumber;
      }
      channelFileNames.setFileName(globalFileName);
      // Nombre por direccion
      request.getAddresses().forEach(address -> {
        ChannelData channelData;
        if (append) {
          channelData = generateFilenameForSwift(null, address, request.getFormat(),
            request.getContract(), request.getZonedDateTime(), true);
        } else {
          channelData = generateFilenameForSwift(null, address, request.getFormat(),
            aliasAccount, request.getZonedDateTime(), false);
        }
        String fileName = channelData.getFileName();
        if (!complete) {
          fileName += "_" + accountPageNumber;
        }
        addresses.add(new Address().address(address).fileName(fileName));
      });
    }

    channelFileNames.setAddresses(addresses);

    return channelFileNames;
  }

  private String generateGlobalPath(RequestChannelAppend request) {

    return DIR_GLOBAL_REPORT + PATH_DELIMITER
      + DIR_APPEND
      + PATH_DELIMITER + request.getFrequency()
      + PATH_DELIMITER + request.getFormat()
      + PATH_DELIMITER + request.getContract()
      + PATH_DELIMITER + request.getOutputChannel()
      + PATH_DELIMITER + DIR_VERSION
      + PATH_DELIMITER + request.getGlobalReportVersion()
      + PATH_DELIMITER;
  }

  private String generateGlobalPath(RequestChannelNoAppend request) {

    return DIR_GLOBAL_REPORT + PATH_DELIMITER
      + request.getAccount()
      + PATH_DELIMITER + request.getFrequency()
      + PATH_DELIMITER + request.getFormat()
      + PATH_DELIMITER + request.getContract()
      + PATH_DELIMITER + request.getOutputChannel()
      + PATH_DELIMITER + DIR_VERSION
      + PATH_DELIMITER + (request.getStp() ? request.getVersion() : request.getGlobalReportVersion())
      + PATH_DELIMITER;
  }

  private String generateGlobalPath(RequestChannelComplete request) {

    return DIR_GLOBAL_REPORT + PATH_DELIMITER
      + request.getAccount()
      + PATH_DELIMITER + request.getFrequency()
      + PATH_DELIMITER + request.getFormat()
      + PATH_DELIMITER + request.getContract()
      + PATH_DELIMITER + request.getOutputChannel()
      + PATH_DELIMITER + DIR_VERSION
      + PATH_DELIMITER + (request.getStp() ? request.getVersion() : request.getGlobalReportVersion())
      + PATH_DELIMITER + DIR_COMPLETE
      + PATH_DELIMITER;
  }

  private String generateDefaultAliasAccount() {
    return ALIAS_ACCOUNT_APPEND;
  }

  private String generateAliasAccount(RequestChannelNoAppend request) {
    return request.getAliasAccount();
  }

  private String generateAliasAccount(RequestChannelComplete request) {
    return request.getAliasAccount();
  }

  private ChannelData generateFilenameForEmail(String outputFormat, String aliasAccount, ZonedDateTime zonedDateTime) {

    String filename = "SICSAN.";
    filename += "EMAIL";
    if ("FINS".equalsIgnoreCase(outputFormat)) {
      filename += ".O.";
    } else {
      filename += ".";
    }
    filename += outputFormat;
    filename += ".D";
    filename += DateTimeFormatter.ofPattern("yyMMdd").format(zonedDateTime);
    filename += ".H";
    filename += formatTimeToHHmmss(zonedDateTime);
    filename += ".C";

    if (isNotBlank(aliasAccount)) {
      if (ALIAS_ACCOUNT_APPEND.equals(aliasAccount)) {
        filename += ALIAS_ACCOUNT_APPEND;
      } else {
        aliasAccount = replaceSlashInAlias(aliasAccount);

        filename += aliasAccount.length() <= 6 ? aliasAccount
          : aliasAccount.substring(aliasAccount.length() - 6);
      }
    }

    return ChannelData.builder().fileName(filename).build();
  }

  private ChannelData generateFileNameForEditran(String address, String outputFormat, String aliasAccount, ZonedDateTime zonedDateTime) {

    String filename = editranPrefix;
    filename += ".JF.";

    // length controlled by GTB Desk
    if (isNotBlank(address)) {
      filename += address;
    } else {
      filename += PART_FILENAME_EDITRAN;
    }

    filename += ".";
    filename += outputFormat;
    filename += ".ED.C";

    // remove special characters
    aliasAccount = aliasAccount.replaceAll("[-/+.^:,&%()!=*#$'><?;@ñ]", "");

    filename += aliasAccount.length() <= 6 ?
      aliasAccount :
      substring(aliasAccount, aliasAccount.length() - 6);
    filename += ".D";
    filename += DateTimeFormatter.ofPattern("dd").format(zonedDateTime);
    filename += ".H";
    filename += formatTimeToHHmmss(zonedDateTime);

    return ChannelData.builder().fileName(filename).build();
  }

  private ChannelData generateFilenameForChanneling(String channel, String address, String outputFormat,
                                                    String fileNameAlias, ZonedDateTime zonedDateTime,
                                                    Boolean append, String dateRandomSeconds) {

    String bamClientId = null;
    String filename = "SICSAN.";
    if (isNotBlank(address)) {
      bamClientId = address;
      filename += bamClientId;
    } else {
      filename += channel;
    }
    if ("FINS".equalsIgnoreCase(outputFormat)) {
      filename += ".O.";
    } else {
      filename += ".";
    }
    filename += outputFormat;
    filename += ".D";
    filename += DateTimeFormatter.ofPattern("yyMMdd").format(zonedDateTime);
    filename += ".H";
    filename += dateRandomSeconds;
    filename += ".C";

    if (append) {
      String contractAlias = String.format("%06d", Integer.valueOf(fileNameAlias));

      contractAlias = replaceSlashInAlias(contractAlias);

      filename += contractAlias.length() <= 6 ? contractAlias
        : contractAlias.substring(contractAlias.length() - 6);
    } else {
      fileNameAlias = replaceSlashInAlias(fileNameAlias);
      filename += fileNameAlias.length() <= 6 ? fileNameAlias
        : fileNameAlias.substring(fileNameAlias.length() - 6);
    }


    return ChannelData.builder().fileName(filename).bamClientId(bamClientId).build();
  }

  private ChannelData generateFilenameForSwift(String channel, String address, String outputFormat,
                                               String fileNameAlias, ZonedDateTime zonedDateTime, Boolean append) {

    String bamClientId = null;
    String filename = "SICSAN.";
    if (isNotBlank(address)) {
      bamClientId = address;
      filename += bamClientId;
    } else {
      filename += channel;
    }
    if ("FINS".equalsIgnoreCase(outputFormat)) {
      filename += ".O.";
    } else {
      filename += ".";
    }
    filename += outputFormat;
    filename += ".D";
    filename += DateTimeFormatter.ofPattern("yyMMdd").format(zonedDateTime);
    filename += ".H";
    filename += formatTimeToHHmmss(zonedDateTime);
    filename += ".C";

    if (append) {
      String contractAlias = String.format("%06d", Integer.valueOf(fileNameAlias));

      contractAlias = replaceSlashInAlias(contractAlias);

      filename += contractAlias.length() <= 6 ? contractAlias
        : contractAlias.substring(contractAlias.length() - 6);
    } else {
      fileNameAlias = replaceSlashInAlias(fileNameAlias);
      filename += fileNameAlias.length() <= 6 ? fileNameAlias
        : fileNameAlias.substring(fileNameAlias.length() - 6);
    }


    return ChannelData.builder().fileName(filename).bamClientId(bamClientId).build();
  }

  private String replaceSlashInAlias(String alias) {
    if (alias.contains("/")) {
      alias = alias.replace("/", "-");
    }
    return alias;
  }

  private String formatTimeToHHmmss(ZonedDateTime now) {
    return DateTimeFormatter.ofPattern("HHmmss").format(now);
  }

  private String formatTimeToHHmmssRandomSeconds(ZonedDateTime now) {
    return DateTimeFormatter.ofPattern("HHmmss")
      .format(now)
      .substring(0, 4)
      .concat(generateRandomSeconds());
  }

  private String generateRandomSeconds() {
    return Optional.of(new SecureRandom())
      .map(SecureRandom::nextInt)
      .map(i -> i & Integer.MAX_VALUE)
      .map(i -> i % 60)
      .map(s -> String.format("%02d", s))
      .orElseThrow(RuntimeException::new);
  }
}
