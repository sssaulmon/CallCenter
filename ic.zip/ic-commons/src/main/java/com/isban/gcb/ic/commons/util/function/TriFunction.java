package com.isban.gcb.ic.commons.util.function;

@FunctionalInterface
public interface TriFunction<T, W, S, K> {
  K apply(T t, W w, S s);
}
