package com.isban.gcb.ic.commons.model.downloadapi;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class GlobalReportInfo {

  private String contractId;
  private String version;
  private String enterpriseGroup;
  private String corporate;
  private String localAccount;
  private String serviceType;
  private String sendChannel;
  private String sendFormat;
  private String accountingDate;
  @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
  private String expectedSendDate;
  private String sendDate;
  private String filename;

  public GlobalReportInfo() { }

  public GlobalReportInfo(String contractId, String enterpriseGroup, String corporate, String localAccount,
                          String serviceType, String sendChannel, String sendFormat, String accountingDate,
                          String expectedSendDate, String sendDate, String filename, String version) {
    this.contractId = contractId;
    this.enterpriseGroup = enterpriseGroup;
    this.corporate = corporate;
    this.localAccount = localAccount;
    this.serviceType = serviceType;
    this.sendChannel = sendChannel;
    this.sendFormat = sendFormat;
    this.accountingDate = accountingDate;
    this.expectedSendDate = expectedSendDate;
    this.sendDate = sendDate;
    this.filename = filename;
    this.version = version;
  }

  public String getContractId() {
    return contractId;
  }

  public void setContractId(String contractId) {
    this.contractId = contractId;
  }

  public String getEnterpriseGroup() {
    return enterpriseGroup;
  }

  public void setEnterpriseGroup(String enterpriseGroup) {
    this.enterpriseGroup = enterpriseGroup;
  }

  public String getCorporate() {
    return corporate;
  }

  public void setCorporate(String corporate) {
    this.corporate = corporate;
  }

  public String getLocalAccount() {
    return localAccount;
  }

  public void setLocalAccount(String localAccount) {
    this.localAccount = localAccount;
  }

  public String getServiceType() {
    return serviceType;
  }

  public void setServiceType(String serviceType) {
    this.serviceType = serviceType;
  }

  public String getSendChannel() {
    return sendChannel;
  }

  public void setSendChannel(String sendChannel) {
    this.sendChannel = sendChannel;
  }

  public String getSendFormat() {
    return sendFormat;
  }

  public void setSendFormat(String sendFormat) {
    this.sendFormat = sendFormat;
  }

  public String getAccountingDate() {
    return accountingDate;
  }

  public void setAccountingDate(String accountingDate) {
    this.accountingDate = accountingDate;
  }

  public String getExpectedSendDate() {
    return expectedSendDate;
  }

  public void setExpectedSendDate(String expectedSendDate) {
    this.expectedSendDate = expectedSendDate;
  }

  public String getSendDate() {
    return sendDate;
  }

  public void setSendDate(String sendDate) {
    this.sendDate = sendDate;
  }

  public String getFilename() {
    return filename;
  }

  public void setFilename(String filename) {
    this.filename = filename;
  }

  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;

    if (o == null || getClass() != o.getClass()) return false;

    GlobalReportInfo that = (GlobalReportInfo) o;

    return new EqualsBuilder()
      .append(contractId, that.contractId)
      .append(version, that.version)
      .append(enterpriseGroup, that.enterpriseGroup)
      .append(corporate, that.corporate)
      .append(localAccount, that.localAccount)
      .append(serviceType, that.serviceType)
      .append(sendChannel, that.sendChannel)
      .append(sendFormat, that.sendFormat)
      .append(accountingDate, that.accountingDate)
      .append(expectedSendDate, that.expectedSendDate)
      .append(sendDate, that.sendDate)
      .append(filename, that.filename)
      .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(contractId)
      .append(version)
      .append(enterpriseGroup)
      .append(corporate)
      .append(localAccount)
      .append(serviceType)
      .append(sendChannel)
      .append(sendFormat)
      .append(accountingDate)
      .append(expectedSendDate)
      .append(sendDate)
      .append(filename)
      .toHashCode();
  }

  @Override
  public String toString() {
    return "GlobalReportInfo{" +
      "contractId='" + contractId + '\'' +
      ", version='" + version + '\'' +
      ", enterpriseGroup='" + enterpriseGroup + '\'' +
      ", corporate='" + corporate + '\'' +
      ", localAccount='" + localAccount + '\'' +
      ", serviceType='" + serviceType + '\'' +
      ", sendChannel='" + sendChannel + '\'' +
      ", sendFormat='" + sendFormat + '\'' +
      ", accountingDate='" + accountingDate + '\'' +
      ", expectedSendDate='" + expectedSendDate + '\'' +
      ", sendDate='" + sendDate + '\'' +
      ", filename='" + filename + '\'' +
      '}';
  }
}
