package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@MappedSuperclass
public class AuditableLocalDate {

    @Column(name = "create_date")
    private LocalDate createDate;

    @Column(name = "last_modified_date")
    private LocalDate lastModifiedDate;

    @PrePersist
    public void onPrePersist() {
        this.createDate = LocalDate.now();
        this.lastModifiedDate = LocalDate.now();
    }

    @PreUpdate
    public void onPreUpdate() {
        this.lastModifiedDate = LocalDate.now();
    }
}
