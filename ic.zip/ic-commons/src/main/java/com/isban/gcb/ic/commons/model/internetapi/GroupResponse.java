package com.isban.gcb.ic.commons.model.internetapi;

public class GroupResponse {

  private String enterpriseGroup;

  public GroupResponse() {
  }

  public GroupResponse(String enterpriseGroup) {
    this.enterpriseGroup = enterpriseGroup;
  }

  public GroupResponse enterpriseGroup(String enterpriseGroup) {
    this.enterpriseGroup = enterpriseGroup;
    return this;
  }

  public String getEnterpriseGroup() {
    return enterpriseGroup;
  }

  public void setEnterpriseGroup(String enterpriseGroup) {
    this.enterpriseGroup = enterpriseGroup;
  }
}
