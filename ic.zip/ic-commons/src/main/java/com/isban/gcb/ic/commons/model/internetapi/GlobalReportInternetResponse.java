package com.isban.gcb.ic.commons.model.internetapi;

import com.isban.gcb.ic.commons.model.downloadapi.IntegrationResponseBase;

import java.io.Serializable;

public class GlobalReportInternetResponse extends IntegrationResponseBase<GlobalReportsAndZip> implements Serializable {
  public GlobalReportInternetResponse(String code, String description, GlobalReportsAndZip data) {
    super(code, description, data);
  }

  public GlobalReportInternetResponse() {
  }
}
