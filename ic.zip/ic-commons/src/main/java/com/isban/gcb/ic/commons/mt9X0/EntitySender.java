package com.isban.gcb.ic.commons.mt9X0;

import com.prowidesoftware.swift.model.mt.mt9xx.MT940;

import java.io.Serializable;

/**
 * @author eduardo.rodriguezllo
 * Contiene info de la entidad emisora (Campo {2:} del MT940)
 */
public class EntitySender implements Serializable {

    private String bic; //Entity sender

    /*
    * Constructor Empty
    */
    public EntitySender() {
        this.bic = null;
    }

    /*
    * Constructor Full
    */
    public EntitySender(String bic) {
        this.bic = bic;
    }

    /*
    * Getters
    */
    public String getBic() {
        return bic;
    }

    /*
    * Setters
    */
    public void setBic(String bic) {
        this.bic = bic;
    }

    /**
     * Extracts fields from a MT940 class to a EntitySender Class
     * (ONLY BASIC INFO)
     *
     * @param mt940 MT940 Class
     * @author Eduardo Rodriguez
     */
    public void obtainEntitySenderBasic(MT940 mt940) {
        this.obtainBic(mt940);
    }

    /**
     * Takes a block and with regex matches it with the field of BIC
     *
     * @param block The String we match with the Regex
     * @return If it matches or no
     * @author Eduardo Rodriguez
     */
    private void obtainBic(MT940 mt940) {
        this.setBic(mt940.getSender().trim().substring(0, 8)
                .concat(mt940.getSender().trim().substring(9, 12))); //We extract the Message Type
    }
}
