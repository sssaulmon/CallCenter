package com.isban.gcb.ic.commons.model.report.global;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

/**
 * @since 07/08/2018
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "address",
        "state",
        "fileName",
        "bamClientId"
})
public class Address implements Serializable {

    private static final long serialVersionUID = 106065286758109594L;

    @JsonProperty("address")
    private String address;

    @JsonProperty("state")
    private String state;

    @JsonProperty("fileName")
    private String fileName;

    @JsonProperty("bamClientId")
    private String bamClientId;

    public Address() {
    }


    public String getAddress() {
        return this.address;
    }

    public String getState() {
        return this.state;
    }

    public String getFileName() {
        return this.fileName;
    }

    public String getBamClientId() {
        return this.bamClientId;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setBamClientId(String bamClientId) {
        this.bamClientId = bamClientId;
    }
    public Address address(String address) {
        this.address = address;
        return this;
    }

    public Address state(String state) {
        this.state = state;
        return this;
    }

    public Address fileName(String fileName) {
        this.fileName = fileName;
        return this;
    }

    public Address bamClientId(String bamClientId) {
        this.bamClientId = bamClientId;
        return this;
    }

    public String toString() {
        return "Address(address=" + this.getAddress() + ", state=" + this.getState() + ", fileName=" + this.getFileName() + ", bamClientId=" + this.getBamClientId() + ")";
    }
}