package com.isban.gcb.ic.commons.model.outputformat.standard;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.*;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "outputChannel",
        "accountAlias",
        "accountingDate",
        "contract",
        "version",
        "totalStandardPages"
})
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class OutputStandardMetadata implements Serializable {

    private static final long serialVersionUID = -7719691270333043227L;

    @JsonProperty("outputChannel")
    private String outputChannel;

    @JsonProperty("accountAlias")
    private String accountAlias;

    @JsonProperty("accountingDate")
    private String accountingDate;

    @JsonProperty("contract")
    private String contract;

    @JsonProperty("version")
    private String version;

    @JsonProperty("totalStandardPages")
    private Integer totalStandardPages;

}