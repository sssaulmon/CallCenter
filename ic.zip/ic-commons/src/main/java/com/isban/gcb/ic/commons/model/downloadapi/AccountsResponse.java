package com.isban.gcb.ic.commons.model.downloadapi;

import java.io.Serializable;
import java.util.List;

public class AccountsResponse extends IntegrationResponseBase<List<AccountInfo>> implements Serializable {

  public AccountsResponse(String code, String description, List<AccountInfo> data) {
    super(code, description, data);
  }

  public AccountsResponse(String code, String description) {
    super(code, description);
  }

  public AccountsResponse() {};

}
