package com.isban.gcb.ic.commons.micrometer.constant;

public class MeterConstant {

  private MeterConstant() {
  }

  // METER NAMES
  public static final String EXTRACT_RECEIVED_METER = "extracts.received";
  public static final String EXTRACT_REJECTED_METER = "extracts.rejected";
  public static final String EXTRACT_GENERATED_METER = "extracts.generated";
  public static final String EXTRACT_SENT_METER = "extracts.sent";
  public static final String SWIFT_ACKNOWLEDGE_METER = "swift.acknowledge";
  public static final String EXTRACT_PLANNED_INPUT_METER = "extracts.planned.input";
  public static final String EXTRACT_INPUT_STATUS_METER = "extracts.input.status";
  public static final String EXTRACT_PLANNED_OUTPUT_METER = "extracts.planned.output";
  public static final String EXTRACT_OUTPUT_STATUS_METER = "extracts.output.status";
  public static final String PORTAL_REQUEST = "portal.request";
  public static final String SPECIAL_CLIENTS_METER = "special.clients";
  public static final String SPECIAL_CLIENTS_INPUT_STATUS_METER = "special.clients.input.status";
  public static final String SPECIAL_CLIENTS_OUTPUT_STATUS_METER = "special.clients.output.status";

  // AUX
  public static final String EXTRACT_SENT_METER_PORTAL = "extracts.sent.portal";

  // DIMENSIONS
  public static final String DIMENSION_OUTPUT_CHANNEL = "output.channel";
  public static final String DIMENSION_SENDER_ENTITY = "sender.entity";
  public static final String DIMENSION_UUID_STRUCTURE_ACC = "uuid.structure.acc";
  public static final String DIMENSION_CONTRACT_NUMBER = "contract.number";
  public static final String DIMENSION_ACKNOWLEDGE = "acknowledge";
  public static final String DIMENSION_INPUT_CHANNEL = "input.channel";
  public static final String DIMENSION_PRODUCT_CODE = "product.code";
  public static final String DIMENSION_SUBPRODUCT_CODE = "subproduct.code";
  public static final String DIMENSION_ENTITY_ACCOUNT_ALIAS = "entity.account.alias";
  public static final String DIMENSION_CURRENCY = "currency";
  public static final String DIMENSION_REJECTION_REASON = "rejection.reason";
  public static final String DIMENSION_APPEND = "append";
  public static final String DIMENSION_STATUS = "status";
  public static final String DIMENSION_ACCUMULATED = "accumulated";
  public static final String DIMENSION_BIC_TYPE = "bic.type";
  public static final String DIMENSION_RESEND = "resend";
  public static final String DIMENSION_CLIENT = "client";
  public static final String DIMENSION_CLIENT_CATEGORY = "client.category";
  public static final String DIMENSION_PLANNED = "planned";
  public static final String DIMENSION_REQUEST_ENDPOINT = "request.endpoint";
  public static final String DIMENSION_REQUEST_METHOD = "request.method";
  public static final String DIMENSION_REQUEST_STATUS = "request.status";
  public static final String DIMENSION_SPECIAL_MONITORING = "special.monitoring";

  // VALUES
  public static final String NOT_FOUND = "NOT_FOUND";
  public static final String NON_APPLICABLE = "N/A";

  // HEADER
  public static final String METER_NAME_HEADER = "meter.name";
}
