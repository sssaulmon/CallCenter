package com.isban.gcb.ic.commons.errors;

public class IntegrationException extends RuntimeException {
  private static final long serialVersionUID = -1343260667798562152L;

  private final IntegrationError error;

  public IntegrationException(IntegrationError error) {
    super();
    this.error = error;
  }

  public IntegrationError getError() {
    return error;
  }
}