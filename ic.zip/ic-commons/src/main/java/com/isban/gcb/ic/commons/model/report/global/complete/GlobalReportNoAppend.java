package com.isban.gcb.ic.commons.model.report.global.complete;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.isban.gcb.ic.commons.model.report.global.GlobalMetadata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "globalMetadata",
        "records"
})
public class GlobalReportNoAppend implements Serializable {

    private static final long serialVersionUID = -2722173072678221088L;

    @JsonProperty("globalMetadata")
    protected GlobalMetadata globalMetadata;

    @JsonProperty("records")
    private List<GlobalRecordComplete> records = new ArrayList<>();

    public GlobalReportNoAppend(List<GlobalRecordComplete> records) {
        this.records = records;
    }

    public GlobalReportNoAppend() {
    }

    public GlobalMetadata getGlobalMetadata() { return this.globalMetadata; }

    public void setGlobalMetadata(GlobalMetadata metadata) { this.globalMetadata = metadata; }

    public void addRecord(GlobalRecordComplete record) {
        records.add(record);
    }

    public List<GlobalRecordComplete> getRecords() {
        return this.records;
    }

    public List<GlobalRecordComplete> getReports() {
        return this.records;
    }

    public void setRecords(List<GlobalRecordComplete> records) {
        this.records = records;
    }

    public String toString() {
        return "GlobalReportNoAppend(globalMetadata = " + this.getGlobalMetadata() + ",records=" + this.getRecords() + ")";
    }
}