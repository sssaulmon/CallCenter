package com.isban.gcb.ic.commons.model.downloadapi;

public enum DownloadApiValidationEnum {

  OK("0000", "Validations successfully completed"),
  KO("0001", "Error while executing validations"),
  GROUP_OR_CORPORATE_REQUIRED("0002", "Enterprise group or corporates is required"),
  GROUP_OR_CORPORATE_OR_ACCOUNTS_REQUIRED("0003", "Enterprise group or corporates or accounts is required"),
  DATE_REQUIRED("0004", "Date range or specific date is required"),
  ONLY_ONE_DATE("0005", "Only allowed date range or specific date"),
  NUMBER_REPORTS_REQUIRED("0006", "Number of reports required"),
  CONSISTENCY_GROUP_CORPORATE("0007", "Group and corporate do not match"),
  CONSISTENCY_GROUP_ACCOUNT("0008", "Group and account do not match"),
  CONSISTENCY_GROUP_COUNTRY("0009", "Group and country do not match"),
  CONSISTENCY_GROUP_ENTITY("0010", "Group and entity do not match"),
  CONSISTENCY_GROUP_PRODUCT("0011", "Group and product do not match"),
  CONSISTENCY_GROUP_FORMAT("0012", "Group and format do not match"),
  CONSISTENCY_GROUP_CHANNEL("0013", "Group and channel do not match"),
  CONSISTENCY_CORPORATE_ACCOUNT("0014", "Corporate and account do not match"),
  CONSISTENCY_CORPORATE_COUNTRY("0015", "Corporate and country do not match"),
  CONSISTENCY_CORPORATE_ENTITY("0016", "Corporate and entity do not match"),
  CONSISTENCY_CORPORATE_PRODUCT("0017", "Corporate and product do not match"),
  CONSISTENCY_CORPORATE_FORMAT("0018", "Corporate and format do not match"),
  CONSISTENCY_CORPORATE_CHANNEL("0019", "Corporate and channel do not match"),
  CONSISTENCY_COUNTS_SAME_GROUP("0020", "Accounts must belong to the same corporate group"),
  CONSISTENCY_ENTITY_COUNTRY("0021", "Entity and country do not match"),
  CONSISTENCY_ENTITY_PRODUCT("0022", "Entity and product do not match"),
  CONSISTENCY_PRODUCT_FORMAT("0023", "Product and format do not match"),
  CONSISTENCY_PRODUCT_CHANNEL("0024", "Product and channel do not match");


  private String code;
  private String description;

  DownloadApiValidationEnum(String code, String description) {
    this.code = code;
    this.description = description;
  }

  public String getCode() {
    return code;
  }

  public String getDescription() {
    return description;
  }
}
