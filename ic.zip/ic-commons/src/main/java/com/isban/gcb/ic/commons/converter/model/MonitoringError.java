package com.isban.gcb.ic.commons.converter.model;

import java.io.Serializable;

public class MonitoringError implements Serializable {

  private String code;
  private String title;
  private String message;

  public MonitoringError() {

  }

  public MonitoringError(String code, String title, String message) {
    this.code = code;
    this.title = title;
    this.message = message;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public MonitoringError code(String code) {
    this.code = code;
    return this;
  }

  public MonitoringError title(String title) {
    this.title = title;
    return this;
  }

  public MonitoringError message(String message) {
    this.message = message;
    return this;
  }
}
