package com.isban.gcb.ic.commons.errors;

import java.util.ArrayList;
import java.util.List;

public class IntegrationError {
  private String code;
  private String description;
  private List<String> items;

  public IntegrationError() { items = new ArrayList<>();};

  public IntegrationError(String code, String description) {
    this();
    this.code = code;
    this.description = description;
  }

  public IntegrationError(String code, String description, List<String> items) {
    this(code, description);
    this.items = items;
  }

  public String getCode() {
    return this.code;
  }

  public String getDescription() {
    return this.description;
  }

  public List<String> getItems() {
    return this.items;
  }
}