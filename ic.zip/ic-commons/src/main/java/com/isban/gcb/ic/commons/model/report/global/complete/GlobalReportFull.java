package com.isban.gcb.ic.commons.model.report.global.complete;

import com.isban.gcb.ic.commons.model.report.global.Account;
import com.isban.gcb.ic.commons.model.report.global.GlobalMetadata;
import com.isban.gcb.ic.commons.model.report.global.resend.GlobalReportReSend;

import java.util.Collections;
import java.util.Optional;

public class GlobalReportFull {

  private GlobalReportAppend globalReportAppend;

  private GlobalReportNoAppend globalReportNoAppend;

  private GlobalReportReSend globalReportReSend;

  public GlobalReportFull(GlobalReportAppend globalReportAppend, GlobalReportNoAppend globalReportNoAppend, GlobalReportReSend globalReportReSend) {
    this.globalReportAppend = globalReportAppend;
    this.globalReportNoAppend = globalReportNoAppend;
    this.globalReportReSend = globalReportReSend;
  }

  public GlobalReportFull() {
  }

  public GlobalReportAppend getGlobalReportAppend() {
    return this.globalReportAppend;
  }

  public GlobalReportNoAppend getGlobalReportNoAppend() {
    return this.globalReportNoAppend;
  }

  public GlobalReportReSend getGlobalReportReSend() {
    return this.globalReportReSend;
  }

  public void setGlobalReportAppend(GlobalReportAppend globalReportAppend) {
    this.globalReportAppend = globalReportAppend;
  }

  public void setGlobalReportNoAppend(GlobalReportNoAppend globalReportNoAppend) {
    this.globalReportNoAppend = globalReportNoAppend;
  }

  public void setGlobalReportReSend(GlobalReportReSend globalReportReSend) {
    this.globalReportReSend = globalReportReSend;
  }

  public GlobalReportFull globalReportAppend(GlobalReportAppend globalReportAppend) {
    this.globalReportAppend = globalReportAppend;
    return this;
  }

  public GlobalReportFull globalReportNoAppend(GlobalReportNoAppend globalReportNoAppend) {
    this.globalReportNoAppend = globalReportNoAppend;
    return this;
  }

  public GlobalReportFull globalReportReSend(GlobalReportReSend globalReportReSend) {
    this.globalReportReSend = globalReportReSend;
    return this;
  }

  public GlobalReportFull build() {
    return new GlobalReportFull(globalReportAppend, globalReportNoAppend, globalReportReSend);
  }

  public GlobalMetadata getGlobalMetadata() {
    return Optional.ofNullable(globalReportNoAppend)
      .map(GlobalReportNoAppend::getGlobalMetadata)
      .orElse(Optional.ofNullable(globalReportAppend)
        .map(GlobalReportAppend::getGlobalMetadata)
        .orElse(buildGlobalMetadata(globalReportReSend)));
  }

  private GlobalMetadata buildGlobalMetadata(GlobalReportReSend globalReport) {
    GlobalMetadata metadata = new GlobalMetadata();

    Optional.ofNullable(globalReport)
      .ifPresent(report -> {
        metadata.setContract(report.getContract());
        metadata.setResend(true);
        metadata.setAppend(false);
        metadata.setFormat(report.getFormat());
        metadata.setFrequency(report.getFrequency());
        metadata.setOutputChannel(report.getOutputChannel());
        metadata.setImplementation(report.isImplementation());
        metadata.setGlobalReportVersion(report.getGlobalReportVersion());
        metadata.setRequestAccounts(Collections.singletonList(new Account().account(report.getAccount())));
        metadata.setGlobalReportVersion(report.getGlobalReportVersion());
      });

    return metadata;
  }

  public String toString() {
    return "GlobalReportFull(globalReportAppend=" + this.getGlobalReportAppend() + ", globalReportNoAppend=" + this.getGlobalReportNoAppend() + ", globalReportReSend=" + this.getGlobalReportReSend() + ")";
  }
}