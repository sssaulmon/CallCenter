package com.isban.gcb.ic.commons.mt9X0.enhanced;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "block1",
        "block2",
        "block3",
        "block4",
        "block5",
        "unparsedTexts"
})
public class Message implements Serializable {

    private static final long serialVersionUID = 7085070543541272076L;

    @JsonProperty("block1")
    private Block1 block1;
    @JsonProperty("block2")
    private Block2 block2;
    @JsonProperty("block3")
    private Block3 block3;
    @JsonProperty("block4")
    private Block4 block4;
    @JsonProperty("block5")
    private Block5 block5;
    @JsonProperty("unparsedTexts")
    private UnparsedTexts unparsedTexts;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();

    /**
     * No args constructor for use in serialization
     */
    public Message() {
        /*Empty Constructor*/
    }

    /**
     * @param block1
     * @param block2
     * @param block3
     * @param block4
     * @param unparsedTexts
     */
    public Message(Block1 block1, Block2 block2, Block3 block3, Block4 block4, Block5 block5, UnparsedTexts unparsedTexts) {
        super();
        this.block1 = block1;
        this.block2 = block2;
        this.block3 = block3;
        this.block4 = block4;
        this.block5 = block5;
        this.unparsedTexts = unparsedTexts;
    }

    @JsonProperty("block1")
    public Block1 getBlock1() {
        return block1;
    }

    @JsonProperty("block1")
    public void setBlock1(Block1 block1) {
        this.block1 = block1;
    }

    @JsonProperty("block2")
    public Block2 getBlock2() {
        return block2;
    }

    @JsonProperty("block2")
    public void setBlock2(Block2 block2) {
        this.block2 = block2;
    }

    @JsonProperty("block3")
    public Block3 getBlock3() {
        return block3;
    }

    @JsonProperty("block3")
    public void setBlock3(Block3 block3) {
        this.block3 = block3;
    }

    @JsonProperty("block4")
    public Block4 getBlock4() {
        return block4;
    }

    @JsonProperty("block4")
    public void setBlock4(Block4 block4) {
        this.block4 = block4;
    }

    @JsonProperty("block5")
    public Block5 getBlock5() {
        return block5;
    }

    @JsonProperty("block5")
    public void setBlock5(Block5 block5) {
        this.block5 = block5;
    }

    @JsonProperty("unparsedTexts")
    public UnparsedTexts getUnparsedTexts() {
        return unparsedTexts;
    }

    @JsonProperty("unparsedTexts")
    public void setUnparsedTexts(UnparsedTexts unparsedTexts) {
        this.unparsedTexts = unparsedTexts;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public String toSwiftMessage() {


        String result = "";

        if (this.getBlock1() != null)
            result += this.getBlock1().toSwiftMessage();
        if (this.getBlock2() != null)
            result += this.getBlock2().toSwiftMessage();
        if (this.getBlock3() != null)
            result += this.getBlock3().toSwiftMessage();
        if (this.getBlock4() != null)
            result += this.getBlock4().toSwiftMessage();
        if (this.getBlock5() != null)
            result += this.getBlock5().toSwiftMessage();
        return result;
    }
    
    public String toSwiftFinMessage() {
        String result = "";

        if (this.getBlock1() != null)
            result += this.getBlock1().toSwiftMessage();
        if (this.getBlock2() != null)
            result += this.getBlock2().toSwiftMessage();
        if (this.getBlock3() != null)
            result += this.getBlock3().toSwiftMessage();
        if (this.getBlock4() != null)
            result += this.getBlock4().toSwiftFinMessage();
        if (this.getBlock5() != null)
            result += this.getBlock5().toSwiftMessage();
        return result;
    }
}
