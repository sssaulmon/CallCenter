package com.isban.gcb.ic.commons.model.report.global;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "outputChannel",
        "frequency",
        "format",
        "contract",
        "outputFormatID",
        "totalPagesPerRequestForAllAccounts",
        "append",
        "requestAccounts",
        "stp",
        "implementation",
        "globalReportVersion"
})
public class GlobalMetadata implements Serializable {

    private static final long serialVersionUID = -7719691856333043227L;

    @JsonProperty("outputChannel")
    private String outputChannel;

    @JsonProperty("frequency")
    private String frequency;

    @JsonProperty("format")
    private String format;

    @JsonProperty("contract")
    private String contract;

    @JsonProperty("outputFormatID")
    private String outputFormatID;

    @JsonProperty("totalPagesPerRequestForAllAccounts")
    private Integer totalPagesPerRequestForAllAccounts;

    @JsonProperty("append")
    private Boolean append;

    @JsonProperty("resend")
    private Boolean resend;

    @JsonProperty("stp")
    private Boolean stp;

    @JsonProperty("implementation")
    private Boolean implementation;

    @JsonProperty("globalReportVersion")
    private String globalReportVersion;

    @JsonProperty("requestAccounts")
    private List<Account> requestAccounts = new ArrayList<>();

    @JsonProperty("sendId")
    private String sendId;

    public GlobalMetadata(String outputChannel, String frequency, String format, String contract, String outputFormatID, Integer totalPagesPerRequestForAllAccounts, Boolean append, Boolean resend, Boolean stp, Boolean implementation, String globalReportVersion, List<Account> requestAccounts, String sendId) {
        this.outputChannel = outputChannel;
        this.frequency = frequency;
        this.format = format;
        this.contract = contract;
        this.outputFormatID = outputFormatID;
        this.totalPagesPerRequestForAllAccounts = totalPagesPerRequestForAllAccounts;
        this.append = append;
        this.resend = resend;
        this.stp = stp;
        this.implementation = implementation;
        this.globalReportVersion = globalReportVersion;
        this.requestAccounts = requestAccounts;
        this.sendId = sendId;
    }

    public GlobalMetadata() {
    }

    public Boolean isAppend() {
        return this.append != null && this.append;
    }

    public String getOutputChannel() {
        return this.outputChannel;
    }

    public String getFrequency() {
        return this.frequency;
    }

    public String getFormat() {
        return this.format;
    }

    public String getContract() {
        return this.contract;
    }

    public String getOutputFormatID() {
        return this.outputFormatID;
    }

    public Integer getTotalPagesPerRequestForAllAccounts() {
        return this.totalPagesPerRequestForAllAccounts;
    }

    public Boolean getAppend() {
        return this.append;
    }

    public Boolean isResend() {
        return this.resend != null && this.resend;
    }

    public Boolean getResend() {
        return this.resend;
    }

    public Boolean isStp() {
        return this.stp != null && this.stp;
    }

    public Boolean getStp() {
        return this.stp;
    }

    public Boolean isImplementation() {
        return this.implementation != null && this.implementation;
    }

    public Boolean getImplementation() {
        return this.implementation;
    }

    public String getGlobalReportVersion() {
        return this.globalReportVersion;
    }

    public List<Account> getRequestAccounts() {
        return this.requestAccounts;
    }

    public String getSendId() {
        return this.sendId;
    }

    public void setOutputChannel(String outputChannel) {
        this.outputChannel = outputChannel;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public void setContract(String contract) {
        this.contract = contract;
    }

    public void setOutputFormatID(String outputFormatID) {
        this.outputFormatID = outputFormatID;
    }

    public void setTotalPagesPerRequestForAllAccounts(Integer totalPagesPerRequestForAllAccounts) {
        this.totalPagesPerRequestForAllAccounts = totalPagesPerRequestForAllAccounts;
    }

    public void setAppend(Boolean append) {
        this.append = append;
    }

    public void setResend(Boolean resend) {
        this.resend = resend;
    }

    public void setStp(Boolean stp) {
        this.stp = stp;
    }

    public void setImplementation(Boolean implementation) {
        this.implementation = implementation;
    }

    public void setGlobalReportVersion(String globalReportVersion) {
        this.globalReportVersion = globalReportVersion;
    }

    public void setRequestAccounts(List<Account> requestAccounts) {
        this.requestAccounts = requestAccounts;
    }

    public void setSendId(String sendId) {
        this.sendId = sendId;
    }

    public String toString() {
        return "GlobalMetadata(outputChannel=" + this.getOutputChannel() + ", frequency=" + this.getFrequency()
          + ", format=" + this.getFormat() + ", contract=" + this.getContract() + ", outputFormatID="
          + this.getOutputFormatID() + ", totalPagesPerRequestForAllAccounts=" + this.getTotalPagesPerRequestForAllAccounts()
          + ", append=" + this.getAppend() + ", resend=" + this.isResend() + ", stp=" + this.getStp() + ", implementation="
          + this.getImplementation() + ", globalReportVersion=" + this.getGlobalReportVersion() + ", requestAccounts="
          + this.getRequestAccounts() + ", sendId=" + this.getSendId() + ")";
    }
}