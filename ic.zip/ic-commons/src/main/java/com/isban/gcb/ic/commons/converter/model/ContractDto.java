package com.isban.gcb.ic.commons.converter.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

public class ContractDto implements Cloneable {
  private String contractNumber;
  private String sendChannel;
  private String outputFormat;
  private String outputFormatSubtype;
  private String outputChannelUuid;
  private String customization;
  private String activationDate;
  private String serviceSendFrequency;
  private String aliasEntity;
  private String aliasClientAccount;
  private String aliasClientMasterAccount;
  private String aliasClientGroup;
  private String uuidStructureAcc;
  private String accountUuid;
  private String accountInternational;
  private Boolean stp;
  private Boolean implementation;
  private Boolean needsBicSicSend;
  private Boolean endToEndCustomization;
  private Boolean customCurCnyToCnh;
  private Boolean noSCFCustomization;
  private Boolean unsignedBalanceBAI;
  private Boolean singleBalanceBAI;
  private Boolean camt053StandardCodes;
  private Boolean master;
  private String uuidBusinessGroup;
  private String serviceTypeUuid;
  private List<String> addresses;
  private Boolean hasN43CorporateInAlias;

  public ContractDto(String contractNumber, String sendChannel, String outputFormat, String outputFormatSubtype,
                     String outputChannelUuid, String customization, String activationDate, String serviceSendFrequency,
                     String aliasEntity, String aliasClientAccount, String aliasClientGroup, String uuidStructureAcc,
                     String accountUuid, String accountInternational, Boolean stp, Boolean implementation,
                     Boolean needsBicSicSend, Boolean endToEndCustomization, Boolean customCurCnyToCnh, String uuidBusinessGroup,
                     Boolean noSCFCustomization, Boolean unsignedBalanceBAI, String lastGlobalReportSent,
                     List<String> addresses, Boolean hasN43CorporateInAlias) {
    this.contractNumber = contractNumber;
    this.sendChannel = sendChannel;
    this.outputFormat = outputFormat;
    this.outputFormatSubtype = outputFormatSubtype;
    this.outputChannelUuid = outputChannelUuid;
    this.customization = customization;
    this.activationDate = activationDate;
    this.serviceSendFrequency = serviceSendFrequency;
    this.aliasEntity = aliasEntity;
    this.aliasClientAccount = aliasClientAccount;
    this.aliasClientGroup = aliasClientGroup;
    this.uuidStructureAcc = uuidStructureAcc;
    this.accountInternational = accountInternational;
    this.accountUuid = accountUuid;
    this.stp = stp;
    this.implementation = implementation;
    this.needsBicSicSend = needsBicSicSend;
    this.endToEndCustomization = endToEndCustomization;
    this.customCurCnyToCnh = customCurCnyToCnh;
    this.uuidBusinessGroup = uuidBusinessGroup;
    this.unsignedBalanceBAI = unsignedBalanceBAI;
    this.noSCFCustomization = noSCFCustomization;
    this.addresses = addresses;
    this.hasN43CorporateInAlias = hasN43CorporateInAlias;
  }

  @Override
  public ContractDto clone() {
    return new ContractDto()
      .contractNumber(this.getContractNumber())
      .sendChannel(this.getSendChannel())
      .outputFormat(this.getOutputFormat())
      .outputFormatSubtype(this.getOutputFormatSubtype())
      .outputChannelUuid(this.getOutputChannelUuid())
      .customization(this.getCustomization())
      .activationDate(this.getActivationDate())
      .serviceSendFrequency(this.getServiceSendFrequency())
      .aliasEntity(this.getAliasEntity())
      .aliasClientAccount(this.getAliasClientAccount())
      .aliasClientMasterAccount(this.getAliasClientMasterAccount())
      .aliasClientGroup(this.getAliasClientGroup())
      .uuidStructureAcc(this.getUuidStructureAcc())
      .accountInternational(this.getAccountInternational())
      .accountUuid(this.getAccountUuid())
      .stp(this.stp)
      .implementation(this.implementation)
      .needsBicSicSend(this.needsBicSicSend)
      .endToEndCustomization(this.endToEndCustomization)
      .customCurCnyToCnh(this.customCurCnyToCnh)
      .uuidBusinessGroup(this.uuidBusinessGroup)
      .noSCFCustomization(this.noSCFCustomization)
      .unsignedBalanceBAI(this.unsignedBalanceBAI)
      .singleBalanceBAI(singleBalanceBAI)
      .camt053StandardCodes(camt053StandardCodes)
      .master(this.master)
      .serviceTypeUuid(serviceTypeUuid)
      .addresses(new ArrayList<>(this.getAddresses()))
      .hasN43CorporateInAlias(this.hasN43CorporateInAlias);
  }

  public ContractDto() {
  }

  public ContractDto contractNumber(String contractNumber) {
    this.contractNumber = contractNumber;
    return this;
  }

  public ContractDto sendChannel(String sendChannel) {
    this.sendChannel = sendChannel;
    return this;
  }

  public ContractDto outputFormat(String outputFormatUuid) {
    this.outputFormat = outputFormatUuid;
    return this;
  }

  public ContractDto outputFormatSubtype(String outputFormatSubtype) {
    this.outputFormatSubtype = outputFormatSubtype;
    return this;
  }

  public ContractDto outputChannelUuid(String outputChannelUuid) {
    this.outputChannelUuid = outputChannelUuid;
    return this;
  }

  public ContractDto customization(String customization) {
    this.customization = customization;
    return this;
  }

  public ContractDto activationDate(String activationDate) {
    this.activationDate = activationDate;
    return this;
  }

  public ContractDto serviceSendFrequency(String serviceSendFrequency) {
    this.serviceSendFrequency = serviceSendFrequency;
    return this;
  }

  public ContractDto aliasEntity(String alias) {
    this.aliasEntity = alias;
    return this;
  }

  public ContractDto aliasClientAccount(String alias) {
    this.aliasClientAccount = alias;
    return this;
  }

  public ContractDto aliasClientGroup(String alias) {
    this.aliasClientGroup = alias;
    return this;
  }

  public ContractDto uuidStructureAcc(String uuidStructureAcc) {
    this.uuidStructureAcc = uuidStructureAcc;
    return this;
  }

  public ContractDto accountInternational(String account) {
    this.accountInternational = account;
    return this;
  }

  public ContractDto accountUuid(String uuid) {
    this.accountUuid = uuid;
    return this;
  }

  public ContractDto implementation(Boolean implementation) {
    this.implementation = implementation;
    return this;
  }

  public ContractDto endToEndCustomization(Boolean customization) {
    this.endToEndCustomization = customization;
    return this;
  }

  public ContractDto customCurCnyToCnh(Boolean customCurCnyToCnh) {
    this.customCurCnyToCnh = customCurCnyToCnh;
    return this;
  }

  public ContractDto needsBicSicSend(Boolean bicSicSend) {
    this.needsBicSicSend = bicSicSend;
    return this;
  }

  public ContractDto uuidBusinessGroup(String uuid) {
    this.uuidBusinessGroup = uuid;
    return this;
  }

  public ContractDto addresses(List<String> addresses) {
    this.addresses = addresses;
    return this;
  }

  public ContractDto stp(Boolean stp) {
    this.stp = stp;
    return this;
  }

  public ContractDto noSCFCustomization(Boolean noSCFCustomization) {
    this.noSCFCustomization = noSCFCustomization;
    return this;
  }

  public ContractDto unsignedBalanceBAI(Boolean unsignedBalanceBAI) {
    this.unsignedBalanceBAI = unsignedBalanceBAI;
    return this;
  }

  public ContractDto singleBalanceBAI(Boolean singleBalanceBAI) {
    this.singleBalanceBAI = singleBalanceBAI;
    return this;
  }

  public ContractDto camt053StandardCodes(Boolean camt053StandardCodes) {
    this.camt053StandardCodes = camt053StandardCodes;
    return this;
  }

  public ContractDto aliasClientMasterAccount(String aliasClientMasterAccount) {
    this.aliasClientMasterAccount = aliasClientMasterAccount;
    return this;
  }

  public ContractDto master(Boolean master) {
    this.master = master;
    return this;
  }

  public ContractDto serviceTypeUuid(String serviceTypeUuid) {
    this.serviceTypeUuid = serviceTypeUuid;
    return this;
  }

  public ContractDto hasN43CorporateInAlias(Boolean hasN43CorporateInAlias) {
    this.hasN43CorporateInAlias = hasN43CorporateInAlias;
    return this;
  }

  public String getContractNumber() {
    return this.contractNumber;
  }

  public String getSendChannel() {
    return this.sendChannel;
  }

  public String getOutputFormat() {
    return this.outputFormat;
  }

  public String getOutputFormatSubtype() {
    return outputFormatSubtype;
  }

  public String getOutputChannelUuid() {
    return this.outputChannelUuid;
  }

  public String getCustomization() {
    return this.customization;
  }

  public String getActivationDate() {
    return this.activationDate;
  }

  public String getServiceSendFrequency() {
    return this.serviceSendFrequency;
  }

  public String getAliasEntity() {
    return this.aliasEntity;
  }

  public String getAliasClientAccount() {
    return this.aliasClientAccount;
  }

  public String getAliasClientGroup() {
    return this.aliasClientGroup;
  }

  public String getUuidStructureAcc() {
    return this.uuidStructureAcc;
  }

  public String getAccountInternational() {
    return this.accountInternational;
  }

  public String getAccountUuid() {
    return this.accountUuid;
  }

  public String getUuidBusinessGroup() {
    return this.uuidBusinessGroup;
  }

  @JsonProperty("isStp")
  public Boolean isStp() {
    return this.stp;
  }

  @JsonProperty("implementation")
  public Boolean isImplementation() {
    return this.implementation;
  }

  @JsonProperty("needsBicSicSend")
  public Boolean isNeedsBicSicSend() {
    return this.needsBicSicSend;
  }

  @JsonProperty("endToEndCustomization")
  public Boolean isEndToEndCustomization() {
    return this.endToEndCustomization;
  }

  @JsonProperty("customCurCnyToCnh")
  public Boolean isCustomCurCnyToCnh() {
    return this.customCurCnyToCnh;
  }

  @JsonProperty("noSCFCustomization")
  public Boolean isNoSCFCustomization() {
    return noSCFCustomization;
  }

  @JsonProperty("unsignedBalanceBAI")
  public Boolean isUnsignedBalanceBAI() {
    return unsignedBalanceBAI;
  }

  @JsonProperty("singleBalanceBAI")
  public Boolean isSingleBalanceBAI() {
    return singleBalanceBAI;
  }

  @JsonProperty("camt053StandardCodes")
  public Boolean isCamt053StandardCodes() {
    return camt053StandardCodes;
  }

  @JsonProperty("hasN43CorporateInAlias")
  public Boolean isN43CorporateInAlias() {
    return hasN43CorporateInAlias;
  }

  public String getAliasClientMasterAccount() {
    return aliasClientMasterAccount;
  }

  public Boolean getMaster() {
    return master;
  }

  public String getServiceTypeUuid() {
    return serviceTypeUuid;
  }

  public List<String> getAddresses() {
    return this.addresses;
  }

  public void setContractNumber(String contractNumber) {
    this.contractNumber = contractNumber;
  }

  public void setSendChannel(String sendChannel) {
    this.sendChannel = sendChannel;
  }

  public void setOutputFormat(String outputFormat) {
    this.outputFormat = outputFormat;
  }

  public void setOutputFormatSubtype(String outputFormatSubtype) {
    this.outputFormatSubtype = outputFormatSubtype;
  }

  public void setOutputChannelUuid(String outputChannelUuid) {
    this.outputChannelUuid = outputChannelUuid;
  }

  public void setCustomization(String customization) {
    this.customization = customization;
  }

  public void setActivationDate(String activationDate) {
    this.activationDate = activationDate;
  }

  public void setServiceSendFrequency(String serviceSendFrequency) {
    this.serviceSendFrequency = serviceSendFrequency;
  }

  public void setAliasEntity(String aliasEntity) {
    this.aliasEntity = aliasEntity;
  }

  public void setAliasClientAccount(String alias) {
    this.aliasClientAccount = alias;
  }

  public void setAliasClientGroup(String alias) {
    this.aliasClientGroup = alias;
  }

  public void setUuidStructureAcc(String uuidStructureAcc) {
    this.uuidStructureAcc = uuidStructureAcc;
  }

  public void setAccountInternational(String account) {
    this.accountInternational = account;
  }

  public void setAccountUuid(String uuid) {
    this.accountUuid = uuid;
  }

  public void setUuidBusinessGroup(String uuid) {
    this.uuidBusinessGroup = uuid;
  }

  @JsonProperty("isStp")
  public void setIsStp(Boolean stp) {
    this.stp = stp;
  }

  @JsonProperty("implementation")
  public void setImplementation(Boolean implementation) {
    this.implementation = implementation;
  }

  @JsonProperty("needsBicSicSend")
  public void setNeedsBicSend(Boolean bicSicSend) {
    this.needsBicSicSend = bicSicSend;
  }

  @JsonProperty("endToEndCustomization")
  public void setEndToEndCustomization(Boolean endToEndCustomization) {
    this.endToEndCustomization = endToEndCustomization;
  }

  @JsonProperty("customCurCnyToCnh")
  public void setCustomCurCnyToCnh(Boolean customCurCnyToCnh) {
    this.customCurCnyToCnh = customCurCnyToCnh;
  }

  public void setAddresses(List<String> addresses) {
    this.addresses = addresses;
  }

  public void setHasN43CorporateInAlias(Boolean hasN43CorporateInAlias) {
    this.hasN43CorporateInAlias = hasN43CorporateInAlias;
  }


  @Override
  public String toString() {
    return "ContractDto(" +
      "contractNumber=" + this.getContractNumber() + ", " +
      "sendChannel=" + this.getSendChannel() + ", " +
      "outputFormat=" + this.getOutputFormat() + ", " +
      "outputFormatSubtype=" + this.getOutputFormatSubtype() + ", " +
      "outputChannelUuid=" + this.getOutputChannelUuid() + ", " +
      "customization=" + this.getCustomization() + ", " +
      "activationDate=" + this.getActivationDate() + ", " +
      "serviceSendFrequency=" + this.getServiceSendFrequency() + ", " +
      "aliasEntity=" + this.getAliasEntity() + ", " +
      "aliasClientAccount=" + this.getAliasClientAccount() + ", " +
      "aliasClientMasterAccount=" + getAliasClientMasterAccount() + ", " +
      "aliasClientGroup=" + this.getAliasClientGroup() + ", " +
      "isStp= " + this.isStp() + ", " +
      "uuidStructureAcc=" + this.getUuidStructureAcc() + ", " +
      "accountInternational=" + this.getAccountInternational() + ", " +
      "accountUuid=" + this.getAccountUuid() + ", " +
      "uuidBusinessGroup=" + this.getUuidBusinessGroup() + ", " +
      "implementation= " + this.isImplementation() + ", " +
      "needsBicSicSend= " + this.isNeedsBicSicSend() + ", " +
      "noSCFCustomization= " + this.isNoSCFCustomization() + ", " +
      "unsignedBalanceBAI= " + this.isUnsignedBalanceBAI() + ", " +
      "singleBalanceBAI= " + singleBalanceBAI + ", " +
      "camt053StandardCodes= " + camt053StandardCodes + ", " +
      "master= " + getMaster() + ", " +
      "serviceTypeUuid= " + serviceTypeUuid + ", " +
      "this.addresses=" + this.getAddresses() + ", " +
      "hasN43CorporateInAlias= " + hasN43CorporateInAlias +
      ")";
  }
}