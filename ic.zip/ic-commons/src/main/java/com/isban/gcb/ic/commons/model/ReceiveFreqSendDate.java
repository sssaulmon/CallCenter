package com.isban.gcb.ic.commons.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * A ReceiveFreqSendDate.
 */
@Entity
@Table(name = "receive_freq_send_date",
        indexes = {@Index(columnList = "uuid", name = "uuid_receive_freq_send_date")})
public class ReceiveFreqSendDate extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "receive_freq_send_date_gen")
    @SequenceGenerator(name = "receive_freq_send_date_gen",
            sequenceName = "rec_freq_send_date_generator", allocationSize = 1)
    private Long id;

    @Size(max = 100)
    @Column(name = "description", length = 100)
    private String description;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Size(max = 20)
    @Column(name = "last_modified_user", length = 20)
    private String lastModifiedUser;

    @Size(max = 40)
    @Column(name = "uuid", length = 40)
    private String uuid;

    @OneToMany(mappedBy = "receiveFreqSendDate")
    @JsonIgnore
    private Set<ReceiveFreqDaily> idReciveFreqSendDates = new HashSet<>();


    private Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ReceiveFreqSendDate description(String description) {
        this.description = description;
        return this;
    }

    private LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public ReceiveFreqSendDate endDate(LocalDate endDate) {
        this.endDate = endDate;
        return this;
    }

    private String getLastModifiedUser() {
        return lastModifiedUser;
    }

    public void setLastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
    }

    public ReceiveFreqSendDate lastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
        return this;
    }

    public Set<ReceiveFreqDaily> getIdReciveFreqSendDates() {
        return idReciveFreqSendDates;
    }

    public void setIdReciveFreqSendDates(Set<ReceiveFreqDaily> receiveFreqDailies) {
        this.idReciveFreqSendDates = receiveFreqDailies;
    }

    public ReceiveFreqSendDate idReciveFreqSendDates(Set<ReceiveFreqDaily> receiveFreqDailies) {
        this.idReciveFreqSendDates = receiveFreqDailies;
        return this;
    }

    public ReceiveFreqSendDate addIdReciveFreqSendDate(ReceiveFreqDaily receiveFreqDaily) {
        this.idReciveFreqSendDates.add(receiveFreqDaily);
        receiveFreqDaily.setReceiveFreqSendDate(this);
        return this;
    }

    public ReceiveFreqSendDate removeIdReciveFreqSendDate(ReceiveFreqDaily receiveFreqDaily) {
        this.idReciveFreqSendDates.remove(receiveFreqDaily);
        receiveFreqDaily.setReceiveFreqSendDate(null);
        return this;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ReceiveFreqSendDate receiveFreqSendDate = (ReceiveFreqSendDate) o;
        if (receiveFreqSendDate.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), receiveFreqSendDate.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "ReceiveFreqSendDate{" + "id=" + getId() + ", description='" + getDescription() + "'"
                + ", createDate='" + getCreateDate() + "'" + ", endDate='" + getEndDate() + "'"
                + ", lastModifiedDate='" + getLastModifiedDate() + "'" + ", lastModifiedUser='"
                + getLastModifiedUser() + "'" + "}";
    }
}
