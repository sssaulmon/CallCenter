package com.isban.gcb.ic.commons.xml;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.util.Optional;

public class EBCDICAdapter extends XmlAdapter<String, String>{

	private static final String EBCDIC_REGEX="[^a-zA-Z0-9/\\-?:().,'+{}\\r\\n\\f\\s]";

	@Override
	public String unmarshal(String value) {
		return Optional.ofNullable(value)
			.map(val -> val.replaceAll(EBCDIC_REGEX, " "))
			.orElse(null);
	}

	@Override
	public String marshal(String value) {
		return value;
	}

}
