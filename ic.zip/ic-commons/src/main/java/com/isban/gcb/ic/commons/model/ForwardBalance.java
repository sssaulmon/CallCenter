package com.isban.gcb.ic.commons.model;


import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.isban.gcb.ic.commons.util.DateTimeUtils;
import com.prowidesoftware.swift.model.field.Field65;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "forward_balance")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ForwardBalance extends AuditableLocalDateTime implements Serializable {

    private static final long serialVersionUID = 6021382235586980754L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Size(max = 2)
    @Column(nullable = false)
    private String mark;

    @NotNull
    @Column(name = "fw_date", nullable = false)
    private LocalDate date;

    @Column(nullable = false, columnDefinition = "NUMBER(16,3)")
    private Double amount;

    @JsonBackReference
    @ManyToOne
    @JoinColumn(name = "extract_id")
    private Extract extract;

    public ForwardBalance(Field65 field65) {
        this.mark = field65.getDCMark().substring(0, 1);
        this.date = DateTimeUtils.parseToLocalDate(field65.getDate());
        this.amount = Double.parseDouble(field65.getAmount().replace(',', '.'));
    }

    public static ForwardBalance newInstanceFrom(ForwardBalance original, Extract extract) {
        ForwardBalance forwardBalance = new ForwardBalance();
        forwardBalance.setMark(original.getMark());
        forwardBalance.setDate(original.getDate());
        forwardBalance.setAmount(original.getAmount());
        forwardBalance.setExtract(extract);
        return forwardBalance;
    }
    
    @Override
    public String toString() {
        return "ForwardBalance{" + "id=" + id + ", mark=" + mark + ", date=" + date + ", amount="
                + amount + ", createdDate=" + getCreateDate() + ", lastModifiedDate="
                + getLastModifiedDate() + '}';
    }
}
