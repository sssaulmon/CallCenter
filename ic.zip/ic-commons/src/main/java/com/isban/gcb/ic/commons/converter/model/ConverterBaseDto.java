package com.isban.gcb.ic.commons.converter.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ConverterBaseDto {

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String regType;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String countryCode;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private AccountDto accountDto;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String currency;

  @Override
  public String toString() {
    return regType + countryCode + accountDto + currency;
  }

  @Override
  public boolean equals(Object o) {

    if (o == this) return true;
    if (!(o instanceof ConverterBaseDto)) {
      return false;
    }
    ConverterBaseDto instance2 = (ConverterBaseDto) o;

    return regType.equals(instance2.getRegType())
      && countryCode.equals(instance2.getCountryCode())
      && Objects.equals(accountDto, instance2.getAccountDto())
      && currency.equals(instance2.getCurrency());

  }

  @Override
  public int hashCode() {

    return Objects.hash(regType, countryCode, accountDto, currency);
  }

  public void reset() {
    this.regType = null;
    this.countryCode = null;
    this.currency = null;
    this.accountDto = null;
  }
}