package com.isban.gcb.ic.commons.model.downloadapi;

public class DownloadZIPHttpResponse extends IntegrationResponseBase<DownloadZipInfoDto> {

  public DownloadZIPHttpResponse(String codeResponse, String description, DownloadZipInfoDto data) {
    super(codeResponse, description, data);
  }
}