package com.isban.gcb.ic.commons.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;

@Entity
@Table(name = "currency")
public class Currency implements Serializable {

  private static final long serialVersionUID = -3209326456881013424L;

  @Id
  private String id;

  @NotBlank
  @Column(name = "name")
  private String name;

  @NotBlank
  @Column(name = "decimals")
  private String decimals;

  public Currency() {

  }

  public Currency(String id, String name, String decimals) {
    this.id = id;
    this.name = name;
    this.decimals = decimals;
  }

  public String getCurrencyId() {
    return this.id;
  }

  public void setCurrencyId(String id) {
    this.id = id;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDecimals() {
    return this.decimals;
  }

  public void setDecimals(String decimals) {
    this.decimals = decimals;
  }

  @Override
  public boolean equals(Object o) {

    if (this == o) {
      return true;
    }

    return Optional.ofNullable(o)
      .filter(object -> this.getClass() == object.getClass())
      .map(Currency.class::cast)
      .filter(object -> Objects.equals(getCurrencyId(), object.getCurrencyId()))
      .map(object -> Boolean.TRUE)
      .orElse(Boolean.FALSE);

  }

  @Override
  public int hashCode() {
    return Objects.hashCode(getCurrencyId());
  }

  @Override
  public String toString() {
    return "Currency{" + "id=" + getCurrencyId() + ", name='" + getName() + "'" + ", decimals='" + getDecimals() + "}";
  }


}


