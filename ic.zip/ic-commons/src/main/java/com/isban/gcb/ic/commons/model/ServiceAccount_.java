package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(ServiceAccount.class)
public abstract class ServiceAccount_ extends com.isban.gcb.ic.commons.model.AuditableLocalDate_ {

	public static volatile SingularAttribute<ServiceAccount, AssoCorpSubProductAcc> assoCorpSubProductAcc;
	public static volatile SingularAttribute<ServiceAccount, LocalDate> endDate;
	public static volatile SingularAttribute<ServiceAccount, Service> service;
	public static volatile SingularAttribute<ServiceAccount, String> lastModifiedUser;
	public static volatile SingularAttribute<ServiceAccount, Long> id;
	public static volatile SingularAttribute<ServiceAccount, String> aliasAccClient;
	public static volatile SingularAttribute<ServiceAccount, String> uuid;
	public static volatile SingularAttribute<ServiceAccount, String> accountSendHours;

	public static final String ASSO_CORP_SUB_PRODUCT_ACC = "assoCorpSubProductAcc";
	public static final String END_DATE = "endDate";
	public static final String SERVICE = "service";
	public static final String LAST_MODIFIED_USER = "lastModifiedUser";
	public static final String ID = "id";
	public static final String ALIAS_ACC_CLIENT = "aliasAccClient";
	public static final String UUID = "uuid";
	public static final String ACCOUNT_SEND_HOURS = "accountSendHours";

}

