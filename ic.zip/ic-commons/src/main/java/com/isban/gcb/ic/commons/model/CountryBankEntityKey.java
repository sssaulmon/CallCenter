package com.isban.gcb.ic.commons.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;

@Embeddable
public class CountryBankEntityKey implements Serializable {

  @Pattern(regexp = "[A-Z]{11}")
  private String bic;

  @Pattern(regexp = "[A-Z]{2}")
  @Column(name = "country_code")
  private String countryCode;

  @Min(0)
  @Max(99)
  @Column(name = "bank_code")
  private Integer bankCode;

  public CountryBankEntityKey() {
  }

  public CountryBankEntityKey(String bic, String countryCode, Integer bankCode) {
    this.bic = bic;
    this.countryCode = countryCode;
    this.bankCode = bankCode;
  }

  public String getBic() {
    return this.bic;
  }

  public void setBic(String bic) {
    this.bic = bic;
  }

  public String getCountryCode() {
    return this.countryCode;
  }

  public void setCountryCode(String code) {
    this.countryCode = code;
  }

  public Integer getBankCode() {
    return this.bankCode;
  }

  public void setBankCode(Integer code) {
    this.bankCode = code;
  }

  @Override
  public boolean equals(Object o) {

    if (this == o) {
      return true;
    }

    return Optional.ofNullable(o)
      .filter(object -> this.getClass() == object.getClass())
      .map(CountryBankEntityKey.class::cast)
      .filter(object -> Objects.equals(getBic(), object.getBic()))
      .filter(object -> Objects.equals(getBankCode(), object.getBankCode()))
      .filter(object -> Objects.equals(getCountryCode(), object.getCountryCode()))
      .map(object -> Boolean.TRUE)
      .orElse(Boolean.FALSE);

  }

  @Override
  public int hashCode() {
    return Objects.hashCode(getBic() + getBankCode() + getCountryCode());
  }

  @Override
  public String toString() {
    return "CountryBankEntityKey {bic=" + this.getBic() + ", countryCode=" + this.getCountryCode() + ", bankCode=" + this.getBankCode();
  }

}

