package com.isban.gcb.ic.commons.converter.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SummaryHeaderSwf0 {

  /**
   * Tipo registro (01)
   * <p>
   * 0 = Resumen
   * 1 = Cabecera
   * 2 = Detalle de movimientos
   */
  private String regType;

  /**
   * Codigo del pais (03)
   * <p>
   * PRI = Puerto Rico
   * 052 = Mexico
   * 080 = Argentina
   * 997 = Chile
   */
  private String countryCode;

  /**
   * Datos de la cuenta
   */
  private AccountDto accountDto;

  /**
   * Divisa (03)
   */
  private String currency;

  /**
   * Registro
   */
  private RegistryDto registryDto;


  @Override
  public String toString() {
    return regType + countryCode + accountDto + currency + registryDto;
  }

  @Override
  public boolean equals(Object o) {

    if (o == this) return true;
    if (!(o instanceof SummaryHeaderSwf0)) {
      return false;
    }
    SummaryHeaderSwf0 instance2 = (SummaryHeaderSwf0) o;

    return regType.equals(instance2.getRegType())
      && countryCode.equals(instance2.getCountryCode())
      && accountDto.equals(instance2.getAccountDto())
      && currency.equals(instance2.getCurrency())
      && registryDto.equals(instance2.getRegistryDto());

  }

  @Override
  public int hashCode() {

    return Objects.hash(regType, countryCode, accountDto, currency, registryDto);
  }
}
