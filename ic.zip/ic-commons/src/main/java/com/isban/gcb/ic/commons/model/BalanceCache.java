package com.isban.gcb.ic.commons.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import static javax.persistence.GenerationType.SEQUENCE;

@Table(name = "balance_cache")
@Entity
public class BalanceCache extends AuditableLocalDateTime implements Serializable {

  private static final long serialVersionUID = -911681736597284135L;

  @Id
  @GeneratedValue(strategy = SEQUENCE, generator = "BALANCE_CACHE_GENERATOR")
  @SequenceGenerator(name = "BALANCE_CACHE_GENERATOR", sequenceName = "BALANCE_CACHE_SEQ", allocationSize = 1)
  private Long id;
  @Column(name = "bic")
  private String bic;
  @Column(name = "account_code")
  private String accountCode;
  @Column(name = "currency")
  private String currency;
  @Column(name = "balance_type")
  private String balanceType;
  @Column(name = "accounting_date")
  private LocalDateTime accountingDate;
  @Column(name = "opening_mark")
  private String openingMark;
  @Column(name = "opening_date")
  private LocalDateTime openingDate;
  @Column(name = "opening_amount")
  private BigDecimal openingAmount;
  @Column(name = "closing_mark")
  private String closingMark;
  @Column(name = "closing_date")
  private LocalDateTime closingDate;
  @Column(name = "closing_amount")
  private BigDecimal closingAmount;
  @Column(name = "available_mark")
  private String availableMark;
  @Column(name = "available_date")
  private LocalDateTime availableDate;
  @Column(name = "available_amount")
  private BigDecimal availableAmount;
  @ManyToOne
  @JoinColumn(name = "extract_id", referencedColumnName = "id")
  @JsonBackReference
  private Extract extract;
  @Column(name = "transactions")
  private boolean transactions;
  @Column(name = "best_transactions")
  private boolean bestTransactions;
  @Column(name = "information")
  private String information;
  @Column(name = "status")
  private String status;

  //for hibernate
  public BalanceCache() {
    super();
  }

  public Long getId() {
    return id;
  }

  public String getBic() {
    return bic;
  }

  public String getAccountCode() {
    return accountCode;
  }

  public String getCurrency() {
    return currency;
  }

  public String getBalanceType() {
    return balanceType;
  }

  public LocalDateTime getAccountingDate() {
    return accountingDate;
  }

  public String getOpeningMark() {
    return openingMark;
  }

  public LocalDateTime getOpeningDate() {
    return openingDate;
  }

  public BigDecimal getOpeningAmount() {
    return openingAmount;
  }

  public String getClosingMark() {
    return closingMark;
  }

  public LocalDateTime getClosingDate() {
    return closingDate;
  }

  public BigDecimal getClosingAmount() {
    return closingAmount;
  }

  public String getAvailableMark() {
    return availableMark;
  }

  public LocalDateTime getAvailableDate() {
    return availableDate;
  }

  public BigDecimal getAvailableAmount() {
    return availableAmount;
  }

  public Extract getExtract() {
    return extract;
  }

  public String getStatus() {
    return status;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void setBic(String bic) {
    this.bic = bic;
  }

  public void setAccountCode(String accountCode) {
    this.accountCode = accountCode;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public void setBalanceType(String balanceType) {
    this.balanceType = balanceType;
  }

  public void setAccountingDate(LocalDateTime accountingDate) {
    this.accountingDate = accountingDate;
  }

  public void setOpeningMark(String openingMark) {
    this.openingMark = openingMark;
  }

  public void setOpeningDate(LocalDateTime openingDate) {
    this.openingDate = openingDate;
  }

  public void setOpeningAmount(BigDecimal openingAmount) {
    this.openingAmount = openingAmount;
  }

  public void setClosingMark(String closingMark) {
    this.closingMark = closingMark;
  }

  public void setClosingDate(LocalDateTime closingDate) {
    this.closingDate = closingDate;
  }

  public void setClosingAmount(BigDecimal closingAmount) {
    this.closingAmount = closingAmount;
  }

  public void setAvailableMark(String availableMark) {
    this.availableMark = availableMark;
  }

  public void setAvailableDate(LocalDateTime availableDate) {
    this.availableDate = availableDate;
  }

  public void setAvailableAmount(BigDecimal availableAmount) {
    this.availableAmount = availableAmount;
  }

  public void setExtract(Extract extract) {
    this.extract = extract;
  }

  public boolean hasTransactions() {
    return transactions;
  }

  public void setTransactions(boolean transactions) {
    this.transactions = transactions;
  }

  public boolean hasBestTransactions() {
    return bestTransactions;
  }

  public void setBestTransactions(boolean bestTransactions) {
    this.bestTransactions = bestTransactions;
  }

  public String getInformation() {
    return information;
  }

  public void setInformation(String information) {
    this.information = information;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;

    if (o == null || getClass() != o.getClass()) return false;

    BalanceCache that = (BalanceCache) o;

    return new EqualsBuilder()
      .appendSuper(super.equals(o))
      .append(transactions, that.transactions)
      .append(bestTransactions, that.bestTransactions)
      .append(id, that.id)
      .append(bic, that.bic)
      .append(accountCode, that.accountCode)
      .append(currency, that.currency)
      .append(balanceType, that.balanceType)
      .append(accountingDate, that.accountingDate)
      .append(openingMark, that.openingMark)
      .append(openingDate, that.openingDate)
      .append(openingAmount, that.openingAmount)
      .append(closingMark, that.closingMark)
      .append(closingDate, that.closingDate)
      .append(closingAmount, that.closingAmount)
      .append(availableMark, that.availableMark)
      .append(availableDate, that.availableDate)
      .append(availableAmount, that.availableAmount)
      .append(extract, that.extract)
      .append(information, that.information)
      .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .appendSuper(super.hashCode())
      .append(id)
      .append(bic)
      .append(accountCode)
      .append(currency)
      .append(balanceType)
      .append(accountingDate)
      .append(openingMark)
      .append(openingDate)
      .append(openingAmount)
      .append(closingMark)
      .append(closingDate)
      .append(closingAmount)
      .append(availableMark)
      .append(availableDate)
      .append(availableAmount)
      .append(extract)
      .append(transactions)
      .append(bestTransactions)
      .append(information)
      .toHashCode();
  }

  @Override
  public String toString() {
    return "BalanceCache{" +
      "id=" + id +
      ", bic='" + bic + '\'' +
      ", accountCode='" + accountCode + '\'' +
      ", currency='" + currency + '\'' +
      ", balanceType='" + balanceType + '\'' +
      ", accountingDate=" + accountingDate +
      ", openingMark='" + openingMark + '\'' +
      ", openingDate=" + openingDate +
      ", openingAmount=" + openingAmount +
      ", closingMark='" + closingMark + '\'' +
      ", closingDate=" + closingDate +
      ", closingAmount=" + closingAmount +
      ", availableMark='" + availableMark + '\'' +
      ", availableDate=" + availableDate +
      ", availableAmount=" + availableAmount +
      ", extract=" + extract +
      ", transactions=" + transactions +
      ", bestTransactions=" + bestTransactions +
      ", status=" + status +
      "} " + super.toString();
  }
}
