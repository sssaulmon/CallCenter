package com.isban.gcb.ic.commons.util.function;

@FunctionalInterface
public interface ThrowingSupplier<T> {
  T get() throws Exception;
}
