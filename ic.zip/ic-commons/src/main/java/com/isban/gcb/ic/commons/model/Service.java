package com.isban.gcb.ic.commons.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "service", indexes = {@Index(columnList = "uuid", name = "uuid_service")})
public class Service extends AuditableLocalDate implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "service_gen")
  @SequenceGenerator(name = "service_gen", sequenceName = "service_generator", allocationSize = 1)
  private Long id;

  @Size(max = 100)
  @Column(name = "name", length = 100)
  private String name;

  @Size(max = 50)
  @Column(name = "CONTRACT_NUMBER", length = 50)
  private String contractNumber;

  @NotNull
  @Column(name = "uuid", length = 40, nullable = false)
  private String uuid;

  @Column(name = "start_date")
  private LocalDate startDate;

  @Column(name = "end_date")
  private LocalDate endDate;

  @Size(max = 20)
  @Column(name = "last_modified_user", length = 20)
  private String lastModifiedUser;

  @Size(max = 40)
  @Column(name = "uuid_structure_bussines_group", length = 40)
  private String uuidStructureBussinesGroup;

  @NotNull
  @Column(name = "append_accounts", nullable = false)
  private Boolean appendAccounts;

  @Size(max = 50)
  @Column(name = "send_days")
  private String sendDays;

  @Size(max = 1000)
  @Column(name = "send_hours", length = 1000)
  private String sendHours;

  @Size(max = 50)
  @Column(name = "time_delta")
  private String timeDelta;

  @NotNull
  @Column(name = "uninformed_send", nullable = false)
  private Boolean uninformedSend;

  @OneToMany(mappedBy = "service")
  @JsonIgnore
  private Set<ServiceAccount> serviceAccountSet = new HashSet<>();

  @OneToMany(mappedBy = "service")
  @JsonIgnore
  private Set<ServiceAddress> serviceAddressSet = new HashSet<>();

  @ManyToOne
  private ServiceType serviceType;

  @ManyToOne
  private ServiceSendFormat serviceSendFormat;

  @ManyToOne
  private ServiceSendFreq serviceSendFreq;

  @ManyToOne
  private ServiceSendChannel serviceSendChannel;

  @ManyToOne
  private CustomizationType customizationType;

  @Column(name = "implementation_channel")
  private Boolean implementationChannel;

  @NotNull
  @Column(name = "unix_new_line", nullable = false, columnDefinition = "NUMBER(1,0) DEFAULT 0")
  private Boolean unixNewLine;

  @NotNull
  @Column(name = "sic_migrated", nullable = false, columnDefinition = "NUMBER(1,0) DEFAULT 1")
  private Boolean sicMigrated;

  @Column(name = "filename_alias")
  private String filenameAlias;

  @NotNull
  @Column(name = "new_line_end", nullable = false, columnDefinition = "NUMBER(1,0) DEFAULT 1")
  private Boolean newLineEnd;

  @Column(name = "glob_rep_client_alias", columnDefinition = "NUMBER(1,0) DEFAULT 0")
  private Boolean globalReportClientAlias;

  @Size(max = 255)
  @Column(name = "subtype")
  private String subType;

  @Column(name = "BIC_SIC_SEND", columnDefinition = "NUMBER(1,0) DEFAULT 0")
  private Boolean bicSicSend;

  @Column(name = "END_TO_END_CUSTOMIZATION", columnDefinition = "NUMBER(1,0) DEFAULT 0")
  private Boolean endToEndCustomization;

  @Column(name = "DELTA", columnDefinition = "NUMBER(1,0) DEFAULT 0")
  private Boolean hasDelta;

  @Column(name = "CUSTOM_CUR_CNY_TO_CNH", columnDefinition = "NUMBER(1,0) DEFAULT 0")
  private Boolean customCurCnyToCnh;

  @Column(name = "sending_hours_check", columnDefinition = "NUMBER(1,0) DEFAULT 1")
  private boolean sendingHoursCheck;

  @Size(max = 255)
  @Column(name = "subtype_code")
  private String subTypeCode;

  @Column(name = "no_scf_customization", columnDefinition = "NUMBER(1,0) DEFAULT 0")
  private Boolean noSCFCustomization;

  @Column(name = "unsigned_balance_bai", columnDefinition = "NUMBER(1,0) DEFAULT 0")
  private Boolean unsignedBalanceBAI;

  @Column(name = "single_balance_bai", columnDefinition = "NUMBER(1,0) DEFAULT 0")
  private Boolean singleBalanceBAI;

  @Column(name = "camt053_standard_codes", columnDefinition = "NUMBER(1,0) DEFAULT 0")
  private Boolean camt053StandardCodes;

  @Column(name = "HAS_N43_CORPORATE_IN_ALIAS", columnDefinition = "NUMBER(1,0) DEFAULT 0")
  private Boolean hasN43CorporateInAlias;
}
