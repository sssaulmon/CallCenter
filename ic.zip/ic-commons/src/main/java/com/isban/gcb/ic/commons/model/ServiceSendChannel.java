package com.isban.gcb.ic.commons.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * A ServiceSendChannel.
 */
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "service_send_channel",
        indexes = {@Index(columnList = "uuid", name = "uuid_service_send_channel")})
public class ServiceSendChannel extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "service_send_channel_gen")
    @SequenceGenerator(name = "service_send_channel_gen",
            sequenceName = "service_send_channel_generator", allocationSize = 1)
    private Long id;

    @Size(max = 100)
    @Column(name = "description", length = 100)
    private String description;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Size(max = 40)
    @Column(name = "uuid")
    private String uuid;

    /**
     * FK for ServiceAdress
     */
    @OneToMany(mappedBy = "serviceSendChannel")
    @JsonIgnore
    private Set<Service> serviceSet = new HashSet<>();

    public ServiceSendChannel(Long id) {
        super();
        this.id = id;
    }

    private Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ServiceSendChannel description(String description) {
        this.description = description;
        return this;
    }

    private LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public ServiceSendChannel endDate(LocalDate endDate) {
        this.endDate = endDate;
        return this;
    }

    public Set<Service> getServiceSet() {
        return serviceSet;
    }

    public void setServiceSet(Set<Service> serviceSet) {
        this.serviceSet = serviceSet;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ServiceSendChannel serviceSendChannel = (ServiceSendChannel) o;
        if (serviceSendChannel.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), serviceSendChannel.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "ServiceSendChannel{" + "id=" + getId() + ", description='" + getDescription() + "'"
                + ", createDate='" + getCreateDate() + "'" + ", endDate='" + getEndDate() + "'"
                + ", lastModifiedDate='" + getLastModifiedDate() + "'" + "}";
    }
}
