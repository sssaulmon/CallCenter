package com.isban.gcb.ic.commons.mt9X0.enhanced;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "applicationId",
        "serviceId",
        "logicalTerminal",
        "sessionNumber",
        "sequenceNumber"
})
public class Block1 implements Serializable {

    private static final long serialVersionUID = -653634173788135084L;

    @JsonProperty("applicationId")
    private String applicationId;
    @JsonProperty("serviceId")
    private String serviceId;
    @JsonProperty("logicalTerminal")
    private String logicalTerminal;
    @JsonProperty("sessionNumber")
    private String sessionNumber;
    @JsonProperty("sequenceNumber")
    private String sequenceNumber;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();

    /**
     * No args constructor for use in serialization
     */
    public Block1() {
        /*Empty Constructor*/
    }

    /**
     * @param logicalTerminal
     * @param serviceId
     * @param applicationId
     * @param sessionNumber
     * @param sequenceNumber
     */
    public Block1(String applicationId, String serviceId, String logicalTerminal, String sessionNumber, String sequenceNumber) {
        super();
        this.applicationId = applicationId;
        this.serviceId = serviceId;
        this.logicalTerminal = logicalTerminal;
        this.sessionNumber = sessionNumber;
        this.sequenceNumber = sequenceNumber;
    }

    @JsonProperty("applicationId")
    public String getApplicationId() {
        return applicationId;
    }

    @JsonProperty("applicationId")
    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    @JsonProperty("serviceId")
    public String getServiceId() {
        return serviceId;
    }

    @JsonProperty("serviceId")
    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    @JsonProperty("logicalTerminal")
    public String getLogicalTerminal() {
        return logicalTerminal;
    }

    @JsonProperty("logicalTerminal")
    public void setLogicalTerminal(String logicalTerminal) {
        this.logicalTerminal = logicalTerminal;
    }

    @JsonProperty("sessionNumber")
    public String getSessionNumber() {
        return sessionNumber;
    }

    @JsonProperty("sessionNumber")
    public void setSessionNumber(String sessionNumber) {
        this.sessionNumber = sessionNumber;
    }

    @JsonProperty("sequenceNumber")
    public String getSequenceNumber() {
        return sequenceNumber;
    }

    @JsonProperty("sequenceNumber")
    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public String toSwiftMessage() {
      return "{1:" + this.getApplicationId() + this.getServiceId() + this.getLogicalTerminal()
                + this.getSessionNumber() + this.getSequenceNumber() + "}";
    }
}
