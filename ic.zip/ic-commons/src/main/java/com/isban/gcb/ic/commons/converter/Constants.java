package com.isban.gcb.ic.commons.converter;

/**
 * @since 24/01/2018
 */
public final class Constants {

  public static final String CONVERTER_TYPE_ZERO = "0";
  public static final String CONVERTER_TYPE_ONE = "1";
  public static final String CONVERTER_TYPE_TWO = "2";
  public static final String CONVERTER_TYPE_PREFIX = "CONVERSOR";
  public static final String CONVERTER_DATE_FORMAT = "yyMMdd";
  public static final String CONVERTER_TYPE_ZERO_TIME_FORMAT = "HH:mm:ss";
  public static final String CONVERTER_TYPE_TWO_TIME_FORMAT = "HHmm";
  public static final String SWIFT_FLOW_DATE_FORMAT = "yyMMdd";
  public static final int PADDING_FILE = 503;

  public static final Integer CURRENCY_MAX_DECIMALS = 2;
  public static final Integer CURRENCY_MIN_DECIMALS = 0;
  public static final String FIELD_20_SEQUENCE_NAME = "FIELD20_SEQUENCE";
  public static final String SEQUENCE_NUMBER_SEQUENCE_NAME = "SEQUENCE_NUMBER_SEQUENCE";
  public static final int FIELD_20_MAX_PADDING_SIZE = 10;
  public static final int SEQUENCE_MAX_PADDING_SIZE = 6;


  // REGEX PATTERNS FOR TYPE 1 (Numbers Mark the Substring -> 5_24 = [5-24])
  public static final String REX_TYPE_ONE_4_24 = "(^|\\s+)\\S+(\\s+|$)";
  public static final String REX_TYPE_ONE_24_27 = "[a-zA-Z]{3}";
  public static final String REX_TYPE_ONE_42_48 = "[0-9]{6}";
  public static final String REX_TYPE_ONE_48_54 = "[0-9]{6}";
  public static final String REX_TYPE_ONE_54_69 = "[\\+\\-]{1}[0-9]{14}";
  public static final String REX_TYPE_ONE_69_84 = "[\\+\\-]{1}[0-9]{14}";
  public static final String REX_TYPE_ONE_84_89 = "[0-9]{5}";

  // REGEX PATTERNS FOR TYPE 2 (Numbers Mark the Substring -> 5_24 = [5-24])
  public static final String REX_TYPE_TWO_4_24 = "(^|\\s+)\\S+(\\s+|$)";
  public static final String REX_TYPE_TWO_24_27 = "[a-zA-Z]{3}";
  public static final String REX_TYPE_TWO_27_36 = "[0-9]{9}";
  public static final String REX_TYPE_TWO_74_80 = "[0-9]{6}";
  public static final String REX_TYPE_TWO_80_86 = "[0-9]{6}";
  public static final String REX_TYPE_TWO_90_96 = "[0-9]{6}";
  public static final String REX_TYPE_TWO_96_97 = "[HD]{1}";
  public static final String REX_TYPE_TWO_97_112 = "[\\+\\-]{1}[0-9]{14}";
  public static final String REX_TYPE_TWO_112_127 = "[\\+\\-]{1}[0-9]{14}";
  public static final String REX_TYPE_TWO_172_175 = "[a-zA-Z0-9]{3}";

  public static final String MT940_OUTPUT = "O";
  public static final String MT940_INPUT = "I";
  public static final String MT940_DATE_FORMAT = "yyyy-MM-dd";

  public static final String CONVERTER_ACCOUNT_STATUS_OK = "Recibido OK";
  public static final String CONVERTER_ACCOUNT_STATUS_KO = "Recibido KO";
  public static final String CONVERTER_ACCOUNT_STATUS_DUPLICATED = "Reporte duplicado";
  public static final String CONVERTER_ACCOUNT_WITHOUT_SLA = "Pte revisar SLA";

  public static final String ACCEPT = "Accept";
  public static final String CONTENT_TYPE = "Content-type";

  public static final String SIX_EXCLAMATIONS = "!!!!!!";

  public static final int CONVERTER_VERSION_LENGTH = 9;

  public static final String S3_CONVERTER_NAME_REX = ".*/(.*)";
  public static final String EXTEND_CONVERTER = "^.*\\.EXTEND\\..*$";

  private Constants() {
    //Just Sonar Things
  }
}
