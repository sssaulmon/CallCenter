package com.isban.gcb.ic.commons.mt9X0.enhanced;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "messageInfo"
})
public class MessageType2 implements Serializable {

    private static final long serialVersionUID = -4785354336995007304L;

    @JsonProperty("messageInfo")
    private String messageInfo;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();

    /**
     * No args constructor for use in serialization
     */
    public MessageType2() {
        /*Empty Constructor*/
    }

    /**
     * @param messageInfo
     */
    public MessageType2(String messageInfo) {
        super();
        this.messageInfo = messageInfo;
    }

    @JsonProperty("messageInfo")
    public String getMessageInfo() {
        return messageInfo;
    }

    @JsonProperty("messageInfo")
    public void setMessageInfo(String messageInfo) {
        this.messageInfo = messageInfo;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
