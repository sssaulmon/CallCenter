package com.isban.gcb.ic.commons.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * A ServiceSendFreq.
 */
@Entity
@Table(name = "service_send_freq",
        indexes = {@Index(columnList = "uuid", name = "uuid_service_send_freq")})
public class ServiceSendFreq extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "service_send_freq_gen")
    @SequenceGenerator(name = "service_send_freq_gen", sequenceName = "service_send_freq_generator",
            allocationSize = 1)
    private Long id;

    @Size(max = 100)
    @Column(name = "description", length = 100)
    private String description;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Size(max = 40)
    @Column(name = "uuid")
    private String uuid;

    @OneToMany(mappedBy = "serviceSendFreq")
    @JsonIgnore
    private Set<Service> idServiceSendFreqs = new HashSet<>();


    private Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    private String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ServiceSendFreq description(String description) {
        this.description = description;
        return this;
    }

    private LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public ServiceSendFreq endDate(LocalDate endDate) {
        this.endDate = endDate;
        return this;
    }

    public Set<Service> getIdServiceSendFreqs() {
        return idServiceSendFreqs;
    }

    public void setIdServiceSendFreqs(Set<Service> services) {
        this.idServiceSendFreqs = services;
    }

    public ServiceSendFreq idServiceSendFreqs(Set<Service> services) {
        this.idServiceSendFreqs = services;
        return this;
    }

    public ServiceSendFreq addIdServiceSendFreq(Service service) {
        this.idServiceSendFreqs.add(service);
        service.setServiceSendFreq(this);
        return this;
    }

    public ServiceSendFreq removeIdServiceSendFreq(Service service) {
        this.idServiceSendFreqs.remove(service);
        service.setServiceSendFreq(null);
        return this;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ServiceSendFreq serviceSendFreq = (ServiceSendFreq) o;
        if (serviceSendFreq.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), serviceSendFreq.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "ServiceSendFreq{" + "id=" + getId() + ", description='" + getDescription() + "'"
                + ", createDate='" + getCreateDate() + "'" + ", endDate='" + getEndDate() + "'"
                + ", lastModifiedDate='" + getLastModifiedDate() + "'" + "}";
    }
}
