package com.isban.gcb.ic.commons.mt9X0.enhanced;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.prowidesoftware.swift.model.field.Field28C;
import com.prowidesoftware.swift.model.field.Field61;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
  "tags"
})
public class Block4 implements Serializable {

  private static final String PAGE_NUMBER_TAG_NAME = "28C";
  private static final String INTERMEDIATE_INITIAL_BALANCE_TAG_NAME = "60M";
  private static final String TRANSACTION_TAG_NAME = "61";
  private static final String INTERMEDIATE_BALANCE_TAG_NAME = "62M";
  private static final String FINAL_BALANCE_TAG_NAME = "62F";
  private static final String TRANSACTION_TAG_DESCRIPTION_NAME = "86";
  private static final String REVERSE_MARKER = "R";
  private static final String CREDIT_MARKER = "C";
  private static final String DEBIT_MARKER = "D";
  private static final long serialVersionUID = 4469937631777181568L;
  private static final List<String> initialTags = Arrays.asList("20", "21", "25", "25P", "28C", "60F", "60M");

  @JsonProperty("tags")
  private List<Tag> tags = null;
  @JsonIgnore
  private Map<String, Object> additionalProperties = new HashMap<>();

  @JsonIgnore
  private long headerElements;

  /**
   * No args constructor for use in serialization
   */
  public Block4() {
    /*Empty Constructor*/
  }

  /**
   * @param tags
   */
  public Block4(List<Tag> tags) {
    super();
    this.tags = tags;
    headerElements = IntStream.range(0, tags.size())
      .parallel()
      .mapToObj(tags::get)
      .map(Tag::getName)
      .filter(initialTags::contains)
      .count();
  }

  @JsonProperty("tags")
  public List<Tag> getTags() {
    return tags;
  }

  @JsonProperty("tags")
  public void setTags(List<Tag> tags) {
    this.tags = tags;
  }

  @JsonAnyGetter
  public Map<String, Object> getAdditionalProperties() {
    return this.additionalProperties;
  }

  public long getHeaderElements() {
    return headerElements;
  }

  @JsonIgnore
  public Tag findByName(String name) {
    Tag tag = null;
    for (int i = 0; i < this.tags.size(); i++) {
      if (this.tags.get(i).getName().equals(name))
        tag = this.tags.get(i);
    }
    return tag;
  }

  @JsonIgnore
  public void modifyByName(String name, String value) {
    for (int i = 0; i < this.tags.size(); i++) {
      if (this.tags.get(i).getName().equals(name))
        this.tags.get(i).setValue(value);
    }
  }

  /*
   * Returns the last position of a found tag or "-1" if not
   * */
  @JsonIgnore
  public int findTagPosition(String nameTag) {

    int position = -1;
    for (int i = this.tags.size() - 1; i >= 0; i--) {
      if (this.tags.get(i).getName().equals(nameTag))
        return i;
    }
    return position;
  }

  /*
   * Returns a List of Positions where a Tag name matches
   * */
  @JsonIgnore
  public List<Integer> findTagPositions(String nameTag) {
    List<Integer> positions = new ArrayList<>();
    for (int i = 0; i < this.tags.size(); i++) {
      if (this.tags.get(i).getName().equals(nameTag))
        positions.add(i);
    }
    return positions;
  }

  /*
   * Adds New Tag to given position,
   * If it's empty or position overflows it's added at the end
   *
   */
  @JsonIgnore
  public void addNewTagByPosition(Tag tag, int position) {
    if (this.tags != null && position >= 0 && position <= this.tags.size())
      this.tags.add(position, tag);
    else
      this.addNewTag(tag);
  }

  /*
   * Adds New Tag to the end of the list
   */
  @JsonIgnore
  public void addNewTag(Tag tag) {
    if (this.tags == null)
      tags = new ArrayList<>();
    this.tags.add(tag);
  }

  @JsonIgnore
  public void removeTagByPosition(int position) {
    this.tags.remove(position);
  }

  @JsonIgnore
  public Tag removeAndGetTagByPosition(int position) {
    return tags.remove(position);
  }

  @JsonAnySetter
  public void setAdditionalProperty(String name, Object value) {
    this.additionalProperties.put(name, value);
  }

  public String toSwiftMessage() {
    String result = "{4:\r\n";
    result += tags.stream()
      .parallel()
      .map(campo -> ":" + campo.getName() + ":" + campo.getValue() + "\r\n")
      .collect(Collectors.joining());
    result += "-}";
    return result;

  }

  public String toSwiftFinMessage() {
    String result = "{4:\r\n";
    result += tags.stream()
      .parallel()
      .map(campo -> ":" + campo.getName() + ":" + campo.getValue().replaceAll("\\R", "\r\n") + "\r\n")
      .collect(Collectors.joining());
    result += "-}";
    return result;
  }

  public void removeTagsFromIndex(int index) {
    for (int i = this.tags.size() - 1; i >= index; i--) {
      this.removeTagByPosition(i);
    }
  }

  public List<Tag> removeAndGetTagsFromIndex(int index) {

    return IntStream.rangeClosed(1, tags.size() - index)
      .mapToObj(i -> removeAndGetTagByPosition(index))
      .collect(Collectors.toList());
  }

  public List<Tag> removeLastTransaction() {
    List<Tag> removedTags = new ArrayList<>();
    int position = this.findTagPosition(TRANSACTION_TAG_NAME);
    removedTags.add(this.tags.remove(position));
    Tag following;
    try {
      following = this.tags.get(position);
    } catch (IndexOutOfBoundsException ex) {
      return removedTags;
    }
    if (following.getName().equals(TRANSACTION_TAG_DESCRIPTION_NAME)) {
      removedTags.add(this.tags.remove(position));
    }
    return removedTags;
  }

  public void addNewTags(List<Tag> tagList) {
    tagList.forEach(this::addNewTag);
  }

  public List<Tag> extractClosingTags() {
    int finalBalancePosition = findTagPosition(FINAL_BALANCE_TAG_NAME);
    List<Tag> tagsFromFinalBalance = new ArrayList<>(getTags().subList(finalBalancePosition, getTags().size()));
    removeTagsFromIndex(finalBalancePosition);
    return tagsFromFinalBalance;
  }

  public void removeOptionalTagsFromIntermediatePage() {
    int finalBalancePosition = findTagPosition(INTERMEDIATE_BALANCE_TAG_NAME);
    removeTagsFromIndex(finalBalancePosition + 1);
  }

  private void increasePageNumberTag() {
    Field28C field28C = new Field28C(findByName(PAGE_NUMBER_TAG_NAME).getValue());
    field28C.setSequenceNumber((String.format("%05d", (field28C.getComponent2AsNumber().intValue() + 1))).replace(' ', '0'));
    modifyByName(PAGE_NUMBER_TAG_NAME, field28C.getValue());
  }

  public void addToBlock(List<Tag> closingTags, List<Tag> transactionList, String intermediateBalance) {
    addNewTag(new Tag(INTERMEDIATE_INITIAL_BALANCE_TAG_NAME, intermediateBalance));
    addNewTags(transactionList);
    addNewTags(closingTags);
    increasePageNumberTag();
  }

  public List<Field61> getTransactionsFromMarker(String markCD) {
    return getTags().stream()
      .parallel()
      .filter(tag -> TRANSACTION_TAG_NAME.equals(tag.getName()))
      .map(tag -> new Field61(tag.getValue()))
      .filter(field61 -> markCD.equals(field61.getDCMark()) || getReverseMarker(markCD).equals(field61.getDCMark()))
      .collect(Collectors.toList());
  }

  private String getReverseMarker(String markCD) {
    if (markCD.equals(CREDIT_MARKER))
      return REVERSE_MARKER + DEBIT_MARKER;
    return REVERSE_MARKER + CREDIT_MARKER;
  }
}
