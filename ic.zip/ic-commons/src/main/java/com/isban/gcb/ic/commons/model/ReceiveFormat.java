package com.isban.gcb.ic.commons.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * A ReceiveFormat.
 */
@Entity
@Table(name = "receive_format",
        indexes = {@Index(columnList = "uuid", name = "uuid_receive_format")})
public class ReceiveFormat extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "receive_format_gen")
    @SequenceGenerator(name = "receive_format_gen", sequenceName = "receive_format_generator",
            allocationSize = 1)
    private Long id;

    @NotNull
    @Size(max = 10)
    @Column(name = "code", length = 10, nullable = false)
    private String code;

    @Size(max = 50)
    @Column(name = "description", length = 50)
    private String description;

    @Size(max = 40)
    @Column(name = "uuid")
    private String uuid;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Size(max = 20)
    @Column(name = "last_modified_user", length = 20)
    private String lastModifiedUser;

    @OneToMany(mappedBy = "receiveFormat")
    @JsonIgnore
    private Set<Subproduct> idReciveFormats = new HashSet<>();


    private Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    private String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public ReceiveFormat code(String code) {
        this.code = code;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ReceiveFormat description(String description) {
        this.description = description;
        return this;
    }

    private LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public ReceiveFormat endDate(LocalDate endDate) {
        this.endDate = endDate;
        return this;
    }

    private String getLastModifiedUser() {
        return lastModifiedUser;
    }

    public void setLastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
    }

    public ReceiveFormat lastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
        return this;
    }

    public Set<Subproduct> getIdReciveFormats() {
        return idReciveFormats;
    }

    public void setIdReciveFormats(Set<Subproduct> subproducts) {
        this.idReciveFormats = subproducts;
    }

    public ReceiveFormat idReciveFormats(Set<Subproduct> subproducts) {
        this.idReciveFormats = subproducts;
        return this;
    }

    public ReceiveFormat addIdReciveFormat(Subproduct subproduct) {
        this.idReciveFormats.add(subproduct);
        subproduct.setReceiveFormat(this);
        return this;
    }

    public ReceiveFormat removeIdReciveFormat(Subproduct subproduct) {
        this.idReciveFormats.remove(subproduct);
        subproduct.setReceiveFormat(null);
        return this;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ReceiveFormat receiveFormat = (ReceiveFormat) o;
        if (receiveFormat.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), receiveFormat.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "ReceiveFormat{" + "id=" + getId() + ", code='" + getCode() + "'" + ", description='"
                + getDescription() + "'" + ", lastModifiedDate='" + getLastModifiedDate() + "'"
                + ", endDate='" + getEndDate() + "'" + ", lastModifiedUser='"
                + getLastModifiedUser() + "'" + "}";
    }
}
