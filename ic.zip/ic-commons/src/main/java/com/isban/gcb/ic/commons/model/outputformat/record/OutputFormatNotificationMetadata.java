package com.isban.gcb.ic.commons.model.outputformat.record;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "extract",
        "accountEntity",
        "senderEntity",
        "productCode",
        "subProductCode",
        "currency",
        "transformSize",
        "address",
        "incomingDate"
})
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class OutputFormatNotificationMetadata implements Serializable {

    private static final long serialVersionUID = -1519291233333043227L;

    @JsonProperty("extract")
    private String extract;

    @JsonProperty("accountEntity")
    private String accountEntity;

    @JsonProperty("senderEntity")
    private String senderEntity;

    @JsonProperty("productCode")
    private String productCode;

    @JsonProperty("subProductCode")
    private String subProductCode;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("transformSize")
    private String transformSize;

    @JsonProperty("address")
    private String address;

    @JsonProperty("incomingDate")
    private String incomingDate;

}