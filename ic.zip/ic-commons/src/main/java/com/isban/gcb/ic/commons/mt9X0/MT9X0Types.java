/**
 * Formato de mensaje MT940
 * Estructura:
 * seccion		:: Tipo de información en estructura tipo MT (SWIFT)
 * field_name 	:: Nombre del campo
 * tag			:: Tag de cabecera de mensaje swift
 * format		:: Formato del mensaje en expresión Swift
 * comment		:: Comentario descriptivo acerca del campo
 */
package com.isban.gcb.ic.commons.mt9X0;

public enum MT9X0Types {

    IGTIPOMENSAJE("Informacion Mensaje", "Tipo de Mensaje", "{2:", "a3!c", "M", "Desde la posición 2, cogemos los siguientes 3 dígitos"),
    IGBICEMISORA("Informacion Entidad Emisora", "BIC Entidad emisora", "{2:", "4!a2!a2!c3!c", "M", "Desde la posición 15, cogemos las 12 siguientes y eliminamos la posición 9. Los 11 caracteres restantes son los que se guardan"),
    IETRANREFNUM("Informacion General Extracto", "Transaction Reference Number", "20", "16x", "M"),
    IERELREF("Informacion General Extracto", "Related Reference", "21", "16x", "O"),
    IEACCOUNTID("Informacion General Extracto", "Account Identification", "25", "35x", "M"),
    IEACCOUNTIDP("Informacion General Extracto", "Account Identification", "25P", "35x", "M", "Es obligatorio el tag 25 con el número de cuenta. Si lo que llega es el 25p, además hay que guardar el BIC (en la segunda línea)"),
    IEIDCODE_BIC("Informacion General Extracto", "Identifier Code (BIC)", "25P", "4!a2!a2!c[3!c]", "M", "Es obligatorio el tag 25 con el número de cuenta. Si lo que llega es el 25p, además hay que guardar el BIC (en la segunda línea)"),
    IESTATEMNTNUM("Informacion General Extracto", "Statement Number", "28C", "5n", "M"),
    OBDCMARK("Opening Balance", "D/C Mark", "60F", "1!", "M"),
    OBDATE("Opening Balance", "Date (YYMMDD)", "60F", "a6!", "M"),
    OBCURRENCY("Opening Balance", "Currency (código ISO)", "60F", "n3!a", "M"),
    OBAMOUNT("Opening Balance", "Amount", "60F", "15d", "M"),
    IMVALUEDATE("Informacion Movimientos", "Value Date (YYMMDD)", "61", "6!n", "M"),
    IMENTRYDATE("Informacion Movimientos", "Entry Date (MMDD)", "61", "[4!n]", "O", "Si es numerico, tenemos el Entry Date, si no, directamente pasa el Debit/Credit Mark. Este valor puede ser de 1 carácter (C o D) o de 2 (RC o RD), debe tenerse esto en cuenta para identificar si se ha llenado o no el siguiente campo (Funds Code)"),
    IMDEBCREDCARD("Informacion Movimientos", "Debit/Credit Mark", "61", "2a", "M", "Si es numerico, tenemos el Entry Date, si no, directamente pasa el Debit/Credit Mark. Este valor puede ser de 1 carácter (C o D) o de 2 (RC o RD), debe tenerse esto en cuenta para identificar si se ha llenado o no el siguiente campo (Funds Code)"),
    IMFUNDSCODE("Informacion Movimientos", "Funds Code (3er carácter de la divisa)", "61", "[1!a]", "O", "Si es texto tenemos el Funds Code, si no, directamente pasa al Amount."),
    IMINFAMOUNT("Informacion Movimientos", "Amount", "61", "15d", "M"),
    IMTRANTYPE("Informacion Movimientos", "Transaction Type", "61", "1!", "M"),
    IMIDCODE("Informacion Movimientos", "Identification Code", "61", "a3!c", "M"),
    IMREFACCOWN("Informacion Movimientos", "Reference for the Account Owner", "61", "16x", "M"),
    IMREFACSRVINS("Informacion Movimientos", "Reference of the Account Servicing Institution", "61", "[//16x]", "O"),
    IMSUPPLDETAIL("Informacion Movimientos", "Supplementary Details", "61", "[34x]", "O", "Habría un salto de línea antes de este campo"),
    IMINFACCOWN("Informacion Movimientos", "Information to Account Owner", "86", "6*65x", "O"),
    CBDCMARK("Closing Balance", "D/C Mark", "62F", "1!", "M"),
    CBDATE("Closing Balance", "Date (YYMMDD)", "62F", "a6!", "M"),
    CBCURRENCY("Closing Balance", "Currency (código ISO)", "62F", "n3!a", "M"),
    CBAMOUNT("Closing Balance", "Amount", "62F", "15d", "M"),
    CBAVBAL("Closing Available Balance", "D/C Mark", "64", "1!", "M"),
    CBAVDATE("Closing Available Balance", "Date (YYMMDD)", "64", "a6!", "M"),
    CBAVCURRENCY("Closing Available Balance", "Currency (código ISO)", "64", "n3!a", "M"),
    CBAVAMOUNT("Closing Available Balance", "Amount", "64", "15d", "M"),
    FAAVMARK("Forward Available Balance", "D/C Mark", "65", "1!", "M"),
    FAAVDATE("Forward Available Balance", "Date (YYMMDD)", "65", "a6!", "M"),
    FAAVCURRENCY("Forward Available Balance", "Currency (código ISO)", "65", "n3!a", "M"),
    FAAVAMOUNT("Forward Available Balance", "Amount", "65", "15d", "M"),
    IXACCOWNER("Informacion General Extracto Opt", "Information to Account Owner", "86", "6*65x", "O");

    private String valor = new String();

  MT9X0Types(String seccion, String field_name, String tag, String format, String status, String... comment) {
    }

    public String getValor() {

        return this.valor;
    }

  public MT9X0Types setValor(String value) {

        this.valor = value;
        return this;
    }

}
