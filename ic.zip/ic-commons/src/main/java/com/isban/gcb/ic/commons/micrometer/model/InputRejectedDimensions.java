package com.isban.gcb.ic.commons.micrometer.model;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Getter
@NoArgsConstructor
public class InputRejectedDimensions extends InputDimensions {

  private String rejectionReason;

  @Builder(builderMethodName = "inputRejectedBuilder")
  public InputRejectedDimensions(Boolean accumulated, String bicType, String client, String clientCategory,
                                 String currency, String entityAccountAlias, Boolean planned, String productCode,
                                 String senderEntity, String subproductCode, String uuidStructureAcc, InputChannel inputChannel,
                                 OffsetDateTime accountingDateUTC, String status, String rejectionReason) {
    super(accumulated, bicType, client, clientCategory, currency, entityAccountAlias, planned, productCode, senderEntity, 
      subproductCode, uuidStructureAcc, accountingDateUTC, status, inputChannel);
    this.rejectionReason = rejectionReason;
  }
}
