package com.isban.gcb.ic.commons.channels.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
public class BaseRequestChannelFileNames {
    protected String outputChannel;
    protected String contract;
    protected String frequency;
    protected String format;
    protected Boolean stp;
    protected String globalReportVersion;
    protected ZonedDateTime zonedDateTime;
    protected List<String> addresses = new ArrayList<>();
}
