package com.isban.gcb.ic.commons.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Entity
@Table(name = "GLOBAL_REPORT_SEND", indexes = {@Index(name = "globalReportSendIdIndex", columnList="send_id", unique = false)})
public class GlobalReportSend extends AuditableLocalDateTime implements Serializable {

  private static final long serialVersionUID = 3244507425874077589L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GLOBAL_REP_SEND_GEN")
  @SequenceGenerator(name = "GLOBAL_REP_SEND_GEN", sequenceName = "GLOBAL_REP_SEND_SEQ", allocationSize = 1)
  private Long id;

  @NotNull
  @Column(name = "send_id", nullable = false)
  private String sendId;

  @NotNull
  @Column(name = "send_number", columnDefinition = "NUMBER(1,0) default 1")
  private Integer sendNumber;

  @NotNull
  @Column(name = "resend", columnDefinition = "NUMBER(1,0) default 0")
  private Boolean resend;

  @ManyToOne
  @JoinColumn(name = "global_report_id", referencedColumnName = "id")
  private GlobalReport globalReport;

  public GlobalReportSend() {

  }

  public GlobalReportSend(Long id, @NotNull String sendId, @NotNull Integer sendNumber, @NotNull Boolean resend, @NotNull GlobalReport globalReport) {
    this.id = id;
    this.sendId = sendId;
    this.sendNumber = sendNumber;
    this.resend = resend;
    this.globalReport = globalReport;
  }

  public Long getId() {
    return this.id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getSendId() {
    return this.sendId;
  }

  public void setSendId(String id) {
    this.sendId = id;
  }

  public Integer getSendNumber() {
    return this.sendNumber;
  }

  public void setSendNumber(Integer number) {
    this.sendNumber = number;
  }

  public Boolean isResend() {
    return this.resend;
  }

  public void setResend(Boolean resend) {
    this.resend = resend;
  }

  public GlobalReport getGlobalReport() {
    return this.globalReport;
  }

  public void setGlobalReport(GlobalReport report) {
    this.globalReport = report;
  }

  public GlobalReportSend id(Long id) {
    this.id = id;
    return this;
  }

  public GlobalReportSend sendId(@NotNull String sendId) {
    this.sendId = sendId;
    return this;
  }

  public GlobalReportSend sendNumber(@NotNull Integer sendNumber) {
    this.sendNumber = sendNumber;
    return this;
  }

  public GlobalReportSend resend(@NotNull Boolean resend) {
    this.resend = resend;
    return this;
  }

  public GlobalReportSend globalReport(@NotNull GlobalReport globalReport) {
    this.globalReport = globalReport;
    return this;
  }

}