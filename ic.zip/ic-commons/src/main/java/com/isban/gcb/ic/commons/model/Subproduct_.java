package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Subproduct.class)
public abstract class Subproduct_ extends com.isban.gcb.ic.commons.model.AuditableLocalDate_ {

	public static volatile SingularAttribute<Subproduct, ReceiveFreqDaily> receiveFreqDaily;
	public static volatile SingularAttribute<Subproduct, Product> product;
	public static volatile SingularAttribute<Subproduct, String> code;
	public static volatile SingularAttribute<Subproduct, LocalDate> endDate;
	public static volatile SingularAttribute<Subproduct, ReceiveChannel> receiveChannel;
	public static volatile SingularAttribute<Subproduct, String> description;
	public static volatile SetAttribute<Subproduct, CrossReference> crossReferenceSet;
	public static volatile SingularAttribute<Subproduct, ReceiveFormat> receiveFormat;
	public static volatile SingularAttribute<Subproduct, Long> id;
	public static volatile SingularAttribute<Subproduct, String> uuid;
	public static volatile SetAttribute<Subproduct, AssoCorpSubProductAcc> slaEntitySet;

	public static final String RECEIVE_FREQ_DAILY = "receiveFreqDaily";
	public static final String PRODUCT = "product";
	public static final String CODE = "code";
	public static final String END_DATE = "endDate";
	public static final String RECEIVE_CHANNEL = "receiveChannel";
	public static final String DESCRIPTION = "description";
	public static final String CROSS_REFERENCE_SET = "crossReferenceSet";
	public static final String RECEIVE_FORMAT = "receiveFormat";
	public static final String ID = "id";
	public static final String UUID = "uuid";
	public static final String SLA_ENTITY_SET = "slaEntitySet";

}

