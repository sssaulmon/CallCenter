package com.isban.gcb.ic.commons.model.report.global.complete;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.isban.gcb.ic.commons.model.report.global.GlobalMetadata;
import com.isban.gcb.ic.commons.model.report.record.MetadataSend;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "globalMetadata",
        "metadataSend",
        "text"
})
public class GlobalReportAppend implements Serializable {

    private static final long serialVersionUID = 3770430283632814155L;

    @JsonProperty("globalMetadata")
    protected GlobalMetadata globalMetadata;

    @JsonProperty("metadataSend")
    private MetadataSend metadataSend;

    @JsonProperty("text")
    private String text;

    public GlobalReportAppend(MetadataSend metadataSend, String text) {
        this.metadataSend = metadataSend;
        this.text = text;
    }

    public GlobalReportAppend() {
    }

    public GlobalMetadata getGlobalMetadata() { return this.globalMetadata; }

    public void setGlobalMetadata(GlobalMetadata metadata) { this.globalMetadata = metadata; }

    public MetadataSend getMetadataSend() {
        return this.metadataSend;
    }

    public String getText() {
        return this.text;
    }

    public void setMetadataSend(MetadataSend metadataSend) {
        this.metadataSend = metadataSend;
    }

    public void setText(String text) {
        this.text = text;
    }

    public GlobalReportAppend globalMetadata(GlobalMetadata globalMetadata) {
        this.globalMetadata = globalMetadata;
        return this;
    }

    public GlobalReportAppend metadataSend(MetadataSend metadataSend) {
        this.metadataSend = metadataSend;
        return this;
    }

    public GlobalReportAppend text(String text) {
        this.text = text;
        return this;
    }

    public String toString() {
        return "GlobalReportAppend(globalMetadata = " + this.getGlobalMetadata() + ",metadataSend=" + this.getMetadataSend() + ", text=" + this.getText() + ")";
    }
}