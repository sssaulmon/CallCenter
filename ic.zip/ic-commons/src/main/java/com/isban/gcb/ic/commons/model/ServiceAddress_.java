package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(ServiceAddress.class)
public abstract class ServiceAddress_ extends com.isban.gcb.ic.commons.model.AuditableLocalDate_ {

	public static volatile SingularAttribute<ServiceAddress, String> address;
	public static volatile SingularAttribute<ServiceAddress, LocalDate> endDate;
	public static volatile SingularAttribute<ServiceAddress, Service> service;
	public static volatile SingularAttribute<ServiceAddress, String> lastModifiedUser;
	public static volatile SingularAttribute<ServiceAddress, Long> id;
	public static volatile SingularAttribute<ServiceAddress, String> uuid;

	public static final String ADDRESS = "address";
	public static final String END_DATE = "endDate";
	public static final String SERVICE = "service";
	public static final String LAST_MODIFIED_USER = "lastModifiedUser";
	public static final String ID = "id";
	public static final String UUID = "uuid";

}

