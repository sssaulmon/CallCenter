package com.isban.gcb.ic.commons.converter.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isban.gcb.ic.commons.converter.Constants;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.function.Function;

public class AccountSummaryDto extends ConverterBaseDto {

  /**
   * Codigo de producto (02)
   */
  private String productCode;

  /**
   * Codigo de sub-producto (04)
   */
  private String subProductCode;

  /**
   * Indicador de activo/pasivo (01)
   */
  private String indicatorActivePassive;

  /**
   * Indicador de cuenta madre (01)
   */
  private String indicatorMotherAccount;

  /**
   * Fecha de apertura de la cuenta (06)
   */
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  private LocalDate accountOpeningDate;

  /**
   * Indicador de periodicidad de extraccion (01)
   */
  private String indicatorExtractionPeriodicity;

  /**
   * Fecha de inicio de extraccion (06)
   */
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  private LocalDate extractionStartDate;

  /**
   * Fecha cierre de extraccion (06)
   */
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  private LocalDate extractionEndDate;

  /**
   * Saldo inicial del extracto (con signo) (12,2)
   */
  private BigDecimal initialExtractBalance;

  /**
   * Saldo final del extracto (con signo) (12,2)
   */
  private BigDecimal finalExtractBalance;

  /**
   * Numero de folio (secuencia de extraccion) (05)
   */
  private Integer sequenceExtractNumber;

  /**
   * Fecha de proceso de extraccion (06)
   */
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  private LocalDate extractionProcessDate;

  /**
   * Fecha de la proxima extraccion (06)
   */
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  private LocalDate extractionNextDate;

  /**
   * Saldo disponible a la fecha de cierre (12,2)
   */
  private BigDecimal balanceAvailableAtClosingDate;

  /**
   * Saldo de operaciones con fecha valor mayor a
   * fecha contable. este dato no es considerado por
   * el conversor (12,2)
   */
  private BigDecimal operationBalance;

  /**
   * Complementario (198)
   */
  private String filler;

  public AccountSummaryDto() {
  }

  public String getProductCode() {
    return this.productCode;
  }

  public String getSubProductCode() {
    return this.subProductCode;
  }

  public String getIndicatorActivePassive() {
    return this.indicatorActivePassive;
  }

  public String getIndicatorMotherAccount() {
    return this.indicatorMotherAccount;
  }

  public LocalDate getAccountOpeningDate() {
    return this.accountOpeningDate;
  }

  public String getIndicatorExtractionPeriodicity() {
    return this.indicatorExtractionPeriodicity;
  }

  public LocalDate getExtractionStartDate() {
    return this.extractionStartDate;
  }

  public LocalDate getExtractionEndDate() {
    return this.extractionEndDate;
  }

  public BigDecimal getInitialExtractBalance() {
    return this.initialExtractBalance;
  }

  public BigDecimal getFinalExtractBalance() {
    return this.finalExtractBalance;
  }

  public Integer getSequenceExtractNumber() {
    return this.sequenceExtractNumber;
  }

  public LocalDate getExtractionProcessDate() {
    return this.extractionProcessDate;
  }

  public LocalDate getExtractionNextDate() {
    return this.extractionNextDate;
  }

  public BigDecimal getBalanceAvailableAtClosingDate() {
    return this.balanceAvailableAtClosingDate;
  }

  public BigDecimal getOperationBalance() {
    return this.operationBalance;
  }

  public String getFiller() {
    return this.filler;
  }

  public void setProductCode(String productCode) {
    this.productCode = productCode;
  }

  public void setSubProductCode(String subProductCode) {
    this.subProductCode = subProductCode;
  }

  public void setIndicatorActivePassive(String indicatorActivePassive) {
    this.indicatorActivePassive = indicatorActivePassive;
  }

  public void setIndicatorMotherAccount(String indicatorMotherAccount) {
    this.indicatorMotherAccount = indicatorMotherAccount;
  }

  public void setAccountOpeningDate(LocalDate accountOpeningDate) {
    this.accountOpeningDate = accountOpeningDate;
  }

  public void setIndicatorExtractionPeriodicity(String indicatorExtractionPeriodicity) {
    this.indicatorExtractionPeriodicity = indicatorExtractionPeriodicity;
  }

  public void setExtractionStartDate(LocalDate extractionStartDate) {
    this.extractionStartDate = extractionStartDate;
  }

  public void setExtractionEndDate(LocalDate extractionEndDate) {
    this.extractionEndDate = extractionEndDate;
  }

  public void setInitialExtractBalance(BigDecimal initialExtractBalance) {
    this.initialExtractBalance = initialExtractBalance;
  }

  public void setFinalExtractBalance(BigDecimal finalExtractBalance) {
    this.finalExtractBalance = finalExtractBalance;
  }

  public void setSequenceExtractNumber(Integer sequenceExtractNumber) {
    this.sequenceExtractNumber = sequenceExtractNumber;
  }

  public void setExtractionProcessDate(LocalDate extractionProcessDate) {
    this.extractionProcessDate = extractionProcessDate;
  }

  public void setExtractionNextDate(LocalDate extractionNextDate) {
    this.extractionNextDate = extractionNextDate;
  }

  public void setBalanceAvailableAtClosingDate(BigDecimal balanceAvailableAtClosingDate) {
    this.balanceAvailableAtClosingDate = balanceAvailableAtClosingDate;
  }

  public void setOperationBalance(BigDecimal operationBalance) {
    this.operationBalance = operationBalance;
  }

  public void setFiller(String filler) {
    this.filler = filler;
  }

  @Override
  public String toString() {
    DecimalFormat decimalFMTT = new DecimalFormat("+00000000000000;-00000000000000");
    DecimalFormat integerFMTT = new DecimalFormat("00000");
    Function<LocalDate, String> dateToString = date -> Optional.ofNullable(date)
      .map(dt -> dt.format(DateTimeFormatter.ofPattern(Constants.CONVERTER_DATE_FORMAT)))
      .orElse("null");
    return super.toString()
      + productCode
      + subProductCode
      + indicatorActivePassive
      + indicatorMotherAccount
      + dateToString.apply(accountOpeningDate)
      + indicatorExtractionPeriodicity
      + dateToString.apply(extractionStartDate)
      + dateToString.apply(extractionEndDate)
      + decimalFMTT.format(initialExtractBalance.multiply(new BigDecimal(100)).toBigInteger())
      + decimalFMTT.format(finalExtractBalance.multiply(new BigDecimal(100)).toBigInteger())
      + integerFMTT.format(sequenceExtractNumber)
      + dateToString.apply(extractionProcessDate)
      + dateToString.apply(extractionNextDate)
      + decimalFMTT.format(balanceAvailableAtClosingDate.multiply(new BigDecimal(100)).toBigInteger())
      + decimalFMTT.format(operationBalance.multiply(new BigDecimal(100)).toBigInteger())
      + filler;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;

    if (o == null || getClass() != o.getClass()) return false;

    AccountSummaryDto that = (AccountSummaryDto) o;

    return new EqualsBuilder()
      .appendSuper(super.equals(o))
      .append(productCode, that.productCode)
      .append(subProductCode, that.subProductCode)
      .append(indicatorActivePassive, that.indicatorActivePassive)
      .append(indicatorMotherAccount, that.indicatorMotherAccount)
      .append(accountOpeningDate, that.accountOpeningDate)
      .append(indicatorExtractionPeriodicity, that.indicatorExtractionPeriodicity)
      .append(extractionStartDate, that.extractionStartDate)
      .append(extractionEndDate, that.extractionEndDate)
      .append(initialExtractBalance, that.initialExtractBalance)
      .append(finalExtractBalance, that.finalExtractBalance)
      .append(sequenceExtractNumber, that.sequenceExtractNumber)
      .append(extractionProcessDate, that.extractionProcessDate)
      .append(extractionNextDate, that.extractionNextDate)
      .append(balanceAvailableAtClosingDate, that.balanceAvailableAtClosingDate)
      .append(operationBalance, that.operationBalance)
      .append(filler, that.filler)
      .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .appendSuper(super.hashCode())
      .append(productCode)
      .append(subProductCode)
      .append(indicatorActivePassive)
      .append(indicatorMotherAccount)
      .append(accountOpeningDate)
      .append(indicatorExtractionPeriodicity)
      .append(extractionStartDate)
      .append(extractionEndDate)
      .append(initialExtractBalance)
      .append(finalExtractBalance)
      .append(sequenceExtractNumber)
      .append(extractionProcessDate)
      .append(extractionNextDate)
      .append(balanceAvailableAtClosingDate)
      .append(operationBalance)
      .append(filler)
      .toHashCode();
  }
}
