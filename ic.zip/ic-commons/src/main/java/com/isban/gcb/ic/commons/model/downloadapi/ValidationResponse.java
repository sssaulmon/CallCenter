package com.isban.gcb.ic.commons.model.downloadapi;

public class ValidationResponse {

  private boolean validation;
  private DownloadApiValidationEnum cause;

  public ValidationResponse build() {
    ValidationResponse validationResponse = new ValidationResponse();
    validationResponse.validation = this.validation;
    validationResponse.cause = this.cause;
    return validationResponse;
  }

  public ValidationResponse validation(boolean validation) {
    this.validation = validation;
    return this;
  }

  public ValidationResponse cause(DownloadApiValidationEnum cause) {
    this.cause = cause;
    return this;
  }

  public ValidationResponse() {
  }

  public boolean isValid() {
    return validation;
  }

  public DownloadApiValidationEnum getCause() {
    return cause;
  }

  @Override
  public String toString() {
    return "ValidationResponse { " +
      " validation = " + validation +
      ", cause = '" + cause + '\'' +
      "}";
  }

}
