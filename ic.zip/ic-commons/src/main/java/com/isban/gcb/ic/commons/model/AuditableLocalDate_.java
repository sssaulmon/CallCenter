package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(AuditableLocalDate.class)
public abstract class AuditableLocalDate_ {

	public static volatile SingularAttribute<AuditableLocalDate, LocalDate> lastModifiedDate;
	public static volatile SingularAttribute<AuditableLocalDate, LocalDate> createDate;

	public static final String LAST_MODIFIED_DATE = "lastModifiedDate";
	public static final String CREATE_DATE = "createDate";

}

