package com.isban.gcb.ic.commons.channels.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RequestChannels {

    private String channelEditran;
    private String channelFileact;
    private String channelEbic;
    private String channelH2H;
    private String channelSwiftFin;
    private String channelEmail;
    private String editranPrefix;
}
