package com.isban.gcb.ic.commons.model;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * A CrossReference.
 *
 * @author daniel.cifuentesgarc
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "MOVEMENT_CROSS_REFERENCE",
        indexes = {@Index(columnList = "uuid", name = "uuid_movement_cross_reference")})
public class MovementCrossReference extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = 1;

    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "movement_cross_ref_generator")
    @Id
    @SequenceGenerator(name = "movement_cross_ref_generator",
            sequenceName = "movement_cross_ref_generator", allocationSize = 1)
    private Long id;

    @Column(name = "uuid", length = 40, nullable = false)
    private String uuid;

    @Column(name = "local_movement_code", length = 4)
    private String localMovementCode;

    @Size(max = 40)
    @Column(name = "client_movement_code", length = 40)
    private String clientMovementCode;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Column(name = "last_modified_user", length = 20)
    private String lastModifiedUser;

    @Column(name = "uuid_corporate", length = 40, nullable = false)
    private String uuidCorporate;

    @JoinColumn(name = "SUBPRODUCT_ID", referencedColumnName = "ID")
    @ManyToOne
    private Subproduct subproduct;

}
