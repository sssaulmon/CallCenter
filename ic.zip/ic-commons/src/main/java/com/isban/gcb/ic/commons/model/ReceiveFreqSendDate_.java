package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(ReceiveFreqSendDate.class)
public abstract class ReceiveFreqSendDate_ extends com.isban.gcb.ic.commons.model.AuditableLocalDate_ {

	public static volatile SingularAttribute<ReceiveFreqSendDate, LocalDate> endDate;
	public static volatile SingularAttribute<ReceiveFreqSendDate, String> description;
	public static volatile SingularAttribute<ReceiveFreqSendDate, String> lastModifiedUser;
	public static volatile SetAttribute<ReceiveFreqSendDate, ReceiveFreqDaily> idReciveFreqSendDates;
	public static volatile SingularAttribute<ReceiveFreqSendDate, Long> id;
	public static volatile SingularAttribute<ReceiveFreqSendDate, String> uuid;

	public static final String END_DATE = "endDate";
	public static final String DESCRIPTION = "description";
	public static final String LAST_MODIFIED_USER = "lastModifiedUser";
	public static final String ID_RECIVE_FREQ_SEND_DATES = "idReciveFreqSendDates";
	public static final String ID = "id";
	public static final String UUID = "uuid";

}

