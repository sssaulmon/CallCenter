package com.isban.gcb.ic.commons.model.report.global;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.isban.gcb.ic.commons.model.report.record.Metadata;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "metadata",
        "text"
})
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class GlobalRecord implements Serializable {

    private static final long serialVersionUID = 1736815269448620300L;

    @JsonProperty("metadata")
    private Metadata metadata;

    @JsonProperty("text")
    private String text;

}