package com.isban.gcb.ic.commons.micrometer.model;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.OffsetDateTime;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class BaseDimensions {
  private Boolean accumulated;
  private String bicType;
  private String client;
  private String clientCategory;
  private String currency;
  private String entityAccountAlias;
  private Boolean planned;
  private String productCode;
  private String senderEntity;
  private String subproductCode;
  private String uuidStructureAcc;
  private String status;
  private OffsetDateTime accountingDateUTC;

  @Builder
  public BaseDimensions(Boolean accumulated, String bicType, String client, String clientCategory, String currency, 
                        String entityAccountAlias, Boolean planned, String productCode, String senderEntity, String 
                          subproductCode, String uuidStructureAcc, OffsetDateTime accountingDateUTC, String status) {
    this.accumulated = accumulated;
    this.bicType = bicType;
    this.client = client;
    this.clientCategory = clientCategory;
    this.currency = currency;
    this.entityAccountAlias = entityAccountAlias;
    this.planned = planned;
    this.productCode = productCode;
    this.senderEntity = senderEntity;
    this.subproductCode = subproductCode;
    this.uuidStructureAcc = uuidStructureAcc;
    this.accountingDateUTC = accountingDateUTC;
    this.status = status;
  }
  
  
}
