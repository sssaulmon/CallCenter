package com.isban.gcb.ic.commons.model;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class MftValidationRequest {

  @NotNull
  private String incomingDate;

  @NotNull
  private Integer sendingSequence;

  @NotEmpty
  @Size(min = 2, max = 2)
  private String countryCode;

  @Min(0)
  @Max(9)
  @NotNull
  private Integer bankCode;

  @NotEmpty
  @Size(min = 4, max = 4)
  private String productCode;

  @NotEmpty
  private String subproductCode;

  @NotEmpty
  private String accountAlias;

  @NotNull
  private String accountingDate;

  @NotNull
  private String filename;

  @NotNull
  private String type;

  @NotNull
  private String currency;

  @NotNull
  private String xmlSanFileName;

  @NotNull
  private String xmlData;

  private String statementNumber;

  public MftValidationRequest() {
    super();
  }

  public String getIncomingDate() {
    return incomingDate;
  }

  public MftValidationRequest incomingDate(String incomingDate) {
    this.incomingDate = incomingDate;
    return this;
  }

  public Integer getSendingSequence() {
    return sendingSequence;
  }

  public MftValidationRequest sendingSequence(Integer sendingSequence) {
    this.sendingSequence = sendingSequence;
    return this;
  }

  public String getCountryCode() {
    return countryCode;
  }

  public MftValidationRequest countryCode(String countryCode) {
    this.countryCode = countryCode;
    return this;
  }

  public Integer getBankCode() {
    return bankCode;
  }

  public MftValidationRequest bankCode(Integer bankCode) {
    this.bankCode = bankCode;
    return this;
  }

  public String getProductCode() {
    return productCode;
  }

  public MftValidationRequest productCode(String productCode) {
    this.productCode = productCode;
    return this;
  }

  public String getSubproductCode() {
    return subproductCode;
  }

  public MftValidationRequest subproductCode(String subproductCode) {
    this.subproductCode = subproductCode;
    return this;
  }

  public String getAccountAlias() {
    return accountAlias;
  }

  public MftValidationRequest accountAlias(String accountAlias) {
    this.accountAlias = accountAlias;
    return this;
  }

  public String getAccountingDate() {
    return accountingDate;
  }

  public MftValidationRequest accountingDate(String accountingDate) {
    this.accountingDate = accountingDate;
    return this;
  }

  public String getFilename() {
    return filename;
  }

  public MftValidationRequest filename(String filename) {
    this.filename = filename;
    return this;
  }

  public String getType() {
    return type;
  }

  public MftValidationRequest type(String type) {
    this.type = type;
    return this;
  }

  public String getCurrency() {
    return currency;
  }

  public MftValidationRequest currency(String currency) {
    this.currency = currency;
    return this;
  }

  public String getXmlSanFileName() {
    return xmlSanFileName;
  }

  public MftValidationRequest xmlSanFileName(String xmlSanFileName) {
    this.xmlSanFileName = xmlSanFileName;
    return this;
  }

  public String getXmlData() {
    return xmlData;
  }

  public MftValidationRequest xmlData(String xmlData) {
    this.xmlData = xmlData;
    return this;
  }

  public String getStatementNumber() {
    return statementNumber;
  }

  public MftValidationRequest statementNumber(String statementNumber) {
    this.statementNumber = statementNumber;
    return this;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;

    if (o == null || getClass() != o.getClass()) return false;

    MftValidationRequest that = (MftValidationRequest) o;

    return new EqualsBuilder()
      .append(incomingDate, that.incomingDate)
      .append(sendingSequence, that.sendingSequence)
      .append(countryCode, that.countryCode)
      .append(bankCode, that.bankCode)
      .append(productCode, that.productCode)
      .append(subproductCode, that.subproductCode)
      .append(accountAlias, that.accountAlias)
      .append(accountingDate, that.accountingDate)
      .append(filename, that.filename)
      .append(type, that.type)
      .append(currency, that.currency)
      .append(xmlSanFileName, that.xmlSanFileName)
      .append(xmlData, that.xmlData)
      .append(statementNumber, that.statementNumber)
      .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(incomingDate)
      .append(sendingSequence)
      .append(countryCode)
      .append(bankCode)
      .append(productCode)
      .append(subproductCode)
      .append(accountAlias)
      .append(accountingDate)
      .append(filename)
      .append(type)
      .append(currency)
      .append(xmlSanFileName)
      .append(xmlData)
      .append(statementNumber)
      .toHashCode();
  }

  @Override
  public String toString() {
    return "MftValidationRequest{" +
      "incomingDate='" + incomingDate + '\'' +
      ", sendingSequence=" + sendingSequence +
      ", countryCode='" + countryCode + '\'' +
      ", bankCode=" + bankCode +
      ", productCode='" + productCode + '\'' +
      ", subproductCode='" + subproductCode + '\'' +
      ", accountAlias='" + accountAlias + '\'' +
      ", accountingDate='" + accountingDate + '\'' +
      ", filename='" + filename + '\'' +
      ", type='" + type + '\'' +
      ", currency='" + currency + '\'' +
      ", xmlSanFileName='" + xmlSanFileName + '\'' +
      ", xmlData='" + xmlData + '\'' +
      ", statementNumber='" + statementNumber + '\'' +
      '}';
  }
}
