package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(ExtractMovement.class)
public abstract class ExtractMovement_ extends com.isban.gcb.ic.commons.model.AuditableLocalDateTime_ {

	public static volatile SingularAttribute<ExtractMovement, String> identificationCode;
	public static volatile SingularAttribute<ExtractMovement, Double> amount;
	public static volatile SingularAttribute<ExtractMovement, String> bookBalanceMark;
	public static volatile SingularAttribute<ExtractMovement, LocalDate> entryDate;
	public static volatile SingularAttribute<ExtractMovement, String> institutionReference;
	public static volatile SingularAttribute<ExtractMovement, String> supplementaryDetails;
	public static volatile SingularAttribute<ExtractMovement, LocalDateTime> movementTime;
	public static volatile SingularAttribute<ExtractMovement, LocalDate> valueDate;
	public static volatile SingularAttribute<ExtractMovement, Character> txType;
	public static volatile SingularAttribute<ExtractMovement, String> movementInfo;
	public static volatile SingularAttribute<ExtractMovement, Character> fundsCode;
	public static volatile SingularAttribute<ExtractMovement, Extract> extract;
	public static volatile SingularAttribute<ExtractMovement, String> customerReference;
	public static volatile SingularAttribute<ExtractMovement, Double> bookBalanceAmount;
	public static volatile SingularAttribute<ExtractMovement, Long> id;
	public static volatile SingularAttribute<ExtractMovement, Integer> page;
	public static volatile SingularAttribute<ExtractMovement, String> mark;

	public static final String IDENTIFICATION_CODE = "identificationCode";
	public static final String AMOUNT = "amount";
	public static final String BOOK_BALANCE_MARK = "bookBalanceMark";
	public static final String ENTRY_DATE = "entryDate";
	public static final String INSTITUTION_REFERENCE = "institutionReference";
	public static final String SUPPLEMENTARY_DETAILS = "supplementaryDetails";
	public static final String MOVEMENT_TIME = "movementTime";
	public static final String VALUE_DATE = "valueDate";
	public static final String TX_TYPE = "txType";
	public static final String MOVEMENT_INFO = "movementInfo";
	public static final String FUNDS_CODE = "fundsCode";
	public static final String EXTRACT = "extract";
	public static final String CUSTOMER_REFERENCE = "customerReference";
	public static final String BOOK_BALANCE_AMOUNT = "bookBalanceAmount";
	public static final String ID = "id";
	public static final String PAGE = "page";
	public static final String MARK = "mark";

}

