package com.isban.gcb.ic.commons.model;

public class AccountsError {
  private String source;
  private String message;

  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public AccountsError source(String source) {
    this.source = source;
    return this;
  }

  public String getMessage() {
    return message;
  }

  public AccountsError message(String message) {
    this.message = message;
    return this;
  }

  public void setMessage(String message) {
    this.message = message;
  }
}
