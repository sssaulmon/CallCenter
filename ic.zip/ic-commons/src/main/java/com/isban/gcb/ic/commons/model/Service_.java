package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Service.class)
public abstract class Service_ extends com.isban.gcb.ic.commons.model.AuditableLocalDate_ {

	public static volatile SingularAttribute<Service, Boolean> uninformedSend;
	public static volatile SingularAttribute<Service, ServiceType> serviceType;
	public static volatile SingularAttribute<Service, LocalDate> endDate;
	public static volatile SingularAttribute<Service, String> timeDelta;
	public static volatile SingularAttribute<Service, String> uuid;
	public static volatile SingularAttribute<Service, ServiceSendFormat> serviceSendFormat;
	public static volatile SetAttribute<Service, ServiceAddress> serviceAddressSet;
	public static volatile SingularAttribute<Service, Boolean> globalReportClientAlias;
	public static volatile SingularAttribute<Service, String> lastModifiedUser;
	public static volatile SingularAttribute<Service, Long> id;
	public static volatile SingularAttribute<Service, ServiceSendFreq> serviceSendFreq;
	public static volatile SingularAttribute<Service, CustomizationType> customizationType;
	public static volatile SingularAttribute<Service, Boolean> implementationChannel;
	public static volatile SingularAttribute<Service, String> contractNumber;
	public static volatile SingularAttribute<Service, String> sendDays;
	public static volatile SetAttribute<Service, ServiceAccount> serviceAccountSet;
	public static volatile SingularAttribute<Service, String> filenameAlias;
	public static volatile SingularAttribute<Service, Boolean> unixNewLine;
	public static volatile SingularAttribute<Service, Boolean> appendAccounts;
	public static volatile SingularAttribute<Service, Boolean> sicMigrated;
	public static volatile SingularAttribute<Service, String> sendHours;
	public static volatile SingularAttribute<Service, String> name;
	public static volatile SingularAttribute<Service, ServiceSendChannel> serviceSendChannel;
	public static volatile SingularAttribute<Service, Boolean> newLineEnd;
	public static volatile SingularAttribute<Service, String> uuidStructureBussinesGroup;
	public static volatile SingularAttribute<Service, LocalDate> startDate;

	public static final String UNINFORMED_SEND = "uninformedSend";
	public static final String SERVICE_TYPE = "serviceType";
	public static final String END_DATE = "endDate";
	public static final String TIME_DELTA = "timeDelta";
	public static final String UUID = "uuid";
	public static final String SERVICE_SEND_FORMAT = "serviceSendFormat";
	public static final String SERVICE_ADDRESS_SET = "serviceAddressSet";
	public static final String GLOBAL_REPORT_CLIENT_ALIAS = "globalReportClientAlias";
	public static final String LAST_MODIFIED_USER = "lastModifiedUser";
	public static final String ID = "id";
	public static final String SERVICE_SEND_FREQ = "serviceSendFreq";
	public static final String CUSTOMIZATION_TYPE = "customizationType";
	public static final String IMPLEMENTATION_CHANNEL = "implementationChannel";
	public static final String CONTRACT_NUMBER = "contractNumber";
	public static final String SEND_DAYS = "sendDays";
	public static final String SERVICE_ACCOUNT_SET = "serviceAccountSet";
	public static final String FILENAME_ALIAS = "filenameAlias";
	public static final String UNIX_NEW_LINE = "unixNewLine";
	public static final String APPEND_ACCOUNTS = "appendAccounts";
	public static final String SIC_MIGRATED = "sicMigrated";
	public static final String SEND_HOURS = "sendHours";
	public static final String NAME = "name";
	public static final String SERVICE_SEND_CHANNEL = "serviceSendChannel";
	public static final String NEW_LINE_END = "newLineEnd";
	public static final String UUID_STRUCTURE_BUSSINES_GROUP = "uuidStructureBussinesGroup";
	public static final String START_DATE = "startDate";

}

