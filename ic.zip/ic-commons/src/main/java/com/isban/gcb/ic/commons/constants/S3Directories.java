package com.isban.gcb.ic.commons.constants;

import java.util.stream.Stream;

public enum S3Directories {

  MT940("/mt940/"),
  MT940_PAGES("/mt940/pages/"),
  MT940_RELAY("/mt940relay/"),
  MT940_RELAY_PAGES("/mt940relay/pages/"),
  MT950("/mt950/"),
  MT950_PAGES("/mt950/pages/"),
  MT950_RELAY("/mt950relay/"),
  MT950_RELAY_PAGES("/mt950relay/pages/"),
  STANDARD("/standard/"),
  STANDARD_PAGES("/standard/pages/"),
  OUTPUT_FORMAT("/outputformat/"),
  OUTPUT_FORMAT_PAGES("/outputformat/pages/"),
  GLOBAL_REPORT("/globalreport/"),
  GLOBAL_REPORT_PAGES("/pages/");

  private String directory;

  S3Directories(String directory) {
    this.directory = directory;
  }

  public String getDirectory() {
    return directory;
  }

  public static String getDirectory(String path) {
    return Stream.of(S3Directories.values())
      .filter(s3Directory -> path.equals(s3Directory.directory))
      .map(S3Directories::getDirectory)
      .findFirst()
      .orElseThrow(IllegalArgumentException::new);
  }

}
