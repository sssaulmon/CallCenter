package com.isban.gcb.ic.commons.model;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@Entity(name = "API_SERVICE")
public class ApiService extends AuditableLocalDateTime {

  @Id
  @Column(name = "UUID")
  private String uuid;

  @Column(name = "API_TYPE")
  private String apiType;

  @Column(name = "SERVICE_NAME")
  private String serviceName;

  @Column(name = "SERVICE_TYPE")
  private String serviceType;

  @Column(name = "CLIENT_ID")
  private String clientID;

  @Column(name = "USER_TYPE")
  private String userType;

  @Column(name = "UUID_STRUCTURE_BUSINESS_GROUP")
  private String uuidStructureBusinessGroup;

  @Column(name = "UUID_CORPORATE")
  private String uuidCorporate;

  @Column(name = "START_DATE")
  private LocalDateTime startDate;

  @Column(name = "SEND_CHANNEL")
  private String sendChannel;

  @Column(name = "CONTRACT_NUMBER")
  private String contractNumber;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  @Column(name = "LAST_MODIFIED_USER")
  private String lastModifiedUser;

  @OneToMany(mappedBy = "apiService", cascade = CascadeType.ALL)
  @Column(name = "API_SERVICE_ACCOUNT_UUID")
  private Set<ApiServiceAccount> apiServiceAccounts = new HashSet<>();

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;

    if (o == null || getClass() != o.getClass()) return false;

    ApiService that = (ApiService) o;

    return new EqualsBuilder()
      .appendSuper(super.equals(o))
      .append(uuid, that.uuid)
      .append(apiType, that.apiType)
      .append(serviceName, that.serviceName)
      .append(serviceType, that.serviceType)
      .append(clientID, that.clientID)
      .append(userType, that.userType)
      .append(uuidStructureBusinessGroup, that.uuidStructureBusinessGroup)
      .append(uuidCorporate, that.uuidCorporate)
      .append(startDate, that.startDate)
      .append(sendChannel, that.sendChannel)
      .append(contractNumber, that.contractNumber)
      .append(endDate, that.endDate)
      .append(lastModifiedUser, that.lastModifiedUser)
      .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .appendSuper(super.hashCode())
      .append(uuid)
      .append(apiType)
      .append(serviceName)
      .append(serviceType)
      .append(clientID)
      .append(userType)
      .append(uuidStructureBusinessGroup)
      .append(uuidCorporate)
      .append(startDate)
      .append(sendChannel)
      .append(contractNumber)
      .append(endDate)
      .append(lastModifiedUser)
      .toHashCode();
  }
}
