package com.isban.gcb.ic.commons.mt9X0;

public enum MTAreaType {
    INFOTIPOMEN("Información del tipo de mensaje"),
    INFOENTEMI("Información de la entidad emisora"),
    INFOGENEXTR("Información general Extracto"),
    OPENBAL("Opening Balance - Mandatory"),
    INFOMOVS("Información Movimientos (0...N movimientos) - Optional"),
    CLOSBAL("Closing Balance - Mandatory"),
    CLOSAVBAL("Closing Available Balance - Optional"),
    FORAVBAL("Forward Available Balance - (0…N saldos) Optional"),
    INFOGENEXT("Información general Extracto - Optional");

    private MTAreaType(String descripcion) {
    }

}
