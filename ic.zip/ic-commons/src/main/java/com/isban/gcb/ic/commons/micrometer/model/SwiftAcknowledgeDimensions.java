package com.isban.gcb.ic.commons.micrometer.model;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Getter
@NoArgsConstructor
public class SwiftAcknowledgeDimensions extends OutputDimensions {
  private String acknowledge;

  @Builder(builderMethodName = "swiftAckDimensionsBuilder")
  public SwiftAcknowledgeDimensions(Boolean accumulated, String bicType, String client, String clientCategory, String currency,
                                    String entityAccountAlias, Boolean planned, String productCode, String senderEntity,
                                    String subproductCode, String uuidStructureAcc, Boolean append, Boolean resend,
                                    OutputChannel outputChannel, String contractNumber, OffsetDateTime accountingDateUTC, 
                                    String status, String acknowledge) {
    super(accumulated, bicType, client, clientCategory, currency, entityAccountAlias, planned, productCode, senderEntity,
      subproductCode, uuidStructureAcc, accountingDateUTC, status, append, resend, outputChannel, contractNumber);
    this.acknowledge = acknowledge;
  }
}
