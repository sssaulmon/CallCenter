package com.isban.gcb.ic.commons.balance.cache.dto;

import com.isban.gcb.ic.commons.model.ClosingAvailableBalance;
import com.isban.gcb.ic.commons.model.Extract;
import com.isban.gcb.ic.commons.model.ReceiveFreqDaily;
import com.isban.gcb.ic.commons.model.Subproduct;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import static com.isban.gcb.ic.commons.balance.cache.dto.BalanceType.INTRA_DAY;

public class ExtractDto {

  private Long id;
  private String bic;
  private String accountAlias;
  private String currency;
  private String balanceType;
  private LocalDateTime accountingDate;
  private String openingBalanceMark;
  private LocalDateTime openingBalanceDate;
  private Double openingBalanceAmount;
  private String closingBalanceMark;
  private LocalDateTime closingBalanceDate;
  private Double closingBalanceAmount;
  private String availableBalanceMark;
  private LocalDateTime availableBalanceDate;
  private Double availableBalanceAmount;
  private boolean valid;
  private String formatType;
  private boolean accumulated;
  private boolean transactions;
  private boolean bestTransactions;
  private String information;
  private String status;

  // for JSON, don't delete it
  public ExtractDto() {
    super();
  }

  private ExtractDto(Builder builder) {
    id = builder.id;
    bic = builder.bic;
    accountAlias = builder.accountAlias;
    currency = builder.currency;
    balanceType = builder.balanceType;
    accountingDate = builder.accountingDate;
    openingBalanceMark = builder.openingBalanceMark;
    openingBalanceDate = builder.openingBalanceDate;
    openingBalanceAmount = builder.openingBalanceAmount;
    closingBalanceMark = builder.closingBalanceMark;
    closingBalanceDate = builder.closingBalanceDate;
    closingBalanceAmount = builder.closingBalanceAmount;
    availableBalanceMark = builder.availableBalanceMark;
    availableBalanceDate = builder.availableBalanceDate;
    availableBalanceAmount = builder.availableBalanceAmount;
    valid = builder.valid;
    formatType = builder.formatType;
    accumulated = builder.accumulated;
    transactions = builder.transactions;
    bestTransactions = builder.bestTransactions;
    information = builder.information;
    status = builder.status;
  }

  public Long getId() {
    return id;
  }

  public String getBic() {
    return bic;
  }

  public String getAccountAlias() {
    return accountAlias;
  }

  public String getCurrency() {
    return currency;
  }

  public String getBalanceType() {
    return balanceType;
  }

  public LocalDateTime getAccountingDate() {
    return accountingDate;
  }

  public String getOpeningBalanceMark() {
    return openingBalanceMark;
  }

  public LocalDateTime getOpeningBalanceDate() {
    return openingBalanceDate;
  }

  public Double getOpeningBalanceAmount() {
    return openingBalanceAmount;
  }

  public String getClosingBalanceMark() {
    return closingBalanceMark;
  }

  public LocalDateTime getClosingBalanceDate() {
    return closingBalanceDate;
  }

  public Double getClosingBalanceAmount() {
    return closingBalanceAmount;
  }

  public String getAvailableBalanceMark() {
    return availableBalanceMark;
  }

  public LocalDateTime getAvailableBalanceDate() {
    return availableBalanceDate;
  }

  public Double getAvailableBalanceAmount() {
    return availableBalanceAmount;
  }

  public boolean isValid() {
    return valid;
  }

  public String getFormatType() {
    return formatType;
  }

  public boolean isAccumulated() {
    return accumulated;
  }

  public boolean isTransactions() {
    return transactions;
  }

  public boolean isBestTransactions() {
    return bestTransactions;
  }

  public String getInformation() {
    return information;
  }

  public String getStatus() {
    return status;
  }

  public static Builder builder() {
    return new Builder();
  }

  public static Builder builder(ExtractDto extractDto) {
    return new Builder(extractDto);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;

    if (o == null || getClass() != o.getClass()) return false;

    ExtractDto that = (ExtractDto) o;

    return new EqualsBuilder()
      .append(bic, that.bic)
      .append(accountAlias, that.accountAlias)
      .append(currency, that.currency)
      .append(balanceType, that.balanceType)
      .append(accountingDate, that.accountingDate)
      .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(bic)
      .append(accountAlias)
      .append(currency)
      .append(balanceType)
      .append(accountingDate)
      .toHashCode();
  }

  @Override
  public String toString() {
    return "ExtractDto{" +
      "id=" + id +
      ", bic='" + bic + '\'' +
      ", accountAlias='" + accountAlias + '\'' +
      ", currency='" + currency + '\'' +
      ", balanceType='" + balanceType + '\'' +
      ", accountingDate=" + accountingDate +
      ", openingBalanceMark='" + openingBalanceMark + '\'' +
      ", openingBalanceDate=" + openingBalanceDate +
      ", openingBalanceAmount=" + openingBalanceAmount +
      ", closingBalanceMark='" + closingBalanceMark + '\'' +
      ", closingBalanceDate=" + closingBalanceDate +
      ", closingBalanceAmount=" + closingBalanceAmount +
      ", availableBalanceMark='" + availableBalanceMark + '\'' +
      ", availableBalanceDate=" + availableBalanceDate +
      ", availableBalanceAmount=" + availableBalanceAmount +
      ", valid=" + valid +
      ", formatType='" + formatType + '\'' +
      ", accumulated=" + accumulated +
      ", transactions=" + transactions +
      ", bestTransactions=" + bestTransactions +
      ", information=" + information +
      ", status=" + information +
      '}';
  }

  public static ExtractDto fromExtract(Extract extract, boolean bestTransactions) {
    ClosingAvailableBalance closingAvailableBalance = Optional.ofNullable(extract.getClosingAvailableBalance())
      .orElseGet(ClosingAvailableBalance::new);
    BalanceType balanceType = BalanceType.getBalanceType(extract.getType());
    return builder().accountAlias(extract.getAccountIdentification())
      .accountingDate(getAccountingDate(extract, balanceType))
      .accumulated(isAccumulated(extract))
      .availableBalanceAmount(closingAvailableBalance.getAmount())
      .availableBalanceDate(getLocalDateTime(closingAvailableBalance.getDate()))
      .availableBalanceMark(Optional.ofNullable(closingAvailableBalance.getMark())
        .map(Object::toString)
        .orElse(null))
      .balanceType(balanceType.toString())
      .bic(extract.getEntityAccountBic())
      .closingBalanceAmount(extract.getClosingBalanceAmount())
      .closingBalanceDate(getLocalDateTime(extract.getClosingBalanceDate()))
      .closingBalanceMark(Optional.ofNullable(extract.getClosingBalanceMark())
        .map(Object::toString)
        .orElse(null))
      .currency(extract.getCurrency())
      .formatType(extract.getType())
      .id(extract.getId())
      .openingBalanceAmount(extract.getOpeningBalanceAmount())
      .openingBalanceDate(getLocalDateTime(extract.getOpeningBalanceDate()))
      .openingBalanceMark(Optional.ofNullable(extract.getOpeningBalanceMark())
        .map(Object::toString)
        .orElse(null))
      .valid(extract.getValid())
      .transactions(hasTransactionsForExtractType(extract.getType()))
      .bestTransactions(bestTransactions)
      .build();
  }

  private static LocalDateTime getAccountingDate(Extract extract, BalanceType balanceType) {
    return Optional.of(balanceType)
      .filter(INTRA_DAY::equals)
      .map(given -> extract.getDateTimeIndication())
      .orElse(getLocalDateTime(extract.getClosingBalanceDate()));
  }

  private static LocalDateTime getLocalDateTime(LocalDate localDate) {
    return Optional.ofNullable(localDate)
      .map(LocalDate::atStartOfDay)
      .orElse(null);
  }

  private static boolean isAccumulated(Extract extract) {
    return Optional.of(extract)
      .map(Extract::getSubproduct)
      .map(Subproduct::getReceiveFreqDaily)
      .map(ReceiveFreqDaily::getAccumulatedInformation)
      .orElse(false);
  }

  private static boolean hasTransactionsForExtractType(String extractType) {
    return Optional.of(extractType)
      .filter("MT942"::equals)
      .isPresent();
  }

  public static class Builder {

    private Long id;
    private String bic;
    private String accountAlias;
    private String currency;
    private String balanceType;
    private LocalDateTime accountingDate;
    private String openingBalanceMark;
    private LocalDateTime openingBalanceDate;
    private Double openingBalanceAmount;
    private String closingBalanceMark;
    private LocalDateTime closingBalanceDate;
    private Double closingBalanceAmount;
    private String availableBalanceMark;
    private LocalDateTime availableBalanceDate;
    private Double availableBalanceAmount;
    private boolean valid;
    private String formatType;
    private boolean accumulated;
    private boolean transactions;
    private boolean bestTransactions;
    private String information;
    private String status;

    private Builder() {
      super();
    }

    private Builder(ExtractDto extractDto) {
      id = extractDto.id;
      bic = extractDto.bic;
      accountAlias = extractDto.accountAlias;
      currency = extractDto.currency;
      balanceType = extractDto.balanceType;
      accountingDate = extractDto.accountingDate;
      openingBalanceMark = extractDto.openingBalanceMark;
      openingBalanceDate = extractDto.openingBalanceDate;
      openingBalanceAmount = extractDto.openingBalanceAmount;
      closingBalanceMark = extractDto.closingBalanceMark;
      closingBalanceDate = extractDto.closingBalanceDate;
      closingBalanceAmount = extractDto.closingBalanceAmount;
      availableBalanceMark = extractDto.availableBalanceMark;
      availableBalanceDate = extractDto.availableBalanceDate;
      availableBalanceAmount = extractDto.availableBalanceAmount;
      valid = extractDto.valid;
      formatType = extractDto.formatType;
      accumulated = extractDto.accumulated;
      transactions = extractDto.transactions;
      bestTransactions = extractDto.bestTransactions;
      information = extractDto.information;
      status = extractDto.status;
    }

    public Builder id(Long id) {
      this.id = id;
      return this;
    }

    public Builder bic(String bic) {
      this.bic = bic;
      return this;
    }

    public Builder accountAlias(String accountCode) {
      this.accountAlias = accountCode;
      return this;
    }

    public Builder currency(String currency) {
      this.currency = currency;
      return this;
    }

    public Builder balanceType(String balanceType) {
      this.balanceType = balanceType;
      return this;
    }

    public Builder accountingDate(LocalDateTime accountingDate) {
      this.accountingDate = accountingDate;
      return this;
    }

    public Builder openingBalanceMark(String openingBalanceMark) {
      this.openingBalanceMark = openingBalanceMark;
      return this;
    }

    public Builder openingBalanceDate(LocalDateTime openingBalanceDate) {
      this.openingBalanceDate = openingBalanceDate;
      return this;
    }

    public Builder openingBalanceAmount(Double openingBalanceAmount) {
      this.openingBalanceAmount = openingBalanceAmount;
      return this;
    }

    public Builder closingBalanceMark(String closingBalanceMark) {
      this.closingBalanceMark = closingBalanceMark;
      return this;
    }

    public Builder closingBalanceDate(LocalDateTime closingBalanceDate) {
      this.closingBalanceDate = closingBalanceDate;
      return this;
    }

    public Builder closingBalanceAmount(Double closingBalanceAmount) {
      this.closingBalanceAmount = closingBalanceAmount;
      return this;
    }

    public Builder availableBalanceMark(String availableBalanceMark) {
      this.availableBalanceMark = availableBalanceMark;
      return this;
    }

    public Builder availableBalanceDate(LocalDateTime availableBalanceDate) {
      this.availableBalanceDate = availableBalanceDate;
      return this;
    }

    public Builder availableBalanceAmount(Double availableBalanceAmount) {
      this.availableBalanceAmount = availableBalanceAmount;
      return this;
    }

    public Builder valid(boolean valid) {
      this.valid = valid;
      return this;
    }

    public Builder formatType(String formatType) {
      this.formatType = formatType;
      return this;
    }

    public Builder accumulated(boolean accumulated) {
      this.accumulated = accumulated;
      return this;
    }

    public Builder transactions(boolean transactions) {
      this.transactions = transactions;
      return this;
    }

    public Builder bestTransactions(boolean bestTransactions) {
      this.bestTransactions = bestTransactions;
      return this;
    }

    public Builder information(String information) {
      this.information = information;
      return this;
    }

    public Builder status(String status) {
      this.status = status;
      return this;
    }

    public ExtractDto build() {
      return new ExtractDto(this);
    }
  }
}
