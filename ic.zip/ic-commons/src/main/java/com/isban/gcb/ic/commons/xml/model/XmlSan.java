package com.isban.gcb.ic.commons.xml.model;

import com.isban.gcb.ic.commons.xml.EBCDICAdapter;

import javax.validation.constraints.NotEmpty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(name = "xml_payment")
public class XmlSan {

  @XmlElement(name = "payment_header")
  private XmlSanHeader header;

  @XmlJavaTypeAdapter(EBCDICAdapter.class)
  @NotEmpty
  @XmlElement(name = "payment_body")
  private String paymentBody;

  public XmlSanHeader getHeader() {
    return header;
  }

  public XmlSan header(XmlSanHeader header) {
    this.header = header;
    return this;
  }

  public String getPaymentBody() {
    return paymentBody;
  }

  public XmlSan paymentBody(String paymentBody) {
    this.paymentBody = paymentBody;
    return this;
  }
}
