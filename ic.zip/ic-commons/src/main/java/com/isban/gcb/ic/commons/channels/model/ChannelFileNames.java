package com.isban.gcb.ic.commons.channels.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.isban.gcb.ic.commons.model.report.global.Address;
import lombok.*;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "basePath",
        "fileName",
        "addresses"
})
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class ChannelFileNames implements Serializable {

    private static final long serialVersionUID = 6505690107074545873L;

    @JsonProperty("basePath")
    private String basePath;

    @JsonProperty("fileName")
    private String fileName;

    @JsonProperty("addresses")
    private List<Address> addresses;
}
