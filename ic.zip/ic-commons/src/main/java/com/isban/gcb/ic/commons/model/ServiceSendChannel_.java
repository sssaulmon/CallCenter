package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(ServiceSendChannel.class)
public abstract class ServiceSendChannel_ extends com.isban.gcb.ic.commons.model.AuditableLocalDate_ {

	public static volatile SingularAttribute<ServiceSendChannel, LocalDate> endDate;
	public static volatile SingularAttribute<ServiceSendChannel, String> description;
	public static volatile SingularAttribute<ServiceSendChannel, Long> id;
	public static volatile SingularAttribute<ServiceSendChannel, String> uuid;
	public static volatile SetAttribute<ServiceSendChannel, Service> serviceSet;

	public static final String END_DATE = "endDate";
	public static final String DESCRIPTION = "description";
	public static final String ID = "id";
	public static final String UUID = "uuid";
	public static final String SERVICE_SET = "serviceSet";

}

