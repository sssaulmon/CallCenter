package com.isban.gcb.ic.commons.model.report.global;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
  "account",
  "version",
  "aliasAccount",
  "uuidStructureAcc",
  "master"
})
public class Account implements Serializable {

    private static final long serialVersionUID = -3039312305819065167L;
    @JsonProperty("account")
    private String account;

    @JsonProperty("version")
    private String version;

    @JsonProperty("aliasAccount")
    private String aliasAccount;
  
    @JsonProperty("master")
    private Boolean master;
  
    public Account(String account, String version, String aliasAccount, Boolean master) {
        this.account = account;
        this.version = version;
        this.aliasAccount = aliasAccount;
        this.master = master;
    }

    public Account() {
    }

    public String getAccount() {
        return this.account;
    }

    public String getVersion() {
        return this.version;
    }

    public Boolean isMaster() {
        return this.master;
    }

    public Boolean getMaster() {
        return this.master;
    }
  
    public String getAliasAccount() {
        return this.aliasAccount;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public void setAliasAccount(String aliasAccount) {
        this.aliasAccount = aliasAccount;
    }
  
    public void setMaster(Boolean master) {
        this.master = master;
    }

    public Account account(String account) {
        this.account = account;
        return this;
    }

    public Account version(String version) {
        this.version = version;
        return this;
    }

    public Account aliasAccount(String aliasAccount) {
        this.aliasAccount = aliasAccount;
        return this;
    }

    public Account master(Boolean master) {
        this.master = master;
        return this;
    }
  
    public String toString() {
        return "Account(account=" + this.getAccount() + ", version=" + this.getVersion() + ", aliasAccount=" + this.getAliasAccount() + ", master=" + this.isMaster() + ")";
    }
}