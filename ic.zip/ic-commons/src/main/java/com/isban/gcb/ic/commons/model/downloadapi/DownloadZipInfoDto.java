package com.isban.gcb.ic.commons.model.downloadapi;

public class DownloadZipInfoDto {

  private String s3Url;
  private String fileZip;

  public DownloadZipInfoDto() {
  }

  public DownloadZipInfoDto(String s3Url, String fileName) {
    this.s3Url = s3Url;
    this.fileZip= fileName;
  }

  public String getS3Url() {
    return this.s3Url;
  }

  public String getFileZip() {
    return this.fileZip;
  }

  public void setS3Url(String s3Url) {
    this.s3Url = s3Url;
  }

  public void setFileZip(String fileName) {
    this.fileZip = fileName;
  }

  public String toString() {
    return "DownloadZipInfoDto(s3Url=" + this.getS3Url() + ", fileZip=" + this.getFileZip() + ")";
  }
}