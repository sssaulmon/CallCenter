package com.isban.gcb.ic.commons.converter.model;

import com.isban.gcb.ic.commons.converter.Constants;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RegistryDto {

  /**
   * Fecha de extraccion (06)
   */
  private LocalDate extractDate;

  /**
   * Hora de la extraccion (08)
   */
  private LocalTime extractTime;

  /**
   * Cantidad de registros generados mas el resumen (09)
   */
  private Integer totalRegistryNumber;

  /**
   * Cantidad de cuentas informadas en la interfaz (09)
   */
  private Integer totalAccountsNumber;

  /**
   * Cantidad de movimientos de abonos (09)
   */
  private Integer totalDepositMovementsNumber;

  /**
   * Cantidad de movimientos de cargos (09)
   */
  private Integer totalChargeMovementsNumber;

  /**
   * Importe total de movimientos (14,2)
   */
  private BigDecimal totalMovementsAmount;

  /**
   * Importe total de abonos (14,2)
   */
  private BigDecimal totalDepositAmount;

  /**
   * Importe total de cargos (14,2)
   */
  private BigDecimal totalChargeAmount;

  /**
   * Indicador de proceso (01)
   * <p>
   * N = Normal
   * R = Reproceso
   */
  private String processIndicator;

  /**
   * Complementario (200)
   */
  private String filler;

  @Override
  public String toString() {
    DecimalFormat fmt = new DecimalFormat("+0000000000000000;-0000000000000000");

    return extractDate.format(DateTimeFormatter.ofPattern(Constants.CONVERTER_DATE_FORMAT))
      + extractTime.format(DateTimeFormatter.ofPattern(Constants.CONVERTER_TYPE_ZERO_TIME_FORMAT))
      + String.format("%09d", totalRegistryNumber)
      + String.format("%09d", totalAccountsNumber)
      + String.format("%09d", totalDepositMovementsNumber)
      + String.format("%09d", totalChargeMovementsNumber)
      + fmt.format(totalMovementsAmount.multiply(new BigDecimal(100)).toBigInteger())
      + fmt.format(totalDepositAmount.multiply(new BigDecimal(100)).toBigInteger())
      + fmt.format(totalChargeAmount.multiply(new BigDecimal(100)).toBigInteger())
      + processIndicator
      + filler;
  }

  @Override
  public boolean equals(Object o) {

    if (o == this) return true;
    if (!(o instanceof RegistryDto)) {
      return false;
    }
    RegistryDto instance2 = (RegistryDto) o;

    return extractDate.equals(instance2.getExtractDate())
      && extractTime.equals(instance2.getExtractTime())
      && totalRegistryNumber.equals(instance2.getTotalRegistryNumber())
      && totalAccountsNumber.equals(instance2.getTotalAccountsNumber())
      && totalDepositMovementsNumber.equals(instance2.getTotalDepositMovementsNumber())
      && totalChargeMovementsNumber.equals(instance2.getTotalChargeMovementsNumber())
//                && totalMovementsAmount.equals(instance2.getTotalMovementsAmount())
//                && totalDepositAmount.equals(instance2.getTotalDepositAmount())
//                && totalChargeAmount.equals(instance2.getTotalChargeAmount())
//                && processIndicator.equals(instance2.getProcessIndicator())
      && filler.equals(instance2.getFiller());

  }

  @Override
  public int hashCode() {

    return Objects.hash(extractDate, extractTime, totalRegistryNumber, totalAccountsNumber,
      totalDepositMovementsNumber, totalChargeMovementsNumber, totalMovementsAmount, totalDepositAmount,
      totalChargeAmount, processIndicator, filler);
  }
}