package com.isban.gcb.ic.commons.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "receive_freq_daily",
        indexes = {@Index(columnList = "uuid", name = "uuid_receive_freq_daily")})
public class ReceiveFreqDaily extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "receive_freq_daily_gen")
    @SequenceGenerator(name = "receive_freq_daily_gen", sequenceName = "rec_freq_daily_generator",
            allocationSize = 1)
    private Long id;

    @Column(name = "receive_days")
    private String receiveDays;

    @Size(max = 1000)
    @Column(name = "receive_hour", length = 1000)
    private String receiveHour;

    @Column(name = "receive_festive")
    private Boolean reciveFestive;

    @Column(name = "next_business_day")
    private Boolean nextBusinessDay;

    @Column(name = "next_day_after_weekend")
    private Boolean nextDayAfterWeekend;

    @Size(max = 5)
    @Column(name = "threshold", length = 5)
    private String threshold;

    @Size(max = 40)
    @Column(name = "uuid", length = 40)
    private String uuid;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Column(name = "Receive_Monitoring")
    private Boolean receiveMonitoring;

    @Size(max = 20)
    @Column(name = "last_modified_user", length = 20)
    private String lastModifiedUser;

    @OneToMany(mappedBy = "receiveFreqDaily")
    @JsonIgnore
    private Set<Subproduct> subproducts = new HashSet<>();

    @ManyToOne
    @JoinColumn(name = "RECEIVE_FREQ_TYPE_ID", referencedColumnName = "ID")
    private ReceiveFreqType receiveFreqType;

    @ManyToOne
    @JoinColumn(name = "RECEIVE_FREQ_SEND_DATE_ID", referencedColumnName = "ID")
    private ReceiveFreqSendDate receiveFreqSendDate;

    private Boolean plannable;

    @Column(name = "accumulated_information")
    private Boolean accumulatedInformation;
}
