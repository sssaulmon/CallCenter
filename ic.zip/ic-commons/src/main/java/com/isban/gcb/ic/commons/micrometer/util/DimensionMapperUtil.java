package com.isban.gcb.ic.commons.micrometer.util;

import com.isban.gcb.ic.commons.converter.model.AccountTransactionDto;
import com.isban.gcb.ic.commons.micrometer.model.InputChannel;
import com.isban.gcb.ic.commons.micrometer.model.InputRejectedDimensions;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class DimensionMapperUtil {

  private static final List<String> MFT = Arrays.asList("2", "3", "6");

  public static InputRejectedDimensions toRejectedExtractDimension(AccountTransactionDto accountTransactionDto,
                                                                   String rejectionReason, InputChannel inputChannel) {
    return InputRejectedDimensions.inputRejectedBuilder()
      .rejectionReason(rejectionReason)
      .inputChannel(inputChannel)
      .productCode(accountTransactionDto.getMetadata().getProductCode())
      .subproductCode(accountTransactionDto.getMetadata().getSubproductCode())
      .currency(accountTransactionDto.getMetadata().getCurrency())
      .entityAccountAlias(accountTransactionDto.getMetadata().getAliasAccount())
      .uuidStructureAcc(accountTransactionDto.getMetadata().getUuidStructureAcc())
      .senderEntity(accountTransactionDto.getMetadata().getEntity())
      .accountingDateUTC(Optional.ofNullable(accountTransactionDto.getMetadata().getAccountingDate())
        .map(LocalDate::parse)
        .map(LocalDate::atStartOfDay)
        .map(localDateTime -> OffsetDateTime.of(localDateTime, ZoneOffset.UTC))
        .orElse(null))
      .build();
  }

  public static InputChannel toInputChannel(String subProduct) {
    return Optional.ofNullable(subProduct)
      .filter(MFT::contains)
      .map(data -> InputChannel.MFT)
      .orElse(InputChannel.SWIFT_FIN);
  }

  public static OffsetDateTime getAccountingDateAsUTC(String accountingDateString) {
    return Optional.of(accountingDateString)
      .map(DimensionMapperUtil::getOffsetAccountingDate)
      .map(accountingDateTime -> OffsetDateTime.of(accountingDateTime.toLocalDateTime(), ZoneOffset.UTC))
      .orElseThrow(() -> new RuntimeException("Cannot obtain OffsetDateTime from " + accountingDateString));
  }

  public static OffsetDateTime getOffsetAccountingDate(String dateString) {
    Predicate<String> isIsoBasicDate = date -> date.length() == 10;

    return Optional.of(dateString)
      .filter(isIsoBasicDate)
      .map(date -> OffsetDateTime.of(LocalDate.parse(date).atStartOfDay(), ZoneOffset.UTC))
      .orElseGet(() -> OffsetDateTime.parse(dateString));
  }
}
