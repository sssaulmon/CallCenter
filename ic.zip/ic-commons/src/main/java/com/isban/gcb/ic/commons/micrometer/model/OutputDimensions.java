package com.isban.gcb.ic.commons.micrometer.model;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.OffsetDateTime;

@Getter
@ToString(callSuper = true)
@NoArgsConstructor
public class OutputDimensions extends BaseDimensions {
  
  private Boolean append;
  private Boolean resend;
  private OutputChannel outputChannel;
  private String contractNumber;

  @Builder(builderMethodName = "outputDimensionsBuilder")
  public OutputDimensions(Boolean accumulated, String bicType, String client, String clientCategory, String currency, 
                          String entityAccountAlias, Boolean planned, String productCode, String senderEntity, 
                          String subproductCode, String uuidStructureAcc, OffsetDateTime accountingDateUTC, String status,
                          Boolean append, Boolean resend, OutputChannel outputChannel, String contractNumber) {
    super(accumulated, bicType, client, clientCategory, currency, entityAccountAlias, planned, productCode, senderEntity, 
      subproductCode, uuidStructureAcc, accountingDateUTC, status);
    this.append = append;
    this.resend = resend;
    this.outputChannel = outputChannel;
    this.contractNumber = contractNumber;
  }
}
