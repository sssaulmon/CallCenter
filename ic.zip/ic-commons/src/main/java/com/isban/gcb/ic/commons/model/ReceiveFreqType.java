package com.isban.gcb.ic.commons.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * A ReceiveFreqType.
 */
@Entity
@Table(name = "receive_freq_type", indexes = {
        @Index(columnList = "uuid", name = "uuid_receive_freq_type")})
public class ReceiveFreqType extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "receive_freq_type_gen")
    @SequenceGenerator(name = "receive_freq_type_gen", sequenceName = "receive_freq_type_generator", allocationSize = 1)
    private Long id;

    @Size(max = 100)
    @Column(name = "description", length = 100)
    private String description;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Size(max = 40)
    @Column(name = "uuid")
    private String uuid;

    @Size(max = 20)
    @Column(name = "last_modified_user", length = 20)
    private String lastModifiedUser;

    @OneToMany(mappedBy = "receiveFreqType")
    @JsonIgnore
    private Set<ReceiveFreqDaily> idReciveFreqTypes = new HashSet<>();


    private Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ReceiveFreqType description(String description) {
        this.description = description;
        return this;
    }

    private LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public ReceiveFreqType endDate(LocalDate endDate) {
        this.endDate = endDate;
        return this;
    }

    private String getLastModifiedUser() {
        return lastModifiedUser;
    }

    public void setLastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
    }

    public ReceiveFreqType lastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
        return this;
    }

    public Set<ReceiveFreqDaily> getIdReciveFreqTypes() {
        return idReciveFreqTypes;
    }

    public void setIdReciveFreqTypes(Set<ReceiveFreqDaily> receiveFreqDailies) {
        this.idReciveFreqTypes = receiveFreqDailies;
    }

    public ReceiveFreqType idReciveFreqTypes(Set<ReceiveFreqDaily> receiveFreqDailies) {
        this.idReciveFreqTypes = receiveFreqDailies;
        return this;
    }

    public ReceiveFreqType addIdReciveFreqType(ReceiveFreqDaily receiveFreqDaily) {
        this.idReciveFreqTypes.add(receiveFreqDaily);
        receiveFreqDaily.setReceiveFreqType(this);
        return this;
    }

    public ReceiveFreqType removeIdReciveFreqType(ReceiveFreqDaily receiveFreqDaily) {
        this.idReciveFreqTypes.remove(receiveFreqDaily);
        receiveFreqDaily.setReceiveFreqType(null);
        return this;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ReceiveFreqType receiveFreqType = (ReceiveFreqType) o;
        if (receiveFreqType.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), receiveFreqType.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "ReceiveFreqType{" +
                "id=" + getId() +
                ", description='" + getDescription() + "'" +
                ", createDate='" + getCreateDate() + "'" +
                ", endDate='" + getEndDate() + "'" +
                ", lastModifiedDate='" + getLastModifiedDate() + "'" +
                ", lastModifiedUser='" + getLastModifiedUser() + "'" +
                "}";
    }
}
