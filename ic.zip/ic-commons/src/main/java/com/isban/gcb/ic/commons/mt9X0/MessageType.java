package com.isban.gcb.ic.commons.mt9X0;

import com.prowidesoftware.swift.model.mt.mt9xx.MT940;

import java.io.Serializable;


/**
 * @author eduardo.rodriguezllo
 */
public class MessageType implements Serializable {

    private String messageInfo; //Info of Message Type

    /*
    * Constructor Empty
     */
    public MessageType() {
        messageInfo = null;
    }

    /*
    * Constructor Full
     */
    public MessageType(String messageInfo) {
        this.messageInfo = messageInfo;
    }

    /*
    * Getters
     */
    public String getMessageInfo() {
        return messageInfo;
    }

    /*
    * Setters
     */
    public void setMessageInfo(String messageInfo) {
        this.messageInfo = messageInfo;
    }

    /**
     * Extracts fields from a MT940 class to a MessageType Class
     * (ONLY BASIC INFO)
     *
     * @param mt940 MT940 Class
     * @author Eduardo Rodriguez
     */
    public void obtainMessageTypeBasic(MT940 mt940) {
        this.obtainMessageInfo(mt940);
    }

    /**
     * Takes a MT940 Object and extracts the field of MessageType
     *
     * @param mt940 MT940
     * @author Eduardo Rodriguez
     */
    private void obtainMessageInfo(MT940 mt940) {
        this.setMessageInfo("MT" + mt940.getMtId().toString().trim().substring(4).toUpperCase()); //We extract the Message Type
    }
}
