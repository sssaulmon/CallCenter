package com.isban.gcb.ic.commons.model;

import java.time.LocalDateTime;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(ConverterLatamLog.class)
public abstract class ConverterLatamLog_ {

	public static volatile SingularAttribute<ConverterLatamLog, LocalDateTime> createdDate;
	public static volatile SingularAttribute<ConverterLatamLog, LocalDateTime> lastModifiedDate;
	public static volatile SingularAttribute<ConverterLatamLog, Long> id;
	public static volatile SingularAttribute<ConverterLatamLog, String> kafkaMessage;
	public static volatile SingularAttribute<ConverterLatamLog, String> status;

	public static final String CREATED_DATE = "createdDate";
	public static final String LAST_MODIFIED_DATE = "lastModifiedDate";
	public static final String ID = "id";
	public static final String KAFKA_MESSAGE = "kafkaMessage";
	public static final String STATUS = "status";

}

