package com.isban.gcb.ic.commons.model.downloadapi;

public class IntegrationResponseBase<T> {

  private String code;
  private String description;
  private T data;

  public IntegrationResponseBase(String code, String description) {
    this.code = code;
    this.description = description;
  }

  public IntegrationResponseBase(String code, String description, T data) {
    this.code = code;
    this.description = description;
    this.data = data;
  }

  public IntegrationResponseBase() { }

  public String getCode() {
    return this.code;
  }

  public String getDescription() {
    return this.description;
  }

  public T getData() {
    return this.data;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setData(T data) {
    this.data = data;
  }

  public String toString() {
    return "IntegrationResponseBase(code=" + this.getCode() + ", description=" + this.getDescription() + ", data=" + this.getData() + ")";
  }
}

