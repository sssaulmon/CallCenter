package com.isban.gcb.ic.commons.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity(name = "GLOBAL_REPORT")
public class GlobalReport extends AuditableLocalDateTime implements Serializable {

  private static final long serialVersionUID = -315629436961684464L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GLOBAL_REP_GEN")
  @SequenceGenerator(name = "GLOBAL_REP_GEN", sequenceName = "GLOBAL_REP_SEQ", allocationSize = 1)
  private Long id;
  @Column(name = "bic")
  private String bic;
  @Column(name = "account")
  private String account;
  @Column(name = "currency")
  private String currency;
  @Column(name = "contract_number")
  private String contractNumber;
  @Column(name = "s3path")
  private String s3Path;
  @Column(name = "accounting_date")
  private LocalDateTime accountingDate;
  @Column(name = "incoming_date")
  private LocalDateTime incomingDate;
  @Column(name = "status")
  private String status;
  @Column(name = "service_send_channel")
  private String serviceSendChannel;
  @Column(name = "addresses")
  private String addresses;
  @ManyToOne
  @JoinColumn(name = "extract_id", referencedColumnName = "id")
  @JsonBackReference
  private Extract extract;
  @Column(name = "uuid_global_report")
  private String uuidGlobalReport;
  @Column(name = "type")
  private String type;
  @Column(name = "version")
  private String version;
  @Column(name = "append")
  private Boolean append;
  @Column(name = "file_name")
  private String fileName;

  public GlobalReport() {
    super();
  }

  public Long getId() {
    return id;
  }

  public GlobalReport setId(Long id) {
    this.id = id;
    return this;
  }

  public String getBic() {
    return bic;
  }

  public GlobalReport setBic(String bic) {
    this.bic = bic;
    return this;
  }

  public String getAccount() {
    return account;
  }

  public GlobalReport setAccount(String account) {
    this.account = account;
    return this;
  }

  public String getCurrency() {
    return currency;
  }

  public GlobalReport setCurrency(String currency) {
    this.currency = currency;
    return this;
  }

  public String getContractNumber() {
    return contractNumber;
  }

  public GlobalReport setContractNumber(String contractNumber) {
    this.contractNumber = contractNumber;
    return this;
  }

  public String getS3Path() {
    return s3Path;
  }

  public GlobalReport setS3Path(String s3Path) {
    this.s3Path = s3Path;
    return this;
  }

  public LocalDateTime getAccountingDate() {
    return accountingDate;
  }

  public GlobalReport setAccountingDate(LocalDateTime accountingDate) {
    this.accountingDate = accountingDate;
    return this;
  }

  public String getStatus() {
    return status;
  }

  public GlobalReport setStatus(String status) {
    this.status = status;
    return this;
  }

  public String getServiceSendChannel() {
    return serviceSendChannel;
  }

  public GlobalReport setServiceSendChannel(String serviceSendChannel) {
    this.serviceSendChannel = serviceSendChannel;
    return this;
  }

  public String getAddresses() {
    return addresses;
  }

  public GlobalReport setAddresses(String addresses) {
    this.addresses = addresses;
    return this;
  }

  public Extract getExtract() {
    return extract;
  }

  public GlobalReport setExtract(Extract extract) {
    this.extract = extract;
    return this;
  }

  public String getType() {
    return type;
  }

  public GlobalReport setType(String type) {
    this.type = type;
    return this;
  }

  public LocalDateTime getIncomingDate() {
    return incomingDate;
  }

  public GlobalReport setIncomingDate(LocalDateTime incomingDate) {
    this.incomingDate = incomingDate;
    return this;
  }

  public String getUuidGlobalReport() {
    return uuidGlobalReport;
  }

  public GlobalReport setUuidGlobalReport(String uuidGlobalReport) {
    this.uuidGlobalReport = uuidGlobalReport;
    return this;
  }

  public String getVersion() {
    return version;
  }

  public GlobalReport setVersion(String version) {
    this.version = version;
    return this;
  }

  public Boolean isAppend() {
    return append;
  }

  public GlobalReport setAppend(Boolean append) {
    this.append = append;
    return this;
  }

  public String getFileName() {
    return fileName;
  }

  public GlobalReport setFileName(String fileName) {
    this.fileName = fileName;
    return this;
  }
}
