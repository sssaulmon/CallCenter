package com.isban.gcb.ic.commons.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Extract.class)
public abstract class Extract_ extends com.isban.gcb.ic.commons.model.AuditableLocalDateTime_ {

	public static volatile SingularAttribute<Extract, ClosingAvailableBalance> closingAvailableBalance;
	public static volatile SingularAttribute<Extract, Integer> creditSumEntries;
	public static volatile SingularAttribute<Extract, Double> creditSumAmount;
	public static volatile SingularAttribute<Extract, String> creditFloorLimitMark;
	public static volatile ListAttribute<Extract, ExtractMovement> extractMovements;
	public static volatile SingularAttribute<Extract, LocalDateTime> dateTimeIndication;
	public static volatile SingularAttribute<Extract, String> entityAccountBic;
	public static volatile SingularAttribute<Extract, String> type;
	public static volatile SingularAttribute<Extract, String> floorLimitMark;
	public static volatile SingularAttribute<Extract, Boolean> valid;
	public static volatile SingularAttribute<Extract, String> txRefNumber;
	public static volatile SingularAttribute<Extract, String> relatedReference;
	public static volatile SingularAttribute<Extract, String> accountIdentification;
	public static volatile ListAttribute<Extract, ForwardBalance> forwardBalanceList;
	public static volatile SingularAttribute<Extract, String> currency;
	public static volatile SingularAttribute<Extract, Long> id;
	public static volatile SingularAttribute<Extract, LocalDate> closingBalanceDate;
	public static volatile SingularAttribute<Extract, Integer> statementNumber;
	public static volatile SingularAttribute<Extract, Double> debitSumAmount;
	public static volatile SingularAttribute<Extract, LocalDate> openingBalanceDate;
	public static volatile SingularAttribute<Extract, Character> openingBalanceMark;
	public static volatile SingularAttribute<Extract, String> offset;
	public static volatile SingularAttribute<Extract, String> contractNumber;
	public static volatile SingularAttribute<Extract, Double> creditFloorLimitAmount;
	public static volatile SingularAttribute<Extract, Double> closingBalanceAmount;
	public static volatile SingularAttribute<Extract, Subproduct> subproduct;
	public static volatile SingularAttribute<Extract, String> generalInfo;
	public static volatile SingularAttribute<Extract, Integer> version;
	public static volatile SingularAttribute<Extract, Double> openingBalanceAmount;
	public static volatile SingularAttribute<Extract, Character> closingBalanceMark;
	public static volatile SingularAttribute<Extract, ServiceSendChannel> serviceSendChannel;
	public static volatile SingularAttribute<Extract, Integer> debitSumEntries;
	public static volatile SingularAttribute<Extract, Double> floorLimitAmount;
  public static volatile SingularAttribute<Extract, Boolean> computedBalance;

	public static final String CLOSING_AVAILABLE_BALANCE = "closingAvailableBalance";
	public static final String CREDIT_SUM_ENTRIES = "creditSumEntries";
	public static final String CREDIT_SUM_AMOUNT = "creditSumAmount";
	public static final String CREDIT_FLOOR_LIMIT_MARK = "creditFloorLimitMark";
	public static final String EXTRACT_MOVEMENTS = "extractMovements";
	public static final String DATE_TIME_INDICATION = "dateTimeIndication";
	public static final String ENTITY_ACCOUNT_BIC = "entityAccountBic";
	public static final String TYPE = "type";
	public static final String FLOOR_LIMIT_MARK = "floorLimitMark";
	public static final String VALID = "valid";
	public static final String TX_REF_NUMBER = "txRefNumber";
	public static final String RELATED_REFERENCE = "relatedReference";
	public static final String ACCOUNT_IDENTIFICATION = "accountIdentification";
	public static final String FORWARD_BALANCE_LIST = "forwardBalanceList";
	public static final String CURRENCY = "currency";
	public static final String ID = "id";
	public static final String CLOSING_BALANCE_DATE = "closingBalanceDate";
	public static final String STATEMENT_NUMBER = "statementNumber";
	public static final String DEBIT_SUM_AMOUNT = "debitSumAmount";
	public static final String OPENING_BALANCE_DATE = "openingBalanceDate";
	public static final String OPENING_BALANCE_MARK = "openingBalanceMark";
	public static final String OFFSET = "offset";
	public static final String CONTRACT_NUMBER = "contractNumber";
	public static final String CREDIT_FLOOR_LIMIT_AMOUNT = "creditFloorLimitAmount";
	public static final String CLOSING_BALANCE_AMOUNT = "closingBalanceAmount";
	public static final String SUBPRODUCT = "subproduct";
	public static final String GENERAL_INFO = "generalInfo";
	public static final String VERSION = "version";
	public static final String OPENING_BALANCE_AMOUNT = "openingBalanceAmount";
	public static final String CLOSING_BALANCE_MARK = "closingBalanceMark";
	public static final String SERVICE_SEND_CHANNEL = "serviceSendChannel";
	public static final String DEBIT_SUM_ENTRIES = "debitSumEntries";
	public static final String FLOOR_LIMIT_AMOUNT = "floorLimitAmount";
  public static final String COMPUTED_BALANCE = "computedBalance";

}

