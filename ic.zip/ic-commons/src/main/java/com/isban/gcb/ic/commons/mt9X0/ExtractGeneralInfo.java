package com.isban.gcb.ic.commons.mt9X0;

import com.prowidesoftware.swift.model.mt.mt9xx.MT940;

import java.io.Serializable;

/**
 * @author eduardo.rodriguezllo
 */
public class ExtractGeneralInfo implements Serializable {

    private String transactionRefNumber; //Transaction Reference Number
    private String relatedRef; // Related Reference
    private String accountId; //Account Identification
    private String bic; //Identifier Code (BIC)
    private Integer statementNum; //Statement Number
    private Integer pageNum; //Pager Number (0 if it hasn't)

    /*
    * Constructor Empty
     */
    public ExtractGeneralInfo() {
        this.transactionRefNumber = null;
        this.pageNum = 0;
    }

    /*
    * Constructor Full
     */
    public ExtractGeneralInfo(String transactionRefNumber, String relatedRef, String accountId, String bic, Integer statementNum) {
        this.transactionRefNumber = transactionRefNumber;
        this.relatedRef = relatedRef;
        this.accountId = accountId;
        this.bic = bic;
        this.statementNum = statementNum;
        this.pageNum = 0;
    }

    /*
    * Constructor Full
     */
    public ExtractGeneralInfo(String transactionRefNumber, String relatedRef, String accountId, String bic, Integer statementNum, Integer pageNum) {
        this.transactionRefNumber = transactionRefNumber;
        this.relatedRef = relatedRef;
        this.accountId = accountId;
        this.bic = bic;
        this.statementNum = statementNum;
        this.pageNum = pageNum;
    }

    public String getTransactionRefNumber() {
        return transactionRefNumber;
    }

    public String getRelatedRef() {
        return relatedRef;
    }

    public String getAccountId() {
        return accountId;
    }

    public String getBic() {
        return bic;
    }

    public Integer getStatementNum() {
        return statementNum;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    /*
    * Setters
     */
    public void setTransactionRefNumber(String transactionRefNumber) {
        this.transactionRefNumber = transactionRefNumber;
    }

    public void setRelatedRef(String relatedRef) {
        this.relatedRef = relatedRef;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public void setBic(String bic) {
        this.bic = bic;
    }

    public void setStatementNum(Integer statementNum) {
        this.statementNum = statementNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    /**
     * Extracts fields from a MT940 class to ExtractGeneralInfo class (ONLY
     * BASIC INFO)
     *
     * @param mt940 MT940 Class
     * @author Eduardo Rodriguez
     */
    public void obtainExtractGeneralInfoBasic(MT940 mt940) {
        this.obtainTransactionRefNumber(mt940);
        this.obtainRelatedRef(mt940); //Optional
        this.obtainAccountId(mt940);
        this.obtainStatementNum(mt940);
        this.obtainPageNum(mt940); //Optional?*/
    }

    /**
     * Takes a MT940 Object and extracts the field of Transaction Ref Number
     *
     * @param mt940 MT940
     * @author Eduardo Rodriguez
     */
    private void obtainTransactionRefNumber(MT940 mt940) {
        this.setTransactionRefNumber(mt940.getField20().getValue());
    }

    /**
     * Takes a MT940 Object and extracts the field of Related Ref
     *
     * @param mt940 MT940
     * @author Eduardo Rodriguez
     */
    private void obtainRelatedRef(MT940 mt940) {
        if (mt940.getField21() != null)
            this.setTransactionRefNumber(mt940.getField21().getValue());
    }

    /**
     * Takes a MT940 Object and extracts the field of AccountId
     *
     * @param mt940 MT940
     * @author Eduardo Rodriguez
     */
    private void obtainAccountId(MT940 mt940) {
        if (mt940.getField25P() != null) {
            this.setAccountId(mt940.getField25P().getValue().trim());
            this.setBic(mt940.getField25P().getBIC().trim());
        }
        if (mt940.getField25() != null) {
            this.setAccountId(mt940.getField25().getValue().trim());
        }

    }

    /**
     * Takes a MT940 Object and extracts the field of AccountId
     *
     * @param mt940 MT940
     * @author Eduardo Rodriguez
     */
    private void obtainStatementNum(MT940 mt940) {
        this.setStatementNum(new Integer(mt940.getField28C().getComponent1()));
    }

    /**
     * Takes a MT940 Object and extracts the field of PageNum
     *
     * @param mt940 MT940
     * @author Eduardo Rodriguez
     *
     */
    private void obtainPageNum(MT940 mt940) {
        if(mt940.getField28C().getComponent2() == null && mt940.getField62F() != null) {
            this.setPageNum(new Integer(1));
        }else if(mt940.getField28C().getComponent2() == null && mt940.getField62F() == null){
            this.setPageNum(new Integer(0));
        }else {
            this.setPageNum(new Integer(mt940.getField28C().getComponent2().trim()));
        }
    }
}
