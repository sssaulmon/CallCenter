package com.isban.gcb.ic.commons.converter.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.isban.gcb.ic.commons.converter.Constants;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.isban.gcb.ic.commons.converter.Constants.SIX_EXCLAMATIONS;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TransactionDtoConverter extends ConverterBaseDto {

  private static final String START_DELIMITER = "~#";
  private static final String END_DELIMITER = "#~";

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String movementNumber;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String altairOperationCode;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String movementDescription;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private LocalDate movementDate;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private LocalDate operationDate;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private LocalTime operationTime;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private LocalDate accountingDate;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String movementType;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private BigDecimal movementAmount;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private BigDecimal postBalance;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String chequeNumber;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String conceptCode;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String internalReference;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String clientReference;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String swiftCode;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String subSwiftCodeSan;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String observationIndicator;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String observationDescription;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String operationSerialNumber;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String filler;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String data;

  public void reduceToMinimalJSON() {
    this.data = this.toMinimalString();

    super.reset();

    this.movementNumber = null;
    this.altairOperationCode = null;
    this.movementDescription = null;
    this.movementDate = null;
    this.operationDate = null;
    this.operationTime = null;
    this.accountingDate = null;
    this.movementType = null;
    this.movementAmount = null;
    this.postBalance = null;
    this.chequeNumber = null;
    this.conceptCode = null;
    this.internalReference = null;
    this.clientReference = null;
    this.swiftCode = null;
    this.subSwiftCodeSan = null;
    this.observationIndicator = null;
    this.observationDescription = null;
    this.operationSerialNumber = null;
    this.filler = null;
  }

  @Override
  public String toString() {

    return Optional.ofNullable(super.getAccountDto())
      .map(AccountDto::getNumber)
      .map(account -> this.toStringFromFields())
      .orElse(this.data);
  }

  private String toMinimalString() {

    String line = this.toString();
    int previousLength = -1;
    do {
      previousLength = line.length();
      line = toStringReducedByWhitespaces(10, line);
    } while (line.length() < previousLength);

    return line;
  }

  public String fromMinimalString() {

    String line = this.getData();

    if (Objects.nonNull(line)) {
      int previousLength = -1;
      do {
        previousLength = line.length();
        line = fromStringReducedByWhitespaces(line);
      } while (line.length() > previousLength);
    }

    return line;
  }

  private String toStringReducedByWhitespaces(int numMinBlanks, final String line) {

    List<Integer> blanksList = Stream.of(line)
      .map(l -> l.split("\\S+"))
      .flatMap(Stream::of)
      .map(String::length)
      .sorted()
      .collect(Collectors.toList());

    return blanksList.stream()
      .skip(blanksList.size() - 1)
      .filter(blanks -> blanks >= numMinBlanks)
      .findFirst()
      .map(length -> line.replaceAll("\\s{" + length + "}", START_DELIMITER + length + END_DELIMITER))
      .orElse(line);
  }

  private String fromStringReducedByWhitespaces(String line) {

    int numBlanks = Stream.of(line)
      .filter(str -> str.contains(START_DELIMITER))
      .map(l -> l.split(START_DELIMITER)[1])
      .map(val -> val.split(END_DELIMITER)[0])
      .map(Integer::parseInt)
      .max(Integer::compareTo)
      .orElse(-1);

    return Optional.of(numBlanks)
      .filter(blanks -> blanks > 0)
      .map(blanks -> line.replaceAll(START_DELIMITER + blanks + END_DELIMITER, StringUtils.leftPad("", blanks, ' ')))
      .orElse(line);
  }

  private String toStringFromFields() {

    DecimalFormat decimalFMTT = new DecimalFormat("+00000000000000;-00000000000000");
    String movementAmountString = (movementAmount != null) ? decimalFMTT.format(movementAmount.multiply(new BigDecimal(100)).toBigInteger()) : "!!!!!!!!!!!!!!!";
    String postBalanceString = (postBalance != null) ? decimalFMTT.format(postBalance.multiply(new BigDecimal(100)).toBigInteger()) : "!!!!!!!!!!!!!!!";

    String movementDateString = (movementDate != null) ? movementDate.format(DateTimeFormatter.ofPattern(Constants.CONVERTER_DATE_FORMAT)) : SIX_EXCLAMATIONS;
    String operationDateString = (operationDate != null) ? operationDate.format(DateTimeFormatter.ofPattern(Constants.CONVERTER_DATE_FORMAT)) : SIX_EXCLAMATIONS;
    String operationTimeString = (operationTime != null) ? operationTime.format(DateTimeFormatter.ofPattern(Constants.CONVERTER_TYPE_TWO_TIME_FORMAT)) : SIX_EXCLAMATIONS;
    String accountingDateString = (accountingDate != null) ? accountingDate.format(DateTimeFormatter.ofPattern(Constants.CONVERTER_DATE_FORMAT)) : SIX_EXCLAMATIONS;

    return super.toString()
      + movementNumber
      + altairOperationCode
      + movementDescription
      + movementDateString
      + operationDateString
      + operationTimeString
      + accountingDateString
      + movementType
      + movementAmountString
      + postBalanceString
      + chequeNumber
      + conceptCode
      + internalReference
      + clientReference
      + swiftCode
      + subSwiftCodeSan
      + observationIndicator
      + observationDescription
      + operationSerialNumber
      + filler;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;

    if (o == null || getClass() != o.getClass()) return false;

    TransactionDtoConverter that = (TransactionDtoConverter) o;

    return new EqualsBuilder()
      .appendSuper(super.equals(o))
      .append(movementNumber, that.movementNumber)
      .append(altairOperationCode, that.altairOperationCode)
      .append(movementDescription, that.movementDescription)
      .append(movementDate, that.movementDate)
      .append(operationDate, that.operationDate)
      .append(operationTime, that.operationTime)
      .append(accountingDate, that.accountingDate)
      .append(movementType, that.movementType)
      .append(movementAmount, that.movementAmount)
      .append(postBalance, that.postBalance)
      .append(chequeNumber, that.chequeNumber)
      .append(conceptCode, that.conceptCode)
      .append(internalReference, that.internalReference)
      .append(clientReference, that.clientReference)
      .append(swiftCode, that.swiftCode)
      .append(subSwiftCodeSan, that.subSwiftCodeSan)
      .append(observationIndicator, that.observationIndicator)
      .append(observationDescription, that.observationDescription)
      .append(operationSerialNumber, that.operationSerialNumber)
      .append(filler, that.filler)
      .append(data, that.data)
      .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .appendSuper(super.hashCode())
      .append(movementNumber)
      .append(altairOperationCode)
      .append(movementDescription)
      .append(movementDate)
      .append(operationDate)
      .append(operationTime)
      .append(accountingDate)
      .append(movementType)
      .append(movementAmount)
      .append(postBalance)
      .append(chequeNumber)
      .append(conceptCode)
      .append(internalReference)
      .append(clientReference)
      .append(swiftCode)
      .append(subSwiftCodeSan)
      .append(observationIndicator)
      .append(observationDescription)
      .append(operationSerialNumber)
      .append(filler)
      .append(data)
      .toHashCode();
  }
}
