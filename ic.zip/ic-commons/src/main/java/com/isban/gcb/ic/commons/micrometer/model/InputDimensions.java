package com.isban.gcb.ic.commons.micrometer.model;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.OffsetDateTime;

@Getter
@ToString(callSuper = true)
@NoArgsConstructor
public class InputDimensions extends BaseDimensions {
  private InputChannel inputChannel;

  @Builder(builderMethodName = "inputDimensionsBuilder")
  public InputDimensions(Boolean accumulated, String bicType, String client, String clientCategory, String currency,
                         String entityAccountAlias, Boolean planned, String productCode, String senderEntity,
                         String subproductCode, String uuidStructureAcc, OffsetDateTime accountingDateUTC, String status, 
                         InputChannel inputChannel) {
    super(accumulated, bicType, client, clientCategory, currency, entityAccountAlias, planned, productCode, 
      senderEntity, subproductCode, uuidStructureAcc, accountingDateUTC, status);
    this.inputChannel = inputChannel;
  }
}
