package com.isban.gcb.ic.commons.converter.util;

import com.isban.gcb.ic.commons.mt9X0.enhanced.MT9X0Enhanced;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
public class PageSplitter {

  private static final String REGEX_SPLIT_PAGES = "\\n(?=\\{1:.*)";

  private MT940Mapper mt940Mapper;

  public PageSplitter(MT940Mapper mapper) {
    this.mt940Mapper = mapper;
  }

  public List<String> splitInPages(String mt940Extract) {

    return Stream.of(mt940Extract)
      .map(content -> content.split(REGEX_SPLIT_PAGES))
      .peek(pagesArr -> log.info("Num Pages after split: " + pagesArr.length))
      .flatMap(Arrays::stream)
      .collect(Collectors.toList());
  }

  public String mt940PagesToSwift(List<MT9X0Enhanced> pages) {

    return pages.stream()
      .map(mt940Mapper::mt940EnhancedToSwift)
      .collect(Collectors.joining("\n"));
  }
}