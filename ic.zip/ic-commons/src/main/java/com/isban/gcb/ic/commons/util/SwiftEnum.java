package com.isban.gcb.ic.commons.util;

import com.isban.gcb.ic.commons.constants.S3Directories;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import static com.isban.gcb.ic.commons.constants.S3Directories.MT940_PAGES;
import static com.isban.gcb.ic.commons.constants.S3Directories.MT940_RELAY;
import static com.isban.gcb.ic.commons.constants.S3Directories.MT950_PAGES;
import static com.isban.gcb.ic.commons.constants.S3Directories.MT950_RELAY;

public enum SwiftEnum {

  MT940("^.*(\\{2:[OI]940).*$", "MT940", Arrays.asList(1L, 5L), MT940_RELAY, MT940_PAGES),
  MT950("^.*(\\{2:[OI]950).*$", "MT950", Collections.singletonList(4L), MT950_RELAY, MT950_PAGES);

  String pattern;
  String type;
  List<Long> subProductId;
  S3Directories relayPath;
  S3Directories monitoringPath;

  SwiftEnum(String pattern, String type, List<Long> subProductId, S3Directories relayPath, S3Directories monitoringPath) {
    this.pattern = pattern;
    this.type = type;
    this.subProductId = subProductId;
    this.relayPath = relayPath;
    this.monitoringPath = monitoringPath;
  }

  public static List<Long> getSubproductByType(String type) {
    return Stream.of(SwiftEnum.values())
      .filter(swiftEnum -> type.equals(swiftEnum.type))
      .map(swiftEnum -> swiftEnum.subProductId)
      .findFirst()
      .orElse(MT940.subProductId);
  }

  public static String getTypeByPath(String path) {
    return Stream.of(SwiftEnum.values())
      .filter(swiftEnum -> path.concat("/").contains(swiftEnum.relayPath.getDirectory()))
      .map(swiftEnum -> swiftEnum.type)
      .findFirst()
      .orElse(MT940.type);
  }

  public static String getTypeBySubproduct(String subProductCode) {
    Long code = Long.valueOf(subProductCode);
    return Stream.of(SwiftEnum.values())
      .filter(swiftEnum -> swiftEnum.subProductId.contains(code))
      .map(swiftEnum -> swiftEnum.type)
      .findFirst()
      .orElse(MT940.type);
  }

  public static String getMonitoringPathByPage(String page) {
    return Stream.of(SwiftEnum.values())
      .filter(swiftEnum -> page.replaceAll("\r?\n", "").matches(swiftEnum.pattern))
      .map(swiftEnum -> swiftEnum.monitoringPath.getDirectory())
      .findFirst()
      .orElse(MT940.monitoringPath.getDirectory());
  }
}