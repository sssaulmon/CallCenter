package com.isban.gcb.ic.commons.model.report.global.complete;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.isban.gcb.ic.commons.model.report.global.GlobalMetadata;
import com.isban.gcb.ic.commons.model.report.record.MetadataSend;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "globalMetadata",
        "metadataSend",
        "text"
})
public class GlobalReportCompleteFile implements Serializable {

    private static final long serialVersionUID = -158370157844787098L;

    @JsonProperty("globalMetadata")
    private GlobalMetadata globalMetadata;

    @JsonProperty("metadataSend")
    private MetadataSend metadataSend;

    @JsonProperty("text")
    private String text;

    public GlobalReportCompleteFile() {
    }

    public GlobalMetadata getGlobalMetadata() {
        return this.globalMetadata;
    }

    public MetadataSend getMetadataSend() {
        return this.metadataSend;
    }

    public String getText() {
        return this.text;
    }

    public void setGlobalMetadata(GlobalMetadata globalMetadata) {
        this.globalMetadata = globalMetadata;
    }

    public void setMetadataSend(MetadataSend metadataSend) {
        this.metadataSend = metadataSend;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String toString() {
        return "GlobalReportCompleteFile(globalMetadata=" + this.getGlobalMetadata() + ", metadataSend=" + this.getMetadataSend() + ", text=" + this.getText() + ")";
    }
}