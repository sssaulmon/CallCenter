package com.isban.gcb.ic.commons.errors;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum ResponseStateEnum {

    // Generic codes
    OK("00000", "Operation successfully completed"),
    KO("00001", "Could not complete this operation. An unknown error has occurred."),

    // Errors codes for microservice validations 01

    // Errors for the Accounting Date validations
    EXTRACT_NOT_RECOVERED("01001", "Error recovering file from Storage service."),
    ACCOUNTING_DATE_NOT_INFORMED("01002", "Accounting date not informed in the extract."),
    ACCOUNTING_DATE_OUT_OF_RANGE("01003", "Accounting date of the extract is not valid. It's out of the range defined by Information Center."),
    ACCOUNTING_DATE_NOT_CONFIGURED_TIMEZONE("01013", "No time zone is configured for the indicated BIC"),

    // Errors for the Complete Extracts validations
    EXTRACT_DUPLICATED_PAGES("01004", "There is an extract which has duplicated pages."),

    // Errors for the Business Rules validations of the Extracts
    EXTRACT_INITIAL_BALANCE_PREVIOUS_END_BALANCE("01005", "Initial balance for the extract of the day is different to the final balance of the previous extract."),
    EXTRACT_END_BALANCE_NEXT_INITIAL_BALANCE("01006", "End balance for the extract of the day is different to the initial balance of the next extract."),
    EXTRACT_PAGE_FINAL_BALANCE_CALCULATED_PAGE_BALANCE("01007", "Final balance for a page in the extract of the day is different to initial balance + movements in the page."),
    EXTRACT_FINAL_BALANCE_CALCULATED_BALANCE("01008", "Final balance of the extract of the day is different to initial balance + all movements."),
    EXTRACT_WITHOUT_PAGES("01009", "No pages for extract has been informed. Extract should have at least one page."),
    EXTRACT_END_DATE_NEXT_INITIAL_DATE("01010", "End date for the extract of the day is different to the initial date of the next extract."),
    EXTRACT_WITHOUT_CLOSING_BALANCE_INFO("01011", "Closing balance info not found for extract."),
    EXTRACT_WITHOUT_OPENING_BALANCE_INFO("01012", "Opening balance info not found for extract."),

    // Errors codes for microservice contracts 02
    DATABASE_ERROR_NO_ALIASACCOUNT_FOUND("02001", "The given aliasAccount wasn't found in the SQL DataBase"),
    DATABASE_ERROR_NO_ALIASACCOUNT_ACTIVE("02002", "The given aliasAccount hasn't active Products/Subproducts"),
    DATABASE_ERROR_NO_ACCOUNTS_RELATED_FOUND("02003", "No Accounts related to the given aliasAccount"),
    DATABASE_ERROR_NO_ACTIVE_PRODUCTS_FOUND("02004", "The aren't Products Active for the aliasAccount"),
    DATABASE_ERROR_NO_ACTIVE_SERVICES_FOUND("02005", "No Services related to 'aliasCuenta' found in database"),
    DATABASE_ERROR_NO_SERVICES_FOUND("02006", "No Active Services related to 'aliasCuenta' found in database"),

    // Errors codes for microservice transform 03
    // Se han reservado las posiciones desde 03000 hasta la posicion 03009 para la integración con Biztalk
    // La transformación de Biztalk enviará estos codigos de error y el microservicio los propagará hacia arriba

    ERROR_RECOVERING_FILE_FROM_STORAGE("03010", "Error recovering file from Storage service."),
    ERROR_RECOVERING_FILES_LIST_FROM_STORAGE("03011", "Error recovering metakeys list for files with an specific type and metakey from Storage service."),
    ERROR_SAVING_FILE_INTO_STORAGE("03012", "Error storing file into storage system."),
    EXTRACT_SHOULD_HAVE_AT_LEAST_ONE_PAGE("03013", "An extract should have at least one page."),
    ERROR_RECOVERING_CROSS_REFERENCE_FROM_STORAGE("03014", "Error recovering Cross Reference from storage system."),
    ERROR_DIRECTION_LENGTH_NOT_VALID("03015", "Direction length is not valid. It should have 8 or 11 characteres."),
    ERROR_CONVERSOR_MT940("03016", "Error while executing transformation from Conversor to MT940."),
    ERROR_UNKNOWN_IMPLEMENTED_FACTORY("03017", "Trying to use a pattern factory that was not implemented"),
    ERROR_CROSS_REFERENCE_NOT_FOUND("03018", "Cross Reference is not found, check if exist for subProduct in Information Center"),
    ERROR_RECOVERED_EMPTY_FILE_FROM_STORAGE("03019", "Empty file recovered from Storage"),
    ERROR_RECOVERING_SWIFT_FILES("03020", "Swift files couldn't be retrieved from S3"),

    // Errors codes for microservice storage 04

    // Errors codes for microservice connectivity 05
    QUEUE_NOT_SUPPORTED_MESSAGE("05001", "The Message Received isn't supported"),
    QUEUE_PAGE_RECEIVED_IS_NOT_IN_DB("05002", "The Page Received isn't in the DB"),
    QUEUE_ERROR_DELEGATING_SWIFT_MESSAGE("05010", "Error delegating switf message to MERVA Queue"),
    QUEUE_NACK_RECEIVING_SWIFT_MSG("05011", "NACK received from MERVA"),
    QUEUE_NACK_RECEIVING_SWIFT_CUST("05012", "Custom error received from MERVA"),
    CHANNELING_SFTP_ERROR("05013", "Error during SFTP connection with Channeling"),
    EDITRAN_FTP_ERROR("05014", "Error during FTP connection with Editran"),
    BAM_NOTIFICATION("05015", "Error sending notification to BAM"),

    // Errors codes for kafka distributor connectivity 06
    ERROR_DURING_READ_VALIDATE_FILE("06001", "Error during read/validate file from MFT"),
    ERROR_GETTING_VERSION_FROM_MONITORING("06002", "Error during invoke to monitoring"),
    ERROR_START_APPIAN_FLOW("06003", "Error during start converter flow in appian"),
    ERROR_INVOKE_BIZTALK("06004", "Error during invoke to biztalk"),
    ERROR_INVOKE_CURRENCY("06005","Error during invoke to monitoring"),
    ERROR_DIFFERENT_NUMBER_OF_SAVED_METAKEYS("06006", "Number of files saved is different/less"),
    ERROR_DIFFERENT_NUMBER_OF_STARTED_FLOWS("06007", "Number of flows started in appian is different/less"),
    ERROR_ACCOUNT_WITHOUT_SLA("06008", "La cuenta no tiene SLA"),
    ERROR_DURING_CHECK_SLA("06009", "Error durante comprobación de SLA"),
    ERROR_IN_RELAY_TRANSFORM_TAG_25_NOT_FOUND("06011", "Error durante la transformación a relay. Tag 25 no se ha encontrado"),
    ERROR_IN_RELAY_TRANSFORM_NO_CONTRACTS_FOUND("06012", "Error durante la transformación a relay. No se han encontrado contratos en la entrada."),
    ERROR_IN_RELAY_TRANSFORM_TAG_28_NOT_FOUND("06013", "Error durante la transformación a relay. Tag 28 no se ha encontrado. No se puede estblecer numero de pagina ni de extracto."),
    
    // Error codes for monitoring microservice 07
    ERROR_RECOVERING_CURRENCY_DECIMALS("07007", "Error retrieving decimals from currency table"),

    //Error codes for Conversor while Procesing a File 08
    //Special Errors
    ERROR_ANY_VALIDATION("08000", "Error validación conversor"),
    ERROR_ACCOUNT_WITH_NO_TYPE_ALLOWED("08001", "Tipo de línea no permitido (distinta de 0, 1 ó 2)."),
    ERROR_NO_TYPE_ALLOWED("08002", "No existe una línea de tipo 1 para una línea de movimientos."),
    ERROR_NUMBER_OF_DECIMALS_NOT_ALLOWED("08003", "El rango de los decimales de la divisa no está permitido"),
    ERROR_NUMBER_OF_DECIMALS_NOT_FOUND("08004", "No se encontraron decimales para la divisa"),
    ERROR_CALL_BIZTALK("08005", "Error en la llamada a Biztalk"),
    ERROR_FIELD_20_SEQUENTIAL("08006", "No se ha encontrado secuencial para el campo FIELD_20"),
    ERROR_SEQUENCE_NAME_SEQUENTIAL("08007", "No se ha encontrado secuencial para el campo SEQUENTIAL_NAME"),

    //Errors of Type 1
    ERROR_TYPE_1_POS_24_27("08100", "Línea tipo 1. El código de moneda no es válido. "),
    ERROR_TYPE_1_POS_42_48("08101", "Línea tipo 1. La fecha inicial contable no es válida."),
    ERROR_TYPE_1_POS_48_54("08102", "Línea tipo 1. La fecha final contable no es válida."),
    ERROR_TYPE_1_POS_54_69("08103", "Línea tipo 1. El saldo inicial no es válido"),
    ERROR_TYPE_1_POS_69_84("08104", "Línea tipo 1. El saldo final no es válido."),
    ERROR_TYPE_1_POS_84_89("08105", "Línea tipo 1. El folio debe de ser numérico."),

    //Error of Type 2
    ERROR_TYPE_2_POS_24_27("08200", "Línea tipo 2. El código de moneda no es válido."),
    ERROR_TYPE_2_POS_27_36("08201", "Línea tipo 2. El código de secuencial no es numérico."),
    ERROR_TYPE_2_POS_74_80("08202", "Línea tipo 2. La fecha valor no es válida."),
    ERROR_TYPE_2_POS_80_86("08203", "Línea tipo 2. La fecha operación no es válida."),
    ERROR_TYPE_2_POS_90_96("08204", "Línea tipo 2. La fecha contable no es válida."),
    ERROR_TYPE_2_POS_96_97("08205", "Línea tipo 2. El tipo de movimiento tiene un valor distinto a 'D' o 'H'."),
    ERROR_TYPE_2_POS_97_112("08206", "Línea tipo 2. El importe del movimiento no es válido."),
    ERROR_TYPE_2_POS_112_127("08207", "Línea tipo 2. El saldo posterior no es válido."),
    ERROR_TYPE_2_POS_172_175("08208", "Línea tipo 2. El código Swift no viene informado."),

    ERROR_GENERAL_IN_RELAY_TRANSFORM("0500101", "Error durante la transformación a relay"),
    ERROR_GENERAL_IN_STANDARD_TRANSFORM("0600110", "Error durante la transformación a estándar de salida"),
    ERROR_GENERAL_IN_OUT_FORMAT_TRANSFORM("0700111", "Error durante la transformación a formato de salida"),
    ERROR_STANDARD_REPAGINATION("0600110", "Error en repaginacion estandar de salida"),
    ERROR_GENERAL_IN_SAVE_EXTRACT("0600111", "Error guardando saldos y movimientos"),
    ERROR_GENERAL_IN_DATE_VALIDATION("0200110", "La fecha del extracto no es válida"),
    ERROR_GENERAL_IN_BUSINESS_VALIDATION("0200110", "El extracto no es válido. Fallo en validación de negocio de extracto."),
    ERROR_GENERAL_IN_OUT_FORMAT_SAVE("0800110", "Error durante el guardado del formato de salida."),
    END_OF_DAY_OK_LOCALREPORT("0700100", "El reporte local se ha generado correctamente.Inicio generacion reporte global.");

    /**
     * Code of the response state
     */
    private String code;

    /**
     * Description of the response state
     */
    private String description;

    /**
     * Constructor.
     *
     * @param code        to set
     * @param description to set
     */
    ResponseStateEnum(String code, String description) {
        this.code = code;
        this.description = description;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }
}
