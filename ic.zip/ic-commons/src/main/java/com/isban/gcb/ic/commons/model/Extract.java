package com.isban.gcb.ic.commons.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.isban.gcb.ic.commons.errors.ResponseStateEnum;
import com.isban.gcb.ic.commons.mt9X0.enhanced.Block2;
import com.isban.gcb.ic.commons.mt9X0.enhanced.MT9X0Enhanced;
import com.isban.gcb.ic.commons.mt9X0.enhanced.Message;
import com.isban.gcb.ic.commons.util.DateTimeUtils;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field13D;
import com.prowidesoftware.swift.model.field.Field20;
import com.prowidesoftware.swift.model.field.Field21;
import com.prowidesoftware.swift.model.field.Field25;
import com.prowidesoftware.swift.model.field.Field28C;
import com.prowidesoftware.swift.model.field.Field34F;
import com.prowidesoftware.swift.model.field.Field60F;
import com.prowidesoftware.swift.model.field.Field61;
import com.prowidesoftware.swift.model.field.Field62F;
import com.prowidesoftware.swift.model.field.Field64;
import com.prowidesoftware.swift.model.field.Field65;
import com.prowidesoftware.swift.model.field.Field86;
import com.prowidesoftware.swift.model.field.Field90C;
import com.prowidesoftware.swift.model.field.Field90D;
import com.prowidesoftware.swift.model.mt.mt9xx.MT941;
import com.prowidesoftware.swift.model.mt.mt9xx.MT942;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.ValidationException;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static javax.persistence.FetchType.LAZY;
import static org.apache.commons.lang.StringUtils.leftPad;
import static org.apache.commons.lang.StringUtils.rightPad;

@Entity
@Table(name = "extract")
@Getter
@Setter
@Slf4j
public class Extract extends AuditableLocalDateTime implements Serializable {

  private static final long serialVersionUID = -5858698992992346088L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @NotNull
  @Size(min = 1, max = 5)
  @Column(nullable = false)
  private String type;

  @NotNull
  @Column(name = "version", columnDefinition = "NUMBER(8,0) default 0")
  private Integer version;

  @NotNull
  @Size(max = 50)
  @Column(name = "contract_number", nullable = false)
  private String contractNumber;

  // tag 20
  @NotNull
  @Size(max = 20)
  @Column(name = "tx_ref_number", nullable = false)
  private String txRefNumber;

  // tag 21
  @Column(name = "related_reference")
  @Size(max = 16)
  private String relatedReference;

  // tag 25
  @NotNull
  @Size(max = 35)
  @Column(name = "account_identification", nullable = false)
  private String accountIdentification;

  // from tag 25P
  @NotNull
  @Size(max = 11)
  @Column(name = "entity_account_bic", nullable = false)
  private String entityAccountBic;

  // from tag 28C and mt941 tag 28
  @NotNull
  @Column(name = "statement_number", nullable = false, columnDefinition = "NUMBER(5,0)")
  private Integer statementNumber;

  // from tag 61
  @NotNull
  @Size(max = 3)
  @Column(nullable = false)
  private String currency;

  // tag 60F
  @Column(name = "op_balance_mark")
  private Character openingBalanceMark;

  // tag 60F
  @Column(name = "op_balance_date", columnDefinition = "TIMESTAMP(6)")
  private LocalDate openingBalanceDate;

  // tag 60F
  @Column(name = "op_balance_amount", columnDefinition = "NUMBER(16,3)")
  private Double openingBalanceAmount;

  // tag 62F
  @Column(name = "cl_balance_mark")
  private Character closingBalanceMark;

  // tag 62F
  @Column(name = "cl_balance_date", columnDefinition = "TIMESTAMP(6)")
  private LocalDate closingBalanceDate;

  // tag 62F
  @Column(name = "cl_balance_amount", columnDefinition = "NUMBER(16,3)")
  private Double closingBalanceAmount;

  // tag 65
  @JsonManagedReference
  @OneToMany(mappedBy = "extract", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private List<ForwardBalance> forwardBalanceList;

  // tag 64
  @JsonManagedReference
  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "closing_available_balance_id", referencedColumnName = "id")
  private ClosingAvailableBalance closingAvailableBalance;


  // tag 61
  @JsonManagedReference
  @OneToMany(mappedBy = "extract", cascade = CascadeType.REMOVE)
  private List<ExtractMovement> extractMovements;

  // last tag 86
  @Column(name = "general_info", length = 400)
  private String generalInfo;

  @ManyToOne
  @JoinColumn(name = "subproduct_id", nullable = false)
  private Subproduct subproduct;

  @ManyToOne
  @JoinColumn(name = "service_send_channel_id", nullable = false)
  private ServiceSendChannel serviceSendChannel;

  @NotNull
  @Column(name = "valid", nullable = false)
  private Boolean valid;

  // tag 13D
  @Column(name = "date_time_indication")
  private LocalDateTime dateTimeIndication;

  // tag 13D
  @Size(max = 5)
  private String offset;

  // tag 90D
  @Column(name = "d_sum_entries", columnDefinition = "NUMBER(5,0)")
  private Integer debitSumEntries;

  // tag 90D
  @Column(name = "d_sum_amount", columnDefinition = "NUMBER(15,2)")
  private Double debitSumAmount;

  // tag 90C
  @Column(name = "c_sum_entries", columnDefinition = "NUMBER(5,0)")
  private Integer creditSumEntries;

  // tag 90C
  @Column(name = "c_sum_amount", columnDefinition = "NUMBER(15,2)")
  private Double creditSumAmount;

  // mandatory tag 34F
  @Column(name = "floor_limit_mark", length = 1)
  private String floorLimitMark;

  // mandatory tag 34F
  @Column(name = "floor_limit_amount", columnDefinition = "NUMBER(15,2)")
  private Double floorLimitAmount;

  // optional tag34F
  @Column(name = "cr_floor_limit_mark", length = 1)
  private String creditFloorLimitMark;

  // optional tag34F
  @Column(name = "cr_floor_limit_amount", columnDefinition = "NUMBER(15,2)")
  private Double creditFloorLimitAmount;

  @Column(name = "COMPUTED_BALANCE", columnDefinition = "NUMBER(1,0)")
  private Boolean computedBalance;

  @Column(name = "SERVICE_ACCOUNT_ID", columnDefinition = "NUMBER(19,0)")
  private Long serviceAccountId;

  @Column(name = "UUID_STRUCTURE_ACC", length = 40)
  private String uuidStructureAcc;

  @OneToOne(mappedBy = "extract", fetch = LAZY)
  private BalanceCache balanceCache;

  public Extract() {
    this.valid = true;
    this.extractMovements = new ArrayList<>();
    this.forwardBalanceList = new ArrayList<>();
  }

  // Begin of Extract Constructor Methods by MT files
  public Extract(MT941 mt941) {
    type = "MT941";

    // sender and tags 20, 21, 25, 28
    buildCommonInfo(mt941.getSender(), mt941.getField20(), mt941.getField21(),
      mt941.getField25(), mt941.getField28());

    if (mt941.getField13D() != null) {
      buildTag13D(mt941.getField13D());
    }

    currency = mt941.getField62F().getCurrency();
    if (mt941.getField60F() != null)
      buildTag60F(mt941.getField60F());
    if (mt941.getField90D() != null) {
      buildTag90D(mt941.getField90D());
    }
    if (mt941.getField90C() != null) {
      buildTag90C(mt941.getField90C());
    }
    buildTag62F(mt941.getField62F());
    if (mt941.getField64() != null) {
      closingAvailableBalance = new ClosingAvailableBalance(mt941.getField64());
      closingAvailableBalance.setExtract(this);
    }
    forwardBalanceList = new ArrayList<>();
    mt941.getField65().forEach(this::addForwardBalance);
    buildGeneralInfo(mt941.getField86());
    valid = true;
  }

  public void addPage(MT942 mt942) {
    if (StringUtils.isEmpty(type)) {
      type = "MT942";
      // sender and tags 20, 21, 25, 28
      buildCommonInfo(mt942.getSender(), mt942.getField20(), mt942.getField21(),
        mt942.getField25(), mt942.getField28C());
      // mandatory 34F
      Field34F mandatoryField34 = mt942.getField34F().get(0);
      floorLimitAmount = Double.parseDouble(mandatoryField34.getAmount().replace(',', '.'));
      floorLimitMark = mandatoryField34.getDCMark().substring(0, 1);
      // currency
      currency = mandatoryField34.getCurrency();
      // optional field 34
      if (mt942.getField34F().size() > 1) {
        Field34F creditField34 = mt942.getField34F().get(1);
        creditFloorLimitAmount =
          Double.parseDouble(creditField34.getAmount().replace(',', '.'));
        creditFloorLimitMark = creditField34.getDCMark().substring(0, 1);
      }
      // 13D
      buildTag13D(mt942.getField13D());
    }

    int page = StringUtils.isEmpty(mt942.getField28C().getSequenceNumber()) ? 1
      : Integer.parseInt(mt942.getField28C().getSequenceNumber());
    // parse page tags::
    buildExtract(recoverAllTags(mt942), page);
  }

  private void buildExtract(List<Tag> tagList, int page) {

    boolean isGeneralInfo = false;

    for (Tag t : tagList) {
      switch (t.getName()) {
        case "60F":
          this.buildTag60F(new Field60F(t.getValue()));
          break;
        case "61":
          // adding movement to extract::
          this.addNewMovement(new Field61(t.getValue()), page);
          break;
        case "62F":
          this.buildTag62F(new Field62F(t.getValue()));
          isGeneralInfo = true;
          break;
        case "64":
          this.buildTag64(new Field64(t.getValue()));
          isGeneralInfo = true;
          break;
        case "65":
          this.addForwardBalance(new Field65(t.getValue()));
          break;
        case "86":
          if (!isGeneralInfo) {
            this.addLastMovementInfo(new Field86(t.getValue()));
          } else {
            this.buildGeneralInfo(new Field86(t.getValue()));
          }
          break;
        case "90C":
          // mandatory ::
          this.buildTag90C(new Field90C(t.getValue()));
          isGeneralInfo = true;
          break;
        case "90D":
          // optional ::
          this.buildTag90D(new Field90D(t.getValue()));
          break;
        default:
          log.debug("No tag valid:: {}", t.getName());
      }
    }
  }

  private void addForwardBalance(Field65 field65) {
    log.debug("Found TAG65: {}", field65);
    ForwardBalance fb = new ForwardBalance(field65);
    fb.setExtract(this);
    this.forwardBalanceList.add(fb);
  }

  private void addNewMovement(Field61 field61, Integer pageNumber) {
    log.debug("Found TAG61: {}", field61);
    ExtractMovement em = new ExtractMovement(field61, pageNumber);
    em.setExtract(this);
    this.extractMovements.add(em);
  }

  private void addLastMovementInfo(Field86 field86) {
    log.debug("Found TAG86 (Movement Info): {}", field86);
    this.extractMovements.get(this.extractMovements.size() - 1).addMovementsInfoList(field86);
  }

  private void buildCommonInfo(String sender, Field20 field20, Field21 field21, Field25 field25,
                               Field field28) {
    this.entityAccountBic = sender.replaceFirst("(\\w{8})(\\w)(\\w{3})", "$1$3");
    this.txRefNumber = field20.getValue();
    this.relatedReference = field21 != null ? field21.getReference() : null;
    this.accountIdentification = field25.getValue();
    this.statementNumber = Integer.parseInt(field28.getComponent(1));
  }

  private void buildGeneralInfo(Field86 field86) {
    log.debug("Found TAG86 (General Info): {}", field86);
    if (field86 != null) {
      this.generalInfo = field86.getLines().stream().map(String::trim)
        .collect(Collectors.joining("\r\n"));
    }
  }

  private void buildTag13D(Field13D field13D) {
    this.dateTimeIndication = LocalDateTime.of(
      Objects.requireNonNull(DateTimeUtils.parseToLocalDate(field13D.getDate())),
      DateTimeUtils.parseToLocalTime(field13D.getTime()));
    this.offset = field13D.getSign() + field13D.getOffset();
  }

  private void buildTag60F(Field60F field60F) {
    log.debug("Found TAG60F: {}", field60F);
    this.openingBalanceMark = field60F.getDCMark().charAt(0);
    this.openingBalanceDate = DateTimeUtils.parseToLocalDate(field60F.getDate());
    this.openingBalanceAmount = field60F.amount().doubleValue();
  }

  private void buildTag62F(Field62F field62F) {
    log.debug("Found TAG62F: {}", field62F);
    this.closingBalanceMark = field62F.getDCMark().charAt(0);
    this.closingBalanceDate = DateTimeUtils.parseToLocalDate(field62F.getDate());
    this.closingBalanceAmount = field62F.amount().doubleValue();
  }

  private void buildTag64(Field64 field64) {
    log.debug("Found TAG64: {}", field64);
    ClosingAvailableBalance cab = new ClosingAvailableBalance();
    cab.setAmount(Double.parseDouble(field64.getAmount().replace(',', '.')));
    cab.setDate(DateTimeUtils.parseToLocalDate(field64.getDate()));
    cab.setMark(field64.getDCMark().charAt(0));
    this.closingAvailableBalance = cab;
  }

  private void buildTag90C(Field90C field90C) {
    log.debug("Found TAG90C: {}", field90C);
    this.creditSumEntries = Integer.parseInt(field90C.getComponent1());
    this.creditSumAmount = Double.parseDouble(field90C.getComponent(3).replace(',', '.'));
  }

  private void buildTag90D(Field90D field90D) {
    log.debug("Found TAG90C: {}", field90D);
    this.debitSumEntries = Integer.parseInt(field90D.getComponent1());
    this.debitSumAmount = Double.parseDouble(field90D.getComponent(3).replace(',', '.'));
  }

  private List<Tag> recoverAllTags(MT942 mt942) {
    return mt942.getSwiftMessage().getBlock4().getTags();
  }
  // End of Extract Construct methods

  // Balances File methods Begin
  public String generateBalancesFileLine() {
    String val = rightPad(accountIdentification, 50, " ");
    val += DateTimeUtils.formatISODate(closingBalanceDate);
    val += formatAmount(closingBalanceAmount, closingBalanceMark);
    val += formatClosingAvailableBalance();
    val += DateTimeUtils.formatISODate(openingBalanceDate);
    val += formatAmount(openingBalanceAmount, openingBalanceMark);
    return val;
  }

  private String formatAmount(Double amount, char mark) {
    String am = mark == 'C' ? " " : "-";
    am += String.format("%.2f", amount).replace('.', ',');
    return leftPad(am, 19, " ");
  }

  private String formatClosingAvailableBalance() {
    String result = "";
    if (closingAvailableBalance == null) {
      this.closingAvailableBalance =
        new ClosingAvailableBalance('C', LocalDate.of(1, 1, 1), 0D, this);
    }
    result += DateTimeUtils.formatISODate(closingAvailableBalance.getDate());
    result += formatAmount(closingAvailableBalance.getAmount(),
      closingAvailableBalance.getMark());
    return result;
  }
  // Balances File methods End

  @Override
  public String toString() {
    String toString = "Extract{" + "id=" + id + ", type='" + type + '\'' + ", version="
      + version + ", contractNumber='" + contractNumber + '\'' + ", txRefNumber='"
      + txRefNumber + '\'';
    if (relatedReference != null && !relatedReference.equals("")) {
      toString += ", relatedReference='" + relatedReference + '\'';
    }
    toString += ", accountIdentification='" + accountIdentification + '\''
      + ", entityAccountBic='" + entityAccountBic + '\'' + ", statementNumber="
      + statementNumber + ", currency='" + currency + '\'' + ", openingBalanceMark="
      + openingBalanceMark + ", openingBalanceDate=" + openingBalanceDate
      + ", openingBalanceAmount=" + openingBalanceAmount + ", closingBalanceMark="
      + closingBalanceMark + ", closingBalanceDate=" + closingBalanceDate
      + ", closingBalanceAmount=" + closingBalanceAmount + ", forwardBalanceList=["
      + forwardBalanceList.stream().map(ForwardBalance::toString)
      .collect(Collectors.joining())
      + "]" + ", closingAvailableBalance=" + closingAvailableBalance;
    if (extractMovements != null && !extractMovements.isEmpty()) {
      toString += ", extractMovements=[" + extractMovements.stream()
        .map(ExtractMovement::toString).collect(Collectors.joining()) + "]";
    }
    toString += ", generalInfo='" + generalInfo + '\'' + ", createdDate=" + getCreateDate()
      + ", lastModifiedDate=" + getLastModifiedDate() + ", subproduct=" + subproduct
      + ", serviceSendChannel=" + serviceSendChannel + ", valid=" + valid
      + ", dateTimeIndication=" + dateTimeIndication + ", offset=" + offset
      + ", debitSumEntries=" + debitSumEntries + ", debitSumAmount=" + debitSumAmount
      + ", creditSumEntries=" + creditSumEntries + ", creditSumAmount=" + creditSumAmount
      + ", floorLimitMark=" + floorLimitMark + ", floorLimitAmount=" + floorLimitAmount
      + ", creditFloorLimitMark=" + creditFloorLimitMark + ", creditFloorLimitAmount="
      + creditFloorLimitAmount + '}';
    return toString;
  }


  /////////////////////////////////////////////////////////////
  // METHODS EXISTING IN TRANSFORM BUT NOT IN OTHER PROJECTS //
  /////////////////////////////////////////////////////////////


  public void addPage(MT9X0Enhanced mt940) {
    List<com.isban.gcb.ic.commons.mt9X0.enhanced.Tag> pageTags =
      mt940.getM().getBlock4().getTags();
    if (StringUtils.isEmpty(type)) {
      this.type = "MT940";
      Map<String, Field> tMap = recoverCommonTags(pageTags);
      this.buildCommonInfo(mt940.getEntitySender().getBic(), (Field20) tMap.get("20"),
        (Field21) tMap.get("21"), (Field25) tMap.get("25"), (Field28C) tMap.get("28C"));
    }
    com.isban.gcb.ic.commons.mt9X0.enhanced.Tag f28C =
      pageTags.get(mt940.getTagPositionByName("28C"));

    int page = recoverExtractPage(f28C);

    buildExtractTransform(pageTags, page);
  }

  private void buildCommonInfo(String sender, Field20 field20, Field21 field21, Field25 field25,
                               Field28C field28) {
    entityAccountBic = sender.replaceFirst("(\\w{8})(\\w)(\\w{3})", "$1$3");
    txRefNumber = field20.getValue();
    relatedReference = field21 != null ? field21.getReference() : null;
    accountIdentification = field25.getValue();
    statementNumber = Integer.parseInt(field28.getComponent(1));
  }

  private int recoverExtractPage(com.isban.gcb.ic.commons.mt9X0.enhanced.Tag f28C) {
    Pattern p = Pattern.compile("\\d+/?(\\d+)");
    Matcher m = p.matcher(f28C.getValue());
    return m.matches() ? Integer.parseInt(m.group(1)) : 1;
  }

  private Map<String, Field> recoverCommonTags(
    List<com.isban.gcb.ic.commons.mt9X0.enhanced.Tag> tags) {
    Map<String, Field> m = new HashMap<>();
    for (com.isban.gcb.ic.commons.mt9X0.enhanced.Tag t : tags) {
      switch (t.getName()) {
        case "20":
          m.put("20", new Field20(t.getValue()));
          break;
        case "21":
          m.put("21", new Field21(t.getValue()));
          break;
        case "25":
          m.put("25", new Field25(t.getValue()));
          break;
        case "28C":
          m.put("28C", new Field28C(t.getValue()));
          break;
        default:
          log.debug("Tag name not valid");
      }
    }
    return m;
  }

  private void buildExtractTransform(List<com.isban.gcb.ic.commons.mt9X0.enhanced.Tag> tagList,
                                     int page) {

    boolean isGeneralInfo = false;

    for (com.isban.gcb.ic.commons.mt9X0.enhanced.Tag t : tagList) {
      switch (t.getName()) {
        case "60F":
          this.buildTag60F(new Field60F(t.getValue()));
          break;
        case "61":
          // adding movement to extract::
          this.addNewMovement(new Field61(t.getValue()), page);
          break;
        case "62F":
          this.buildTag62F(new Field62F(t.getValue()));
          isGeneralInfo = true;
          break;
        case "64":
          this.buildTag64(new Field64(t.getValue()));
          isGeneralInfo = true;
          break;
        case "65":
          this.addForwardBalance(new Field65(t.getValue()));
          break;
        case "86":
          if (!isGeneralInfo) {
            this.addLastMovementInfo(new Field86(t.getValue()));
          } else {
            this.buildGeneralInfo(new Field86(t.getValue()));
          }
          break;
        default:
          log.debug("No tag valid:: {}", t.getName());
      }
    }
  }

  public void buildCommonInfo(MT9X0Enhanced mt940, String contractNumber) {
    List<com.isban.gcb.ic.commons.mt9X0.enhanced.Tag> tags = mt940.getM().getBlock4().getTags();
    // common info::
    this.type = Optional.of(mt940)
      .map(MT9X0Enhanced::getM)
      .map(Message::getBlock2)
      .map(Block2::getMessageType)
      .map("MT"::concat)
      .orElse("MT940");
    this.contractNumber = contractNumber;
    this.txRefNumber = getUniqueTagValue(tags, "20");
    this.relatedReference = getUniqueTagValue(tags, "21");
    this.accountIdentification = getUniqueTagValue(tags, "25").trim();

    // something will be necessary when tag 25P works...
    this.entityAccountBic = mt940.getEntitySender().getBic();

    this.statementNumber = getStatementNumber(tags);
    this.currency = mt940.getClosingBalanceM().getCurrency();
  }

  private String getUniqueTagValue(List<com.isban.gcb.ic.commons.mt9X0.enhanced.Tag> tags,
                                   String tagName) {
    List<com.isban.gcb.ic.commons.mt9X0.enhanced.Tag> ts = getTags(tags, tagName);
    if (ts != null && !ts.isEmpty()) {
      return ts.get(0).getValue();
    } else {
      return "";
    }
  }

  private int getStatementNumber(List<com.isban.gcb.ic.commons.mt9X0.enhanced.Tag> tags) {
    String v = getUniqueTagValue(tags, "28C");
    if (v != null) {
      Pattern p = Pattern.compile("(\\d+)(/.+)?");
      Matcher m = p.matcher(v);
      if (m.find()) {
        String val = m.group(1);
        return Integer.parseInt(val);
      }
    }
    log.error("Statement Number is Null");
    throw new ValidationException(ResponseStateEnum.KO.getDescription());
  }

  private List<com.isban.gcb.ic.commons.mt9X0.enhanced.Tag> getTags(
    List<com.isban.gcb.ic.commons.mt9X0.enhanced.Tag> tags, String tagName) {
        return tags.stream().filter(tag -> tag.getName().equals(tagName))
          .collect(Collectors.toList());
    }

    public boolean isComputedBalance() {
        return Optional.ofNullable(computedBalance).orElse(false);
    }

    public static Extract newInstanceFrom(Extract original, List<ForwardBalance> originalForwardBalances, ClosingAvailableBalance originalClosingAvailableBalance) {
        Extract extract = new Extract();
        extract.setType(original.getType());
        extract.setVersion(original.getVersion());
        extract.setContractNumber(original.getContractNumber());
        extract.setTxRefNumber(original.getTxRefNumber());
        extract.setRelatedReference(original.getRelatedReference());
        extract.setAccountIdentification(original.getAccountIdentification());
        extract.setEntityAccountBic(original.getEntityAccountBic());
        extract.setStatementNumber(original.getStatementNumber());
        extract.setCurrency(original.getCurrency());
        extract.setOpeningBalanceMark(original.getOpeningBalanceMark());
        extract.setOpeningBalanceDate(original.getOpeningBalanceDate());
        extract.setOpeningBalanceAmount(original.getOpeningBalanceAmount());
        extract.setClosingBalanceMark(original.getClosingBalanceMark());
        extract.setClosingBalanceDate(original.getClosingBalanceDate());
        extract.setClosingBalanceAmount(original.getClosingBalanceAmount());
        extract.setForwardBalanceList(originalForwardBalances.stream()
          .map(ofb -> ForwardBalance.newInstanceFrom(ofb, extract))
          .collect(Collectors.toList()));
        if(originalClosingAvailableBalance != null) {
            extract.setClosingAvailableBalance(ClosingAvailableBalance.newInstanceFrom(originalClosingAvailableBalance, extract));
        }
        extract.setGeneralInfo(original.getGeneralInfo());
        extract.setSubproduct(original.getSubproduct());
        extract.setServiceSendChannel(original.getServiceSendChannel());
        extract.setValid(original.getValid());
        extract.setDateTimeIndication(original.getDateTimeIndication());
        extract.setOffset(original.getOffset());
        extract.setDebitSumEntries(original.getDebitSumEntries());
        extract.setDebitSumAmount(original.getDebitSumAmount());
        extract.setCreditSumEntries(original.getCreditSumEntries());
      extract.setCreditSumAmount(original.getCreditSumAmount());
      extract.setFloorLimitMark(original.getFloorLimitMark());
      extract.setFloorLimitAmount(original.getFloorLimitAmount());
      extract.setCreditFloorLimitMark(original.getCreditFloorLimitMark());
      extract.setCreditFloorLimitAmount(original.getCreditFloorLimitAmount());
      extract.setComputedBalance(original.getComputedBalance());
      extract.setServiceAccountId(original.getServiceAccountId());
      extract.setUuidStructureAcc(original.getUuidStructureAcc());
      return extract;
    }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;

    if (o == null || getClass() != o.getClass()) return false;

    Extract extract = (Extract) o;

    return new EqualsBuilder()
      .appendSuper(super.equals(o))
      .append(id, extract.id)
      .append(type, extract.type)
      .append(version, extract.version)
      .append(contractNumber, extract.contractNumber)
      .append(txRefNumber, extract.txRefNumber)
      .append(relatedReference, extract.relatedReference)
      .append(accountIdentification, extract.accountIdentification)
      .append(entityAccountBic, extract.entityAccountBic)
      .append(statementNumber, extract.statementNumber)
      .append(currency, extract.currency)
      .append(openingBalanceMark, extract.openingBalanceMark)
      .append(openingBalanceDate, extract.openingBalanceDate)
      .append(openingBalanceAmount, extract.openingBalanceAmount)
      .append(closingBalanceMark, extract.closingBalanceMark)
      .append(closingBalanceDate, extract.closingBalanceDate)
      .append(closingBalanceAmount, extract.closingBalanceAmount)
      .append(forwardBalanceList, extract.forwardBalanceList)
      .append(closingAvailableBalance, extract.closingAvailableBalance)
      .append(extractMovements, extract.extractMovements)
      .append(generalInfo, extract.generalInfo)
      .append(subproduct, extract.subproduct)
      .append(serviceSendChannel, extract.serviceSendChannel)
      .append(valid, extract.valid)
      .append(dateTimeIndication, extract.dateTimeIndication)
      .append(offset, extract.offset)
      .append(debitSumEntries, extract.debitSumEntries)
      .append(debitSumAmount, extract.debitSumAmount)
      .append(creditSumEntries, extract.creditSumEntries)
      .append(creditSumAmount, extract.creditSumAmount)
      .append(floorLimitMark, extract.floorLimitMark)
      .append(floorLimitAmount, extract.floorLimitAmount)
      .append(creditFloorLimitMark, extract.creditFloorLimitMark)
      .append(creditFloorLimitAmount, extract.creditFloorLimitAmount)
      .append(computedBalance, extract.computedBalance)
      .append(serviceAccountId, extract.serviceAccountId)
      .append(uuidStructureAcc, extract.uuidStructureAcc)
      .append(balanceCache, extract.balanceCache)
      .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .appendSuper(super.hashCode())
      .append(id)
      .append(type)
      .append(version)
      .append(contractNumber)
      .append(txRefNumber)
      .append(relatedReference)
      .append(accountIdentification)
      .append(entityAccountBic)
      .append(statementNumber)
      .append(currency)
      .append(openingBalanceMark)
      .append(openingBalanceDate)
      .append(openingBalanceAmount)
      .append(closingBalanceMark)
      .append(closingBalanceDate)
      .append(closingBalanceAmount)
      .append(forwardBalanceList)
      .append(closingAvailableBalance)
      .append(extractMovements)
      .append(generalInfo)
      .append(subproduct)
      .append(serviceSendChannel)
      .append(valid)
      .append(dateTimeIndication)
      .append(offset)
      .append(debitSumEntries)
      .append(debitSumAmount)
      .append(creditSumEntries)
      .append(creditSumAmount)
      .append(floorLimitMark)
      .append(floorLimitAmount)
      .append(creditFloorLimitMark)
      .append(creditFloorLimitAmount)
      .append(computedBalance)
      .append(serviceAccountId)
      .append(uuidStructureAcc)
      .append(balanceCache)
      .toHashCode();
  }
}
