package com.isban.gcb.ic.commons.model.downloadapi;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.isban.gcb.ic.commons.errors.IntegrationError;
import com.isban.gcb.ic.commons.errors.IntegrationException;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class GlobalReportResponse implements Serializable {

  private String code;
  private String description;
  private List<GlobalReportInfo> data;
  private List<IntegrationError> errors;

  public GlobalReportResponse() { errors = new ArrayList<>();};

  public GlobalReportResponse(String code, String description) {
    this();
    this.code = code;
    this.description = description;
  }

  public GlobalReportResponse(IntegrationError error) {
    this();
    this.errors.add(error);
  }

  public GlobalReportResponse(String code, String description, List<GlobalReportInfo> reports) {
    this(code, description);
    this.data = reports;
  }

  public String getCode() {
    return this.code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getDescription() {
    return this.description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public List<IntegrationError> getErrors() {
    return this.errors;
  }

  public void setErrors(List<IntegrationError> errors) {
    this.errors = errors;
  }

  public void addError(IntegrationError error) {
    this.errors.add(error);
  }

  public List<GlobalReportInfo> getData() {
    return this.data;
  }

  public void setData(List<GlobalReportInfo> data) {
    this.data = data;
  }

  public GlobalReportResponse status(DownloadApiValidationEnum status){
    this.setCode(status.getCode());
    this.setDescription(status.getDescription());
    return this;
  }
}
