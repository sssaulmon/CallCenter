package com.isban.gcb.ic.commons.mt9X0;

import com.prowidesoftware.swift.model.field.Field61;
import com.prowidesoftware.swift.model.field.Field86;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * @author eduardo.rodriguezllo
 */
public class Movement implements Serializable {

    private Date valDate = null; // Value Date
    private Date entryDate = null; // Entry Date
    private String debCredMark = null; // Debit Credit Mark
    private String fundsCode = null; // Funds Code (3er caracter de la divisa)
    private Double amount = null; // Debit Credit Mark
    private String transType = null; // Transaction Type
    private String idCode = null; // Identification Type
    private String refAccOwn = null; // Reference for the Account Owner
    private String refAccSI = null; // Reference of the Account Servicing Institution
    private String suppDetails = null; // Suplementary Details
    private String infAccOwn = null; // Information to Account Owner


    /*
    * Constructor Empty
    */
    public Movement() {
        //Empty constructor
    }

    /*
    * Constructor Full
    */
    public Movement(Date valDate, Date entryDate, String debCredMark, String fundsCode,
                    Double amount, String transType, String idCode, String refAccOwn,
                    String refAccSI, String suppDetails, String infAccOwn) {
        this.valDate = valDate;
        this.entryDate = entryDate;
        this.debCredMark = debCredMark;
        this.fundsCode = fundsCode;
        this.amount = amount;
        this.transType = transType;
        this.idCode = idCode;
        this.refAccOwn = refAccOwn;
        this.refAccSI = refAccSI;
        this.suppDetails = suppDetails;
        this.infAccOwn = infAccOwn;
    }

    public Date getValDate() {
        return valDate;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public String getDebCredMark() {
        return debCredMark;
    }

    public String getFundsCode() {
        return fundsCode;
    }

    public Double getAmount() {
        return amount;
    }

    public String getTransType() {
        return transType;
    }

    public String getIdCode() {
        return idCode;
    }

    public String getRefAccOwn() {
        return refAccOwn;
    }

    public String getRefAccSI() {
        return refAccSI;
    }

    public String getSuppDetails() {
        return suppDetails;
    }

    public String getInfAccOwn() {
        return infAccOwn;
    }

    public void setValDate(Date valDate) {
        this.valDate = valDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public void setDebCredMark(String debCredMark) {
        this.debCredMark = debCredMark;
    }

    public void setFundsCode(String fundsCode) {
        this.fundsCode = fundsCode;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public void setIdCode(String idCode) {
        this.idCode = idCode;
    }

    public void setRefAccOwn(String refAccOwn) {
        this.refAccOwn = refAccOwn;
    }

    public void setRefAccSI(String refAccSI) {
        this.refAccSI = refAccSI;
    }

    public void setSuppDetails(String suppDetails) {
        this.suppDetails = suppDetails;
    }

    public void setInfAccOwn(String infAccOwn) {
        this.infAccOwn = infAccOwn;
    }

    /**
     * Extracts fields from Field 61 in a MT940 class to Movement class
     *
     * @param field61 Field 61 of a MT940
     * @author Eduardo Rodriguez
     */
    public void obtainMovement(Field61 field61, Field86 field86) {
        try {
            this.obtainValueDate(field61);
            this.obtainEntryDate(field61);
        } catch (ParseException ignored) {
        }
        this.obtainDebCredMark(field61);
        this.obtaiFundsCode(field61);
        this.obtainAmount(field61);
        this.obtainTransactionType(field61);
        this.obtainIdCode(field61);
        this.obtainRefAccOwn(field61);
        this.obtainRefAccSI(field61);
        this.obtainSuppDetails(field61);
        if (field86 != null)
            this.obtainInfAccOwn(field86);
    }

    /**
     * Extracts from a field 61 of a MT940 the Value Date
     *
     * @param field61 Field 61 of a MT940
     * @author Eduardo Rodriguez
     */
    public void obtainValueDate(Field61 field61) throws ParseException {
        DateFormat formatter;
        formatter = new SimpleDateFormat("yyMMdd");
        this.setValDate(formatter.parse(field61.getValueDate()));
    }

    /**
     * Extracts from a field 61 of a MT940 the EntryDate
     *
     * @param field61 Field 61 of a MT940
     * @author Eduardo Rodriguez
     */
    public void obtainEntryDate(Field61 field61) throws ParseException {
        DateFormat formatter;
        formatter = new SimpleDateFormat("MMdd");
        this.setEntryDate(formatter.parse(field61.getEntryDate()));
    }

    /**
     * Extracts from a field 61 of a MT940 the Value Date
     *
     * @param field61 Field 61 of a MT940
     * @author Eduardo Rodriguez
     */
    public void obtainDebCredMark(Field61 field61) {
        this.setDebCredMark(field61.getDCMark());
    }

    /**
     * Extracts from a field 61 of a MT940 the Funds Code
     *
     * @param field61 Field 61 of a MT940
     * @author Eduardo Rodriguez
     */
    public void obtaiFundsCode(Field61 field61) {
        this.setFundsCode(field61.getFundsCode());
    }

    /**
     * Extracts from a field 61 of a MT940 the Amount
     *
     * @param field61 Field 61 of a MT940
     * @author Eduardo Rodriguez
     */
    public void obtainAmount(Field61 field61) {
        this.setAmount(field61.getAmountAsNumber().doubleValue());
    }

    /**
     * Extracts from a field 61 of a MT940 the Transaction Type
     *
     * @param field61 Field 61 of a MT940
     * @author Eduardo Rodriguez
     */
    public void obtainTransactionType(Field61 field61) {
        this.setTransType(field61.getTransactionType());
    }

    /**
     * Extracts from a field 61 of a MT940 the Identification Code
     *
     * @param field61 Field 61 of a MT940
     * @author Eduardo Rodriguez
     */
    public void obtainIdCode(Field61 field61) {
        this.setIdCode(field61.getIdentificationCode());
    }

    /**
     * Extracts from a field 61 of a MT940 the Reference Account Own
     *
     * @param field61 Field 61 of a MT940
     * @author Eduardo Rodriguez
     */
    public void obtainRefAccOwn(Field61 field61) {
        this.setRefAccOwn(field61.getReferenceForTheAccountOwner());
    }

    /**
     * Extracts from a field 61 of a MT940 the Reference of the Account Servicing Institution
     *
     * @param field61 Field 61 of a MT940
     * @author Eduardo Rodriguez
     */
    public void obtainRefAccSI(Field61 field61) {
        this.setRefAccSI(field61.getReferenceOfTheAccountServicingInstitution());
    }

    /**
     * Extracts from a field 61 of a MT940 the Suplementary Details
     *
     * @param field61 Field 61 of a MT940
     * @author Eduardo Rodriguez
     */
    public void obtainSuppDetails(Field61 field61) {
        this.setSuppDetails(field61.getSupplementaryDetails());
    }

    /**
     * Extracts from a field 86 of a MT940 the Information to Account Owner
     *
     * @param field86 Field 86 of a MT940
     * @author Eduardo Rodriguez
     */
    public void obtainInfAccOwn(Field86 field86) {
        this.setInfAccOwn(field86.getValue());
    }

    /**
     * Checks if a Field61 is followed by a field86
     *
     * @param block4  Block 4 of a MT940
     * @param field61 Field61 to check
     * @return true if there's field 86
     * @author Eduardo Rodriguez
     */
    public boolean check86(String block4, Field61 field61) {
        boolean result = false;
        String[] arraySwift = block4.split("], Tag");

        for (int i = 0; i < arraySwift.length; i++) {
            if (arraySwift[i].contains(field61.getValue()) && arraySwift[i + 1].contains("[86")) {
                result = true;
                break;
            }
        }

        return result;
    }
}
