package com.isban.gcb.ic.commons.model;


import org.apache.commons.lang.builder.ToStringBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

@Entity
@Table(name = "service_account",
  indexes = {@Index(columnList = "uuid", name = "uuid_service_account")})
public class ServiceAccount extends AuditableLocalDate implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "service_account_gen")
  @SequenceGenerator(name = "service_account_gen", sequenceName = "service_account_generator",
    allocationSize = 1)
  private Long id;

  @NotNull
  @Size(max = 50)
  @Column(name = "alias_acc_client", length = 50, nullable = false)
  private String aliasAccClient;

  @Size(max = 40)
  @Column(name = "uuid", length = 40)
  private String uuid;

  @Column(name = "end_date")
  private LocalDate endDate;

  @Size(max = 20)
  @Column(name = "last_modified_user", length = 20)
  private String lastModifiedUser;

  @ManyToOne(fetch = FetchType.LAZY)
  private Service service;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "SLA_ENTITY_ID", referencedColumnName = "ID")
  private AssoCorpSubProductAcc assoCorpSubProductAcc;

  @Size(max = 1000)
  @Column(name = "account_send_hours")
  private String accountSendHours;

  @Column(name = "is_master", columnDefinition = "NUMBER(1,0) DEFAULT 0")
  private boolean isMaster;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }


  public String getAliasAccClient() {
    return aliasAccClient;
  }

  public void setAliasAccClient(String aliasAccClient) {
    this.aliasAccClient = aliasAccClient;
  }

  public ServiceAccount aliasAccClient(String aliasAccClient) {
    this.aliasAccClient = aliasAccClient;
    return this;
  }

  public String getUuid() {
    return uuid;
  }

  public void setUuid(String uuid) {
    this.uuid = uuid;
  }

  public ServiceAccount uuid(String uuid) {
    this.uuid = uuid;
    return this;
  }

  public LocalDate getEndDate() {
    return endDate;
  }

  public void setEndDate(LocalDate endDate) {
    this.endDate = endDate;
  }

  public ServiceAccount endDate(LocalDate endDate) {
    this.endDate = endDate;
    return this;
  }

  public String getLastModifiedUser() {
    return lastModifiedUser;
  }

  public void setLastModifiedUser(String lastModifiedUser) {
    this.lastModifiedUser = lastModifiedUser;
  }

  public ServiceAccount lastModifiedUser(String lastModifiedUser) {
    this.lastModifiedUser = lastModifiedUser;
    return this;
  }

  public Service getService() {
    return service;
  }

  public void setService(Service service) {
    this.service = service;
  }

  public ServiceAccount service(Service service) {
    this.service = service;
    return this;
  }

  public AssoCorpSubProductAcc getAssoCorpSubProductAcc() {
    return assoCorpSubProductAcc;
  }

  public void setAssoCorpSubProductAcc(AssoCorpSubProductAcc assoCorpSubProductAcc) {
    this.assoCorpSubProductAcc = assoCorpSubProductAcc;
  }

  public String getAccountSendHours() {
    return accountSendHours;
  }

  public void setAccountSendHours(String accountSendHours) {
    this.accountSendHours = accountSendHours;
  }

  public boolean isMaster() {
    return isMaster;
  }

  public ServiceAccount setMaster(boolean master) {
    isMaster = master;
    return this;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ServiceAccount serviceAccount = (ServiceAccount) o;
    if (serviceAccount.getId() == null || getId() == null) {
      return false;
    }
    return Objects.equals(getId(), serviceAccount.getId());
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(getId());
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this).append("id", id).append("aliasAccClient", aliasAccClient)
      .append("uuid", uuid).append("createDate", getCreateDate()).append("endDate", endDate)
      .append("lastModifiedDate", getLastModifiedDate())
      .append("lastModifiedUser", lastModifiedUser).append("service", service)
      .append("assoCorpSubProductAcc", assoCorpSubProductAcc)
      .append("isMaster", isMaster)
      .toString();
  }
}

