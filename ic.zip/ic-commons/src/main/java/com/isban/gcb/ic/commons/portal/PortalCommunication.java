package com.isban.gcb.ic.commons.portal;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.time.LocalDateTime;

@Builder
@Getter
@ToString
public class PortalCommunication {
  private LocalDateTime start;
  private LocalDateTime end;
  private long amount;
  private String status;
  private String filename;
}
