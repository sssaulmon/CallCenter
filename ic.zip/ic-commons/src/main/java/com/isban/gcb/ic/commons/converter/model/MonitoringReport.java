package com.isban.gcb.ic.commons.converter.model;

import java.io.Serializable;
import java.util.List;

public class MonitoringReport implements Serializable {

  private String uuid;
  private String account;
  private String entity;
  private String accountingDate;
  private String currency;
  private String metakey;
  private String status;
  private String type;
  private Long timestamp;
  private Long version;
  private Long subProductId;
  private boolean fileExtend;
  private List<MonitoringError> errors;

  public String getUuid() {
    return uuid;
  }

  public void setUuid(String id) {
    this.uuid = id;
  }

  public String getAccount() {
    return account;
  }

  public void setAccount(String account) {
    this.account = account;
  }

  public String getEntity() {
    return entity;
  }

  public void setEntity(String entity) {
    this.entity = entity;
  }

  public String getAccountingDate() {
    return accountingDate;
  }

  public void setAccountingDate(String accountingDate) {
    this.accountingDate = accountingDate;
  }

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public String getMetakey() {
    return metakey;
  }

  public void setMetakey(String metakey) {
    this.metakey = metakey;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public Long getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(Long timestamp) {
    this.timestamp = timestamp;
  }

  public Long getVersion() {
    return version;
  }

  public void setVersion(Long version) {
    this.version = version;
  }

  public boolean isFileExtend() {
    return fileExtend;
  }

  public void setFileExtend(boolean fileExtend) {
    this.fileExtend = fileExtend;
  }

  public List<MonitoringError> getErrors() {
    return errors;
  }

  public void setErrors(List<MonitoringError> errors) {
    this.errors = errors;
  }

  public Long getSubProductId() {
    return subProductId;
  }

  public void setSubProductId(Long subProductId) {
    this.subProductId = subProductId;
  }

  public String toString() {
    return "MonitoringReport(uuid=" + this.getUuid() + ", account=" + this.getAccount() + ", entity=" + this.getEntity()
      + ", accountingDate=" + this.getAccountingDate() + ", currency=" + this.getCurrency() + ", metakey=" + this.getMetakey()
      + ", status=" + this.getStatus() + ", type=" + this.getType() + ", timestamp=" + this.getTimestamp() + ", version="
      + this.getVersion() + ", fileExtend=" + this.isFileExtend() + ", subProductId=" + this.getSubProductId() + ", errors=" + this.getErrors() + ")";
  }
}