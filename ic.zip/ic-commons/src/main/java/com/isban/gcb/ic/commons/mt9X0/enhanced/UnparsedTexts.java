package com.isban.gcb.ic.commons.mt9X0.enhanced;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "texts"
})
public class UnparsedTexts implements Serializable {

    private static final long serialVersionUID = 5844394757619121441L;
    @JsonProperty("texts")
    private List<String> texts = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();

    /**
     * No args constructor for use in serialization
     */
    public UnparsedTexts() {
        /*Empty Constructor*/
    }

    /**
     * @param texts
     */
    public UnparsedTexts(List<String> texts) {
        super();
        this.texts = texts;
    }

    @JsonProperty("texts")
    public List<String> getTexts() {
        return texts;
    }

    @JsonProperty("texts")
    public void setTexts(List<String> texts) {
        this.texts = texts;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
