package com.isban.gcb.ic.commons.xml;

import com.isban.gcb.ic.commons.xml.exception.XmlSanParserException;
import com.isban.gcb.ic.commons.xml.model.XmlSan;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.StringReader;
import java.io.StringWriter;

@Slf4j
public class XmlSanMapper {

  private static XmlSanMapper xmlSanMapper;
  private JAXBContext jaxbContext;

  public static XmlSanMapper getInstance() {
    if (xmlSanMapper == null) {
      xmlSanMapper = new XmlSanMapper();
    }
    return xmlSanMapper;
  }

  private XmlSanMapper() {
    try {
      jaxbContext = JAXBContext.newInstance(XmlSan.class);
    } catch (JAXBException e) {
      log.error(e.getMessage(), e);
    }
  }

  public XmlSan toXML(String xmlSanString) {
    try {
      if (StringUtils.isEmpty(xmlSanString)) {
        throw new XmlSanParserException("String is null or empty.", new IllegalArgumentException());
      }
      Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
      XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
      xmlInputFactory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
      xmlInputFactory.setProperty("javax.xml.stream.isSupportingExternalEntities", false);
      XMLStreamReader reader = xmlInputFactory.createXMLStreamReader(new StringReader(xmlSanString));
      return (XmlSan) unmarshaller.unmarshal(reader);
    } catch (XMLStreamException | FactoryConfigurationError | JAXBException exception) {
      throw new XmlSanParserException(exception.getMessage(), exception);
    }
  }

  public String toString(XmlSan xmlSan) {
    try {
      Marshaller marshaller = jaxbContext.createMarshaller();
      StringWriter stringWriter = new StringWriter();
      marshaller.marshal(xmlSan, stringWriter);
      return stringWriter.toString();
    } catch (Exception e) {
      throw new IllegalStateException(e);
    }
  }
}
