package com.isban.gcb.ic.commons.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;
import java.util.Set;

/**
 * A Subproduct.
 */
@Entity
@Table(name = "subproduct", indexes = {@Index(columnList = "uuid", name = "uuid_subproduct")})
public class Subproduct extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "subproduct_gen")
    @SequenceGenerator(name = "subproduct_gen", sequenceName = "subproduct_generator",
            allocationSize = 1)
    @Column(name = "id")
    private Long id;

    @NotNull
    @Size(max = 10)
    @Column(name = "code", length = 10, nullable = false)
    private String code;

    @Size(max = 50)
    @Column(name = "description", length = 50)
    private String description;

    @Size(max = 40)
    @Column(name = "uuid", length = 40)
    private String uuid;

    @Column(name = "end_date")
    private LocalDate endDate;

    @ManyToOne
    @JoinColumn(name = "product_id", referencedColumnName = "id")
    private Product product;

    @OneToMany(mappedBy = "subproduct", fetch = FetchType.LAZY)
    private Set<AssoCorpSubProductAcc> slaEntitySet;

    @OneToMany(mappedBy = "subproduct", fetch = FetchType.LAZY)
    private Set<CrossReference> crossReferenceSet;

    @OneToMany(mappedBy = "subproduct", fetch = FetchType.LAZY)
    private Set<MovementCrossReference> movementCrossReferenceSet;

    @ManyToOne
    @JoinColumn(name = "RECEIVE_FORMAT_ID", referencedColumnName = "ID")
    private ReceiveFormat receiveFormat;

    @ManyToOne
    @JoinColumn(name = "RECEIVE_CHANNEL_ID", referencedColumnName = "ID")
    private ReceiveChannel receiveChannel;

    @ManyToOne
    @JoinColumn(name = "RECEIVE_FREQ_DAILY_ID", referencedColumnName = "ID")
    private ReceiveFreqDaily receiveFreqDaily;

    public Subproduct(Long id) {
        super();
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Subproduct code(String code) {
        this.code = code;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Subproduct description(String description) {
        this.description = description;
        return this;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public Subproduct uuid(String uuid) {
        this.uuid = uuid;
        return this;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public Subproduct endDate(LocalDate endDate) {
        this.endDate = endDate;
        return this;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Subproduct product(Product product) {
        this.product = product;
        return this;
    }


    public ReceiveFormat getReceiveFormat() {
        return receiveFormat;
    }

    public void setReceiveFormat(ReceiveFormat receiveFormat) {
        this.receiveFormat = receiveFormat;
    }

    public Subproduct receiveFormat(ReceiveFormat receiveFormat) {
        this.receiveFormat = receiveFormat;
        return this;
    }

    public ReceiveChannel getReceiveChannel() {
        return receiveChannel;
    }

    public void setReceiveChannel(ReceiveChannel receiveChannel) {
        this.receiveChannel = receiveChannel;
    }

    public Subproduct receiveChannel(ReceiveChannel receiveChannel) {
        this.receiveChannel = receiveChannel;
        return this;
    }

    public ReceiveFreqDaily getReceiveFreqDaily() {
        return receiveFreqDaily;
    }

    public void setReceiveFreqDaily(ReceiveFreqDaily receiveFreqDaily) {
        this.receiveFreqDaily = receiveFreqDaily;
    }

    public Subproduct receiveFreqDaily(ReceiveFreqDaily receiveFreqDaily) {
        this.receiveFreqDaily = receiveFreqDaily;
        return this;
    }

    public Set<AssoCorpSubProductAcc> getSlaEntitySet() {
        return slaEntitySet;
    }

    public void setSlaEntitySet(Set<AssoCorpSubProductAcc> slaEntitySet) {
        this.slaEntitySet = slaEntitySet;
    }

    public Set<CrossReference> getCrossReferenceSet() {
        return crossReferenceSet;
    }

    public void setCrossReferenceSet(Set<CrossReference> crossReferences) {
        this.crossReferenceSet = crossReferences;
    }

    public Set<MovementCrossReference> getMovementCrossReferenceSet() {
        return movementCrossReferenceSet;
    }

    public void setMovementCrossReferenceSet(Set<MovementCrossReference> crossReferences) {
        this.movementCrossReferenceSet = crossReferences;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Subproduct subproduct = (Subproduct) o;
        if (subproduct.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), subproduct.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Subproduct{" + "id=" + getId() + ", code='" + getCode() + "'" + ", description='"
                + getDescription() + "'" + ", uuid='" + getUuid() + "'" + ", createDate='"
                + getCreateDate() + "'" + ", endDate='" + getEndDate() + "'"
                + ", lastModifiedDate='" + getLastModifiedDate() + "'" + "}";
    }

    public Subproduct() {}

    public Subproduct(LocalDate endDate) {
        this.endDate = endDate;
    }
}
