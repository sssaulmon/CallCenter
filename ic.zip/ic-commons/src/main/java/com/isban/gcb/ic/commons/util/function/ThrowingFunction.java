package com.isban.gcb.ic.commons.util.function;

@FunctionalInterface
public interface ThrowingFunction<T, S> {

  S apply(T t) throws Exception;
}
