package com.isban.gcb.ic.commons.model.report.global.complete;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.isban.gcb.ic.commons.model.report.record.Metadata;
import com.isban.gcb.ic.commons.model.report.record.MetadataSend;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "metadata",
        "metadataSend",
        "text"
})
public class GlobalRecordComplete implements Serializable {

    private static final long serialVersionUID = 8977213933476897416L;

    @JsonProperty("metadata")
    private Metadata metadata;

    @JsonProperty("metadataSend")
    private MetadataSend metadataSend;

    @JsonProperty("text")
    private String text;

    @JsonProperty("data")
    private byte[] data;

    @JsonProperty("fileExtension")
    private String fileExtension;

    public GlobalRecordComplete() {
    }

    public Metadata getMetadata() {
        return this.metadata;
    }

    public MetadataSend getMetadataSend() {
        return this.metadataSend;
    }

    public String getText() {
        return this.text;
    }

    public byte[] getData() {
        return this.data;
    }

    public String getFileExtension() {
        return this.fileExtension;
    }

    public void setMetadata(Metadata metadata) {
        this.metadata = metadata;
    }

    public void setMetadataSend(MetadataSend metadataSend) {
        this.metadataSend = metadataSend;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public void setFileExtension(String fileExtension) {
        this.fileExtension = fileExtension;
    }

    public GlobalRecordComplete metadata(Metadata metadata) {
        this.metadata = metadata;
        return this;
    }

    public GlobalRecordComplete metadataSend(MetadataSend metadataSend) {
        this.metadataSend = metadataSend;
        return this;
    }

    public GlobalRecordComplete text(String text) {
        this.text = text;
        return this;
    }

    public GlobalRecordComplete data(byte[] data) {
        this.data = data;
        return this;
    }

    public GlobalRecordComplete fileExtension(String fileExtension) {
        this.fileExtension = fileExtension;
        return this;
    }

    public String toString() {
        return "GlobalRecordComplete(metadata=" + this.getMetadata() + ", metadataSend=" + this.getMetadataSend() + ", text=" + this.getText() + ", data=" + java.util.Arrays.toString(this.getData()) + ", fileExtension=" + this.getFileExtension() + ")";
    }
}
