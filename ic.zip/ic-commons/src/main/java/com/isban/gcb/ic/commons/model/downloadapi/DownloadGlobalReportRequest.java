package com.isban.gcb.ic.commons.model.downloadapi;

import org.apache.commons.lang.StringUtils;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class DownloadGlobalReportRequest extends DownloadApiRequest {

  private List<GlobalReportInfo> reports;

  public DownloadGlobalReportRequest() {
    super();
  }

  public List<GlobalReportInfo> getReports() {
    return reports;
  }

  public void setReports(List<GlobalReportInfo> reports) {
    this.reports = reports;
  }

  @Override
  public String toString() {
    return "DownloadApiRequest(accounts=" + this.getAccounts() + ", products=" + this.getProducts() + ", formats=" + this.getFormats() +
      ", channels=" + this.getChannels() + ", startDate=" + this.getStartDate() + ", endDate=" + this.getEndDate() + ", specificDate=" + this.getSpecificDate() +
      ", reportsNumber=" + this.getReportsNumber() + ", lastReport=" + this.isLastReport() + ", zipRequest=" + this.isZipRequest() + ", reports=" + toStrReports() +")";
  }

  private String toStrReports() {
    return Optional.ofNullable(this.reports)
      .map(reports -> reports.stream().map(GlobalReportInfo::toString).collect(Collectors.joining("}\n{", "\n{ ", " }\n")))
      .orElse(StringUtils.EMPTY);
  }
}
