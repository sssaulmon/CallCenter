package com.isban.gcb.ic.commons.mt9X0.enhanced;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "tags"
})
public class Block5 implements Serializable {

    private static final long serialVersionUID = -3807140752546283897L;

    @JsonProperty("tags")
    private List<Tag> tags = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();

    /**
     * No args constructor for use in serialization
     */
    public Block5() {
        /*Empty Constructor*/
    }

    /**
     * @param tags
     */
    public Block5(List<Tag> tags) {
        super();
        this.tags = tags;
    }

    @JsonProperty("tags")
    public List<Tag> getTags() {
        return tags;
    }

    @JsonProperty("tags")
    public void setTags(List<Tag> tags) {
        this.tags = tags;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public String toSwiftMessage() {
        String result = new String();

        result += "{5:";

        result = tags.stream().map((campo) -> "{" + campo.getName() + ":" + campo.getValue() + "}").reduce(result, String::concat);
        result += "}";
        return result;

    }
}
