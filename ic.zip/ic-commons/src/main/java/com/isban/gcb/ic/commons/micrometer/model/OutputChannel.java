package com.isban.gcb.ic.commons.micrometer.model;

import java.util.HashMap;
import java.util.Map;

public enum OutputChannel {
  H2H("H2H"), EBIC("EBICS"), FILEACT("Fileact"),
  EDITRAN("EDITRAN"), EMAIL("e-Mail"), SWIFT("SWIFT FIN"),
  PORTAL("SCN Portal");

  private static final Map<String, OutputChannel> outputChannelMap = new HashMap<>();
  private String description;

  OutputChannel(String description) {
    this.description = description;
  }

  static {
    for (OutputChannel outputChannel : OutputChannel.values()) {
      outputChannelMap.put(outputChannel.description, outputChannel);
    }
  }

  public static OutputChannel get(String outputChannelDescription) {
    return outputChannelMap.get(outputChannelDescription);
  }
}
