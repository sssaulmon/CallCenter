package com.isban.gcb.ic.commons.xml.exception;

public class XmlSanParserException extends RuntimeException {

  private static final long serialVersionUID = -2399438523657392409L;

  public XmlSanParserException(String message, Throwable cause) {
    super("Parser XML San: " + message, cause);
  }
}
