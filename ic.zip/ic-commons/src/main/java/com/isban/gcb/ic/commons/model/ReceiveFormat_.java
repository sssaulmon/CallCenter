package com.isban.gcb.ic.commons.model;

import java.time.LocalDate;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(ReceiveFormat.class)
public abstract class ReceiveFormat_ extends com.isban.gcb.ic.commons.model.AuditableLocalDate_ {

	public static volatile SetAttribute<ReceiveFormat, Subproduct> idReciveFormats;
	public static volatile SingularAttribute<ReceiveFormat, String> code;
	public static volatile SingularAttribute<ReceiveFormat, LocalDate> endDate;
	public static volatile SingularAttribute<ReceiveFormat, String> description;
	public static volatile SingularAttribute<ReceiveFormat, String> lastModifiedUser;
	public static volatile SingularAttribute<ReceiveFormat, Long> id;
	public static volatile SingularAttribute<ReceiveFormat, String> uuid;

	public static final String ID_RECIVE_FORMATS = "idReciveFormats";
	public static final String CODE = "code";
	public static final String END_DATE = "endDate";
	public static final String DESCRIPTION = "description";
	public static final String LAST_MODIFIED_USER = "lastModifiedUser";
	public static final String ID = "id";
	public static final String UUID = "uuid";

}

