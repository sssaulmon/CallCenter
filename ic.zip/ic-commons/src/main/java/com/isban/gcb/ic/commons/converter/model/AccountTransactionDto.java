package com.isban.gcb.ic.commons.converter.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.isban.gcb.ic.commons.mt9X0.enhanced.MT9X0Enhanced;
import com.isban.gcb.ic.commons.util.function.FunctionalUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountTransactionDto {

  @JsonIgnore
  private static final String LINE_DELIMITER = "\n";

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String uuid;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private AccountMetadata metadata;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private AccountSummaryDto accountSummary;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String metakey;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String status;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private boolean fileExtend;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String type;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Long version;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private boolean slaValidated;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private boolean statusUpdateOnly;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private BusinessRules validationBusinessRules;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<MonitoringError> errorsFound;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<TransactionDtoConverter> transactions;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String text;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private byte[] data;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<MT9X0Enhanced> mt940;

  public void addError(MonitoringError error) {
    errorsFound = Optional.ofNullable(this.errorsFound)
      .orElseGet(ArrayList::new);
    errorsFound.add(error);
  }

  public String serialize(boolean withEndLineBreak) {

    final String END_MESSAGE_DELIMITER = Optional.of(withEndLineBreak)
      .filter(val -> val == Boolean.TRUE)
      .map(val -> LINE_DELIMITER)
      .orElse("");

    String movements = Optional.ofNullable(transactions)
      .map(movs -> movs.stream()
        .map(TransactionDtoConverter::fromMinimalString)
        .collect(Collectors.joining(LINE_DELIMITER)))
      .orElse(StringUtils.EMPTY);

    return Optional.of(movements)
      .filter(FunctionalUtils.not(String::isEmpty))
      .map(movs -> accountSummary.toString().concat(LINE_DELIMITER).concat(movs).concat(END_MESSAGE_DELIMITER))
      .orElse(accountSummary.toString().concat(END_MESSAGE_DELIMITER));
  }

  @Override
  public String toString() {

    String movements = Optional.ofNullable(transactions)
      .map(movs -> movs.stream()
        .map(TransactionDtoConverter::toString)
        .collect(Collectors.joining(LINE_DELIMITER)))
      .orElse("");

    return accountSummary.toString()
      .concat(LINE_DELIMITER)
      .concat(movements)
      .concat(LINE_DELIMITER);
  }

  @Override
  public boolean equals(Object o) {

    if (o == this) return true;
    if (!(o instanceof AccountTransactionDto)) {
      return false;
    }
    AccountTransactionDto instance2 = (AccountTransactionDto) o;

    return Objects.equals(uuid, instance2.getUuid())
      && Objects.equals(metadata, instance2.getMetadata())
      && Objects.equals(accountSummary, instance2.getAccountSummary())
      && Objects.equals(transactions, instance2.getTransactions())
      && Objects.equals(metakey, instance2.getMetakey())
      && Objects.equals(status, instance2.getStatus())
      && Objects.equals(fileExtend, instance2.isFileExtend())
      && Objects.equals(type, instance2.getType())
      && Objects.equals(version, instance2.getVersion())
      && Objects.equals(slaValidated, instance2.isSlaValidated())
      && Objects.equals(statusUpdateOnly, instance2.isStatusUpdateOnly())
      && Objects.equals(text, instance2.getText())
      && Arrays.equals(data, instance2.getData())
      && Objects.equals(mt940, instance2.getMt940());
  }

  @Override
  public int hashCode() {
    return Objects.hash(uuid, metadata, accountSummary, transactions, metakey, status, fileExtend,
      type, version, slaValidated, statusUpdateOnly, text, new String(data), mt940);
  }

  public boolean hasErrors() {
    return (this.errorsFound != null && !this.errorsFound.isEmpty());
  }
}
