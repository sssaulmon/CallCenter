package com.isban.gcb.ic.commons.model.report.global;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.isban.gcb.ic.commons.model.report.record.MetadataSend;
import lombok.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "globalMetadata",
        "metadataSend",
        "records"
})
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class GlobalReport implements Serializable {

    private static final long serialVersionUID = 410619000101887090L;

    @JsonProperty("globalMetadata")
    private GlobalMetadata globalMetadata;

    @JsonProperty("metadataSend")
    private MetadataSend metadataSend;

    @JsonProperty("records")
    private List<GlobalRecord> records = new ArrayList<>();

    @JsonProperty("data")
    private byte[] data;

    @JsonProperty("fileExtension")
    private String fileExtension;

    public void addRecord(GlobalRecord record) {
        records.add(record);
    }
}
