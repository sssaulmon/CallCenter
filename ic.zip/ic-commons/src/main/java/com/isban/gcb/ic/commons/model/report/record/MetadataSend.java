package com.isban.gcb.ic.commons.model.report.record;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.isban.gcb.ic.commons.model.report.global.Address;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @since 06/09/2018
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "s3Path",
        "requestAddresses"
})
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class MetadataSend implements Serializable {

    private static final long serialVersionUID = -1356929005411289687L;

    @JsonProperty("s3Path")
    private String s3Path;

    @JsonProperty("requestAddresses")
    private List<Address> requestAddresses = new ArrayList<>();
}
