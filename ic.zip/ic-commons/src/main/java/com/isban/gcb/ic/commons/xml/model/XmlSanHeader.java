package com.isban.gcb.ic.commons.xml.model;

import javax.validation.constraints.NotEmpty;
import javax.xml.bind.annotation.XmlElement;

public class XmlSanHeader {

  @NotEmpty
  @XmlElement(name = "FECHA-ENVIO")
  private String sendDate;

  @NotEmpty
  @XmlElement(name = "SECUENCIA-FECHA")
  private Integer sequenceDate;

  @NotEmpty
  @XmlElement(name = "CODIGO-ISO-PAIS")
  private String isoCode;

  @NotEmpty
  @XmlElement(name = "BANCO-ORIGEN")
  private Integer sourceBank;

  @NotEmpty
  @XmlElement(name = "NEMO-INSTRUMENTO")
  private String nemoInstrument;

  @NotEmpty
  @XmlElement(name = "INSTRUMENTO-FTO-FLUJO")
  private String flowInstrument;

  @NotEmpty
  @XmlElement(name = "NOMFICORIGEN")
  private String sourceFileName;

  @NotEmpty
  @XmlElement(name = "TIPO-PROCESO")
  private String processType;

  @NotEmpty
  @XmlElement(name = "COD-CLIENTE-LOCAL")
  private String customerCode;

  @NotEmpty
  @XmlElement(name = "CTA-ASOCIADA")
  private String associatedAccount;

  @NotEmpty
  @XmlElement(name = "TOTAL-REGISTROS")
  private String totalRecords;


  public String getSendDate() {
    return sendDate;
  }

  public XmlSanHeader sendDate(String sendDate) {
    this.sendDate = sendDate;
    return this;
  }

  public Integer getSequenceDate() {
    return sequenceDate;
  }

  public XmlSanHeader sequenceDate(Integer sequenceDate) {
    this.sequenceDate = sequenceDate;
    return this;
  }

  public String getIsoCode() {
    return isoCode;
  }

  public XmlSanHeader isoCode(String isoCode) {
    this.isoCode = isoCode;
    return this;
  }

  public Integer getSourceBank() {
    return sourceBank;
  }

  public XmlSanHeader sourceBank(Integer sourceBank) {
    this.sourceBank = sourceBank;
    return this;
  }

  public String getNemoInstrument() {
    return nemoInstrument;
  }

  public XmlSanHeader nemoInstrument(String nemoInstrument) {
    this.nemoInstrument = nemoInstrument;
    return this;
  }

  public String getFlowInstrument() {
    return flowInstrument;
  }

  public XmlSanHeader flowInstrument(String flowInstrument) {
    this.flowInstrument = flowInstrument;
    return this;
  }

  public String getSourceFileName() {
    return sourceFileName;
  }

  public XmlSanHeader sourceFileName(String sourceFileName) {
    this.sourceFileName = sourceFileName;
    return this;
  }

  public String getProcessType() {
    return processType;
  }

  public XmlSanHeader processType(String processType) {
    this.processType = processType;
    return this;
  }

  public String getCustomerCode() {
    return customerCode;
  }

  public XmlSanHeader customerCode(String customerCode) {
    this.customerCode = customerCode;
    return this;
  }

  public String getAssociatedAccount() {
    return associatedAccount;
  }

  public XmlSanHeader associatedAccount(String associatedAccount) {
    this.associatedAccount = associatedAccount;
    return this;
  }

  public String getTotalRecords() {
    return totalRecords;
  }

  public XmlSanHeader totalRecords(String totalRecords) {
    this.totalRecords = totalRecords;
    return this;
  }

  @Override
  public String toString() {
    return "XmlSanHeader{" +
      "sendDate='" + sendDate + '\'' +
      ", sequenceDate=" + sequenceDate +
      ", isoCode='" + isoCode + '\'' +
      ", sourceBank=" + sourceBank +
      ", nemoInstrument='" + nemoInstrument + '\'' +
      ", flowInstrument='" + flowInstrument + '\'' +
      ", sourceFileName='" + sourceFileName + '\'' +
      ", processType='" + processType + '\'' +
      ", customerCode='" + customerCode + '\'' +
      ", associatedAccount='" + associatedAccount + '\'' +
      ", totalRecords='" + totalRecords + '\'' +
      '}';
  }
}
