package com.isban.gcb.ic.commons.model.outputformat.record;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.*;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "requestedOutputFormat",
        "sequenceNumber",
        "customizationType",
        "accountNumber",
        "clientAlias",
        "typeFormat",
        "entityName"
})
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class OutputFormatMetadata implements Serializable {

    private static final long serialVersionUID = -1519291244333043227L;

    @JsonProperty("requestedOutputFormat")
    private String requestedOutputFormat;

    @JsonProperty("sequenceNumber")
    private String sequenceNumber;

    @JsonProperty("customizationType")
    private String customizationType;

    @JsonProperty("accountNumber")
    private String accountNumber;

    @JsonProperty("clientAlias")
    private String clientAlias;

    @JsonProperty("typeFormat")
    private String typeFormat;

    @JsonProperty("entityName")
    private String entityName;

}
