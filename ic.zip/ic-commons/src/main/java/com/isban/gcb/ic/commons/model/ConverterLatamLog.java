package com.isban.gcb.ic.commons.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @since 24/02/2018
 */
@Entity
@Table(name = "LATAM_CONVERTER_LOG")
public class ConverterLatamLog implements Serializable {

    private static final long serialVersionUID = -3391576327680707468L;

    private Long id;
    private String kafkaMessage;
    private String status;

    @Column(name = "LAST_MODIFIED_DATE", nullable = false)
    private LocalDateTime lastModifiedDate;

    @Column(name = "CREATED_DATE", nullable = false, updatable = false)
    private LocalDateTime createdDate;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "latam_converter_log_generator")
    @SequenceGenerator(name = "latam_converter_log_generator",
            sequenceName = "seq_latam_converter_log", allocationSize = 1)
    @Column(name = "ID", columnDefinition = "NUMBER(18,0)")
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Column(name = "KAFKA_MESSAGE")
    public String getKafkaMessage() {
        return kafkaMessage;
    }

    public void setKafkaMessage(String kafkaMessage) {
        this.kafkaMessage = kafkaMessage;
    }

    @Column(name = "STATUS", length = 30)
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(LocalDateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    @PrePersist
    public void onPrePersist() {
        this.createdDate = LocalDateTime.now();
    }

    @PreUpdate
    public void onPreUpdate() {
        this.lastModifiedDate = LocalDateTime.now();
    }
}
