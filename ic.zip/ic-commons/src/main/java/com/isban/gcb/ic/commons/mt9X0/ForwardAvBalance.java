package com.isban.gcb.ic.commons.mt9X0;

import com.prowidesoftware.swift.model.field.Field65;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author eduardo.rodriguezllo
 */
public class ForwardAvBalance implements Balance, Serializable {

    private String dcMark; // D/C Mark
    private Date date; // Date (YYMMDD)
    private String currency; //Currency (código ISO)
    private Double amount; // Amount

    /*
    * Constructor Empty
    */
    public ForwardAvBalance() {
        this.dcMark = null;
        this.date = null;
        this.currency = null;
        this.amount = null;
    }

    /*
    * Constructor Full
    */
    public ForwardAvBalance(String dcMark, Date date, String currency, Double amount) {
        this.dcMark = dcMark;
        this.date = date;
        this.currency = currency;
        this.amount = amount;
    }

    /*
    * Getters
    */
    @Override
    public String getDcMark() {
        return dcMark;
    }

    @Override
    public Date getDate() {
        return date;
    }

    @Override
    public String getCurrency() {
        return currency;
    }

    @Override
    public Double getAmount() {
        return amount;
    }

    /*
    * Setters
    */
    @Override
    public void setDcMark(String dcMark) {
        this.dcMark = dcMark;
    }

    @Override
    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @Override
    public void setAmount(Double amount) {
        this.amount = amount;
    }

    /**
     * Extracts fields from Field 61 in a MT940 class to Movement class
     *
     * @param field65 Field 65 of a MT940
     * @author Eduardo Rodriguez
     */
    public void obtainForwardAvBalance(Field65 field65) {
        this.obtainDCMark(field65);
        try {
            this.obtainDate(field65);
        } catch (ParseException ignored) {
        }
        this.obtainCurrency(field65);
        this.obtainAmount(field65);
    }


    /**
     * Takes a MT940 Object and extracts the field of 65 : DCMark
     *
     * @param field65 Field65
     * @author Eduardo Rodriguez
     */
    private void obtainDCMark(Field65 field65) {
        this.setDcMark(field65.getDCMark());
    }

    /**
     * Takes a MT940 Object and extracts the field of 65 : Date
     *
     * @param field65 Field 65
     * @author Eduardo Rodriguez
     */
    private void obtainDate(Field65 field65) throws ParseException {
        DateFormat formatter;
        formatter = new SimpleDateFormat("yyMMdd");
        this.setDate(formatter.parse(field65.getDate()));
    }

    /**
     * Takes a MT940 Object and extracts the field of 64 : Currency
     *
     * @param field65 Field 65
     * @author Eduardo Rodriguez
     */
    private void obtainCurrency(Field65 field65) {
        this.setCurrency(field65.getCurrency());
    }

    /**
     * Takes a MT940 Object and extracts the field of 64 : Amount
     *
     * @param mt940 MT940
     * @author Eduardo Rodriguez
     */
    private void obtainAmount(Field65 field65) {
        this.setAmount(field65.getAmountAsNumber().doubleValue());
    }
}
