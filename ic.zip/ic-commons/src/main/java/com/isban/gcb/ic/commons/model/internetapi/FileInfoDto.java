package com.isban.gcb.ic.commons.model.internetapi;

public class FileInfoDto {

  private String s3Url;
  private String fileName;

  public FileInfoDto() {
  }

  public FileInfoDto(String s3Url, String fileName) {
    this.s3Url = s3Url;
    this.fileName= fileName;
  }

  public String getS3Url() {
    return this.s3Url;
  }

  public String getFileName() {
    return this.fileName;
  }

  public void setS3Url(String s3Url) {
    this.s3Url = s3Url;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public FileInfoDto s3Url(String url) {
    this.s3Url = url;
    return this;
  }

  public FileInfoDto fileName(String name) {
    this.fileName = name;
    return this;
  }

  public String toString() {
    return "DownloadZipInfoDto(s3Url=" + this.getS3Url() + ", fileName=" + this.getFileName() + ")";
  }
}
