package com.isban.gcb.ic.commons.model.internetapi;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;

public class GlobalReportsInternetRequest {
  private String enterpriseGroup;
  private List<String> products;
  private List<String> accounts;
  private String startDate;
  private String endDate;
  private String specificDate;
  private Boolean lastReport;
  private String corporateTaxId;
  @JsonIgnore
  private String clientId;

  public String getEnterpriseGroup() {
    return enterpriseGroup;
  }

  public void setEnterpriseGroup(String enterpriseGroup) {
    this.enterpriseGroup = enterpriseGroup;
  }

  public List<String> getProducts() {
    return products;
  }

  public void setProducts(List<String> products) {
    this.products = products;
  }

  public List<String> getAccounts() {
    return accounts;
  }

  public void setAccounts(List<String> accounts) {
    this.accounts = accounts;
  }

  public String getStartDate() {
    return startDate;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getSpecificDate() {
    return specificDate;
  }

  public void setSpecificDate(String specificDate) {
    this.specificDate = specificDate;
  }

  public Boolean getLastReport() {
    return lastReport;
  }

  public void setLastReport(Boolean lastReport) {
    this.lastReport = lastReport;
  }

  public String getCorporateTaxId() {
    return corporateTaxId;
  }

  public void setCorporateTaxId(String corporateTaxId) {
    this.corporateTaxId = corporateTaxId;
  }

  public String getClientId() {
    return clientId;
  }

  public void setClientId(String clientId) {
    this.clientId = clientId;
  }
}
