package com.isban.gcb.ic.commons.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class MUR {
    @Id
    @Column(name = "murId", updatable = false, nullable = false, unique = true, length = 256)
    private String murId;

    @Column(columnDefinition = "NUMBER(12,0)")
    private Long murValue;

    public MUR() {}

    public MUR(String murId) {
        this.murId = murId;
        this.murValue = 1L;
    }

    public void incrementMurValue() {
        murValue++;
    }
}
