package com.isban.gcb.ic.commons.micrometer.model;

public enum InputChannel {
  SWIFT_FIN, MFT
}
