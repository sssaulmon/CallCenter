package com.isban.gcb.ic.commons.model.report.global.resend;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.isban.gcb.ic.commons.model.report.global.Address;

import java.io.Serializable;

/**
 * @since 11/09/2018
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "content",
        "address"
})
public class ContentReSend implements Serializable {

    private static final long serialVersionUID = 1854270957897240405L;

    @JsonProperty("content")
    private String content;

    @JsonProperty("address")
    private Address address;

    public ContentReSend() {
    }

    public String getContent() {
        return this.content;
    }

    public Address getAddress() {
        return this.address;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public ContentReSend content(String content) {
        this.content = content;
        return this;
    }

    public ContentReSend address(Address address) {
        this.address = address;
        return this;
    }

    public String toString() {
        return "ContentReSend(content=" + this.getContent() + ", address=" + this.getAddress() + ")";
    }
}