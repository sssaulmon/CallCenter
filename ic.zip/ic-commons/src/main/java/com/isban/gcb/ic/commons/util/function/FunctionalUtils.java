package com.isban.gcb.ic.commons.util.function;

import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;

public interface FunctionalUtils {

  static <T> Predicate<T> not(Predicate<T> source) {
    return source.negate();
  }

  static <T, E> BiPredicate<T, E> not(BiPredicate<T, E> source) {
    return source.negate();
  }

  static <T> UnaryOperator<T> peek(Consumer<T> consumer) {
    return value -> {
      consumer.accept(value);
      return value;
    };
  }
}