package com.isban.gcb.ic.commons.model.downloadapi;

import java.util.List;

public class AccountRequest extends DownloadApiRequest {

  private String enterpriseGroup;
  private String corporateTaxId;
  private List<String> corporates;
  private List<String> countries;
  private List<String> bics;
  private List<String> currencies;

  public AccountRequest() {
    super();
  }

  public String getEnterpriseGroup() {
    return enterpriseGroup;
  }

  public void setEnterpriseGroup(String enterpriseGroup) {
    this.enterpriseGroup = enterpriseGroup;
  }

  public String getCorporateTaxId() {
    return corporateTaxId;
  }

  public void setCorporateTaxId(String corporateTaxId) {
    this.corporateTaxId = corporateTaxId;
  }

  public List<String> getCorporates() {
    return corporates;
  }

  public void setCorporates(List<String> corporates) {
    this.corporates = corporates;
  }

  public List<String> getCountries() {
    return countries;
  }

  public void setCountries(List<String> countries) {
    this.countries = countries;
  }

  public List<String> getBics() {
    return bics;
  }

  public void setBics(List<String> bics) {
    this.bics = bics;
  }

  public List<String> getCurrencies() {
    return this.currencies;
  }

  public void setCurrencies(List<String> currencies) {
    this.currencies = currencies;
  }

  public AccountRequest enterpriseGroup(String enterpriseGroup){
    this.enterpriseGroup = enterpriseGroup;
    return this;
  }

  public AccountRequest corporateTaxId(String corporateTaxId){
    this.corporateTaxId = corporateTaxId;
    return this;
  }

  public AccountRequest corporates(List<String> corporates){
    this.corporates = corporates;
    return this;
  }

  public AccountRequest countries(List<String> countries){
    this.countries = countries;
    return this;
  }

  public AccountRequest bics(List<String> bics){
    this.bics = bics;
    return this;
  }

  public AccountRequest currencies(List<String> currencies) {
    this.currencies = currencies;
    return this;
  }

  @Override
  public String toString() {
    return "AccountRequest{" +
      "\n enterpriseGroup: " + this.getEnterpriseGroup() +
      ",\n corporateTaxId: " + this.getCorporateTaxId() +
      ",\n corporates: " + this.getCorporates() +
      ",\n countries: " + this.getCountries() +
      ",\n entities: " + this.getBics() +
      ",\n currencies: " + this.getCurrencies() +
      ",\n products: " + super.getProducts() +
      ",\n formats: " + super.getFormats() +
      ",\n channel: " + super.getChannels() +
      ",\n startDate:" + super.getStartDate() +
      ",\n endDate: " + super.getEndDate() +
      ",\n specificDate: " + super.getSpecificDate() +
      '}';
  }
}
