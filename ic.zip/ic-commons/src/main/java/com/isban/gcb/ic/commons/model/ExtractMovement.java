package com.isban.gcb.ic.commons.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.isban.gcb.ic.commons.util.DateTimeUtils;
import com.isban.gcb.ic.commons.util.ExtractMovementDatesEnum;
import com.prowidesoftware.swift.model.field.Field61;
import com.prowidesoftware.swift.model.field.Field86;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang.StringUtils;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static org.apache.commons.lang.StringUtils.leftPad;
import static org.apache.commons.lang.StringUtils.right;
import static org.apache.commons.lang.StringUtils.rightPad;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "movement")
@JsonInclude(Include.NON_NULL)
@JsonPropertyOrder({"id", "valueDate", "entryDate", "mark", "amount", "txType",
        "identificationCode", "customerReference", "institutionReference", "supplementaryDetails",
        "movementInfo", "movementTime", "bookBalanceMark", "bookBalanceAmount", "page"})
public class ExtractMovement extends AuditableLocalDateTime implements Serializable {

    private static final long serialVersionUID = 736221917625751741L;

    @JsonProperty("id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @JsonProperty("valueDate")
    @Column(name = "value_date", nullable = false)
    private LocalDate valueDate;

    @JsonProperty("entryDate")
    @Column(name = "entry_date")
    private LocalDate entryDate;

    @JsonProperty("mark")
    @NotNull
    @Size(min = 1, max = 2)
    @Column(nullable = false)
    private String mark;

    @JsonProperty("fundsCode")
    @Column(name = "funds_code")
    private Character fundsCode;

    @NotNull
    @JsonProperty("amount")
    @Column(nullable = false, columnDefinition = "NUMBER(16,3)")
    private Double amount;

    @JsonProperty("txType")
    @NotNull
    @Column(name = "tx_type", nullable = false)
    private Character txType;

    @JsonProperty("identificationCode")
    @NotNull
    @Column(name = "identification_code", nullable = false)
    @Size(max = 3)
    private String identificationCode;

    @JsonProperty("customerReference")
    @NotNull
    @Column(name = "customer_reference", nullable = false)
    @Size(max = 16)
    private String customerReference;

    @JsonProperty("institutionReference")
    @Column(name = "institution_reference")
    @Size(max = 16)
    private String institutionReference;

    @JsonProperty("supplementaryDetails")
    @Column(name = "supplementary_details")
    @Size(max = 34)
    private String supplementaryDetails;

    @JsonBackReference
    @ManyToOne(fetch = FetchType.EAGER)
    @NotNull
    @JoinColumn(name = "extract_id", referencedColumnName = "id", nullable = false)
    private Extract extract;

    @Column(name = "movement_info", length = 400)
    private String movementInfo;

    @JsonProperty("page")
    @Column(columnDefinition = "NUMBER(5,0) default 1")
    private Integer page;

    @JsonProperty("movementTime")
    @Column(name = "movement_time")
    private LocalDateTime movementTime;

    @JsonProperty("bookBalanceMark")
    @Size(max = 2)
    @Column(name = "book_balance_mark", length = 2)
    private String bookBalanceMark;

    @JsonProperty("bookBalanceAmount")
    @Column(name = "book_balance_amount", columnDefinition = "NUMBER(17,2)")
    private Double bookBalanceAmount;

    @Override
    public String toString() {
        return "ExtractMovement{" + "valueDate=" + valueDate + ", entryDate=" + entryDate
                + ", mark='" + mark + '\'' + ", fundsCode=" + fundsCode + ", amount=" + amount
                + ", txType=" + txType + ", identificationCode='" + identificationCode + '\''
                + ", customerReference='" + customerReference + '\'' + ", institutionReference='"
                + institutionReference + '\'' + ", supplementaryDetails='" + supplementaryDetails
                + '\'' + ", movementInfo='" + movementInfo + '\'' + ", page=" + page
                + ", movementTime=" + movementTime + ", bookBalanceMark='" + bookBalanceMark + '\''
                + ", bookBalanceAmount=" + bookBalanceAmount + '}';
    }

    public ExtractMovement(Field61 tag61, Integer page) {
        this.valueDate = DateTimeUtils.parseToLocalDate(tag61.getValueDate());
        if (!StringUtils.isEmpty(tag61.getEntryDate())) {
            LocalDate d = DateTimeUtils
                    .parseToLocalDate(tag61.getValueDate().substring(0, 2) + tag61.getEntryDate());
            entryDate = ExtractMovementDatesEnum.getCorrectEntryDate(d, valueDate);
        }
        this.page = page;
        this.mark = tag61.getDCMark();
        if (!StringUtils.isEmpty(tag61.getFundsCode())) {
            this.fundsCode = tag61.getFundsCode().charAt(0);
        }
        this.amount = tag61.amount().doubleValue();
        this.txType = tag61.getTransactionType().charAt(0);
        this.identificationCode = tag61.getIdentificationCode();
        this.customerReference = tag61.getReferenceForTheAccountOwner();
        this.institutionReference = tag61.getReferenceOfTheAccountServicingInstitution();

        this.formatSupplementaryDetails(tag61.getSupplementaryDetails(), valueDate);
    }

    public void addMovementsInfoList(Field86 tag86) {
        this.movementInfo =
                tag86.getLines().stream().map(String::trim).collect(Collectors.joining("\r\n"));
    }

    private void formatSupplementaryDetails(String supplementaryDetails, LocalDate valueDate) {
        if (!StringUtils.isEmpty(supplementaryDetails)) {
            Pattern p = Pattern.compile("/TIME/(\\d{6})/AFTER/([C, D])(\\d+,\\d*?)");
            Matcher m = p.matcher(supplementaryDetails);
            if (!m.matches()) {
                this.supplementaryDetails = supplementaryDetails;
            } else {
                this.movementTime =
                        LocalDateTime.of(valueDate, DateTimeUtils.parseToLocalTime(m.group(1)));
                this.bookBalanceMark = m.group(2).substring(0, 1);
                this.bookBalanceAmount = Double.parseDouble(m.group(3).replace(',', '.'));
            }
        }
    }

    public String generateMovementFileValue() {
        String val = "";
        val += right(leftPad(id.toString(), 7, "0"), 7);
        val += rightPad(extract.getAccountIdentification(), 50, " ");
        val += extract.getClosingBalanceDate();
        val += valueDate == null ? DateTimeUtils.formatISODate(extract.getClosingBalanceDate())
                : DateTimeUtils.formatISODate(valueDate);
        String am = mark.equals("C") || mark.equals("RD") ? " " : "-";
        am += String.format("%.2f", amount).replace('.', ',');
        val += leftPad(am, 19, " ");
        val += identificationCode;
        String cR = customerReference == null ? "" : customerReference;
        val += rightPad(cR, 16, " ");
        String iR = institutionReference == null ? "" : institutionReference;
        val += rightPad(iR, 16, " ");

        String details = movementInfo == null ? "" : movementInfo.replaceAll("\r\n", "");
        details += supplementaryDetails != null ? ("//  " + rightPad(supplementaryDetails, 34, " "))
                : "";
        val += rightPad(details, 428);

        val += leftPad(extract.getStatementNumber().toString(), 5, "0");
        val += leftPad(page == null ? "1" : page.toString(), 5, "0");
        return val;
    }
    
    public static ExtractMovement newInstanceFrom(ExtractMovement original, Extract extract) {
        ExtractMovement movement = new ExtractMovement();
        movement.setValueDate(original.getValueDate());
        movement.setEntryDate(original.getEntryDate());
        movement.setMark(original.getMark());
        movement.setFundsCode(original.getFundsCode());
        movement.setAmount(original.getAmount());
        movement.setTxType(original.getTxType());
        movement.setIdentificationCode(original.getIdentificationCode());
        movement.setCustomerReference(original.getCustomerReference());
        movement.setInstitutionReference(original.getInstitutionReference());
        movement.setSupplementaryDetails(original.getSupplementaryDetails());
        movement.setMovementInfo(original.getMovementInfo());
        movement.setPage(original.getPage());
        movement.setMovementTime(original.getMovementTime());
        movement.setBookBalanceMark(original.getBookBalanceMark());
        movement.setBookBalanceAmount(original.getBookBalanceAmount());
        movement.setExtract(extract);
        return movement;
    }
}
