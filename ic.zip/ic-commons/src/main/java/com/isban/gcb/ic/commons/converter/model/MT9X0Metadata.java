package com.isban.gcb.ic.commons.converter.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class MT9X0Metadata {
  @JsonProperty(required = true) private String account;
  @JsonProperty(required = true) private String currency;
  @JsonProperty(required = true) private String entity;
  @JsonProperty(required = true) private String statementNumber;
  @JsonProperty(required = true) private Integer pageNumber;
  @JsonProperty(required = true) private Long timestamp;
  @JsonProperty(required = true) private Long offset;
  @JsonProperty(required = true) private Integer partition;
  @JsonProperty(required = true) private Long version;
  @JsonProperty(required = true) private String statementStatus;
  @JsonProperty(required = true) private String pageKey;
  @JsonProperty(required = true) private String statementKey;
  @JsonProperty(required = true) private String versionKey;
  @JsonProperty(required = true) private Integer totalPages;
  @JsonProperty(required = true) private String accountingDate;
  @JsonProperty(required = true) private boolean firstPage;
  @JsonProperty(required = true) private String swiftType;
  @JsonProperty(required = true) private String uuid;
}
