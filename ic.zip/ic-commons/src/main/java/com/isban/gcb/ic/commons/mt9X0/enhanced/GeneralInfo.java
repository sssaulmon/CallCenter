package com.isban.gcb.ic.commons.mt9X0.enhanced;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "transactionRefNumber",
        "accountId",
        "statementNum",
        "pageNum"
})
public class GeneralInfo implements Serializable {

    private static final long serialVersionUID = -2058213635810892055L;

    @JsonProperty("transactionRefNumber")
    private String transactionRefNumber;
    @JsonProperty("accountId")
    private String accountId;
    @JsonProperty("statementNum")
    private Integer statementNum;
    @JsonProperty("pageNum")
    private Integer pageNum;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();

    /**
     * No args constructor for use in serialization
     */
    public GeneralInfo() {
        /*Empty Constructor*/
    }

    /**
     * @param accountId
     * @param statementNum
     * @param transactionRefNumber
     * @param pageNum
     */
    public GeneralInfo(String transactionRefNumber, String accountId, Integer statementNum, Integer pageNum) {
        super();
        this.transactionRefNumber = transactionRefNumber;
        this.accountId = accountId;
        this.statementNum = statementNum;
        this.pageNum = pageNum;
    }

    @JsonProperty("transactionRefNumber")
    public String getTransactionRefNumber() {
        return transactionRefNumber;
    }

    @JsonProperty("transactionRefNumber")
    public void setTransactionRefNumber(String transactionRefNumber) {
        this.transactionRefNumber = transactionRefNumber;
    }

    @JsonProperty("accountId")
    public String getAccountId() {
        return accountId;
    }

    @JsonProperty("accountId")
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    @JsonProperty("statementNum")
    public Integer getStatementNum() {
        return statementNum;
    }

    @JsonProperty("statementNum")
    public void setStatementNum(Integer statementNum) {
        this.statementNum = statementNum;
    }

    @JsonProperty("pageNum")
    public Integer getPageNum() {
        return pageNum;
    }

    @JsonProperty("pageNum")
    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
