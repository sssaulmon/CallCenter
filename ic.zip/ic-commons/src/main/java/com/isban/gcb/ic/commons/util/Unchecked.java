package com.isban.gcb.ic.commons.util;

import com.isban.gcb.ic.commons.util.function.ThrowingConsumer;
import com.isban.gcb.ic.commons.util.function.ThrowingFunction;
import com.isban.gcb.ic.commons.util.function.ThrowingSupplier;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public interface Unchecked {

  static <T, S> Function<T, S> function(ThrowingFunction<T, S> source) {
    return before -> {
      try {
        return source.apply(before);
      } catch (Throwable e) {
        throw new UncheckedException(e);
      }
    };
  }

  static <T> Consumer<T> consumer(ThrowingConsumer<T> source) {
    return before -> {
      try {
        source.accept(before);
      } catch (Throwable e) {
        throw new UncheckedException(e);
      }
    };
  }

  static <T> Supplier<T> supplier(ThrowingSupplier<T> source) {
    return () -> {
      try {
        return source.get();
      } catch (Throwable e) {
        throw new UncheckedException(e);
      }
    };
  }
}
