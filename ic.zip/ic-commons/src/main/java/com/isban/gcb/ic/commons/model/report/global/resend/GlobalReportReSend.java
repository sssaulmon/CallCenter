package com.isban.gcb.ic.commons.model.report.global.resend;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @since 11/09/2018
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "contract",
        "outputChannel",
        "frequency",
        "format",
        "globalReportVersion",
        "account",
        "implementation",
        "contents"
})
public class GlobalReportReSend implements Serializable {

    private static final long serialVersionUID = 7348956008372882627L;

    @JsonProperty("contract")
    private String contract;

    @JsonProperty("outputChannel")
    private String outputChannel;

    @JsonProperty("frequency")
    private String frequency;

    @JsonProperty("format")
    private String format;

    @JsonProperty("globalReportVersion")
    private String globalReportVersion;

    @JsonProperty("account")
    private String account;

    @JsonProperty("implementation")
    private boolean implementation;

    @JsonProperty("contents")
    private List<ContentReSend> contents = new ArrayList<>();

    @JsonProperty("data")
    private byte[] data;

    @JsonProperty("fileExtension")
    private String fileExtension;

    public GlobalReportReSend() {
    }

    public void addContent(ContentReSend content) {
        contents.add(content);
    }

    public String getContract() {
        return this.contract;
    }

    public String getOutputChannel() {
        return this.outputChannel;
    }

    public String getFrequency() {
        return this.frequency;
    }

    public String getFormat() {
        return this.format;
    }

    public String getGlobalReportVersion() {
        return this.globalReportVersion;
    }

    public String getAccount() {
        return this.account;
    }

    public boolean isImplementation() {
        return this.implementation;
    }

    public List<ContentReSend> getContents() {
        return this.contents;
    }

    public byte[] getData() {
        return this.data;
    }

    public String getFileExtension() {
        return this.fileExtension;
    }

    public void setContract(String contract) {
        this.contract = contract;
    }

    public void setOutputChannel(String outputChannel) {
        this.outputChannel = outputChannel;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public void setGlobalReportVersion(String globalReportVersion) {
        this.globalReportVersion = globalReportVersion;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public void setImplementation(boolean implementation) {
        this.implementation = implementation;
    }

    public void setContents(List<ContentReSend> contents) {
        this.contents = contents;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public void setFileExtension(String fileExtension) {
        this.fileExtension = fileExtension;
    }

    public GlobalReportReSend contract(String contract) {
        this.contract = contract;
        return this;
    }

    public GlobalReportReSend outputChannel(String outputChannel) {
        this.outputChannel = outputChannel;
        return this;
    }

    public GlobalReportReSend frequency(String frequency) {
        this.frequency = frequency;
        return this;
    }

    public GlobalReportReSend format(String format) {
        this.format = format;
        return this;
    }

    public GlobalReportReSend globalReportVersion(String globalReportVersion) {
        this.globalReportVersion = globalReportVersion;
        return this;
    }

    public GlobalReportReSend account(String account) {
        this.account = account;
        return this;
    }

    public GlobalReportReSend implementation(boolean implementation) {
        this.implementation = implementation;
        return this;
    }

    public GlobalReportReSend contents(List<ContentReSend> contents) {
        this.contents = contents;
        return this;
    }

    public GlobalReportReSend data(byte[] data) {
        this.data = data;
        return this;
    }

    public GlobalReportReSend fileExtension(String fileExtension) {
        this.fileExtension = fileExtension;
        return this;
    }

    public String toString() {
        return "GlobalReportReSend(contract=" + this.getContract() + ", outputChannel=" + this.getOutputChannel() + ", frequency=" + this.getFrequency() + ", format=" + this.getFormat() + ", globalReportVersion=" + this.getGlobalReportVersion() + ", account=" + this.getAccount() + ", implementation=" + this.isImplementation() + ", contents=" + this.getContents() + ", data=" + java.util.Arrays.toString(this.getData()) + ", fileExtension=" + this.getFileExtension() + ")";
    }
}