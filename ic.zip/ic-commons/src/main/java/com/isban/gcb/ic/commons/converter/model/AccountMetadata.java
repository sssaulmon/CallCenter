package com.isban.gcb.ic.commons.converter.model;

import java.util.List;

public class AccountMetadata {
  private String bic;
  private String entity;
  private String entityName;
  private String aliasAccount;
  private String localAccount;
  private String currency;
  private String accountingDate;
  private String incomingDate;
  private String transformSize;
  private String statementNumber;
  private String version;
  private String productCode;
  private String subproductCode;
  private String subproductUuid;
  private Integer currencyDecimals;
  private String uuidCorporate;
  private String corporate;
  private String bicEntityAcc;
  private String uuidStructureAcc;
  private String previousTag64;
  private List<ContractDto> contracts;

  public AccountMetadata() {
  }

  public String getBic() {
    return this.bic;
  }

  public String getEntity() {
    return this.entity;
  }

  public String getEntityName() {
    return entityName;
  }

  public String getAliasAccount() {
    return this.aliasAccount;
  }

  public String getLocalAccount() {
    return this.localAccount;
  }

  public String getCurrency() {
    return this.currency;
  }

  public String getAccountingDate() {
    return this.accountingDate;
  }

  public String getIncomingDate() {
    return this.incomingDate;
  }

  public String getTransformSize() {
    return this.transformSize;
  }

  public String getStatementNumber() {
    return this.statementNumber;
  }

  public String getVersion() {
    return this.version;
  }

  public String getProductCode() {
    return this.productCode;
  }

  public String getSubproductCode() {
    return this.subproductCode;
  }

  public String getSubproductUuid() {
    return this.subproductUuid;
  }

  public Integer getCurrencyDecimals() {
    return this.currencyDecimals;
  }

  public String getUuidCorporate() {
    return this.uuidCorporate;
  }

  public String getBicEntityAcc() {
    return this.bicEntityAcc;
  }

  public String getUuidStructureAcc() {
    return this.uuidStructureAcc;
  }

  public List<ContractDto> getContracts() {
    return this.contracts;
  }

  public String getCorporate() {
    return corporate;
  }

  public String getPreviousTag64() {
    return previousTag64;
  }

  public void setBic(String bic) {
    this.bic = bic;
  }

  public void setEntity(String entity) {
    this.entity = entity;
  }

  public void setEntityName(String entityName) {
    this.entityName = entityName;
  }

  public void setAliasAccount(String aliasAccount) {
    this.aliasAccount = aliasAccount;
  }

  public void setLocalAccount(String localAccount) {
    this.localAccount = localAccount;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public void setAccountingDate(String accountingDate) {
    this.accountingDate = accountingDate;
  }

  public void setIncomingDate(String incomingDate) {
    this.incomingDate = incomingDate;
  }

  public void setTransformSize(String transformSize) { this.transformSize = transformSize; }

  public void setStatementNumber(String statementNumber) {
    this.statementNumber = statementNumber;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public void setProductCode(String productCode) {
    this.productCode = productCode;
  }

  public void setSubproductCode(String subproductCode) {
    this.subproductCode = subproductCode;
  }

  public void setSubproductUuid(String uuid) {
    this.subproductUuid = uuid;
  }

  public void setCurrencyDecimals(Integer currencyDecimals) {
    this.currencyDecimals = currencyDecimals;
  }

  public void setUuidCorporate(String uuid) {
    this.uuidCorporate = uuid;
  }

  public void setBicEntityAcc(String bicEntityAcc) {
    this.bicEntityAcc = bicEntityAcc;
  }

  public void setUuidStructureAcc(String uuid) {
    this.uuidStructureAcc = uuid;
  }

  public void setContracts(List<ContractDto> contracts) {
    this.contracts = contracts;
  }

  public void setCorporate(String corporate) {
    this.corporate = corporate;
  }

  public void setPreviousTag64(String previousTag64) {
    this.previousTag64 = previousTag64;
  }

  public AccountMetadata bic(String bic) {
    this.bic = bic;
    return this;
  }

  public AccountMetadata entity(String entity) {
    this.entity = entity;
    return this;
  }

  public AccountMetadata entityName(String entityName) {
    this.entityName = entityName;
    return this;
  }

  public AccountMetadata aliasAccount(String aliasAccount) {
    this.aliasAccount = aliasAccount;
    return this;
  }

  public AccountMetadata localAccount(String localAccount) {
    this.localAccount = localAccount;
    return this;
  }

  public AccountMetadata currency(String currency) {
    this.currency = currency;
    return this;
  }

  public AccountMetadata accountingDate(String accountingDate) {
    this.accountingDate = accountingDate;
    return this;
  }

  public AccountMetadata incomingDate(String incomingDate) {
    this.incomingDate = incomingDate;
    return this;
  }

  public AccountMetadata transformSize(String transformSize) {
    this.transformSize = transformSize;
    return this;
  }

  public AccountMetadata statementNumber(String statementNumber) {
    this.statementNumber = statementNumber;
    return this;
  }

  public AccountMetadata version(String version) {
    this.version = version;
    return this;
  }

  public AccountMetadata productCode(String productCode) {
    this.productCode = productCode;
    return this;
  }

  public AccountMetadata subproductCode(String subproductCode) {
    this.subproductCode = subproductCode;
    return this;
  }

  public AccountMetadata subproductUuid(String uuid) {
    this.subproductUuid = uuid;
    return this;
  }

  public AccountMetadata currencyDecimals(Integer currencyDecimals) {
    this.currencyDecimals = currencyDecimals;
    return this;
  }

  public AccountMetadata uuidCorporate(String uuidCorporate) {
    this.uuidCorporate = uuidCorporate;
    return this;
  }

  public AccountMetadata bicEntityAcc(String bicEntityAcc) {
    this.bicEntityAcc = bicEntityAcc;
    return this;
  }

  public AccountMetadata uuidStructureAcc(String uuid) {
    this.uuidStructureAcc = uuid;
    return this;
  }

  public AccountMetadata contracts(List<ContractDto> contracts) {
    this.contracts = contracts;
    return this;
  }

  public AccountMetadata corporate(String corporate) {
    this.corporate = corporate;
    return this;
  }

  public AccountMetadata previousTag64(String previousTag64) {
    this.previousTag64 = previousTag64;
    return this;
  }

  @Override
  public String toString() {
    return "AccountMetadata(" + "bic=" + this.getBic() + ", " +
      "entity=" + this.getEntity() + ", " +
      "entityName=" + entityName + ", " +
      "aliasAccount=" + this.getAliasAccount() + ", " +
      "localAccount=" + this.getLocalAccount() + ", " +
      "currency=" + this.getCurrency() + ", " +
      "accountingDate=" + this.getAccountingDate() + ", " +
      "incomingDate=" + this.getIncomingDate() + ", " +
      "transformSize=" + this.getTransformSize() + ", " +
      "statementNumber=" + this.getStatementNumber() + ", " +
      "version=" + this.getVersion() + ", " +
      "productCode=" + this.getProductCode() + ", " +
      "subproductCode=" + this.getSubproductCode() + ", " +
      "subproductUuid=" + this.getSubproductUuid() + ", " +
      "currencyDecimals=" + this.getCurrencyDecimals() + ", " +
      "uuidCorporate=" + this.getUuidCorporate() + ", " +
      "corporate='" + corporate + ", " +
      "bicEntityAcc=" + this.getBicEntityAcc() + ", " +
      "uuidStructureAcc=" + this.getUuidStructureAcc() + ", " +
      "previousTag64='" + previousTag64 + ", " +
      "contracts=" + this.getContracts() +
      ")";
  }
}