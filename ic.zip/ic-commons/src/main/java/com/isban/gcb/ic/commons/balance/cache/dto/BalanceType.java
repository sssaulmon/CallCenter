package com.isban.gcb.ic.commons.balance.cache.dto;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

public enum BalanceType {

  INTRA_DAY("INTR", Arrays.asList("MT941", "MT942")),
  END_OF_DAY("FIND", Arrays.asList("MT940", "MT950")),
  ONLINE("ONLI", Collections.emptyList());

  private final String dbType;
  private final List<String> formats;

  BalanceType(String dbType, List<String> formats) {
    this.dbType = dbType;
    this.formats = formats;
  }

  public List<String> getFormats() {
    return formats;
  }

  @Override
  public String toString() {
    return dbType;
  }

  public static BalanceType getBalanceType(String format) {
    return Stream.of(BalanceType.values())
      .filter(balanceType -> balanceType.getFormats().contains(format))
      .findAny()
      .orElseThrow(() -> new RuntimeException("Format not recognized for any Balance Type"));
  }
}
