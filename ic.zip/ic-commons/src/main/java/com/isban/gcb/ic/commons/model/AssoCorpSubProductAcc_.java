package com.isban.gcb.ic.commons.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import java.time.LocalDate;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(AssoCorpSubProductAcc.class)
public abstract class AssoCorpSubProductAcc_ extends com.isban.gcb.ic.commons.model.AuditableLocalDate_ {

	public static volatile SingularAttribute<AssoCorpSubProductAcc, String> bicEntityAcc;
	public static volatile SingularAttribute<AssoCorpSubProductAcc, LocalDate> endDate;
	public static volatile SingularAttribute<AssoCorpSubProductAcc, String> uuidCorporate;
	public static volatile SetAttribute<AssoCorpSubProductAcc, ServiceAccount> accountSet;
	public static volatile SingularAttribute<AssoCorpSubProductAcc, String> alias;
	public static volatile SingularAttribute<AssoCorpSubProductAcc, String> uuidStructureAcc;
	public static volatile SingularAttribute<AssoCorpSubProductAcc, String> currency;
	public static volatile SingularAttribute<AssoCorpSubProductAcc, String> lastModifiedUser;
	public static volatile SingularAttribute<AssoCorpSubProductAcc, Subproduct> subproduct;
	public static volatile SingularAttribute<AssoCorpSubProductAcc, Long> id;
	public static volatile SingularAttribute<AssoCorpSubProductAcc, String> uuid;
	public static volatile SingularAttribute<AssoCorpSubProductAcc, Boolean> gtsIndicator;
	public static volatile SingularAttribute<AssoCorpSubProductAcc, LocalDate> gtsIndicatorDate;

	public static final String BIC_ENTITY_ACC = "bicEntityAcc";
	public static final String END_DATE = "endDate";
	public static final String UUID_CORPORATE = "uuidCorporate";
	public static final String ACCOUNT_SET = "accountSet";
	public static final String ALIAS = "alias";
	public static final String UUID_STRUCTURE_ACC = "uuidStructureAcc";
	public static final String CURRENCY = "currency";
	public static final String LAST_MODIFIED_USER = "lastModifiedUser";
	public static final String SUBPRODUCT = "subproduct";
	public static final String ID = "id";
	public static final String UUID = "uuid";
	public static final String GTS_INDICATOR = "gtsIndicator";
	public static final String GTS_INDICATOR_DATE = "gtsIndicatorDate";

}

