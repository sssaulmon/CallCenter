package com.isban.gcb.ic.commons.model.outputformat.record;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.isban.gcb.ic.commons.model.outputformat.standard.OutputStandardMetadata;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
  "outputStandardMetadata",
  "outputFormatMetadata",
  "outputFormatMetadataSend",
  "notificationMetadata",
  "requestID",
  "text",
  "subType"
})
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class OutputFormatRecord implements Serializable {

    private static final long serialVersionUID = -7719694800333043227L;

    @JsonProperty("outputStandardMetadata")
    private OutputStandardMetadata outputStandardMetadata;

    @JsonProperty("outputFormatMetadata")
    private OutputFormatMetadata outputFormatMetadata;

    @JsonProperty("outputFormatMetadataSend")
    private OutputFormatMetadataSend outputFormatMetadataSend;

    @JsonProperty("notificationMetadata")
    private OutputFormatNotificationMetadata notificationMetadata;

    @JsonProperty("requestID")
    private String requestID;

    @JsonProperty("text")
    private String text;

    @JsonProperty("data")
    private byte[] data;

    @JsonProperty("subType")
    private String subType;

    @JsonProperty("template")
    private byte[] template;

}