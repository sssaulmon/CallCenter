package com.isban.gcb.ic.commons.model;


import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 * A ServiceAddress.
 */
@Entity
@Table(name = "service_address",
        indexes = {@Index(columnList = "uuid", name = "uuid_service_address")})
public class ServiceAddress extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "service_address_gen")
    @SequenceGenerator(name = "service_address_gen", sequenceName = "service_address_generator",
            allocationSize = 1)
    private Long id;


    @Size(max = 40)
    @Column(name = "uuid", length = 40)
    private String uuid;

    @Size(max = 200)
    @Column(name = "address", length = 200)
    private String address;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Size(max = 20)
    @Column(name = "last_modified_user", length = 20)
    private String lastModifiedUser;

    @ManyToOne
    private Service service;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public ServiceAddress uuid(String uuid) {
        this.uuid = uuid;
        return this;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public ServiceAddress address(String address) {
        this.address = address;
        return this;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public ServiceAddress endDate(LocalDate endDate) {
        this.endDate = endDate;
        return this;
    }

    private String getLastModifiedUser() {
        return lastModifiedUser;
    }

    public void setLastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
    }

    public ServiceAddress lastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
        return this;
    }

    public Service getService() {
        return service;
    }

    public void setService(Service service) {
        this.service = service;
    }

    public ServiceAddress service(Service service) {
        this.service = service;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ServiceAddress serviceAddress = (ServiceAddress) o;
        if (serviceAddress.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), serviceAddress.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "ServiceAddress{" + "id=" + getId() + ", uuid='" + getUuid() + "'" + ", address='"
                + getAddress() + "'" + ", createDate='" + getCreateDate() + "'" + ", endDate='"
                + getEndDate() + "'" + ", lastModifiedDate='" + getLastModifiedDate() + "'"
                + ", lastModifiedUser='" + getLastModifiedUser() + "'" + "}";
    }
}
