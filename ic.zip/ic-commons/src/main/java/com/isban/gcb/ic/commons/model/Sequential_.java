package com.isban.gcb.ic.commons.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Sequential.class)
public abstract class Sequential_ {

	public static volatile SingularAttribute<Sequential, Long> sequenceValue;
	public static volatile SingularAttribute<Sequential, String> sequenceId;

	public static final String SEQUENCE_VALUE = "sequenceValue";
	public static final String SEQUENCE_ID = "sequenceId";

}

