package com.isban.gcb.ic.commons.model;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;

@Entity
@Table(name = "country_bank_entity")
public class CountryBankEntity implements Serializable {

  private static final long serialVersionUID = 9212759852552149545L;

  @Embedded
  @Id
  private CountryBankEntityKey id;

  @NotBlank
  @Column(name = "zone_id")
  private String zoneId;

  public CountryBankEntity() {
  }

  public CountryBankEntity(CountryBankEntityKey id, String zoneId) {
    this.id = id;
    this.zoneId = zoneId;
  }

  public CountryBankEntityKey getId() {
    return this.id;
  }

  public void setId(CountryBankEntityKey id) {
    this.id = id;
  }

  public String getZoneId() {
    return this.zoneId;
  }

  public void setZoneId(String id) {
    this.zoneId = id;
  }

  @Override
  public boolean equals(Object o) {

    if (this == o) {
      return true;
    }

    return Optional.ofNullable(o)
      .filter(object -> this != object && this.getClass() != o.getClass())
      .map(CountryBankEntity.class::cast)
      .filter(object -> Objects.equals(getId(), object.getId()))
      .map(object -> Boolean.TRUE)
      .orElse(Boolean.FALSE);

  }

  @Override
  public int hashCode() {
    return Objects.hashCode(getId());
  }

  @Override
  public String toString() {
    return "CountryBankEntity {" +
      Optional.ofNullable(this.id)
        .map(key -> "bic=" + key.getBic() + ", countryCode=" + key.getCountryCode() + ", bankCode=" + key.getBankCode())
        .orElse("bic=null, countryCode=null, bankCode=null")
      + ", zoneId=" + this.getZoneId() + "}";
  }
}

