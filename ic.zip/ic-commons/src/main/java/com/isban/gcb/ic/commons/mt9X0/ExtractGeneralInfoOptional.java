package com.isban.gcb.ic.commons.mt9X0;

import java.io.Serializable;

/**
 * @author eduardo.rodriguezllo
 */
public class ExtractGeneralInfoOptional implements Serializable {

    private String infoAccOwn; //Information to Account Owner

    /*
    * Constructor Empty
    */
    public ExtractGeneralInfoOptional() {
        this.infoAccOwn = null;
    }

    /*
    * Constructor Full
    */
    public ExtractGeneralInfoOptional(String infoAccOwn) {
        this.infoAccOwn = infoAccOwn;
    }

    /*
    * Getters
    */
    public String getInfoAccOwn() {
        return infoAccOwn;
    }

    /*
    * Setters
    */
    public void setInfoAccOwn(String infoAccOwn) {
        this.infoAccOwn = infoAccOwn;
    }
}
