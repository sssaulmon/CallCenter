package com.isban.gcb.ic.commons.util;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.StringUtils;

import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class GroupRegExUtils {

  private static Matcher getMatcher(String regex, String evaluateString) {
    return Pattern.compile(regex).matcher(evaluateString);
  }

  public static boolean validate(String regex, String evaluateString) {
    if (StringUtils.isEmpty(evaluateString) || StringUtils.isEmpty(regex)) {
      return false;
    }
    return getMatcher(regex, evaluateString).find();
  }

  public static Map<String, String> getGroups(String regex, String evaluateString) {
    Matcher matcher = getMatcher(regex, evaluateString);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Regular expression not match with evaluateString");
    }

    Set<String> namedGroups = getNamedGroups(regex);
    return namedGroups.stream().collect(Collectors.toMap(x -> x, matcher::group));
  }

  private static Set<String> getNamedGroups(String regex) {
    Set<String> namedGroups = new TreeSet<>();
    Matcher m = Pattern.compile("\\(\\?<([a-zA-Z][a-zA-Z0-9]*)>").matcher(regex);
    while (m.find()) {
      namedGroups.add(m.group(1));
    }

    return namedGroups;
  }
}