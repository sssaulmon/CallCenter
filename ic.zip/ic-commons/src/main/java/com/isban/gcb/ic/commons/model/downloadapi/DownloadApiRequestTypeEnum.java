package com.isban.gcb.ic.commons.model.downloadapi;

public enum DownloadApiRequestTypeEnum {

  ACCOUNTS(1, "Accounts"),
  GLOBAL_REPORTS(2, "Global Reports"),
  DOWNLOAD_REPORTS(3, "Download Reports"),
  CONTINGENCY(4, "Contingency"),
  INTERNET(5, "Internet");

  private int code;
  private String description;


  DownloadApiRequestTypeEnum(int code, String description) {
    this.code = code;
    this.description = description;
  }

  public int getCode() {
    return code;
  }

  public String getDescription() {
    return description;
  }
}
