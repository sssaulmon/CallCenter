package com.isban.gcb.ic.commons.util;

import org.apache.commons.lang.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateTimeUtils {

  public static final String DATE_REGEX = "^.*T.*Z$";

  private DateTimeUtils() {
  }

  public static String formatISODate(LocalDate date) {
    DateTimeFormatter df = DateTimeFormatter.ISO_DATE;
    return date.format(df);
  }

  public static LocalDate parseToLocalDate(String date) {
    if (StringUtils.isEmpty(date)) {
      return null;
    }
    DateTimeFormatter f;
    Pattern p = Pattern.compile("(\\d{4})-(\\d{2})-(\\d{2})");
    Matcher m = p.matcher(date);
    if (m.matches()) {
      f = DateTimeFormatter.ISO_DATE;
    } else {
      f = DateTimeFormatter.ofPattern("yyMMdd");
    }
    return LocalDate.parse(date, f);
  }

  public static LocalTime parseToLocalTime(String time) {
    Pattern p = Pattern.compile("\\d{6}");
    Matcher m = p.matcher(time);
    DateTimeFormatter df;
    if (m.matches()) {
      df = DateTimeFormatter.ofPattern("HHmmss");
    } else {
      df = DateTimeFormatter.ofPattern("HHmm");
    }
    return LocalTime.parse(time, df);

  }

  public static LocalDateTime getAccountingDate(String type, String accountingDate) {
    return Optional.of(accountingDate)
      .filter(str -> str.matches(DATE_REGEX))
      .map(mt -> getINTRAccountingDate(accountingDate))
      .orElseGet(() -> getFINDAccountingDate(accountingDate));
  }

  public static LocalDateTime getINTRAccountingDate(String date) {
    return Optional.of(date)
      .map(str -> str.replace("T", " "))
      .map(str -> LocalDateTime.parse(str, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ssZZZZZ")))
      .orElseThrow(IllegalArgumentException::new);
  }

  public static LocalDateTime getFINDAccountingDate(String date) {
    return Optional.of(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
      .map(pattern -> LocalDate.parse(date, pattern).atStartOfDay())
      .map(LocalDateTime::from)
      .orElseThrow(IllegalArgumentException::new);
  }
}
