package com.isban.gcb.ic.commons.converter.model;

import com.fasterxml.jackson.annotation.JsonInclude;

public class ReprocessDTO {

  @JsonInclude(JsonInclude.Include.NON_NULL) private String uuid;
  @JsonInclude(JsonInclude.Include.NON_NULL) private String json;
  @JsonInclude(JsonInclude.Include.NON_NULL) private String processingDate;
  @JsonInclude(JsonInclude.Include.NON_NULL) private String topic;

  public ReprocessDTO uuid(String uuid) {
    this.uuid = uuid;
    return this;
  }

  public ReprocessDTO payload(String payload) {
    this.json = payload;
    return this;
  }

  public ReprocessDTO offsetDateTime(String offsetDateTime) {
    this.processingDate = offsetDateTime;
    return this;
  }

  public ReprocessDTO topic(String topic) {
    this.topic = topic;
    return this;
  }

  public String getUuid() {
    return uuid;
  }

  public void setUuid(String uuid) {
    this.uuid = uuid;
  }

  public String getJson() {
    return json;
  }

  public void setJson(String json) {
    this.json = json;
  }

  public String getProcessingDate() {
    return processingDate;
  }

  public void setProcessingDate(String processingDate) {
    this.processingDate = processingDate;
  }

  public String getTopic() {
    return topic;
  }

  public void setTopic(String topic) {
    this.topic = topic;
  }
}
