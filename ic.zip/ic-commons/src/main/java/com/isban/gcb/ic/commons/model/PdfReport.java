package com.isban.gcb.ic.commons.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;

@Entity
@Table(name = "PDF_REPORT")
public class PdfReport implements Serializable {

  private static final long serialVersionUID = -5467150588817519310L;

  @Id
  private PdfReportKey id;

  @NotBlank
  @Column(name = "tag_text", length = 1000)
  private String tagText;

  public PdfReport() {
  }

  public PdfReport(PdfReportKey key, String tagText) {
    this.id = key;
    this.tagText = tagText;
  }

  public PdfReport(String countryCode, String tagName, String tagText) {
    this.id = new PdfReportKey(countryCode, tagName);
    this.tagText = tagText;
  }

  public PdfReportKey getId() {
    return this.id;
  }

  public void setId(PdfReportKey id) {
    this.id = id;
  }

  public String getTagText() {
    return this.tagText;
  }

  public void setTagText(String text) {
    this.tagText = text;
  }

  @Override
  public boolean equals(Object o) {

    return Optional.ofNullable(o)
      .filter(object -> this.getClass() == object.getClass())
      .map(PdfReport.class::cast)
      .filter(object -> this.getId().equals(object.getId()))
      .filter(object -> this.getTagText().equals(object.getTagText()))
      .map(object -> Boolean.TRUE)
      .orElse(Boolean.FALSE);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(getId().getCountryCode() + getId().getTagName() + getTagText());
  }

  @Override
  public String toString() {
    return "PdfReport{" + "id=" + getId() + ", tagText='" + getTagText() + "'}";
  }
}