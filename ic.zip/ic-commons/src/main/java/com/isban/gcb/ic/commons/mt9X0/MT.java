/**
 * Abstracción de clase tipo mensaje swift MT
 */
package com.isban.gcb.ic.commons.mt9X0;

import java.util.HashMap;
import java.util.Map;

public abstract class MT {

    private Map<String, String> metadatos = new HashMap<>();

    protected String getMetadato(String clave) {
      return metadatos.get(clave);
    }

  protected void setMetadato(String clave, String valor) {
    metadatos.put(clave, valor);
  }

}
