package com.isban.gcb.ic.commons.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Entity that represents a sequence. A sequence is composed by identifier which represents
 * functionally the meta-key(metaclave) used to identify a file in the context of the transformation
 * process.This process makes a lot of transformation of files from MT940 format to SWIFT format.
 *
 * @author Jaidermes Nebrijo Duarte
 * @author 21-11-2017
 */
@Entity
public class Sequential {
    /**
     * Identifier of the sequence.
     */
    @Id
    @Column(name = "sequenceId", updatable = false, nullable = false, unique = true, length = 256)
    private String sequenceId;

    /**
     * The value of the sequence.
     */
    @Column(columnDefinition = "NUMBER(12,0)")
    private Long sequenceValue;

    /**
     * @return
     */
    public String getSequenceId() {
        return sequenceId;
    }

    /**
     * @param sequenceId
     */
    public void setSequenceId(String sequenceId) {
        this.sequenceId = sequenceId;
    }

    /**
     * @return
     */
    public Long getSequenceValue() {
        return sequenceValue;
    }

    /**
     * @param sequenceValue
     */
    public void setSequenceValue(Long sequenceValue) {
        this.sequenceValue = sequenceValue;
    }

    /**
     *
     */
    @Override
    public String toString() {
        return "Sequential [sequenceId=" + sequenceId + ", sequenceValue=" + sequenceValue + "]";
    }

}
