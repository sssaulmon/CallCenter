package com.isban.gcb.ic.commons.model.downloadapi;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(
  name = "DOWNLOAD_API_HISTORY_REQUEST"
)
public class DownloadRequestEntity implements Serializable {

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOWNLOAD_API_HISTORY_GEN")
  @SequenceGenerator(name = "DOWNLOAD_API_HISTORY_GEN", sequenceName = "DOWNLOAD_API_HISTORY_SEQ",
    allocationSize = 1)
  private Long history_id;

  @Column(name = "REQUEST_TIME")
  private LocalDateTime requestTime;

  @Column(name = "ENTERPRISE_GROUP")
  private String enterpriseGroup;

  @Column(name = "CORPORATES")
  private String corporates;

  @Column(name = "ACCOUNTS")
  private String accounts;

  @Column(name = "COUNTRIES")
  private String countries;

  @Column(name = "BICS")
  private String bics;

  @Column(name = "CURRENCIES")
  private String currencies;

  @Column(name = "PRODUCTS")
  private String products;

  @Column(name = "FORMATS")
  private String formats;

  @Column(name = "CHANNELS")
  private String channels;

  @Column(name = "START_DATE")
  private LocalDate startDate;

  @Column(name = "END_DATE")
  private LocalDate endDate;

  @Column(name = "SPECIFIC_DATE")
  private LocalDate specificDate;

  @Column(name = "REPORTS")
  private Integer reports;

  @Column(name = "TYPE_ID")
  private Integer type;

  @Column(name = "CLIENT_ID")
  private String clientId;

  public DownloadRequestEntity() {
  }

  public Long getHistory_id() {
    return history_id;
  }

  public void setHistory_id(Long history_id) {
    this.history_id = history_id;
  }

  public LocalDateTime getRequestTime() {
    return requestTime;
  }

  public void setRequestTime(LocalDateTime requestTime) {
    this.requestTime = requestTime;
  }

  public String getEnterpriseGroup() {
    return enterpriseGroup;
  }

  public void setEnterpriseGroup(String enterpriseGroup) {
    this.enterpriseGroup = enterpriseGroup;
  }

  public String getCorporates() {
    return corporates;
  }

  public void setCorporates(String corporates) {
    this.corporates = corporates;
  }

  public String getAccounts() {
    return accounts;
  }

  public void setAccounts(String accounts) {
    this.accounts = accounts;
  }

  public String getCountries() {
    return countries;
  }

  public void setCountries(String countries) {
    this.countries = countries;
  }

  public String getBics() {
    return bics;
  }

  public void setBics(String bics) {
    this.bics = bics;
  }

  public String getCurrencies() {
    return currencies;
  }

  public void setCurrencies(String currencies) {
    this.currencies = currencies;
  }

  public String getProducts() {
    return products;
  }

  public void setProducts(String products) {
    this.products = products;
  }

  public String getFormats() {
    return formats;
  }

  public void setFormats(String formats) {
    this.formats = formats;
  }

  public String getChannels() {
    return channels;
  }

  public void setChannels(String channels) {
    this.channels = channels;
  }

  public LocalDate getStartDate() {
    return startDate;
  }

  public void setStartDate(LocalDate startDate) {
    this.startDate = startDate;
  }

  public LocalDate getEndDate() {
    return endDate;
  }

  public void setEndDate(LocalDate endDate) {
    this.endDate = endDate;
  }

  public LocalDate getSpecificDate() {
    return specificDate;
  }

  public void setSpecificDate(LocalDate specificDate) {
    this.specificDate = specificDate;
  }

  public Integer getReports() {
    return reports;
  }

  public void setReports(Integer reports) {
    this.reports = reports;
  }

  public Integer getType() {
    return type;
  }

  public void setType(Integer type) {
    this.type = type;
  }

  public String getClientId() {
    return clientId;
  }

  public void setClientId(String clientId) {
    this.clientId = clientId;
  }
}