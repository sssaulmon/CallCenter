package com.isban.gcb.ic.commons.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A ServiceSendFormat.
 */
@Entity
@Table(name = "service_send_format")
public class ServiceSendFormat extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = 1L;

    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @Id
    @SequenceGenerator(name = "sequenceGenerator", sequenceName = "service_send_format_generator",
            allocationSize = 1)
    private Long id;

    @Size(max = 100)
    @Column(name = "description", length = 100)
    private String description;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Size(max = 40)
    @Column(name = "uuid")
    private String uuid;


    @OneToMany(mappedBy = "serviceSendFormat")
    @JsonIgnore
    private Set<Service> idServiceSendFormats = new HashSet<>();

    private String outputFormat;

    public String getOutputFormat() {
        return outputFormat;
    }

    public void setOutputFormat(String outputFormat) {
        this.outputFormat = outputFormat;
    }

    private Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ServiceSendFormat description(String description) {
        this.description = description;
        return this;
    }

    private LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public ServiceSendFormat endDate(LocalDate endDate) {
        this.endDate = endDate;
        return this;
    }

    public Set<Service> getIdServiceSendFormats() {
        return idServiceSendFormats;
    }

    public void setIdServiceSendFormats(Set<Service> services) {
        this.idServiceSendFormats = services;
    }

    public ServiceSendFormat idServiceSendFormats(Set<Service> services) {
        this.idServiceSendFormats = services;
        return this;
    }

    public ServiceSendFormat addIdServiceSendFormat(Service service) {
        this.idServiceSendFormats.add(service);
        service.setServiceSendFormat(this);
        return this;
    }

    public ServiceSendFormat removeIdServiceSendFormat(Service service) {
        this.idServiceSendFormats.remove(service);
        service.setServiceSendFormat(null);
        return this;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ServiceSendFormat serviceSendFormat = (ServiceSendFormat) o;
        if (serviceSendFormat.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), serviceSendFormat.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "ServiceSendFormat{" + "id=" + getId() + ", description='" + getDescription() + "'"
                + ", createDate='" + getCreateDate() + "'" + ", endDate='" + getEndDate() + "'"
                + ", lastModifiedDate='" + getLastModifiedDate() + "'" + "}";
    }
}
