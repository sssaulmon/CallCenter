package com.isban.gcb.ic.commons.model;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.isban.gcb.ic.commons.util.DateTimeUtils;
import com.prowidesoftware.swift.model.field.Field64;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "closing_available_bal")
@Getter
@Setter
@NoArgsConstructor
public class ClosingAvailableBalance extends AuditableLocalDateTime implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private Character mark;

    @NotNull
    @Column(name = "cl_av_date")
    private LocalDate date;

    @NotNull
    @Column(columnDefinition = "NUMBER(16,3)")
    private Double amount;

    @JsonBackReference
    @OneToOne(mappedBy = "closingAvailableBalance")
    private Extract extract;

    public ClosingAvailableBalance(Field64 field64) {
        this.mark = field64.getDCMark().charAt(0);
        this.date = DateTimeUtils.parseToLocalDate(field64.getDate());
        this.amount = Double.parseDouble(field64.getAmount().replace(',', '.'));
    }

    ClosingAvailableBalance(Character mark, LocalDate date, Double amount, Extract extract) {
        this.mark = mark;
        this.date = date;
        this.amount = amount;
        this.extract = extract;
    }
    
    public static ClosingAvailableBalance newInstanceFrom(ClosingAvailableBalance original, Extract extract) {
        return new ClosingAvailableBalance(original.getMark(), original.getDate(), original.getAmount(), extract); 
    }

    @Override
    public String toString() {
        return "ClosingAvailableBalance{" + "id=" + id + ", mark=" + mark + ", date=" + date
                + ", amount=" + amount + ", createdDate=" + getCreateDate() + ", lastModifiedDate="
                + getLastModifiedDate() + '}';
    }
}
