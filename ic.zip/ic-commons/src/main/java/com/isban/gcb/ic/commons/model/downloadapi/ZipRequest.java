package com.isban.gcb.ic.commons.model.downloadapi;

import java.util.Map;
import java.util.Optional;

public class ZipRequest {

  private String zipFileName;
  private Map<String, String> fileNameToMetakey;

  public ZipRequest(String zipFileName, Map<String, String> fileNameToMetakey) {
    this.zipFileName = zipFileName;
    this.fileNameToMetakey = fileNameToMetakey;
  }

  public ZipRequest() {
  }

  public void setZipFileName(String zipFileName) {
    this.zipFileName = zipFileName;
  }

  public void setFileNameToMetakey(Map<String, String> fileNameToMetakey) {
    this.fileNameToMetakey = fileNameToMetakey;
  }

  public String getZipFileName() {
    return zipFileName;
  }

  public Map<String, String> getFileNameToMetakey() {
    return fileNameToMetakey;
  }

  public String toString() {
    return "ZipRequest(zipFileName=" + this.getZipFileName() + ", fileNameToMetakey=" + metakeysToString() + ")";
  }

  private String metakeysToString() {
    return Optional.ofNullable(this.fileNameToMetakey)
      .map(metakeys -> String.join(",", metakeys.values()))
      .orElse("null");
  }
}
