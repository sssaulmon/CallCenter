package com.isban.gcb.ic.commons.mt9X0.enhanced;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "ioMessage",
        "senderInputTime",
        "MIRDate",
        "MIRLogicalTerminal",
        "MIRSessionNumber",
        "MIRSequenceNumber",
        "receiverOutputDate",
        "receiverOutputTime",
        "messagePriority",
        "messageType"
})
public class Block2 implements Serializable {

    private static final long serialVersionUID = 6297517390605289346L;

    @JsonProperty("ioMessage")
    private String ioMessage;
    @JsonProperty("senderInputTime")
    private String senderInputTime;
    @JsonProperty("MIRDate")
    private String mIRDate;
    @JsonProperty("MIRLogicalTerminal")
    private String mIRLogicalTerminal;
    @JsonProperty("MIRSessionNumber")
    private String mIRSessionNumber;
    @JsonProperty("MIRSequenceNumber")
    private String mIRSequenceNumber;
    @JsonProperty("receiverOutputDate")
    private String receiverOutputDate;
    @JsonProperty("receiverOutputTime")
    private String receiverOutputTime;
    @JsonProperty("messagePriority")
    private String messagePriority;
    @JsonProperty("messageType")
    private String messageType;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();

    /**
     * No args constructor for use in serialization
     */
    public Block2() {
        /*Empty Constructor*/
    }

    /**
     * @param ioMessage
     * @param mIRDate
     * @param receiverOutputTime
     * @param messagePriority
     * @param mIRLogicalTerminal
     * @param senderInputTime
     * @param messageType
     * @param receiverOutputDate
     * @param mIRSequenceNumber
     * @param mIRSessionNumber
     */
    public Block2(String ioMessage, String senderInputTime, String mIRDate, String mIRLogicalTerminal, String mIRSessionNumber, String mIRSequenceNumber, String receiverOutputDate, String receiverOutputTime, String messagePriority, String messageType) {
        super();
        this.ioMessage = ioMessage;
        this.senderInputTime = senderInputTime;
        this.mIRDate = mIRDate;
        this.mIRLogicalTerminal = mIRLogicalTerminal;
        this.mIRSessionNumber = mIRSessionNumber;
        this.mIRSequenceNumber = mIRSequenceNumber;
        this.receiverOutputDate = receiverOutputDate;
        this.receiverOutputTime = receiverOutputTime;
        this.messagePriority = messagePriority;
        this.messageType = messageType;
    }


    @JsonProperty("ioMessage")
    public String getIOMessage() {
        return ioMessage;
    }

    @JsonProperty("ioMessage")
    public void setIOMessage(String ioMessage) {
        this.ioMessage = ioMessage;
    }


    @JsonProperty("senderInputTime")
    public String getSenderInputTime() {
        return senderInputTime;
    }

    @JsonProperty("senderInputTime")
    public void setSenderInputTime(String senderInputTime) {
        this.senderInputTime = senderInputTime;
    }

    @JsonProperty("MIRDate")
    public String getMIRDate() {
        return mIRDate;
    }

    @JsonProperty("MIRDate")
    public void setMIRDate(String mIRDate) {
        this.mIRDate = mIRDate;
    }

    @JsonProperty("MIRLogicalTerminal")
    public String getMIRLogicalTerminal() {
        return mIRLogicalTerminal;
    }

    @JsonProperty("MIRLogicalTerminal")
    public void setMIRLogicalTerminal(String mIRLogicalTerminal) {
        this.mIRLogicalTerminal = mIRLogicalTerminal;
    }

    @JsonProperty("MIRSessionNumber")
    public String getMIRSessionNumber() {
        return mIRSessionNumber;
    }

    @JsonProperty("MIRSessionNumber")
    public void setMIRSessionNumber(String mIRSessionNumber) {
        this.mIRSessionNumber = mIRSessionNumber;
    }

    @JsonProperty("MIRSequenceNumber")
    public String getMIRSequenceNumber() {
        return mIRSequenceNumber;
    }

    @JsonProperty("MIRSequenceNumber")
    public void setMIRSequenceNumber(String mIRSequenceNumber) {
        this.mIRSequenceNumber = mIRSequenceNumber;
    }

    @JsonProperty("receiverOutputDate")
    public String getReceiverOutputDate() {
        return receiverOutputDate;
    }

    @JsonProperty("receiverOutputDate")
    public void setReceiverOutputDate(String receiverOutputDate) {
        this.receiverOutputDate = receiverOutputDate;
    }

    @JsonProperty("receiverOutputTime")
    public String getReceiverOutputTime() {
        return receiverOutputTime;
    }

    @JsonProperty("receiverOutputTime")
    public void setReceiverOutputTime(String receiverOutputTime) {
        this.receiverOutputTime = receiverOutputTime;
    }

    @JsonProperty("messagePriority")
    public String getMessagePriority() {
        return messagePriority;
    }

    @JsonProperty("messagePriority")
    public void setMessagePriority(String messagePriority) {
        this.messagePriority = messagePriority;
    }

    @JsonProperty("messageType")
    public String getMessageType() {
        return messageType;
    }

    @JsonProperty("messageType")
    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public String toSwiftMessage() {
      return "{2:" + this.getIOMessage() + this.getMessageType() + this.getSenderInputTime()
                + this.getMIRDate() + this.getMIRLogicalTerminal()
                + this.getMIRSessionNumber() + this.getMIRSequenceNumber()
                + this.getReceiverOutputDate() + this.getReceiverOutputTime()
                + this.getMessagePriority() + "}";
    }
}
