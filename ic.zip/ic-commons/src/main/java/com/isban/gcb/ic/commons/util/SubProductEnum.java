package com.isban.gcb.ic.commons.util;

import java.util.stream.Stream;

public enum SubProductEnum {

  CONVERSOR_SUBPRODUCT_ID("", 2L),
  EXTEND_CONVERTER_SUBPRODUCT_ID("^.*\\.EXTEND\\..*$", 3L),
  SAP_CONVERTER_SUBPRODUCT_ID("^.*\\.SAP\\..*$", 6L);

  String regex;
  Long subProductId;

  SubProductEnum(String regex, Long subProductId) {
    this.regex = regex;
    this.subProductId = subProductId;
  }

  public static Long getSubProduct(String path) {
    String fileName = path.replaceAll(".*/(.*)", "$1");
    return Stream.of(SubProductEnum.values())
      .filter(subProductEnum -> fileName.matches(subProductEnum.regex))
      .map(subProductEnum -> subProductEnum.subProductId)
      .findFirst()
      .orElse(CONVERSOR_SUBPRODUCT_ID.subProductId);
  }

}
