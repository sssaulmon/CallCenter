package com.isban.gcb.ic.commons.converter.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.isban.gcb.ic.commons.mt9X0.MT9X0;
import com.isban.gcb.ic.commons.mt9X0.enhanced.MT9X0Enhanced;
import com.isban.gcb.ic.commons.mt9X0.enhanced.Message;
import com.isban.gcb.ic.commons.util.Unchecked;
import com.prowidesoftware.swift.model.mt.mt9xx.MT940;

import java.util.Optional;
import java.util.function.BiFunction;

import static com.isban.gcb.ic.commons.converter.Constants.MT940_INPUT;
import static com.isban.gcb.ic.commons.converter.Constants.MT940_OUTPUT;

public class MT940Mapper {

  private Gson gsonMapper;

  private ObjectMapper jsonMapper;

  public MT940Mapper(Gson gsonMapper, ObjectMapper objectMapper) {
    this.gsonMapper = gsonMapper;
    this.jsonMapper = objectMapper;
  }

  public MT9X0Enhanced parseMt940FromSwift(String mt940Swift) {
    return Optional.of(mt940Swift)
      .map(MT9X0::new)
      .map(this::parseMt940FromSwift)
      .orElseThrow(() -> new RuntimeException("Can't parse string to swift mt940"));
  }

  public MT9X0Enhanced parseMt940FromSwift(MT9X0 mt940) {

    MT9X0Enhanced mt940Enhanced = Optional.of(mt940)
      .map(gsonMapper::toJson)
      .map(Unchecked.function(json -> jsonMapper.readValue(json, MT9X0Enhanced.class)))
      .orElseThrow(() -> new RuntimeException("Can't parse swift mt940 to mt940 enhanced"));

    BiFunction<MT940, MT9X0Enhanced, MT9X0Enhanced> setIO = (original, enhanced) -> {
      enhanced.getM().getBlock2().setIOMessage(original.getSwiftMessage().getBlock2().isOutput() ? MT940_OUTPUT : MT940_INPUT);
      return enhanced;
    };

    return Optional.of(mt940Enhanced)
      .map(enhanced -> setIO.apply(mt940, enhanced))
      .orElseThrow(() -> new RuntimeException("Can't set I/O Message Field in MT9X0Enhanced"));
  }

  public String mt940EnhancedToSwift(MT9X0Enhanced mt940Enhanced) {

    return Optional.of(mt940Enhanced)
      .map(MT9X0Enhanced::getM)
      .map(Message::toSwiftMessage)
      .orElseThrow(() -> new RuntimeException("Can't convert mt940 enhanced to swift"));
  }

  public MT9X0Enhanced parseToMt940Enhanced(String mt940String) {

    return Optional.of(mt940String)
      .map(Unchecked.function(json -> jsonMapper.readValue(json, MT9X0Enhanced.class)))
      .orElseThrow(() -> new RuntimeException("Can't parse string to mt940 enhanced"));
  }

  public String mt940EnhancedToString(MT9X0Enhanced mt940) {

    return Optional.of(mt940)
      .map(Unchecked.function(jsonMapper::writeValueAsString))
      .orElseThrow(() -> new RuntimeException("Can't convert mt940 enhanced to string"));
  }
}