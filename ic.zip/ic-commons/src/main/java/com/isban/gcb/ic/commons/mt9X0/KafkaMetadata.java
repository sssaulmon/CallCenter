package com.isban.gcb.ic.commons.mt9X0;

import java.io.Serializable;


/**
 * @author Eduardo Rodriguez
 */
public class KafkaMetadata implements Serializable {

    private Long timestamp;
    private String topic;
    private Integer partition;
    private Long offset;

    /*
    * Empty constructor
    */
    public KafkaMetadata() {
        timestamp = null;
        topic = null;
        partition = null;
        offset = null;
    }

    /*
    * Full constructor
    */
    public KafkaMetadata(Long timestamp, String topic, Integer partition, Long offset) {
        this.timestamp = timestamp;
        this.topic = topic;
        this.partition = partition;
        this.offset = offset;
    }

    /*
    * Getters
    */
    public Long getTimestamp() {
        return timestamp;
    }

    public String getTopic() {
        return topic;
    }

    public Integer getPartition() {
        return partition;
    }

    public Long getOffset() {
        return offset;
    }

    /*
    * Setters
    */
    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public void setPartition(Integer partition) {
        this.partition = partition;
    }

    public void setOffset(Long offset) {
        this.offset = offset;
    }


}
