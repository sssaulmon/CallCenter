package com.isban.gcb.ic.commons.mapper;

import com.isban.gcb.ic.commons.model.MftDataMessage;
import com.isban.gcb.ic.commons.model.MftValidationRequest;
import com.isban.gcb.ic.commons.util.GroupRegExUtils;
import com.isban.gcb.ic.commons.xml.XmlSanMapper;
import com.isban.gcb.ic.commons.xml.model.XmlSan;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import java.util.function.ToIntFunction;
import java.util.function.UnaryOperator;

public class MftValidationRequestMapper {

  private MftValidationRequestMapper() {
    super();
  }

  public static Map<String, Object> toMessageHeaders(MftValidationRequest mftValidationRequest) {
    Map<String, Object> map = new HashMap<>();
    BiConsumer<String, Supplier<Object>> putHeader = (name, value) -> {
      if (Objects.nonNull(value.get())) {
        map.put(name, value.get());
      }
    };

    Optional.of(mftValidationRequest)
      .ifPresent(data -> {
        putHeader.accept("incomingDate", data::getIncomingDate);
        putHeader.accept("sendingSequence", data::getSendingSequence);
        putHeader.accept("countryCode", data::getCountryCode);
        putHeader.accept("bankCode", data::getBankCode);
        putHeader.accept("productCode", data::getProductCode);
        putHeader.accept("subproductCode", data::getSubproductCode);
        putHeader.accept("accountAlias", data::getAccountAlias);
        putHeader.accept("accountingDate", data::getAccountingDate);
        putHeader.accept("filename", data::getFilename);
        putHeader.accept("type", data::getType);
        putHeader.accept("currency", data::getCurrency);
        putHeader.accept("xmlSanFileName", data::getXmlSanFileName);
        putHeader.accept("xmlData", data::getXmlData);
      });

    return map;
  }

  public static MftValidationRequest fromMessageHeaders(Map<String, Object> headers) {
    UnaryOperator<String> getHeader = name -> (String) headers.get(name);
    ToIntFunction<String> getHeaderInt = name -> (Integer) headers.get(name);
    return new MftValidationRequest()
      .incomingDate(getHeader.apply("incomingDate"))
      .sendingSequence(getHeaderInt.applyAsInt("sendingSequence"))
      .countryCode(getHeader.apply("countryCode"))
      .bankCode(getHeaderInt.applyAsInt("bankCode"))
      .productCode(getHeader.apply("productCode"))
      .subproductCode(getHeader.apply("subproductCode"))
      .accountAlias(getHeader.apply("accountAlias"))
      .accountingDate(getHeader.apply("accountingDate"))
      .filename(getHeader.apply("filename"))
      .type(getHeader.apply("type"))
      .currency(getHeader.apply("currency"))
      .xmlSanFileName(getHeader.apply("xmlSanFileName"))
      .xmlData(getHeader.apply("xmlData"));
  }

  public static MftValidationRequest getMftValidationRequest(MftDataMessage message, String incomingDate) {

    XmlSan xmlSan = XmlSanMapper.getInstance().toXML(message.getXml());
    String type = "INTR".equals(xmlSan.getHeader().getNemoInstrument()) ? "XMLSAN" : xmlSan.getHeader().getNemoInstrument();

    return new MftValidationRequest()
      .accountAlias(xmlSan.getHeader().getAssociatedAccount())
      .accountingDate(xmlSan.getHeader().getSendDate())
      .bankCode(xmlSan.getHeader().getSourceBank())
      .countryCode(xmlSan.getHeader().getIsoCode())
      .currency(type.equals("DDAB") ? "-1" : getCurrencyCode(xmlSan.getPaymentBody()))
      .filename(xmlSan.getHeader().getSourceFileName())
      .incomingDate(incomingDate)
      .productCode(xmlSan.getHeader().getNemoInstrument())
      .sendingSequence(xmlSan.getHeader().getSequenceDate())
      .subproductCode(xmlSan.getHeader().getFlowInstrument().replaceFirst("^0*", ""))
      .type(type)
      .xmlSanFileName(message.getFileName())
      .xmlData(message.getXml());
  }

  private static String getCurrencyCode(String paymentBody) {
    String regex = "(.{16})(?<currencyCode>.{3}).*";
    Map<String, String> groups = GroupRegExUtils.getGroups(regex, paymentBody);
    return groups.get("currencyCode");
  }
}
