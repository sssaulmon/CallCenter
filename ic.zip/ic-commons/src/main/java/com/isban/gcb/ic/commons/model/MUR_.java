package com.isban.gcb.ic.commons.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(MUR.class)
public abstract class MUR_ {

	public static volatile SingularAttribute<MUR, String> murId;
	public static volatile SingularAttribute<MUR, Long> murValue;

	public static final String MUR_ID = "murId";
	public static final String MUR_VALUE = "murValue";

}

