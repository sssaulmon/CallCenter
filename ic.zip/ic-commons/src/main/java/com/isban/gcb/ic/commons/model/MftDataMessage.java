package com.isban.gcb.ic.commons.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import javax.validation.constraints.NotEmpty;
import java.util.Objects;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@JsonInclude(NON_NULL)
public class MftDataMessage {

  @NotEmpty private String fileName;
  @NotEmpty private String xml;
  private byte[] data;
  private String fileExtension;

  public MftDataMessage() {
    super();
  }

  public String getFileName() {
    return fileName;
  }

  public String getXml() {
    return xml;
  }

  public byte[] getData() {
    return data;
  }

  public String getFileExtension() {
    return fileExtension;
  }

  public MftDataMessage fileName(String fileName) {
    this.fileName = fileName;
    return this;
  }

  public MftDataMessage xml(String xml) {
    this.xml = xml;
    return this;
  }

  public MftDataMessage data(byte[] data) {
    this.data = data;
    return this;
  }

  public MftDataMessage fileExtension(String fileExtension) {
    this.fileExtension = fileExtension;
    return this;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    MftDataMessage that = (MftDataMessage) o;
    return Objects.equals(fileName, that.fileName) &&
      Objects.equals(xml, that.xml) &&
      Objects.equals(data, that.data) &&
      Objects.equals(fileExtension, that.fileExtension);
  }

  @Override
  public int hashCode() {
    return Objects.hash(fileName, xml, data, fileExtension);
  }

  @Override
  public String toString() {
    return "MftDataMessage{" +
      "fileName='" + fileName + '\'' +
      ", xml='" + xml + '\'' +
      ", data=" + data +
      ", fileExtension='" + fileExtension + '\'' +
      '}';
  }
}
