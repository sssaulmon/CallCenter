package com.isban.gcb.ic.commons.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Tabla products
 */
@Entity
@Table(name = "product", indexes = {@Index(columnList = "uuid", name = "uuid_product")})
public class Product extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = -3160593319316641867L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "product_gen")
    @SequenceGenerator(name = "product_gen", sequenceName = "product_generator", allocationSize = 1)
    private Long id;

    @Size(max = 10)
    @Column(name = "code", length = 10)
    private String code;

    @Size(max = 100)
    @Column(name = "description", length = 100)
    private String description;

    @Size(max = 40)
    @Column(name = "uuid", length = 40)
    private String uuid;

    @Size(max = 40)
    @Column(name = "bic", length = 40)
    private String bic;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Size(max = 20)
    @Column(name = "last_modified_user", length = 20)
    private String lastModifiedUser;

    @OneToMany(mappedBy = "product", fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<Subproduct> subproducts = new HashSet<>();


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Product code(String code) {
        this.code = code;
        return this;
    }

    private String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Product description(String description) {
        this.description = description;
        return this;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public Product uuid(String uuid) {
        this.uuid = uuid;
        return this;
    }

    public String getBic() {
        return bic;
    }

    public void setBic(String bic) {
        this.bic = bic;
    }

    public Product bic(String bic) {
        this.bic = bic;
        return this;
    }

    private LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public Product endDate(LocalDate endDate) {
        this.endDate = endDate;
        return this;
    }

    private String getLastModifiedUser() {
        return lastModifiedUser;
    }

    public void setLastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
    }

    public Product lastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
        return this;
    }

    public Set<Subproduct> getSubproducts() {
        return subproducts;
    }

    public void setSubproducts(Set<Subproduct> subproducts) {
        this.subproducts = subproducts;
    }

    public Product sucbproduct(Set<Subproduct> subproduct) {
        this.subproducts = subproduct;
        return this;
    }

    public Product addSubproduct(Subproduct subproduct) {
        this.subproducts.add(subproduct);
        subproduct.setProduct(this);
        return this;
    }

    public Product removeSubproduct(Subproduct subproduct) {
        this.subproducts.remove(subproduct);
        subproduct.setProduct(null);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Product product = (Product) o;
        if (product.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), product.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Product{" + "id=" + getId() + ", code='" + getCode() + "'" + ", description='"
                + getDescription() + "'" + ", uuid='" + getUuid() + "'" + ", bic='" + getBic() + "'"
                + ", createDate='" + getCreateDate() + "'" + ", lastModifiedDate='"
                + getLastModifiedDate() + "'" + ", endDate='" + getEndDate() + "'"
                + ", lastModifiedUser='" + getLastModifiedUser() + "'" + "}";
    }
}
