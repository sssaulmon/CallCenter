package com.isban.gcb.ic.commons.util;

import java.time.LocalDate;
import java.util.Optional;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.stream.Stream;

public enum ExtractMovementDatesEnum {
  VALUE_DATE_BEFORE((entryDate, valueDate) -> Optional.ofNullable(entryDate)
    .filter(date -> entryDate.getMonth().getValue() == 1)
    .filter(date -> valueDate.getMonth().getValue() == 12)
    .isPresent(), entryDate -> entryDate.plusYears(1)),
  VALUE_DATE_AFTER((entryDate, valueDate) -> Optional.ofNullable(entryDate)
    .filter(date -> entryDate.getMonth().getValue() == 12)
    .filter(date -> valueDate.getMonth().getValue() == 1)
    .isPresent(), entryDate -> entryDate.minusYears(1)),
  VALUE_DATE_COMMON_CASE((entryDate, valueDate) -> true, entryDate -> entryDate);

  private BiPredicate<LocalDate, LocalDate> condition;
  private Function<LocalDate, LocalDate> finalEntryDate;

  ExtractMovementDatesEnum(BiPredicate<LocalDate, LocalDate> condition, Function<LocalDate, LocalDate> finalEntryDate) {
    this.condition = condition;
    this.finalEntryDate = finalEntryDate;
  }

  public static LocalDate getCorrectEntryDate(LocalDate entryDate, LocalDate valueDate) {
    return Stream.of(ExtractMovementDatesEnum.values())
      .filter(givenCase -> givenCase.condition.test(entryDate, valueDate))
      .findFirst()
      .map(givenCase -> givenCase.finalEntryDate.apply(entryDate))
      .orElse(null);
  }
}
