package com.isban.gcb.ic.commons.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * A ReceiveChannel.
 */
@Entity
@Table(name = "receive_channel",
        indexes = {@Index(columnList = "uuid", name = "uuid_receive_channel")})
public class ReceiveChannel extends AuditableLocalDate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "receive_channel_gen")
    @SequenceGenerator(name = "receive_channel_gen", sequenceName = "receive_channel_generator",
            allocationSize = 1)
    private Long id;

    @Size(max = 40)
    @Column(name = "uuid")
    private String uuid;

    @Size(max = 100)
    @Column(name = "description", length = 100)
    private String description;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Size(max = 20)
    @Column(name = "last_modified_user", length = 20)
    private String lastModifiedUser;

    @OneToMany(mappedBy = "receiveChannel")
    @JsonIgnore
    private Set<Subproduct> idReciveChannels = new HashSet<>();

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    private Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    private String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ReceiveChannel description(String description) {
        this.description = description;
        return this;
    }

    private LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public ReceiveChannel endDate(LocalDate endDate) {
        this.endDate = endDate;
        return this;
    }

    private String getLastModifiedUser() {
        return lastModifiedUser;
    }

    public void setLastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
    }

    public ReceiveChannel lastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
        return this;
    }

    public Set<Subproduct> getIdReciveChannels() {
        return idReciveChannels;
    }

    public void setIdReciveChannels(Set<Subproduct> idReciveChannels) {
        this.idReciveChannels = idReciveChannels;
    }

    public ReceiveChannel idReciveChannels(Set<Subproduct> subproducts) {
        this.idReciveChannels = subproducts;
        return this;
    }

    public ReceiveChannel addIdReciveChannel(Subproduct subproduct) {
        this.idReciveChannels.add(subproduct);
        subproduct.setReceiveChannel(this);
        return this;
    }

    public ReceiveChannel removeIdReciveChannel(Subproduct subproduct) {
        this.idReciveChannels.remove(subproduct);
        subproduct.setReceiveChannel(null);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ReceiveChannel receiveChannel = (ReceiveChannel) o;
        if (receiveChannel.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), receiveChannel.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "ReceiveChannel{" + "id=" + getId() + ", description='" + getDescription() + "'"
                + ", createDate='" + getCreateDate() + "'" + ", endDate='" + getEndDate() + "'"
                + ", lastModifiedDate='" + getLastModifiedDate() + "'" + ", lastModifiedUser='"
                + getLastModifiedUser() + "'" + "}";
    }
}
