package com.isban.gcb.ic.commons.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;

@Embeddable
public class PdfReportKey implements Serializable {

  private static final long serialVersionUID = -5359421797764543139L;

  @Pattern(regexp = "[A-Z]")
  @Column(name = "country_code", length = 10)
  private String countryCode;

  @Column(name = "tag_name")
  private String tagName;

  public PdfReportKey() {
  }

  public PdfReportKey(String countryCode, String tagName) {
    this.countryCode = countryCode;
    this.tagName = tagName;
  }

  public String getCountryCode() {
    return this.countryCode;
  }

  public void setCountryCode(String code) {
    this.countryCode = code;
  }

  public String getTagName() {
    return this.tagName;
  }

  public void setTagName(String name) {
    this.tagName = name;
  }

  @Override
  public boolean equals(Object o) {

    return Optional.ofNullable(o)
      .filter(object -> this.getClass() == object.getClass())
      .map(PdfReportKey.class::cast)
      .filter(object -> this.getCountryCode().equals(object.getCountryCode()))
      .filter(object -> this.getTagName().equals(object.getTagName()))
      .map(object -> Boolean.TRUE)
      .orElse(Boolean.FALSE);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(this.getCountryCode() + this.getTagName());
  }

  @Override
  public String toString() {
    return "PdfReportKey {countryCode=" + this.getCountryCode() + ", tagName=" + this.getTagName();
  }
}