package com.santander.scib.gtb.ic.gcm.service.balance.chain.chains;

import com.isban.gcb.ic.commons.model.BalanceCache;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.mapper.TransactionMapper;
import com.santander.scib.gtb.ic.gcm.repository.BalanceCacheRepository;
import com.santander.scib.gtb.ic.gcm.repository.ExtractMovementRepository;
import com.santander.scib.gtb.ic.gcm.service.AccountsService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OnlineChainTest {

  @Mock private BalanceCacheRepository balanceCacheRepository;
  @Mock private ExtractMovementRepository movementRepository;
  @Mock private TransactionMapper mapper;
  @Mock private AccountsService accountsService;

  private OnlineChain onlineChain;
  private TransactionDTO transactionDTO;
  private BalanceCache balanceCache;

  @Before
  public void setUp() {
    onlineChain = new OnlineChain();
    transactionDTO = TransactionDTO.builder().build();
    balanceCache = new BalanceCache();
    ReflectionTestUtils.setField(onlineChain, "balanceCacheRepository", balanceCacheRepository);
  }

  @Test
  public void testIntrWillReturnFalseTest() {
    balanceCache.setBalanceType("INTR");

    when(balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrency(any(), any(), any(), any()))
      .thenReturn(Optional.of(balanceCache));

    assertFalse(onlineChain.test(transactionDTO));
  }

  @Test
  public void testFindWillReturnFalseTest() {
    balanceCache.setBalanceType("FIND");

    when(balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrency(any(), any(), any(), any()))
      .thenReturn(Optional.of(balanceCache));

    assertFalse(onlineChain.test(transactionDTO));
  }

  @Test
  public void testOnlineWillReturnTrueTest() {
    balanceCache.setBalanceType("ONLI");

    when(balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrency(any(), any(), any(), any()))
      .thenReturn(Optional.of(balanceCache));

    assertTrue(onlineChain.test(transactionDTO));
  }

  @Test
  public void testOnlineWithAccountingDateWillReturnTrueTest() {
    balanceCache.setBalanceType("ONLI");
    transactionDTO.setAccountingDate(LocalDate.now());

    when(balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrencyAndAccountingDateLessThanEqual(any(), any(), any(), any(), any()))
      .thenReturn(Optional.of(balanceCache));

    assertTrue(onlineChain.test(transactionDTO));
  }
}
