package com.santander.scib.gtb.ic.gcm.strategies;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.gtb.ic.gcm.api.balance.model.account.ErrorItem;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.BalanceRequest;
import com.santander.scib.gtb.ic.gcm.communication.binding.ApiOutputBinding;
import com.santander.scib.gtb.ic.gcm.model.NotificationError;
import com.santander.scib.gtb.ic.gcm.service.balance.AccountBalanceService;
import com.santander.scib.gtb.ic.gcm.test.utils.TestUtils;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.jetbrains.annotations.NotNull;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.stream.test.binder.MessageCollector;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.messaging.Message;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles("integration")
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_CLASS)
public class OnlineStrategiesIntegrationDBErrorTest {

  private final HttpHeaders httpHeaders = new HttpHeaders();
  private MockMvc mockMvc;
  private static MockWebServer mockBackEnd;

  @Autowired private WebApplicationContext webApplicationContext;
  @Autowired private ObjectMapper mapper;
  @Autowired private MessageCollector messageCollector;
  @Autowired private ApiOutputBinding apiOutputBinding;
  @MockBean private AccountBalanceService accountBalanceService;

  @After
  public void tearDown() throws IOException {
    mockBackEnd.shutdown();
    messageCollector.forChannel(apiOutputBinding.apiRequestFailed()).clear();
  }

  @Before
  public void setUpMvc() throws IOException {
    mockBackEnd = new MockWebServer();
    mockBackEnd.start(6429);

    mockMvc = MockMvcBuilders
      .webAppContextSetup(webApplicationContext)
      .build();
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    httpHeaders.add("X-Santander-Global-Id", "123456");
    httpHeaders.add("Authorization", TestUtils.loadResource("security/bearer.txt"));
  }

  @Test
  public void incorrect500Response_ShouldSendErrorMessage() throws Exception {
    BalanceRequest body = TestUtils.loadObject("strategies/requests/V3request.json", BalanceRequest.class);
    ErrorItem apiResponseExpected = TestUtils.loadObject("strategies/responses/dataBaseError.json", ErrorItem.class);
    NotificationError topicExpected = TestUtils.loadObject("strategies/kafka/correctDBConnection.json", NotificationError.class);

    mockBackEnd.enqueue(createMockResponse("{\"access_token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(new MockResponse().setResponseCode(500));

    given(accountBalanceService.findAccountBalance(any(AccountDTO.class), eq(null))).willThrow(RuntimeException.class);

    MvcResult mvcResult = mockMvc.perform(post("/balances")
      .headers(httpHeaders)
      .content(mapper.writeValueAsBytes(body))
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(request().asyncStarted())
      .andExpect(status().isOk())
      .andReturn();

    mockMvc.perform(asyncDispatch(mvcResult))
      .andExpect(status().is5xxServerError())
      .andExpect(content().json(mapper.writeValueAsString(apiResponseExpected), true));

    Message<String> payload = (Message<String>) messageCollector.forChannel(apiOutputBinding.apiRequestFailed()).poll(6, SECONDS);
    Assert.assertNotNull(payload);
    NotificationError resultKafka = TestUtils.loadContent(payload.getPayload(), NotificationError.class);
    Assert.assertEquals(topicExpected.getMessage(), resultKafka.getMessage());
    Assert.assertEquals(topicExpected.getType(), resultKafka.getType());
    Assert.assertEquals(topicExpected.getExceptionType(), resultKafka.getExceptionType());
  }

  @NotNull
  private MockResponse createMockResponse(String body) {
    return new MockResponse()
      .setBody(body)
      .addHeader("Content-Type", MediaType.APPLICATION_JSON);
  }

  @NotNull
  private MockResponse createMockResponseWithClass(String file, Class<?> clazz) throws JsonProcessingException {
    return createMockResponseWithClass(file, 200, clazz);
  }

  @NotNull
  private MockResponse createMockResponseWithClass(String file, int responseCode, Class<?> clazz) throws JsonProcessingException {
    return new MockResponse()
      .setResponseCode(responseCode)
      .setBody(mapper.writeValueAsString(TestUtils.loadObject(file, clazz)))
      .addHeader("Content-Type", MediaType.APPLICATION_JSON);
  }
}
