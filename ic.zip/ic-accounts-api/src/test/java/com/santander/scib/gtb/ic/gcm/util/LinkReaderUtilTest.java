package com.santander.scib.gtb.ic.gcm.util;

import org.junit.Test;

import static com.santander.scib.gtb.ic.gcm.util.LinkReaderUtil.getOffset;
import static org.assertj.core.api.Assertions.assertThat;

public class LinkReaderUtilTest {

  @Test
  public void givenAStringLink_whenGetOffset_thenReturnOffsetFromStringLink() {
    assertThat(getOffset(null)).isNull();
    assertThat(getOffset("/accounts/BSCHLUL0USD22006129796/transactions?_limit=1")).isNull();
    assertThat(getOffset("/accounts/BSCHLUL0USD22006129796/transactions?_offset=0&_limit=1")).isEqualTo("0");
    assertThat(getOffset("/accounts/BSCHBRSPBRL4641000130003727/transactions?_offset=4;page_id%3D000010999300287*000010999300287*0000000000000413482019-02-042021-02-01&_limit=1"))
      .isEqualTo("4;page_id%3D000010999300287*000010999300287*0000000000000413482019-02-042021-02-01");
    assertThat(getOffset("/accounts/BSCHBRSPBRL4641000130003727/transactions?_offset=4;page_id%3D000010999300287*000010999300287*0000000000000413482019-02-042021-02-01&_limit=1&_limit2=2"))
      .isEqualTo("4;page_id%3D000010999300287*000010999300287*0000000000000413482019-02-042021-02-01");
    assertThat(getOffset("/accounts/BSCHBRSPBRL4641000130003727/transactions?_offset=4;page_id%3D000010999300287*000010999300287*0000000000000413482019-02-042021-02-01"))
      .isEqualTo("4;page_id%3D000010999300287*000010999300287*0000000000000413482019-02-042021-02-01");
    assertThat(getOffset("/accounts/BSCHLUL0USD22006129796/transactions?_limit=1&_offset=1")).isEqualTo("1");
    assertThat(getOffset("/accounts/BSCHLUL0USD22006129796/transactions?_limit=1&from_accounting_date=2020" +
      "1014T000000000%2B0200&_offset=20&account_id_type=IBA&_sort=-date&to_accounting_date=20201014T235959999%2B0200"))
      .isEqualTo("20");
    assertThat(getOffset("/accounts/004900013000040530/transactions?_limit=1&_offset=2020112311055135165600001004900013000040530002532HEREG00490001f"))
      .isEqualTo("2020112311055135165600001004900013000040530002532HEREG00490001f");
  }
}