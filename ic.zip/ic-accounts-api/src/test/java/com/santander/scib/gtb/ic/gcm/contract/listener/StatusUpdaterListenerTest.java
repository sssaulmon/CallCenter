package com.santander.scib.gtb.ic.gcm.contract.listener;

import com.santander.scib.gtb.ic.gcm.contract.binding.GenerateFileInputBinding;
import com.santander.scib.gtb.ic.gcm.repository.GlobalReportRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@EmbeddedKafka
@RunWith(SpringRunner.class)
@ActiveProfiles("integration")
public class StatusUpdaterListenerTest {
  @Autowired private GenerateFileInputBinding generateFileInputBinding;
  @Autowired private GlobalReportRepository repository;


  @Test
  public void updateFilesTest() throws InterruptedException {
    String payload = LocalDateTime.now().toString();

    assertThat(repository.findById(1L).get().getStatus()).isEqualTo("Generado OK");

    Optional.of(payload)
      .map(MessageBuilder::withPayload)
      .map(MessageBuilder::build)
      .ifPresent(generateFileInputBinding.updateFileStatus()::send);

    TimeUnit.SECONDS.sleep(1);

    assertThat(repository.findById(1L).get().getStatus()).isEqualTo("Enviado OK");
  }
}
