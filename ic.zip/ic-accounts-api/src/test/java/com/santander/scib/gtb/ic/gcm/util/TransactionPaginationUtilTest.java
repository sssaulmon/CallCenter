package com.santander.scib.gtb.ic.gcm.util;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import org.junit.Before;
import org.junit.Test;
import org.springframework.data.domain.Pageable;

import static org.assertj.core.api.Assertions.assertThat;

public class TransactionPaginationUtilTest {

  private static final int DEFAULT_LIMIT = 2;
  private static final int MAX_LIMIT = 5;
  private static final int EXPORT_LIMIT = 100;
  private static final int DAYS_LIMIT = 3;
  private TransactionPaginationUtil paginationUtil;

  @Before
  public void setup() {
    paginationUtil = new TransactionPaginationUtil(DEFAULT_LIMIT, MAX_LIMIT, EXPORT_LIMIT, DAYS_LIMIT);
  }

  @Test
  public void givenNullLimitWhenBuildPageRequestThenLimitIsTheDefaultOne() {
    TransactionDTO transactionDTO = buildTransactionDto(null, null, false);
    Pageable pageable = paginationUtil.buildPageRequest(transactionDTO);
    assertThat(pageable.getPageSize()).isEqualTo(DEFAULT_LIMIT);
    assertThat(pageable.getPageNumber()).isEqualTo(0);
  }

  @Test
  public void givenALimitLessThanMaxWhenBuildPageRequestThenLimitIsTheGivingOne() {
    TransactionDTO transactionDTO = buildTransactionDto(MAX_LIMIT - 1, null, false);
    Pageable pageable = paginationUtil.buildPageRequest(transactionDTO);
    assertThat(pageable.getPageSize()).isEqualTo(MAX_LIMIT - 1);
    assertThat(pageable.getPageNumber()).isEqualTo(0);
  }

  @Test
  public void givenALimitGreaterThanMaxWhenBuildPageRequestThenLimitIsTheDefaultOne() {
    TransactionDTO transactionDTO = buildTransactionDto(MAX_LIMIT + 1, null, false);
    Pageable pageable = paginationUtil.buildPageRequest(transactionDTO);
    assertThat(pageable.getPageSize()).isEqualTo(DEFAULT_LIMIT);
    assertThat(pageable.getPageNumber()).isEqualTo(0);
  }

  @Test
  public void givenABcOffsetWhenBuildPageRequestThenPageNumberShouldNotBeTheFirstOne() {
    TransactionDTO transactionDTO = buildTransactionDto(MAX_LIMIT - 1, MAX_LIMIT - 1, false);
    Pageable pageable = paginationUtil.buildPageRequest(transactionDTO);
    assertThat(pageable.getPageSize()).isEqualTo(MAX_LIMIT - 1);
    assertThat(pageable.getPageNumber()).isEqualTo(1);
  }

  @Test
  public void givenNullLimitWhenGetLimitThenReturnDefaultLimit() {
    TransactionDTO transactionDTO = buildTransactionDto(null, null, false);
    assertThat(paginationUtil.getLimit(transactionDTO)).isEqualTo(DEFAULT_LIMIT);
  }

  @Test
  public void givenLimitGreaterThanMaxWhenGetLimitThenReturnDefaultLimit() {
    TransactionDTO transactionDTO = buildTransactionDto(MAX_LIMIT + 1, null, false);
    assertThat(paginationUtil.getLimit(transactionDTO)).isEqualTo(DEFAULT_LIMIT);
  }

  @Test
  public void givenLimitLessThanMaxWhenGetLimitThenReturnProvidedLimit() {
    TransactionDTO transactionDTO = buildTransactionDto(MAX_LIMIT - 1, null, false);
    assertThat(paginationUtil.getLimit(transactionDTO)).isEqualTo(MAX_LIMIT - 1);
  }

  @Test
  public void givenACallToGetLimitInDaysWhenYmlIsLoadedThenReturnLimitInDays() {
    assertThat(paginationUtil.getLimitInDays()).isEqualTo(DAYS_LIMIT);
  }

  @Test
  public void givenAnExportProcessWhenBuildPageRequestThenLimitIsTheExportParameter() {
    TransactionDTO transactionDTO = buildTransactionDto(null, null, true);
    Pageable pageable = paginationUtil.buildPageRequest(transactionDTO);
    assertThat(pageable.getPageSize()).isEqualTo(EXPORT_LIMIT);
    assertThat(pageable.getPageNumber()).isEqualTo(0);
  }

  private TransactionDTO buildTransactionDto(Integer limit, Integer bcOffset, boolean forReport) {
    return TransactionDTO.builder()
      .limit(limit)
      .bcOffset(bcOffset)
      .forReport(forReport)
      .build();
  }
}