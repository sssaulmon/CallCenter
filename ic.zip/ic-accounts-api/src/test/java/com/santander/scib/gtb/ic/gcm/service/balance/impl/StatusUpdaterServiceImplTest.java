package com.santander.scib.gtb.ic.gcm.service.balance.impl;

import com.santander.scib.gtb.ic.gcm.repository.GlobalReportRepository;
import com.santander.scib.gtb.ic.gcm.service.balance.StatusUpdaterService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import javax.transaction.Transactional;
import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles("integration")
public class StatusUpdaterServiceImplTest {

  @Autowired private StatusUpdaterService service;
  @Autowired private GlobalReportRepository repository;

  @Test
  @Transactional
  public void givenProcessDateWithData_whenUpdating_ThenUpdateRecord() {
    assertThat(repository.findById(1L).get().getStatus()).isEqualTo("Generado OK");
    service.process(LocalDateTime.of(2020, 2, 22, 0, 10, 50));
    assertThat(repository.findById(1L).get().getStatus()).isEqualTo("Enviado OK");
  }

  @Test
  @Transactional
  public void givenProcessDateWithNoData_whenUpdating_ThenNoUpdateRecord() {
    assertThat(repository.findById(2L).get().getStatus()).isEqualTo("Generado OK");
    service.process(LocalDateTime.of(2020, 2, 20, 1, 10, 50));
    assertThat(repository.findById(2L).get().getStatus()).isEqualTo("Generado OK");
  }
}