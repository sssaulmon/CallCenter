package com.santander.scib.gtb.ic.gcm.util;

import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static java.time.LocalTime.MAX;
import static java.time.LocalTime.MIN;
import static org.assertj.core.api.Assertions.assertThat;

public class AccountingDateUtilTest {

  @Test
  public void givenNullWhenAtEndOfDayThenCheckLocalTimeAtEndOfday() {
    LocalDateTime atEndOfDay = AccountingDateUtil.atEndOfDay(null);
    assertThat(atEndOfDay.toLocalTime()).isEqualTo(MAX);
  }

  @Test
  public void givenLocalDateWhenAtEndOfDayThenCheckLocalTimeAtEndOfday() {
    LocalDate localDate = LocalDate.of(2020, 3, 2);
    LocalDateTime atEndOfDay = AccountingDateUtil.atEndOfDay(localDate);
    assertThat(atEndOfDay.toLocalDate()).isEqualTo(localDate);
    assertThat(atEndOfDay.toLocalTime()).isEqualTo(MAX);
  }

  @Test
  public void givenNullWhenAtStartOfDayThenCheckLocalTimeAtStartOfday() {
    LocalDateTime atStartOfDay = AccountingDateUtil.atStartOfDay(null);
    assertThat(atStartOfDay.toLocalTime()).isEqualTo(MIN);
  }

  @Test
  public void givenLocalDateWhenAtStartOfDayThenCheckLocalTimeAtStartOfday() {
    LocalDate localDate = LocalDate.of(2020, 3, 2);
    LocalDateTime atStartOfDay = AccountingDateUtil.atStartOfDay(localDate);
    assertThat(atStartOfDay.toLocalDate()).isEqualTo(localDate);
    assertThat(atStartOfDay.toLocalTime()).isEqualTo(MIN);
  }

  @Test(expected = RuntimeException.class)
  public void givenNullWhenAtStartOfDayRangeThenExpectARuntimeException() {
    AccountingDateUtil.atStartOfDayRange(null, 0);
  }

  @Test
  public void givenLocalDateWhenAtStartOfDayRangeThenExpectARuntimeException() {
    LocalDate localDate = LocalDate.of(2020, 3, 15);
    LocalDateTime atStartOfDayRange = AccountingDateUtil.atStartOfDayRange(localDate, 15);
    assertThat(atStartOfDayRange.toLocalDate()).isEqualTo(localDate.minusDays(15));
    assertThat(atStartOfDayRange.toLocalTime()).isEqualTo(MIN);
  }
}