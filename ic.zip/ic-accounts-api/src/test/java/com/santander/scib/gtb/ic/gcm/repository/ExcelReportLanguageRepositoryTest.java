package com.santander.scib.gtb.ic.gcm.repository;

import com.santander.scib.gtb.ic.gcm.model.ExcelReportLanguage;
import com.santander.scib.gtb.ic.gcm.model.ExcelReportLanguageId;
import com.santander.scib.gtb.ic.gcm.test.utils.TestUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles("integration")
public class ExcelReportLanguageRepositoryTest {

  @Autowired ExcelReportLanguageRepository repository;

  @Test
  public void validLoadExcelReportLanguage() {
    ExcelReportLanguageId id = new ExcelReportLanguageId();
    id.setLanguage("en");
    id.setType("balance");
    id.setOrder(1);

    ExcelReportLanguageId secondId = new ExcelReportLanguageId();
    secondId.setLanguage("en");
    secondId.setType("movements");
    secondId.setOrder(1);

    ExcelReportLanguage expected = TestUtils.loadObject("repository/expectedExportReportLanguage.json", ExcelReportLanguage.class);

    Optional<ExcelReportLanguage> result = repository.findById(id);
    assertTrue(result.isPresent());
    ExcelReportLanguage actual = result.get();
    assertEquals(expected, actual);
    assertEquals(expected.isRepeatable(), actual.isRepeatable());
    assertEquals(expected.getValue(), actual.getValue());
    assertEquals(expected.getLanguage(), id.getLanguage());
    assertEquals(expected.getType(), id.getType());
    assertEquals(expected.getOrder(), id.getOrder());
    assertEquals(id.hashCode(), result.hashCode());
    assertNotEquals(id, secondId);
  }
}
