package com.santander.scib.gtb.ic.gcm.strategies;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions.SLBTransactionResponse;
import com.santander.scib.gtb.ic.gcm.communication.binding.ApiOutputBinding;
import com.santander.scib.gtb.ic.gcm.test.utils.TestUtils;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.jetbrains.annotations.NotNull;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.stream.test.binder.MessageCollector;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@EmbeddedKafka
@RunWith(SpringRunner.class)
@ActiveProfiles("integration")
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_CLASS)
public class OnlineAndCacheStrategiesIntegrationTest {

  private HttpHeaders httpHeaders = new HttpHeaders();
  private MockMvc mockMvc;
  private static MockWebServer mockBackEnd;

  @Autowired private WebApplicationContext webApplicationContext;
  @Autowired private ObjectMapper mapper;
  @Autowired private MessageCollector messageCollector;
  @Autowired private ApiOutputBinding apiOutputBinding;

  @AfterClass
  public static void tearDown() throws IOException {
    mockBackEnd.shutdown();
  }

  @BeforeClass
  public static void setUpBackEnd() throws IOException {
    mockBackEnd = new MockWebServer();
    mockBackEnd.start(6429);
  }

  @Before
  public void setUpMvc() {
    mockMvc = MockMvcBuilders
      .webAppContextSetup(webApplicationContext)
      .build();
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    httpHeaders.add("X-Santander-Global-Id", "123456");
    httpHeaders.add("Authorization", TestUtils.loadResource("security/bearer.txt"));
  }

  @Test
  public void givenTransactionsRequest_whenThereAreOnlineAndCacheRecords_thenShowOnlineAndCacheRecords() throws Exception {
    LocalDate currentLocalDate = LocalDate.now();
    AccountTransactionResponse expected = getExpectedAccountTransactionResponse("strategies/responses/OnlineAndCacheNoLimit.json", currentLocalDate);
    performMockMvcCall(expected, "/balances/BSCHGB20XXX1234567890123GBP/transactions?from_accounting_date=2020-03-24&to_accounting_date=2020-03-26", currentLocalDate);
  }

  @Test
  public void givenTransactionsRequest_whenThereAreOnlineAndCacheRecordsWithLimit4FirstPage_thenShowOnlineAndCacheRecords() throws Exception {
    LocalDate currentLocalDate = LocalDate.now();
    AccountTransactionResponse expected = getExpectedAccountTransactionResponse("strategies/responses/OnlineAndCacheLimitFirstPage.json", currentLocalDate);
    performMockMvcCall(expected, "/balances/BSCHGB20XXX1234567890123GBP/transactions?limit=4&from_accounting_date=2020-03-24&to_accounting_date=2020-03-26", currentLocalDate);
  }

  @Test
  public void givenTransactionsRequest_whenThereAreOnlineAndCacheRecordsWithLimit4LastPage_thenShowOnlineAndCacheRecords() throws Exception {
    LocalDate currentLocalDate = LocalDate.now();
    AccountTransactionResponse expected = getExpectedAccountTransactionResponse("strategies/responses/OnlineAndCacheLimitLastPage.json", currentLocalDate);
    performMockMvcCall(expected, "/balances/BSCHGB20XXX1234567890123GBP/transactions?limit=4&bc_offset=3&offset=1&from_accounting_date=2020-03-24&to_accounting_date=2020-03-26", currentLocalDate);
  }

  @Test
  public void givenTransactionsRequest_whenThereAreOnlineAndCacheRecordsWithLimit3SecondPage_thenShowOnlineAndCacheRecords() throws Exception {
    LocalDate currentLocalDate = LocalDate.now();
    AccountTransactionResponse expected = getExpectedAccountTransactionResponse("strategies/responses/OnlineAndCacheLimit3SecondPage.json", currentLocalDate);
    performMockMvcCall(expected, "/balances/BSCHGB20XXX1234567890123GBP/transactions?limit=3&bc_offset=2&offset=1&from_accounting_date=2020-03-24&to_accounting_date=2020-03-26", currentLocalDate);
  }

  @Test
  public void givenTransactionsRequest_whenThereAreOnlineAndCacheRecordsWithLimit3ThirdPage_thenShowOnlineAndCacheRecords() throws Exception {
    LocalDate currentLocalDate = LocalDate.now();
    AccountTransactionResponse expected = getExpectedAccountTransactionResponse("strategies/responses/OnlineAndCacheLimit3ThirdPage.json", currentLocalDate);
    performMockMvcCall(expected, "/balances/BSCHGB20XXX1234567890123GBP/transactions?limit=3&bc_offset=5&offset=1", currentLocalDate);
  }

  private AccountTransactionResponse getExpectedAccountTransactionResponse(String filePath, LocalDate currentLocalDate) {
    String currentDateInFormat = currentLocalDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    String intrDateInFormat = currentLocalDate.minusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    String eodDateInFormat = currentLocalDate.minusDays(2).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    String expectedJsonResponse = Optional.of(filePath)
      .map(TestUtils::loadResource)
      .map(given -> given.replace("$1", currentDateInFormat))
      .map(given -> given.replace("$2", eodDateInFormat))
      .map(given -> given.replace("$3", intrDateInFormat))
      .orElseThrow(IllegalArgumentException::new);
    return TestUtils.loadContent(expectedJsonResponse, AccountTransactionResponse.class);
  }

  @NotNull
  private MockResponse createMockResponse(String body1) {
    return new MockResponse()
      .setBody(body1)
      .addHeader("Content-Type", MediaType.APPLICATION_JSON);
  }

  private String buildJsonContent(LocalDate currentLocalDate) throws JsonProcessingException {
    String apiJsonResponse = mapper.writeValueAsString(TestUtils.loadObject("strategies/responses/apis/V3TransactionsForOnlineAndCache.json", SLBTransactionResponse.class));
    String currentDateInFormat = currentLocalDate.format(DateTimeFormatter.ofPattern("yyyyMMdd")) + "T000000+0100";
    return String.format(apiJsonResponse, currentDateInFormat);
  }

  private void performMockMvcCall(AccountTransactionResponse expected, String url, LocalDate currentLocalDate) throws Exception {
    mockBackEnd.enqueue(createMockResponse("{\"access_token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(createMockResponse(buildJsonContent(currentLocalDate)));
    mockMvc.perform(get(url)
      .headers(httpHeaders)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(status().isOk())
      .andExpect(content().json(mapper.writeValueAsString(expected), true));
  }
}
