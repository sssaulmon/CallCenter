package com.santander.scib.gtb.ic.gcm.test.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import com.santander.scib.gtb.ic.gcm.api.balance.model.config.ObjectMapperConfig;

import java.io.IOException;
import java.util.List;

public class TestUtils {

  private static ObjectMapper mapper = new ObjectMapperConfig().objectMapper();

  public static String loadResource(String fileName) {
    try {
      return Resources.toString(Resources.getResource(fileName), Charsets.UTF_8);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  public static <T> T loadObject(String file, Class<T> clazz) {
    return loadContent(loadResource(file), clazz);
  }

  public static <T> T loadContent(String content, Class<T> clazz) {
    try {
      return mapper.readValue(content, clazz);
    } catch (IOException ex) {
      ex.printStackTrace();
      throw new RuntimeException("Error parsing file to JSON with content: " + content);
    }
  }

  public static <T> List<T> listObject(String file, Class<T> clazz) {
    return listContent(loadResource(file), clazz);
  }

  public static <T> List<T> listContent(String content, Class<T> clazz) {
    try {
      return mapper.readValue(content, mapper.getTypeFactory().constructCollectionType(List.class, clazz));
    } catch (IOException ex) {
      ex.printStackTrace();
      throw new RuntimeException("Error parsing file to JSON with content: " + content);
    }
  }
}
