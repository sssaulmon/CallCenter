package com.santander.scib.gtb.ic.gcm.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.BalanceRequest;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.download.DownloadApiResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionResponse;
import com.santander.scib.gtb.ic.gcm.test.utils.TestUtils;
import com.santander.scib.gtb.ic.gcm.web.exception.InvalidCryptoException;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@EmbeddedKafka
@RunWith(SpringRunner.class)
@ActiveProfiles("integration")
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_CLASS)
public class BalancesControllerIntegrationTest {

  private HttpHeaders httpHeaders;
  private MockMvc mockMvc;
  private static MockWebServer mockBackEnd;

  @Autowired private WebApplicationContext webApplicationContext;
  @Autowired private ObjectMapper mapper;
  @Value("${transactions.limit.days}") int limitDays;

  @AfterClass
  public static void tearDown() throws IOException {
    mockBackEnd.shutdown();
  }

  @BeforeClass
  public static void setUpBackEnd() throws IOException {
    mockBackEnd = new MockWebServer();
    mockBackEnd.start(6429);
  }

  @Before
  public void setup() {
    mockMvc = MockMvcBuilders
      .webAppContextSetup(webApplicationContext)
      .build();
    httpHeaders = new HttpHeaders();
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    httpHeaders.add("X-Santander-Global-Id", "123456");
    httpHeaders.add("Authorization", TestUtils.loadResource("security/bearer.txt"));
  }

  @Test
  public void getBalancesCache() throws Exception {
    BalanceRequest body = TestUtils.loadObject("controller/requestDB.json", BalanceRequest.class);

    List<AccountBalanceDTO> expected = Arrays.asList(TestUtils.loadObject("controller/expected/requestDB_expected.json",
      AccountBalanceDTO[].class));

    MvcResult result = mockMvc.perform(post("/balances")
      .headers(httpHeaders)
      .content(mapper.writeValueAsBytes(body))
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON)).andReturn();

    mockMvc
      .perform(asyncDispatch(result))
      .andExpect(status().isOk())
      .andExpect(content().json(mapper.writeValueAsString(expected), true));
  }

  @Test
  public void getBalancesCacheWithThreshold() throws Exception {
    BalanceRequest body = TestUtils.loadObject("controller/requestDBThreshold.json", BalanceRequest.class);

    List<AccountBalanceDTO> expected = Arrays.asList(
      TestUtils.loadObject("controller/expected/requestDB_threshold_expected.json", AccountBalanceDTO[].class));

    MvcResult result = mockMvc.perform(post("/balances")
      .headers(httpHeaders)
      .content(mapper.writeValueAsBytes(body))
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON)).andReturn();

    mockMvc
      .perform(asyncDispatch(result))
      .andExpect(status().isOk());

    List<AccountBalanceDTO> response = mapper.readValue(result.getResponse().getContentAsString(),
      mapper.getTypeFactory().constructCollectionType(List.class, AccountBalanceDTO.class));
    assertThat(response).containsAll(expected);
  }

  @Test
  public void getBalancesINTRTest() throws Exception {
    String account = "BMSXMXMMXXXAPIACCONVSALDOSCASO1MXN";
    String urlTemplate = "/balances/".concat(account).concat("/transactions");
    LocalDate accountingDate = LocalDate.of(2020, Month.MARCH, 13);
    AccountTransactionResponse expected = TestUtils.loadObject("controller/expected/balancesINTR.json",
      AccountTransactionResponse.class);

    mockMvc.perform(get(urlTemplate)
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("accounting_date", String.valueOf(accountingDate))
      .param("limit", "1")
      .param("offset", "2")
      .param("bc_offset", "3"))
      .andExpect(status().isOk())
      .andExpect(content().json(mapper.writeValueAsString(expected), true));
  }

  @Test
  public void getBalancesINTRWithAccountTransactionsTest() throws Exception {
    String account = "BSCHFRPPXXX111777888999112EUR";
    String urlTemplate = "/balances/".concat(account).concat("/transactions");
    LocalDate accountingDate = LocalDate.of(2020, Month.MARCH, 6);
    AccountTransactionResponse expected = TestUtils.loadObject("controller/expected/balancesINTRWithAccount.json",
      AccountTransactionResponse.class);

    mockMvc.perform(get(urlTemplate)
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("accounting_date", String.valueOf(accountingDate))
      .param("limit", "50")
      .param("offset", "1"))
      .andExpect(status().isOk())
      .andExpect(content().json("{}"));
  }

  @Test
  public void getBalancesBetweenDatesINTRWithAccountTransactionsTest() throws Exception {
    String account = "BSCHFRPPXXX111777888999112EUR";
    String urlTemplate = "/balances/".concat(account).concat("/transactions");
    LocalDate fromAccountingDate = LocalDate.of(2020, Month.MARCH, 6);
    LocalDate toAccountingDate = LocalDate.of(2020, Month.MARCH, 7);
    AccountTransactionResponse expected = TestUtils.loadObject("controller/expected/balancesINTRWithAccountByDates.json",
      AccountTransactionResponse.class);

    mockMvc.perform(get(urlTemplate)
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("from_accounting_date", String.valueOf(fromAccountingDate))
      .param("to_accounting_date", String.valueOf(toAccountingDate))
      .param("limit", "50")
      .param("offset", "1"))
      .andExpect(status().isOk())
      .andExpect(content().json("{}"));
  }

  @Test
  public void getBalancesFINDTest() throws Exception {
    String account = "BSCHFRPPXXX111777888999111EUR";
    String urlTemplate = "/balances/".concat(account).concat("/transactions");
    LocalDate accountingDate = LocalDate.of(2020, Month.MARCH, 6);
    AccountTransactionResponse expected = TestUtils.loadObject("controller/expected/balancesFIND.json",
      AccountTransactionResponse.class);

    mockMvc.perform(get(urlTemplate)
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("accounting_date", String.valueOf(accountingDate))
      .param("limit", "1")
      .param("offset", "2")
      .param("bc_offset", "3"))
      .andExpect(status().isOk())
      .andExpect(content().json(mapper.writeValueAsString(expected), true));
  }

  @Test
  public void getBalancesWillReturnNotFoundTest() throws Exception {
    String account = "NOT_FOUND";
    String urlTemplate = "/balances/".concat(account).concat("/transactions");
    LocalDate accountingDate = LocalDate.of(1900, Month.JANUARY, 1);
    AccountTransactionResponse expected = TestUtils.loadObject("controller/expected/balancesNotFound.json",
      AccountTransactionResponse.class);

    mockMvc.perform(get(urlTemplate)
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("accounting_date", String.valueOf(accountingDate))
      .param("limit", "1")
      .param("offset", "2")
      .param("bc_offset", "3"))
      .andExpect(status().isOk())
      .andExpect(content().json(mapper.writeValueAsString(expected), true));
  }

  @Test
  public void tooManyAccounts_ShouldSendErrorMessage() throws Exception {
    BalanceRequest body = TestUtils.loadObject("controller/incorrectNumberOfAccountsRequest.json", BalanceRequest.class);

    mockMvc.perform(post("/balances")
      .headers(httpHeaders)
      .content(mapper.writeValueAsBytes(body))
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(status().isBadRequest())
      .andExpect(content().json("{}"));
  }

  @Test
  public void aliasAndAccountIdPresent_ShouldSendErrorMessage() throws Exception {
    BalanceRequest body = TestUtils.loadObject("controller/incorrectAliasAndAccountIdRequest.json", BalanceRequest.class);

    mockMvc.perform(post("/balances")
      .headers(httpHeaders)
      .content(mapper.writeValueAsBytes(body))
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(status().isBadRequest())
      .andExpect(content().json("{}"));
  }

  @Test
  public void givenTransactionsRequest_whenHaveOperationAndFromAndToDates_thenBadRequest() throws Exception {
    mockMvc.perform(get("/balances/BSCHFRPPXXX111777888999111EUR/transactions")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("accounting_date", String.valueOf(LocalDate.now()))
      .param("from_accounting_date", String.valueOf(LocalDate.now()))
      .param("to_accounting_date", String.valueOf(LocalDate.now())))
      .andExpect(status().isBadRequest())
      .andExpect(content().json("{}"));
  }

  @Test
  public void givenTransactionsRequest_whenHaveOperationAndFromDate_thenBadRequest() throws Exception {
    mockMvc.perform(get("/balances/BSCHFRPPXXX111777888999111EUR/transactions")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("accounting_date", String.valueOf(LocalDate.now()))
      .param("from_accounting_date", String.valueOf(LocalDate.now())))
      .andExpect(status().isBadRequest())
      .andExpect(content().json("{}"));
  }

  @Test
  public void givenTransactionsRequest_whenHaveOperationAndToDate_thenBadRequest() throws Exception {
    mockMvc.perform(get("/balances/BSCHFRPPXXX111777888999111EUR/transactions")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("accounting_date", String.valueOf(LocalDate.now()))
      .param("to_accounting_date", String.valueOf(LocalDate.now())))
      .andExpect(status().isBadRequest())
      .andExpect(content().json("{}"));
  }

  @Test
  public void givenTransactionsRequest_whenHaveToDateAndNotFromDate_thenBadRequest() throws Exception {
    mockMvc.perform(get("/balances/BSCHFRPPXXX111777888999111EUR/transactions")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("to_accounting_date", String.valueOf(LocalDate.now())))
      .andExpect(status().isBadRequest())
      .andExpect(content().json("{}"));
  }

  @Test
  public void givenTransactionsRequest_whenHaveFromDateAndNotToDate_thenOkStatus() throws Exception {
    mockMvc.perform(get("/balances/BSCHFRPPXXX111777888999111EUR/transactions")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("from_accounting_date", String.valueOf(LocalDate.now())))
      .andExpect(status().isOk())
      .andExpect(content().json("{}"));
  }

  @Test
  public void givenTransactionsRequest_whenHaveFromDateAndToDate_thenOkStatus() throws Exception {
    mockMvc.perform(get("/balances/BSCHFRPPXXX111777888999111EUR/transactions")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("from_accounting_date", String.valueOf(LocalDate.now()))
      .param("to_accounting_date", String.valueOf(LocalDate.now())))
      .andExpect(status().isOk())
      .andExpect(content().json("{}"));
  }

  @Test
  public void givenTransactionsRequest_whenHaveaccountingDate_thenOkStatus() throws Exception {
    mockMvc.perform(get("/balances/BSCHFRPPXXX111777888999111EUR/transactions")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("accounting_date", String.valueOf(LocalDate.now())))
      .andExpect(status().isOk())
      .andExpect(content().json("{}"));
  }

  @Test
  public void givenTransactionsRequest_whenNoDates_thenOkStatus() throws Exception {
    mockMvc.perform(get("/balances/BSCHFRPPXXX111777888999111EUR/transactions")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE))
      .andExpect(status().isOk())
      .andExpect(content().json("{}"));
  }

  @Test
  public void givenTransactionsRequest_whenHaveFromDateAndIsAfterDateLimit_thenOkStatus() throws Exception {
    mockMvc.perform(get("/balances/BSCHFRPPXXX111777888999111EUR/transactions")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("from_accounting_date", String.valueOf(LocalDate.now().minusDays(limitDays - 1))))
      .andExpect(status().isOk())
      .andExpect(content().json("{}"));
  }

  @Test
  public void givenTransactionsRequest_whenHaveFromDateAndIsBeforeDateLimit_thenBadRequest() throws Exception {
    mockMvc.perform(get("/balances/BSCHFRPPXXX111777888999111EUR/transactions")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("from_accounting_date", String.valueOf(LocalDate.now().minusDays(limitDays + 1))))
      .andExpect(status().isBadRequest())
      .andExpect(content().json("{}"));
  }

  @Test
  public void givenTransactionsRequest_whenHaveFromDateAndToDateInRange_thenOkStatus() throws Exception {
    mockMvc.perform(get("/balances/BSCHFRPPXXX111777888999111EUR/transactions")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("from_accounting_date", String.valueOf(LocalDate.of(2020, 3, 1)))
      .param("to_accounting_date", String.valueOf(LocalDate.of(2020, 3, 15))))
      .andExpect(status().isOk())
      .andExpect(content().json("{}"));
  }

  @Test
  public void givenTransactionsRequest_whenHaveFromDateAndToDateNotInRange_thenBadRequest() throws Exception {
    mockMvc.perform(get("/balances/BSCHFRPPXXX111777888999111EUR/transactions")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("from_accounting_date", String.valueOf(LocalDate.of(2020, 1, 1)))
      .param("to_accounting_date", String.valueOf(LocalDate.of(2020, 5, 1))))
      .andExpect(status().isBadRequest())
      .andExpect(content().json("{}"));
  }

  @Test
  public void reportsByExistsUuid() throws Exception {
    String expected = TestUtils.loadResource("controller/reports/uuidTestExists.json");
    mockMvc.perform(get("/balances/uuidTest/reports")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(status().isOk())
      .andExpect(content().json(expected, true));
  }

  @Test
  public void reportsByNotExistsUuid() throws Exception {
    mockMvc.perform(get("/balances/uuidNotExistsTest/reports")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(status().isOk());
  }

  @Test
  public void reportsGetZipOK() throws Exception {
    DownloadApiResponse expected = TestUtils.loadObject("controller/reports/uuidTestExistsZip.json", DownloadApiResponse.class);
    expected.fileName("REPORTS_ALL.zip");

    URL url = new URL("http://url1.zip");
    mockBackEnd.enqueue(createMockResponseWithClass(mapper.writeValueAsString(url)));
    mockMvc.perform(get("/balances/uuidTest/reports/zip?requestIds=dyFp3eXrz7wlNEDPdLOIMQ==,kB4k6w_skrj0Qc6Ks9Rzzg==,ZH82H4OaJkKNbsOcdALfmg==,UQMuKwvboL_3FwzH0Ihhuw==")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(status().isOk())
      .andExpect(content().json(mapper.writeValueAsString(expected), true));
  }

  @Test
  public void reportsGetZipNoContent() throws Exception {

    mockMvc.perform(get("/balances/uuidTest/reports/zip?requestIds=p_PjEt6ipCIRe5oEgXeEsg==")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(status().isOk());
  }

  @Test
  public void reportsGetZipBadRequest() throws Exception {

    mockMvc.perform(get("/balances/uuidTest/reports/zip")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(status().isBadRequest());
  }

  @Test
  @ExceptionHandler(InvalidCryptoException.class)
  public void reportsGetZipCryptoException() throws Exception {

    mockMvc.perform(get("/balances/uuidTest/reports/zip?requestIds=a_PjEt6ipCIRe5oEgXeEsg==")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(status().isInternalServerError());
  }

  @Test
  public void getBalancesBetweenDatesNoShowIntrTest() throws Exception {
    String account = "BSCHFRPPXXX111777888999XXXEUR";
    String urlTemplate = "/balances/".concat(account).concat("/transactions");
    LocalDate fromAccountingDate = LocalDate.of(2020, Month.MARCH, 6);
    LocalDate toAccountingDate = LocalDate.of(2020, Month.MARCH, 8);
    AccountTransactionResponse expected = TestUtils.loadObject("controller/expected/transactionsNotINTR.json",
      AccountTransactionResponse.class);

    mockMvc.perform(get(urlTemplate)
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("from_accounting_date", String.valueOf(fromAccountingDate))
      .param("to_accounting_date", String.valueOf(toAccountingDate))
      .param("limit", "50")
      .param("offset", "1"))
      .andExpect(status().isOk())
      .andExpect(content().json(mapper.writeValueAsString(expected), true));
  }

  private MockResponse createMockResponseWithClass(String file) {
    return new MockResponse()
      .setBody(file)
      .addHeader("Content-Type", MediaType.APPLICATION_JSON);
  }
}
