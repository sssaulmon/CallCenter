package com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions;

import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class AccountTransactionDTOTest {

  @Test
  public void testHashCode() {
    AccountTransactionDTO a = new AccountTransactionDTO()
      .alias("ALIAS")
      .accountId("ACCOUNTID")
      .accountOwner("OWNER")
      .balance(BigDecimal.ZERO)
      .currency("EUR");
    AccountTransactionDTO b = new AccountTransactionDTO()
      .alias("ALIASTWO")
      .accountId("ACCOUNTID")
      .accountOwner("OWNER")
      .balance(BigDecimal.ZERO)
      .currency("EUR");

    assertEquals(a, a);
    assertNotEquals(a, b);
    assertNotEquals(a, "");
    assertNotEquals(a, null);
    assertNotEquals(a.hashCode(), b.hashCode());
    assertNotEquals(a.toString(), b.toString());
  }
}
