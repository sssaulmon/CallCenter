package com.santander.scib.gtb.ic.gcm.util.crypto;

import com.santander.scib.gtb.ic.gcm.web.exception.InvalidCryptoException;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

@Slf4j
public class AESSymmetricCryptoTest {

  private AESSymmetricCrypto aesSymmetricCrypto;
  private AESSymmetricCrypto errorAesSymmetricCrypto;

  @Before
  public void setup() {
    aesSymmetricCrypto = new AESSymmetricCrypto("jmXUb0nD2iR5T0ly");
    errorAesSymmetricCrypto = new AESSymmetricCrypto("12345");
  }

  @Test
  public void okEncryptTest() {
    String example = "1212121212";

    String encrypt = aesSymmetricCrypto.encrypt(example);
    log.info(encrypt);
    String decrypt = aesSymmetricCrypto.decrypt(encrypt);
    log.info(decrypt);

    Assert.assertEquals(example, decrypt);
  }

  @Test(expected = InvalidCryptoException.class)
  public void errorEncryptTest() {
    String example = "1212121212";
    String encryptExample = "-7QeILWT1mi6_8N4IHhqDw==";

    String encrypt = errorAesSymmetricCrypto.encrypt(example);
    log.info(encrypt);

    Assert.assertEquals(encryptExample, encrypt);
  }

  @Test(expected = InvalidCryptoException.class)
  public void errorDecryptTest() {
    String example = "1212121212";
    String encrypt = "-7QeILWT1mi6_8N4IHhqDw==";

    String decrypt = errorAesSymmetricCrypto.decrypt(encrypt);
    log.info(decrypt);

    Assert.assertEquals(example, decrypt);
  }
}
