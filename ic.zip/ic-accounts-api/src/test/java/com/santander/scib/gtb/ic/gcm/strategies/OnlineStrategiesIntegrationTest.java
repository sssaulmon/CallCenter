package com.santander.scib.gtb.ic.gcm.strategies;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.gtb.ic.gcm.api.balance.model.account.ErrorItem;
import com.santander.scib.gtb.ic.gcm.api.balance.model.global.transactions.GlobalTransactionResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.BalanceRequest;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.balance.SLBAccountBalanceResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions.SLBTransactionResponse;
import com.santander.scib.gtb.ic.gcm.communication.binding.ApiOutputBinding;
import com.santander.scib.gtb.ic.gcm.model.NotificationError;
import com.santander.scib.gtb.ic.gcm.test.utils.TestUtils;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.jetbrains.annotations.NotNull;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.stream.test.binder.MessageCollector;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.messaging.Message;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@EmbeddedKafka
@RunWith(SpringRunner.class)
@ActiveProfiles("integration")
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_CLASS)
public class OnlineStrategiesIntegrationTest {

  private final HttpHeaders httpHeaders = new HttpHeaders();
  private MockMvc mockMvc;
  private static MockWebServer mockBackEnd;

  @Autowired private WebApplicationContext webApplicationContext;
  @Autowired private ObjectMapper mapper;
  @Autowired private MessageCollector messageCollector;
  @Autowired private ApiOutputBinding apiOutputBinding;

  @After
  public void tearDown() throws IOException {
    mockBackEnd.shutdown();
  }

  @Before
  public void setUpMvc() throws IOException {
    mockBackEnd = new MockWebServer();
    mockBackEnd.start(6429);

    mockMvc = MockMvcBuilders
      .webAppContextSetup(webApplicationContext)
      .build();
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    httpHeaders.add("X-Santander-Global-Id", "123456");
    httpHeaders.add("Authorization", TestUtils.loadResource("security/bearer.txt"));
  }

  @Test
  public void correctV2BalancesRequest_ShouldCompleteV2Strategy() throws Exception {
    BalanceRequest body = TestUtils.loadObject("strategies/requests/V2request.json", BalanceRequest.class);
    List<AccountBalanceDTO> expected = Arrays.asList(TestUtils.loadObject("strategies/responses/V2expectedResponse.json",
      AccountBalanceDTO[].class));

    mockBackEnd.enqueue(createMockResponse("{\"token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(createMockResponse("{\"access_token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(createMockResponseWithClass("strategies/responses/V2webClientResponse.json", SLBAccountBalanceResponse.class));

    MvcResult result = mockMvc.perform(post("/balances")
      .headers(httpHeaders)
      .content(mapper.writeValueAsBytes(body))
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON)).andReturn();

    // TODO comparar las salidas tomando en cuenta que la fecha y hora son la actual
    mockMvc
      .perform(asyncDispatch(result))
      .andExpect(status().isOk());
  }

  @Test
  public void correctV2TransactionsRequest_ShouldCompleteV2Strategy() throws Exception {
    AccountTransactionResponse expected = TestUtils.loadObject("strategies/responses/V2TransactionsExpectedResponse.json",
      AccountTransactionResponse.class);

    mockBackEnd.enqueue(createMockResponse("{\"token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(createMockResponse("{\"access_token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(createMockResponseWithClass("strategies/responses/V2TransactionsWebClientResponse.json",
      GlobalTransactionResponse.class));

    mockMvc.perform(get("/balances/ABBYGB2LXXX09022210205699GBP/transactions")
      .headers(httpHeaders)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(status().isOk())
      .andExpect(content().json(mapper.writeValueAsString(expected), true));
  }

  @Test
  public void correctV2TransactionsWithoutLinksRequest_ShouldCompleteV2Strategy() throws Exception {
    AccountTransactionResponse expected = TestUtils.loadObject("strategies/responses/V2TransactionsWithoutLinksExpectedResponse.json",
      AccountTransactionResponse.class);

    mockBackEnd.enqueue(createMockResponse("{\"token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(createMockResponse("{\"access_token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(createMockResponseWithClass("strategies/responses/V2TransactionsWithoutLinksWebClientResponse.json",
      GlobalTransactionResponse.class));

    mockMvc.perform(get("/balances/ABBYGB2LXXX09022210205699GBP/transactions")
      .headers(httpHeaders)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(status().isOk())
      .andExpect(content().json(mapper.writeValueAsString(expected), true));
  }

  @Test
  public void correctV3BalancesRequest_ShouldCompleteV3Strategy() throws Exception {
    BalanceRequest body = TestUtils.loadObject("strategies/requests/V3request.json", BalanceRequest.class);
    List<AccountBalanceDTO> expected = Arrays.asList(TestUtils.loadObject("strategies/responses/V3BalancesExpectedResponse.json",
      AccountBalanceDTO[].class));

    mockBackEnd.enqueue(createMockResponse("{\"access_token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(createMockResponseWithClass("strategies/responses/V3BalancesWebClientResponse.json", SLBAccountBalanceResponse.class));

    MvcResult result = mockMvc.perform(post("/balances")
      .headers(httpHeaders)
      .content(mapper.writeValueAsBytes(body))
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON)).andReturn();

    // TODO comparar las salidas tomando en cuenta que la fecha y hora son la actual
    mockMvc
      .perform(asyncDispatch(result))
      .andExpect(status().isOk());
  }

  @Test
  public void correctV3BalancesRequest_BadRequestV3Strategy() throws Exception {
    BalanceRequest body = TestUtils.loadObject("strategies/requests/V3request.json", BalanceRequest.class);
    NotificationError expected = TestUtils.loadObject("strategies/kafka/correctBadRequest.json", NotificationError.class);

    mockBackEnd.enqueue(createMockResponse("{\"access_token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(createMockResponseWithClass("strategies/responses/V3BalancesWebClientBadRequestResponse.json", 400, ErrorItem.class));

    MvcResult result = mockMvc.perform(post("/balances")
      .headers(httpHeaders)
      .content(mapper.writeValueAsBytes(body))
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON)).andReturn();

    mockMvc
      .perform(asyncDispatch(result))
      .andExpect(status().isOk());

    Message<String> payload = (Message<String>) messageCollector.forChannel(apiOutputBinding.apiRequestFailed()).poll(6, SECONDS);
    Assert.assertNotNull(payload);
    NotificationError resultKafka = TestUtils.loadContent(payload.getPayload(), NotificationError.class);
    Assert.assertEquals(expected.getMessage(), resultKafka.getMessage());
    Assert.assertEquals(expected.getType(), resultKafka.getType());
    Assert.assertEquals(expected.getExceptionType(), resultKafka.getExceptionType());
  }

  @Test
  public void correctV3BalancesRequest_BadRequest401V3Strategy() throws Exception {
    BalanceRequest body = TestUtils.loadObject("strategies/requests/V3request.json", BalanceRequest.class);
    NotificationError expected = TestUtils.loadObject("strategies/kafka/correctUnauthorized.json", NotificationError.class);

    mockBackEnd.enqueue(createMockResponse("{\"access_token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(createMockResponseWithClass("strategies/responses/V3BalancesWebClientUnauthorizedResponse.json", 401, ErrorItem.class));

    MvcResult result = mockMvc.perform(post("/balances")
      .headers(httpHeaders)
      .content(mapper.writeValueAsBytes(body))
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON)).andReturn();

    mockMvc
      .perform(asyncDispatch(result))
      .andExpect(status().isOk());

    Message<String> payload = (Message<String>) messageCollector.forChannel(apiOutputBinding.apiRequestFailed()).poll(6, SECONDS);
    Assert.assertNotNull(payload);
    NotificationError resultKafka = TestUtils.loadContent(payload.getPayload(), NotificationError.class);
    Assert.assertEquals(expected.getMessage(), resultKafka.getMessage());
    Assert.assertEquals(expected.getType(), resultKafka.getType());
    Assert.assertEquals(expected.getExceptionType(), resultKafka.getExceptionType());
  }

  @Test
  public void correctV3BalancesRequest_BadRequest404V3Strategy() throws Exception {
    BalanceRequest body = TestUtils.loadObject("strategies/requests/V3request.json", BalanceRequest.class);
    NotificationError expected = TestUtils.loadObject("strategies/kafka/correctNotFound.json", NotificationError.class);

    mockBackEnd.enqueue(createMockResponse("{\"access_token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(createMockResponseWithClass("strategies/responses/V3BalancesWebClientNotFoundResponse.json", 404, ErrorItem.class));

    MvcResult result = mockMvc.perform(post("/balances")
      .headers(httpHeaders)
      .content(mapper.writeValueAsBytes(body))
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON)).andReturn();

    mockMvc
      .perform(asyncDispatch(result))
      .andExpect(status().isOk());

    Message<String> payload = (Message<String>) messageCollector.forChannel(apiOutputBinding.apiRequestFailed()).poll(6, SECONDS);
    Assert.assertNotNull(payload);
    NotificationError resultKafka = TestUtils.loadContent(payload.getPayload(), NotificationError.class);
    Assert.assertEquals(expected.getMessage(), resultKafka.getMessage());
    Assert.assertEquals(expected.getType(), resultKafka.getType());
    Assert.assertEquals(expected.getExceptionType(), resultKafka.getExceptionType());
  }

  @Test
  public void correctV3TransactionsRequest_ShouldCompleteV3Strategy() throws Exception {
    LocalDate currentLocalDate = LocalDate.now();
    String valueDateInFormat = currentLocalDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    String expectedJsonResponse = TestUtils.loadResource("strategies/responses/V3TransactionsExpectedResponse.json");
    AccountTransactionResponse expected = TestUtils.loadContent(expectedJsonResponse.replace("$1", valueDateInFormat), AccountTransactionResponse.class);

    String apiJsonResponse = mapper.writeValueAsString(
      TestUtils.loadObject("strategies/responses/V3TransactionsWebClientResponse.json", SLBTransactionResponse.class));
    String currentDateInFormat = currentLocalDate.format(DateTimeFormatter.ofPattern("yyyyMMdd")) + "T000000000+0100";
    mockBackEnd.enqueue(createMockResponse("{\"access_token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(createMockResponse(String.format(apiJsonResponse, currentDateInFormat, currentDateInFormat)));

    mockMvc.perform(get("/balances/BSCHGB20XXX1100100775250GBP/transactions")
      .headers(httpHeaders)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(status().isOk())
      .andExpect(content().json(mapper.writeValueAsString(expected), true));
  }

  @Test
  public void incorrect400Response_ShouldSendErrorMessage() throws Exception {
    BalanceRequest body = TestUtils.loadObject("strategies/requests/V3request.json", BalanceRequest.class);

    mockBackEnd.enqueue(createMockResponse("{\"access_token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockBackEnd.enqueue(new MockResponse().setResponseCode(400));

    MvcResult mvcResult = mockMvc.perform(post("/balances")
      .headers(httpHeaders)
      .content(mapper.writeValueAsBytes(body))
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON))
      .andExpect(request().asyncStarted())
      .andExpect(status().isOk())
      .andReturn();

    mockMvc.perform(asyncDispatch(mvcResult))
      .andExpect(status().isOk())
      .andExpect(content().json("[{}]"));

    Message<?> payload = messageCollector.forChannel(apiOutputBinding.apiRequestFailed()).poll(6, SECONDS);
    Assert.assertNotNull(payload);
    assertThat((String) payload.getPayload()).isNotNull();
  }

  @NotNull
  private MockResponse createMockResponse(String body1) {
    return new MockResponse()
      .setBody(body1)
      .addHeader("Content-Type", MediaType.APPLICATION_JSON);
  }

  @NotNull
  private MockResponse createMockResponseWithClass(String file, Class<?> clazz) throws JsonProcessingException {
    return createMockResponseWithClass(file, 200, clazz);
  }

  @NotNull
  private MockResponse createMockResponseWithClass(String file, int responseCode, Class<?> clazz) throws JsonProcessingException {
    return new MockResponse()
      .setResponseCode(responseCode)
      .setBody(mapper.writeValueAsString(TestUtils.loadObject(file, clazz)))
      .addHeader("Content-Type", MediaType.APPLICATION_JSON);
  }
}
