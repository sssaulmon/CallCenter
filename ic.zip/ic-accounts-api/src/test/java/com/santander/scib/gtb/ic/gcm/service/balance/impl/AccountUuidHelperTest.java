package com.santander.scib.gtb.ic.gcm.service.balance.impl;

import com.isban.gcb.ic.commons.balance.cache.dto.ExtractDto;
import com.isban.gcb.ic.commons.model.AssoCorpSubProductAcc;
import com.isban.gcb.ic.commons.model.ServiceAccount;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.mapper.AccountBalanceMapper;
import com.santander.scib.gtb.ic.gcm.model.ServiceAccountFlat;
import com.santander.scib.gtb.ic.gcm.repository.ServiceAccountRepository;
import com.santander.scib.gtb.ic.gcm.repository.SlaEntityRepository;
import com.santander.scib.gtb.ic.gcm.service.balance.AccountUuidHelper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.data.util.Streamable;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class AccountUuidHelperTest {

  private AccountUuidHelper transformationService;
  private AccountBalanceDTO accountBalanceDTO;
  private AccountDTO accountDTO;
  private TransactionDTO transactionDTO;
  @Mock private AccountBalanceMapper accountBalanceMapper;
  @Mock private ServiceAccountRepository serviceAccountRepository;
  @Mock private SlaEntityRepository slaEntityRepository;

  @Before
  public void setUp() {
    transformationService = new AccountUuidHelperImpl(accountBalanceMapper, serviceAccountRepository,
      slaEntityRepository);

    accountBalanceDTO = new AccountBalanceDTO()
      .bic("BIC")
      .accountId("ACCOUNT_ID")
      .alias("ALIAS")
      .currency("CUR");

    accountDTO = new AccountDTO()
      .bic("BIC")
      .accountId("ACCOUNT_ID")
      .alias("ALIAS")
      .currency("CUR");

    transactionDTO = TransactionDTO.builder()
      .accountId("ACCOUNT_ID")
      .bic("BIC")
      .currency("CUR")
      .build();
  }

  @Test
  public void givenAccountBalanceDto_whenTransformWithInternational_thenReturnExtractWithAccountUuid() {
    AssoCorpSubProductAcc assoCorpSubProductAcc = new AssoCorpSubProductAcc();
    assoCorpSubProductAcc.setUuidStructureAcc("UUID_INTERNATIONAL");

    when(accountBalanceMapper.mapToExtractDto(accountBalanceDTO)).thenReturn(ExtractDto.builder().build());
    when(slaEntityRepository.findFirstByAccountInternationalNumberAndBicEntityAccAndCurrency(accountBalanceDTO.getAccountId(),
      accountBalanceDTO.getBic(), accountBalanceDTO.getCurrency())).thenReturn(Optional.of(assoCorpSubProductAcc));
    ExtractDto extractDtoResult = transformationService.transform(accountBalanceDTO);
    assertThat(extractDtoResult.getAccountAlias()).isEqualTo(assoCorpSubProductAcc.getUuidStructureAcc());
  }

  @Test
  public void givenAccountBalanceDto_whenTransformWithLocal_thenReturnExtractWithAccountUuid() {
    AssoCorpSubProductAcc assoCorpSubProductAcc = new AssoCorpSubProductAcc();
    assoCorpSubProductAcc.setUuidStructureAcc("UUID_LOCAL");

    when(accountBalanceMapper.mapToExtractDto(accountBalanceDTO)).thenReturn(ExtractDto.builder().build());
    when(slaEntityRepository.findFirstByAccountInternationalNumberAndBicEntityAccAndCurrency(accountBalanceDTO.getAccountId(),
      accountBalanceDTO.getBic(), accountBalanceDTO.getCurrency())).thenReturn(Optional.empty());
    when(slaEntityRepository.findFirstByAccountLocalNumberAndBicEntityAccAndCurrency(accountBalanceDTO.getAccountId(),
      accountBalanceDTO.getBic(), accountBalanceDTO.getCurrency())).thenReturn(Optional.of(assoCorpSubProductAcc));
    ExtractDto extractDtoResult = transformationService.transform(accountBalanceDTO);
    assertThat(extractDtoResult.getAccountAlias()).isEqualTo(assoCorpSubProductAcc.getUuidStructureAcc());
  }

  @Test
  public void givenAccountBalanceDto_whenTransformWithAlias_thenReturnExtractWithAccountUuid() {
    AssoCorpSubProductAcc assoCorpSubProductAcc = new AssoCorpSubProductAcc();
    assoCorpSubProductAcc.setUuidStructureAcc("UUID_ALIAS");
    ServiceAccount serviceAccount = new ServiceAccount();
    serviceAccount.setAssoCorpSubProductAcc(assoCorpSubProductAcc);

    when(accountBalanceMapper.mapToExtractDto(accountBalanceDTO)).thenReturn(ExtractDto.builder().build());
    when(slaEntityRepository.findFirstByAccountInternationalNumberAndBicEntityAccAndCurrency(accountBalanceDTO.getAccountId(),
      accountBalanceDTO.getBic(), accountBalanceDTO.getCurrency())).thenReturn(Optional.empty());
    when(slaEntityRepository.findFirstByAccountLocalNumberAndBicEntityAccAndCurrency(accountBalanceDTO.getAccountId(),
      accountBalanceDTO.getBic(), accountBalanceDTO.getCurrency())).thenReturn(Optional.empty());
    when(serviceAccountRepository.findFirstByAliasAccClientAndAssoCorpSubProductAccBicEntityAccAndAssoCorpSubProductAccCurrency(
      accountBalanceDTO.getAlias(), accountBalanceDTO.getBic(), accountBalanceDTO.getCurrency())).thenReturn(Optional.of(serviceAccount));
    ExtractDto extractDtoResult = transformationService.transform(accountBalanceDTO);
    assertThat(extractDtoResult.getAccountAlias()).isEqualTo(assoCorpSubProductAcc.getUuidStructureAcc());
  }

  @Test(expected = RuntimeException.class)
  public void givenAccountBalanceDto_whenTransformAndNotFound_thenThrowRuntimeException() {
    when(accountBalanceMapper.mapToExtractDto(accountBalanceDTO)).thenReturn(ExtractDto.builder().build());
    when(slaEntityRepository.findFirstByAccountInternationalNumberAndBicEntityAccAndCurrency(accountBalanceDTO.getAccountId(),
      accountBalanceDTO.getBic(), accountBalanceDTO.getCurrency())).thenReturn(Optional.empty());
    when(slaEntityRepository.findFirstByAccountLocalNumberAndBicEntityAccAndCurrency(accountBalanceDTO.getAccountId(),
      accountBalanceDTO.getBic(), accountBalanceDTO.getCurrency())).thenReturn(Optional.empty());
    when(serviceAccountRepository.findFirstByAliasAccClientAndAssoCorpSubProductAccBicEntityAccAndAssoCorpSubProductAccCurrency(
      accountBalanceDTO.getAlias(), accountBalanceDTO.getBic(), accountBalanceDTO.getCurrency())).thenReturn(Optional.empty());
    transformationService.transform(accountBalanceDTO);
  }

  @Test
  public void givenAccountDTOs_whenCompleteAndAllContractsFound_thenReturnCompleted() {
    ServiceAccountFlat serviceAccountFlat = new ServiceAccountFlat("BIC", "UUID_INTERNATIONAL", "ALIAS",
      "INTERNATIONAL", null, "CUR");

    when(serviceAccountRepository.findAccountUuid(anySet(), anySet())).thenReturn(Streamable.of(serviceAccountFlat));

    List<AccountDTO> accountDTOs = transformationService.completeWithUuid(Collections.singleton(accountDTO)).getValidAccounts();
    assertThat(accountDTOs.size()).isEqualTo(1);
    accountDTOs.stream()
      .findFirst()
      .ifPresent(dto -> assertThat(dto.getUuid()).isEqualTo("UUID_INTERNATIONAL"));
  }

  @Test
  public void givenAccountDTOs_whenCompleteAndNoContractsFound_thenReturnCompletedWithoutUuid() {
    when(serviceAccountRepository.findAccountUuid(anySet(), anySet())).thenReturn(Streamable.empty());

    List<AccountDTO> accountDTOs = transformationService.completeWithUuid(Collections.singleton(accountDTO)).getValidAccounts();
    assertThat(accountDTOs.size()).isZero();
  }

  @Test
  public void givenTransactionDTO_whenCompleteWithInternational_thenReturnWithAccountUuid() {
    AssoCorpSubProductAcc assoCorpSubProductAcc = new AssoCorpSubProductAcc();
    assoCorpSubProductAcc.setUuidStructureAcc("UUID_INTERNATIONAL");

    when(slaEntityRepository.findFirstByAccountInternationalNumberAndBicEntityAccAndCurrency(transactionDTO.getAccountId(),
      transactionDTO.getBic(), transactionDTO.getCurrency())).thenReturn(Optional.of(assoCorpSubProductAcc));

    TransactionDTO transactionDTOResult = transformationService.completeWithUuid(transactionDTO);
    assertThat(transactionDTOResult.getAccountUuid()).isEqualTo(assoCorpSubProductAcc.getUuidStructureAcc());
  }

  @Test
  public void givenTransactionDTO_whenCompleteWithLocal_thenReturnWithAccountUuid() {
    AssoCorpSubProductAcc assoCorpSubProductAcc = new AssoCorpSubProductAcc();
    assoCorpSubProductAcc.setUuidStructureAcc("UUID_LOCAL");

    when(slaEntityRepository.findFirstByAccountInternationalNumberAndBicEntityAccAndCurrency(transactionDTO.getAccountId(),
      transactionDTO.getBic(), transactionDTO.getCurrency())).thenReturn(Optional.empty());
    when(slaEntityRepository.findFirstByAccountLocalNumberAndBicEntityAccAndCurrency(transactionDTO.getAccountId(),
      transactionDTO.getBic(), transactionDTO.getCurrency())).thenReturn(Optional.of(assoCorpSubProductAcc));

    TransactionDTO transactionDTOResult = transformationService.completeWithUuid(transactionDTO);
    assertThat(transactionDTOResult.getAccountUuid()).isEqualTo(assoCorpSubProductAcc.getUuidStructureAcc());
  }

  @Test
  public void givenTransactionDTO_whenCompleteAndNotFound_thenReturnCompletedWithoutUuid() {
    when(slaEntityRepository.findFirstByAccountInternationalNumberAndBicEntityAccAndCurrency(transactionDTO.getAccountId(),
      transactionDTO.getBic(), transactionDTO.getCurrency())).thenReturn(Optional.empty());
    when(slaEntityRepository.findFirstByAccountLocalNumberAndBicEntityAccAndCurrency(transactionDTO.getAccountId(),
      transactionDTO.getBic(), transactionDTO.getCurrency())).thenReturn(Optional.empty());
    when(serviceAccountRepository.findFirstByAliasAccClientAndAssoCorpSubProductAccBicEntityAccAndAssoCorpSubProductAccCurrency(
      transactionDTO.getAccountId(), transactionDTO.getBic(), transactionDTO.getCurrency())).thenReturn(Optional.empty());
    TransactionDTO transactionDTOResult = transformationService.completeWithUuid(transactionDTO);
    assertThat(transactionDTOResult.getAccountUuid()).isEqualTo(transactionDTO.getAccountId());
  }
}