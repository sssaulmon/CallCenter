package com.santander.scib.gtb.ic.gcm.config;

import org.junit.Test;

public class RequestParamsConstantsTest {

  @Test
  public void santanderClientId() throws Exception {
    assert RequestParamsConstants.SANTANDER_CLIENT_ID.equals("X-Santander-Client-Id");
  }

  @Test
  public void ibmClientId() throws Exception {
    assert RequestParamsConstants.IBM_CLIENT_ID.equals("X-IBM-Client-Id");
  }

  @Test
  public void countryBic() throws Exception {
    assert RequestParamsConstants.COUNTRY_BIC.equals("countryBic");
  }

  @Test
  public void password() throws Exception {
    assert RequestParamsConstants.REQ_PASS.equals("password");
  }

  @Test
  public void userId() throws Exception {
    assert RequestParamsConstants.USER_ID.equals("userId");
  }

  @Test
  public void scope() throws Exception {
    assert RequestParamsConstants.SCOPE.equals("scope");
  }

  @Test
  public void passCode() throws Exception {
    assert RequestParamsConstants.PASS_CODE.equals("passCode");
  }

  @Test
  public void assertion() throws Exception {
    assert RequestParamsConstants.ASSERTION.equals("assertion");
  }

  @Test
  public void country() throws Exception {
    assert RequestParamsConstants.COUNTRY.equals("country");
  }

  @Test
  public void grantType() throws Exception {
    assert RequestParamsConstants.GRANT_TYPE.equals("grant_type");
  }

  @Test
  public void clientId() throws Exception {
    assert RequestParamsConstants.CLIENT_ID.equals("client_id");
  }

  @Test
  public void clientSecret() throws Exception {
    assert RequestParamsConstants.CLIENT_SECRET.equals("client_secret");
  }

  @Test
  public void limit() throws Exception {
    assert RequestParamsConstants.LIMIT.equals("_limit");
  }

  @Test
  public void offset() throws Exception {
    assert RequestParamsConstants.OFFSET.equals("_offset");
  }
}
