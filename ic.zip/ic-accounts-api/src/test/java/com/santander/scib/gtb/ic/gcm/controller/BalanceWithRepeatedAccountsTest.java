package com.santander.scib.gtb.ic.gcm.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.BalanceRequest;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.test.utils.TestUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@RunWith(SpringRunner.class)
@ActiveProfiles("integration")
public class BalanceWithRepeatedAccountsTest {

  @Autowired private MockMvc mockMvc;
  @Autowired private ObjectMapper mapper;

  @Test
  public void givenAccounts_whenSameUUIDInRequest_thenMultipleTimesInResponse() throws Exception {
    performMockCallAndCheckExpectedResult("controller/same-uuid-different-alias.json", "controller/expected/same-uuid-different-alias.json");
    performMockCallAndCheckExpectedResult("controller/same-account-twice.json", "controller/expected/same-account-twice.json");
    performMockCallAndCheckExpectedResult("controller/same-account-three-times.json", "controller/expected/same-account-three-times.json");
  }

  private void performMockCallAndCheckExpectedResult(String fileForBody, String fileForResponse) throws Exception {
    BalanceRequest body = TestUtils.loadObject(fileForBody, BalanceRequest.class);
    List<AccountBalanceDTO> expected = Arrays.asList(TestUtils.loadObject(fileForResponse, AccountBalanceDTO[].class));
    performMockCallAndCheckExpectedResult(body, expected);
  }

  private void performMockCallAndCheckExpectedResult(BalanceRequest body, List<AccountBalanceDTO> expected) throws Exception {
    HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    httpHeaders.add("X-Santander-Global-Id", "123456");
    httpHeaders.add("Authorization", TestUtils.loadResource("security/bearer.txt"));

    MvcResult result = mockMvc.perform(post("/balances")
      .headers(httpHeaders)
      .content(mapper.writeValueAsBytes(body))
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON))
      .andReturn();

    mockMvc
      .perform(asyncDispatch(result))
      .andExpect(status().isOk());

    List<AccountBalanceDTO> response = mapper.readValue(result.getResponse().getContentAsString(),
      mapper.getTypeFactory().constructCollectionType(List.class, AccountBalanceDTO.class));
    assertThat(response).containsAll(expected);
  }
}
