package com.santander.scib.gtb.ic.gcm;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest
public class AccountsApplicationTests {

	@Test
	public void contextLoads() {
		AccountsApplication.main(new String[0]);
	}

}
