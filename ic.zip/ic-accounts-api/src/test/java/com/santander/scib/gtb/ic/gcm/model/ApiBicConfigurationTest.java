package com.santander.scib.gtb.ic.gcm.model;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class ApiBicConfigurationTest {

  @Test
  public void testEqualsAndHashCode() {
    ApiBicConfiguration a = new ApiBicConfiguration();
    a.setBic("BSCHBXMMXXX");
    a.setConvertAmount(true);
    a.setDateSort(false);
    a.setIbanAccount(true);
    ApiBicConfiguration b = new ApiBicConfiguration();
    b.setBic("BSCHBXMMXXX");
    b.setConvertAmount(true);
    b.setDateSort(false);
    b.setIbanAccount(true);
    ApiBicConfiguration c = new ApiBicConfiguration();
    c.setBic("BSCHBXESXXX");
    c.setConvertAmount(true);
    c.setDateSort(false);
    c.setIbanAccount(true);

    assertEquals(a, b);
    assertEquals(a, a);
    assertEquals(a.hashCode(), b.hashCode());
    assertNotEquals(a, c);
    assertNotEquals(a, null);
    assertNotEquals(a, "");
  }
}
