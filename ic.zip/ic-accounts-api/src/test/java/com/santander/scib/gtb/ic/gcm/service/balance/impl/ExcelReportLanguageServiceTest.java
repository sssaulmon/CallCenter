package com.santander.scib.gtb.ic.gcm.service.balance.impl;

import com.santander.scib.gtb.ic.gcm.repository.ExcelReportLanguageRepository;
import com.santander.scib.gtb.ic.gcm.service.ExcelReportLanguageService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("integration")
public class ExcelReportLanguageServiceTest {

  @Autowired private ExcelReportLanguageService service;
  @MockBean private ExcelReportLanguageRepository repository;

  @Test
  public void testValidCacheOnlyExecution() {
    String language = "es";
    String type = "movements";
    List<String> expected = new ArrayList<>();
    expected.add("BIC");

    when(repository.listHeaders(language, type)).thenReturn(expected);

    List<String> result1 = service.listHeadersByLanguage(language, type);
    List<String> result2 = service.listHeadersByLanguage(language, type);

    verify(repository).listHeaders(language, type);
    assertEquals(expected.get(0), result1.get(0));
    assertEquals(expected.get(0), result2.get(0));
  }

  @Test
  public void testValidNoStorageCache() {
    String language = "es";
    String type = "movements";
    List<String> expected = new ArrayList<>();

    when(repository.listHeaders(language, type)).thenReturn(expected);

    List<String> result1 = service.listHeadersByLanguage(language, type);
    List<String> result2 = service.listHeadersByLanguage(language, type);

    verify(repository, Mockito.times(2)).listHeaders(language, type);
    assertTrue(result1.isEmpty());
    assertTrue(result2.isEmpty());
  }

  @Test
  public void testValidReturnDefault() {
    String esLanguage = "es";
    String defaultLanguage = "en";
    String type = "movements";
    List<String> emptyList = new ArrayList<>();
    List<String> expected = new ArrayList<>();
    expected.add("BIC");

    when(repository.listHeaders(esLanguage, type)).thenReturn(emptyList);
    when(repository.listHeaders(defaultLanguage, type)).thenReturn(expected);

    List<String> result1 = service.listHeadersByLanguageOrDefault(esLanguage, type);

    assertEquals(expected.get(0), result1.get(0));
  }
}
