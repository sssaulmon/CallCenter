package com.santander.scib.gtb.ic.gcm.util;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.LinkDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class LinkBuilderUtilTest {
  
  @Mock private TransactionPaginationUtil transactionPaginationUtil;
  private LinkBuilderUtil linkBuilderUtil;

  @Before
  public void setUp() {
    linkBuilderUtil = new LinkBuilderUtil(transactionPaginationUtil);
    when(transactionPaginationUtil.getLimit(any(TransactionDTO.class))).thenReturn(5, 5);
  }

  @Test
  public void givenTransactionDtWithNullLimitWhenBuildThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .next("/balances/bicaccountcurrency/transactions?limit=5&bc_offset=5")
      .build();
    LinkDTO responseLinkDTO = linkBuilderUtil.build(buildTransactionDto(null, null, null), 5, null);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  @Test
  public void givenTransactionDtWithLimitWhenBuildThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .prev("/balances/bicaccountcurrency/transactions?limit=5&bc_offset=0")
      .next("/balances/bicaccountcurrency/transactions?limit=5&bc_offset=10")
      .build();

    LinkDTO responseLinkDTO = linkBuilderUtil.build(buildTransactionDto(5, 5, null), 5, null);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  @Test
  public void givenTransactionDtWithBdResponseLessThanLimitWhenBuildThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .prev("/balances/bicaccountcurrency/transactions?limit=5&bc_offset=0")
      .build();
    LinkDTO responseLinkDTO = linkBuilderUtil.build(buildTransactionDto(5, 5, null), 4, null);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  @Test
  public void givenOnlineTransactionsWithNullLimitWhenBuildThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .next("/balances/bicaccountcurrency/transactions?limit=5&offset=5")
      .build();
    LinkDTO responseLinkDTO = linkBuilderUtil.build(buildTransactionDto(null, null, null, "5", null), null, 5);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  @Test
  public void givenOnlineTransactionsWithLimitWhenBuildThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .prev("/balances/bicaccountcurrency/transactions?limit=5&offset=1")
      .next("/balances/bicaccountcurrency/transactions?limit=5&offset=10")
      .build();

    LinkDTO responseLinkDTO = linkBuilderUtil.build(buildTransactionDto(5, null, "5", "10", "1"), null, 5);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  @Test
  public void givenOnlineTransactionsWithResponseLessThanLimitWhenBuildThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .build();
    LinkDTO responseLinkDTO = linkBuilderUtil.build(buildTransactionDto(5, null, "5"), null, 4);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  @Test
  public void givenOnlineAndCacheTransactionsWithNullLimitWhenBuildThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .next("/balances/bicaccountcurrency/transactions?limit=5&bc_offset=1&offset=4")
      .build();
    LinkDTO responseLinkDTO = linkBuilderUtil.build(buildTransactionDto(null, null, null, "4", null), 1, 4);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  @Test
  public void givenOnlineAndCacheTransactionsWithLimitWhenBuildThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .next("/balances/bicaccountcurrency/transactions?limit=5&bc_offset=2&offset=8")
      .build();

    LinkDTO responseLinkDTO = linkBuilderUtil.build(buildTransactionDto(5, null, "5", "8", null), 2, 3);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  @Test
  public void givenOnlineAndCacheTransactionsWithLimitAndNoMoreOnlineWhenBuildThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .next("/balances/bicaccountcurrency/transactions?limit=5&bc_offset=5&offset=5")
      .build();

    LinkDTO responseLinkDTO = linkBuilderUtil.build(buildTransactionDto(5, null, "5", "5", null), 5, 0);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  @Test
  public void givenOnlineAndCacheTransactionsWithResponseLessThanLimitWhenBuildThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .build();
    LinkDTO responseLinkDTO = linkBuilderUtil.build(buildTransactionDto(5, null, "5"), 2, 2);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  @Test
  public void givenOnlineAndCacheTransactionsWithResponseLessThanLimitAndNoFirstPageWhenBuildThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .prev("/balances/bicaccountcurrency/transactions?limit=5&bc_offset=0")
      .build();
    LinkDTO responseLinkDTO = linkBuilderUtil.build(buildTransactionDto(5, 5, "10"), 2, 2);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  @Test
  public void givenSpainOnlineAndCacheTransactionsWithResponseLessThanLimitAndNoFirstPageWhenBuildThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .prev("/balances/bicaccountcurrency/transactions?limit=5&offset=2020112300000000000099999004900013000040530a")
      .next("/balances/bicaccountcurrency/transactions?limit=5&offset=2020112300000000000099999004900013000040530b")
      .build();
    LinkDTO responseLinkDTO = linkBuilderUtil.build(buildTransactionDto(5, null, "2020112300000000000099999004900013000040530f",
      "2020112300000000000099999004900013000040530b", "2020112300000000000099999004900013000040530a"), null, 2);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  @Test
  public void givenTransactionDtWithNoResult_WhenBuildLink_ThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .build();
    TransactionDTO build = TransactionDTO.builder()
      .bic("bic")
      .accountId("account")
      .currency("currency")
      .prevOffsetFromApi("0")
      .nextOffsetFromApi("0")
      .build();
    LinkDTO responseLinkDTO = linkBuilderUtil.build(build, null, null);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  @Test
  public void givenTransactionDtWithSamePrevAndNext_WhenBuildLink_ThenReturnLinkDTO() {
    LinkDTO expectedLinkDTO = LinkDTO.builder()
      .first("/balances/bicaccountcurrency/transactions?limit=5")
      .prev("/balances/bicaccountcurrency/transactions?limit=5&offset=36")
      .build();
    TransactionDTO build = TransactionDTO.builder()
      .bic("bic")
      .accountId("account")
      .currency("currency")
      .prevOffsetFromApi("36")
      .nextOffsetFromApi("41")
      .lastOffsetFromApi("41")
      .build();
    LinkDTO responseLinkDTO = linkBuilderUtil.build(build, null, null);
    assertThat(responseLinkDTO.getFirst()).isEqualTo(expectedLinkDTO.getFirst());
    assertThat(responseLinkDTO.getPrev()).isEqualTo(expectedLinkDTO.getPrev());
    assertThat(responseLinkDTO.getNext()).isEqualTo(expectedLinkDTO.getNext());
  }

  private TransactionDTO buildTransactionDto(Integer limit, Integer bcOffset, String offset) {
    return buildTransactionDto(limit, bcOffset, offset, null, null);
  }

  private TransactionDTO buildTransactionDto(Integer limit, Integer bcOffset, String offset, String nextOffset,
                                             String previousOffset) {
    return TransactionDTO.builder()
      .bic("bic")
      .accountId("account")
      .currency("currency")
      .limit(limit)
      .bcOffset(bcOffset)
      .offset(offset)
      .nextOffsetFromApi(nextOffset)
      .prevOffsetFromApi(previousOffset)
      .build();
  }
}