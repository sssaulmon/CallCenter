package com.santander.scib.gtb.ic.gcm.service.balance.chain.chains;

import com.isban.gcb.ic.commons.model.BalanceCache;
import com.isban.gcb.ic.commons.model.Extract;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.mapper.TransactionMapper;
import com.santander.scib.gtb.ic.gcm.repository.BalanceCacheRepository;
import com.santander.scib.gtb.ic.gcm.repository.ExtractMovementRepository;
import com.santander.scib.gtb.ic.gcm.service.AccountsService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class IcChainTest {

  @Mock private BalanceCacheRepository balanceCacheRepository;
  @Mock private ExtractMovementRepository movementRepository;
  @Mock private TransactionMapper mapper;
  @Mock private AccountsService accountsService;

  private IcChain icChain;
  private TransactionDTO transactionDTO;
  private BalanceCache balanceCache;

  @Before
  public void setUp() {
    icChain = new IcChain();
    transactionDTO = TransactionDTO.builder().build();
    balanceCache = new BalanceCache();
    Extract extract = new Extract();
    extract.setId(1L);
    balanceCache.setExtract(extract);
    ReflectionTestUtils.setField(icChain, "balanceCacheRepository", balanceCacheRepository);
  }

  @Test
  public void testIntrWillReturnTrueTest() {
    balanceCache.setBalanceType("INTR");

    when(balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrency(any(), any(), any(), any()))
      .thenReturn(Optional.of(balanceCache));

    assertTrue(icChain.test(transactionDTO));
  }

  @Test
  public void testIntrWithAccountingDateWillReturnTrueTest() {
    balanceCache.setBalanceType("INTR");
    transactionDTO.setAccountingDate(LocalDate.now());

    when(balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrencyAndAccountingDateLessThanEqual(any(), any(), any(), any(), any()))
      .thenReturn(Optional.of(balanceCache));

    assertTrue(icChain.test(transactionDTO));
  }

  @Test
  public void testFindWillReturnTrueTest() {
    balanceCache.setBalanceType("FIND");

    when(balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrency(any(), any(), any(), any()))
      .thenReturn(Optional.of(balanceCache));

    assertTrue(icChain.test(transactionDTO));
  }

  @Test
  public void testFindWithAccountigDateWillReturnTrueTest() {
    balanceCache.setBalanceType("FIND");
    transactionDTO.setAccountingDate(LocalDate.now());

    when(balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrencyAndAccountingDateLessThanEqual(any(), any(), any(), any(), any()))
      .thenReturn(Optional.of(balanceCache));

    assertTrue(icChain.test(transactionDTO));
  }

  @Test
  public void testOnlineWillReturnFalseTest() {
    balanceCache.setBalanceType("ONLI");
    balanceCache.setExtract(null);

    when(balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrency(any(), any(), any(), any()))
      .thenReturn(Optional.of(balanceCache));

    assertFalse(icChain.test(transactionDTO));
  }
}
