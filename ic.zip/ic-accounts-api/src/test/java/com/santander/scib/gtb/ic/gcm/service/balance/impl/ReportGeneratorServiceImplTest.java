package com.santander.scib.gtb.ic.gcm.service.balance.impl;

import com.isban.gcb.ic.commons.model.GlobalReport;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.download.DownloadApiResponse;
import com.santander.scib.gtb.ic.gcm.contract.service.IntradiaStorageClientService;
import com.santander.scib.gtb.ic.gcm.repository.GlobalReportRepository;
import com.santander.scib.gtb.ic.gcm.test.utils.TestUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ReportGeneratorServiceImplTest {

  @Mock private GlobalReportRepository globalReportRepository;
  @Mock private IntradiaStorageClientService intradiaStorageClientService;
  private final List<String> statusReport = Arrays.asList("Generado OK", "Solicitado");
  private ReportGeneratorServiceImpl service;

  @Before
  public void setUp() {
    service = new ReportGeneratorServiceImpl(globalReportRepository,
      intradiaStorageClientService, statusReport);
  }

  @Test
  public void getGenerateReportsTest() {
    String uuid = "TEST";
    GlobalReport globalReport = TestUtils.loadObject("generate-file/response/globalReportResponse.json", GlobalReport.class);
    List<GlobalReport> reports = new LinkedList<>();
    reports.add(globalReport);
    when(globalReportRepository.findByUuidGlobalReportAndStatusInOrderByAccountingDateDesc(any(), any()))
      .thenReturn(Optional.of(reports));

    List<DownloadApiResponse> result = service.getGenerateReports(uuid);
    assertNotNull(result);
    assertEquals(1, result.size());
  }

  @Test
  public void getGenerateOneZipReportsTest() throws MalformedURLException {
    String uuid = "TEST";
    List<Long> ids = Collections.singletonList(1L);
    GlobalReport globalReport = TestUtils.loadObject("generate-file/response/globalReportResponse.json", GlobalReport.class);
    List<GlobalReport> reports = Collections.singletonList(globalReport);
    when(globalReportRepository.findAllById(any())).thenReturn(reports);
    when(intradiaStorageClientService.getZip(any(), any())).thenReturn(new URL("http://180.180.4.98/gcb-des-ln-ci/ZIPS/test-saul_2020-08-14_12%3A21.zip?response-content-disposition=attachment%3B%20filename%3Dtest-saul_2020-08-14_12%3A21.zip&response-content-encoding=UTF-8&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20200814T102129Z&X-Amz-SignedHeaders=host&X-Amz-Expires=299&X-Amz-Credential=TW8M5ROONN39AN8INZ1I%2F20200814%2Fboaw%2Fs3%2Faws4_request&X-Amz-Signature=a7cf7d1868d8ae193f7fb5c7df562d2b9e11f82b6466a0e51ff604504f3d11fb"));

    DownloadApiResponse result = service.getGenerateZip(uuid, ids);
    assertNotNull(result);
    assertEquals("TEST2020-04-22T090000.zip", result.getFileName());
  }

  @Test
  public void getGenerateOneMultipleReportsTest() throws MalformedURLException {
    String uuid = "TEST";
    List<Long> ids = Arrays.asList(1L, 2L);
    List<GlobalReport> reports = TestUtils.listObject("generate-file/response/globalReports.json", GlobalReport.class);
    when(globalReportRepository.findAllById(any())).thenReturn(reports);
    when(intradiaStorageClientService.getZip(any(), any())).thenReturn(new URL("http://180.180.4.98/gcb-des-ln-ci/ZIPS/test-saul_2020-08-14_12%3A21.zip?response-content-disposition=attachment%3B%20filename%3Dtest-saul_2020-08-14_12%3A21.zip&response-content-encoding=UTF-8&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20200814T102129Z&X-Amz-SignedHeaders=host&X-Amz-Expires=299&X-Amz-Credential=TW8M5ROONN39AN8INZ1I%2F20200814%2Fboaw%2Fs3%2Faws4_request&X-Amz-Signature=a7cf7d1868d8ae193f7fb5c7df562d2b9e11f82b6466a0e51ff604504f3d11fb"));

    DownloadApiResponse result = service.getGenerateZip(uuid, ids);
    assertNotNull(result);
    assertEquals("REPORTS_ALL.zip", result.getFileName());
  }
}