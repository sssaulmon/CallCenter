package com.santander.scib.gtb.ic.gcm.service.strategy;

import com.santander.scib.gtb.ic.gcm.web.exception.InvalidResourceTypeException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest
@RunWith(SpringRunner.class)
public class ResourceTypeContextTest {

  @Autowired private ResourceTypeContext resourceTypeContext;

  @Test(expected = InvalidResourceTypeException.class)
  public void invalidResourceTypeResolve() {
    resourceTypeContext.resolve("INVALID");
  }
}