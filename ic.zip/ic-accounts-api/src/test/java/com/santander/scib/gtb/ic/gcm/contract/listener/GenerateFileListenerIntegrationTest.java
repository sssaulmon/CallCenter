package com.santander.scib.gtb.ic.gcm.contract.listener;

import com.santander.scib.gtb.ic.gcm.communication.binding.GenerateFileOutputBinding;
import com.santander.scib.gtb.ic.gcm.contract.binding.GenerateFileInputBinding;
import com.santander.scib.gtb.ic.gcm.model.GenerateFileRequestDTO;
import com.santander.scib.gtb.ic.gcm.test.utils.TestUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.stream.test.binder.MessageCollector;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

@SpringBootTest
@EmbeddedKafka
@RunWith(SpringRunner.class)
@ActiveProfiles("integration")
public class GenerateFileListenerIntegrationTest {

  @Autowired private MessageCollector messageCollector;
  @Autowired private GenerateFileInputBinding generateFileInputBinding;
  @Autowired private GenerateFileOutputBinding generateFileOutputBinding;

  @Test
  public void invalidInputGenerateFileMovementsTest() {
    GenerateFileRequestDTO payload = TestUtils.loadObject("generate-file/request/failInputMovementsRequest.json", GenerateFileRequestDTO.class);

    Optional.of(payload)
      .map(MessageBuilder::withPayload)
      .map(MessageBuilder::build)
      .ifPresent(generateFileInputBinding.generateFileRequest()::send);

    String messageResult = getMessageResult(GenerateFileOutputBinding::generateFileResponse);
    GenerateFileRequestDTO result = TestUtils.loadContent(messageResult, GenerateFileRequestDTO.class);
    GenerateFileRequestDTO expected = TestUtils.loadObject("generate-file/response/failInputMovementsResponse.json", GenerateFileRequestDTO.class);
    Assert.assertEquals(expected.getStatus(), result.getStatus());
  }

  @Test
  public void okGenerateFileMovementsTest() {
    GenerateFileRequestDTO payload = TestUtils.loadObject("generate-file/request/inputMovementsRequest.json", GenerateFileRequestDTO.class);

    Optional.of(payload)
      .map(MessageBuilder::withPayload)
      .map(MessageBuilder::build)
      .ifPresent(generateFileInputBinding.generateFileRequest()::send);

    String messageResult = getMessageResult(GenerateFileOutputBinding::generateFileResponse);
    GenerateFileRequestDTO result = TestUtils.loadContent(messageResult, GenerateFileRequestDTO.class);
    GenerateFileRequestDTO expected = TestUtils.loadObject("generate-file/response/okInputMovementsResponse.json", GenerateFileRequestDTO.class);
    Assert.assertEquals(expected.getStatus(), result.getStatus());
  }

  @Test
  public void notFoundGenerateFileMovementsTest() {
    GenerateFileRequestDTO payload = TestUtils.loadObject("generate-file/request/inputMovementsRequestNotFound.json", GenerateFileRequestDTO.class);

    Optional.of(payload)
      .map(MessageBuilder::withPayload)
      .map(MessageBuilder::build)
      .ifPresent(generateFileInputBinding.generateFileRequest()::send);

    String messageResult = getMessageResult(GenerateFileOutputBinding::generateFileResponse);
    GenerateFileRequestDTO result = TestUtils.loadContent(messageResult, GenerateFileRequestDTO.class);
    Assert.assertEquals("Internal Error", result.getStatus());
  }

  @Test
  public void okGenerateFileMovementsWithCustomizationTest() {
    GenerateFileRequestDTO payload = TestUtils.loadObject("generate-file/request/inputMovementsWithCustomizationRequest.json", GenerateFileRequestDTO.class);

    Optional.of(payload)
      .map(MessageBuilder::withPayload)
      .map(MessageBuilder::build)
      .ifPresent(generateFileInputBinding.generateFileRequest()::send);

    String messageResult = getMessageResult(GenerateFileOutputBinding::generateFileResponse);
    GenerateFileRequestDTO result = TestUtils.loadContent(messageResult, GenerateFileRequestDTO.class);
    GenerateFileRequestDTO expected = TestUtils.loadObject("generate-file/response/okInputMovementsWithCustomizationResponse.json", GenerateFileRequestDTO.class);
    Assert.assertEquals(expected.getStatus(), result.getStatus());
  }

  @Test
  public void invalidCustomizationGenerateFileMovementsTest() {
    GenerateFileRequestDTO payload = TestUtils.loadObject("generate-file/request/invalidCustomizationInputMovementsRequest.json", GenerateFileRequestDTO.class);

    Optional.of(payload)
      .map(MessageBuilder::withPayload)
      .map(MessageBuilder::build)
      .ifPresent(generateFileInputBinding.generateFileRequest()::send);

    String messageResult = getMessageResult(GenerateFileOutputBinding::generateFileResponse);
    GenerateFileRequestDTO result = TestUtils.loadContent(messageResult, GenerateFileRequestDTO.class);
    GenerateFileRequestDTO expected = TestUtils.loadObject("generate-file/response/invalidCustomizationInputMovementsResponse.json", GenerateFileRequestDTO.class);
    Assert.assertEquals(expected.getStatus(), result.getStatus());
  }

  @Test
  public void okGenerateFileBalanceTest() {
    GenerateFileRequestDTO payload = TestUtils.loadObject("generate-file/request/inputBalanceRequest.json", GenerateFileRequestDTO.class);

    Optional.of(payload)
      .map(MessageBuilder::withPayload)
      .map(MessageBuilder::build)
      .ifPresent(generateFileInputBinding.generateFileRequest()::send);

    String messageResult = getMessageResult(GenerateFileOutputBinding::generateFileResponse);
    GenerateFileRequestDTO result = TestUtils.loadContent(messageResult, GenerateFileRequestDTO.class);
    GenerateFileRequestDTO expected = TestUtils.loadObject("generate-file/response/okInputBalanceResponse.json", GenerateFileRequestDTO.class);
    Assert.assertEquals(expected.getStatus(), result.getStatus());
  }

  @Test
  public void invalidResourceTypePayloadGenerateFileBalanceTest() {
    GenerateFileRequestDTO payload = TestUtils.loadObject("generate-file/request/invalidResourceTypeBalanceRequest.json", GenerateFileRequestDTO.class);

    Optional.of(payload)
      .map(MessageBuilder::withPayload)
      .map(MessageBuilder::build)
      .ifPresent(generateFileInputBinding.generateFileRequest()::send);

    String messageResult = getMessageResult(GenerateFileOutputBinding::generateFileResponse);
    GenerateFileRequestDTO result = TestUtils.loadContent(messageResult, GenerateFileRequestDTO.class);
    GenerateFileRequestDTO expected = TestUtils.loadObject("generate-file/response/invalidResourceTypeInputMovementsResponse.json", GenerateFileRequestDTO.class);
    Assert.assertEquals(expected.getStatus(), result.getStatus());
  }

  private String getMessageResult(Function<GenerateFileOutputBinding, MessageChannel> messageChannelFunction) {
    return Optional.of(generateFileOutputBinding)
      .map(messageChannelFunction)
      .map(messageCollector::forChannel)
      .map(message -> {
        try {
          return message.poll(10, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
          throw new RuntimeException();
        }
      })
      .map(Message::getPayload)
      .map(String.class::cast)
      .orElse(null);
  }
}
