package com.santander.scib.gtb.ic.gcm.util;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

public class AccountSplitUtilTest {
  private String account = "BSCHESMMXXX00350003000003915832CLP";

  @Test
  public void getBIC() {
    String bic = AccountSplitUtil.getBic(account);
    Assert.assertEquals("BSCHESMMXXX", bic);
  }

  @Test
  public void getAccountId() {
    String accountId = AccountSplitUtil.getAccountId(account);
    Assert.assertEquals("00350003000003915832", accountId);
  }

  @Test
  public void getCurrency() {
    String currency = AccountSplitUtil.getCurrency(account);
    Assert.assertEquals("CLP", currency);
  }
}
