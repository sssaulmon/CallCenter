package com.santander.scib.gtb.ic.gcm.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.gtb.ic.gcm.api.balance.model.global.transactions.GlobalTransactionResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionResponse;
import com.santander.scib.gtb.ic.gcm.test.utils.TestUtils;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.io.IOException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@RunWith(SpringRunner.class)
@ActiveProfiles("integration")
public class V2CalculatedOffsetTest {

  private final HttpHeaders httpHeaders = new HttpHeaders();
  private final MockWebServer mockWebServer = new MockWebServer();

  @Autowired private MockMvc mockMvc;
  @Autowired private ObjectMapper mapper;

  @Before
  public void setup() throws IOException {
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    httpHeaders.add("X-Santander-Global-Id", "123456");
    httpHeaders.add("Authorization", TestUtils.loadResource("security/bearer.txt"));

    mockWebServer.start(6429);
  }

  @After
  public void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  public void givenUkAccount_whenCallTransactions_thenSuccessfulResponse() throws Exception {
    AccountTransactionResponse expected = loadExpected("strategies/responses/apis/v2/transactions/ABBYGB2LXXX09022210205699GBP/expected.json");
    mockWebServerCalls("strategies/responses/apis/v2/transactions/ABBYGB2LXXX09022210205699GBP/from_global.json");
    MvcResult result = getMvcResult("/balances/ABBYGB2LXXX09022210205699GBP/transactions", "3");

    AccountTransactionResponse response = mapper.readValue(result.getResponse().getContentAsString(), AccountTransactionResponse.class);
    // Offset for this one is regular 
    assertThat(response).isEqualToComparingFieldByField(expected);
  }

  @Test
  public void givenBraAccount_whenCallTransactions_thenSuccessfulResponse() throws Exception {
    AccountTransactionResponse expected = loadExpected("strategies/responses/apis/v2/transactions/BSCHBRSPXXXBSCHLUL0USD22006129796USD/expected.json");
    mockWebServerCalls("strategies/responses/apis/v2/transactions/BSCHBRSPXXXBSCHLUL0USD22006129796USD/from_global.json");
    MvcResult result = getMvcResult("/balances/BSCHBRSPXXXBSCHLUL0USD22006129796USD/transactions", "1");

    AccountTransactionResponse response = mapper.readValue(result.getResponse().getContentAsString(), AccountTransactionResponse.class);
    // Offset for this one means current page
    assertThat(response).isEqualToComparingFieldByField(expected);
  }

  private AccountTransactionResponse loadExpected(String file) {
    return TestUtils.loadObject(file, AccountTransactionResponse.class);
  }

  private void mockWebServerCalls(String file) throws JsonProcessingException {
    mockWebServer.enqueue(createMockResponse("{\"token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockWebServer.enqueue(createMockResponse("{\"access_token\": \"eyJraWQiOiJzdHNfU0hBMXdpdGh\"}"));
    mockWebServer.enqueue(createMockResponse(mapper.writeValueAsString(TestUtils.loadObject(file, GlobalTransactionResponse.class))));
  }

  private MockResponse createMockResponse(String body) {
    return new MockResponse()
      .setResponseCode(200)
      .setBody(body)
      .addHeader("Content-Type", MediaType.APPLICATION_JSON);
  }

  private MvcResult getMvcResult(String url, String offset) throws Exception {
    return mockMvc.perform(get(url)
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON_VALUE)
      .param("limit", "3")
      .param("offset", offset))
      .andExpect(status().isOk())
      .andReturn();
  }
}
