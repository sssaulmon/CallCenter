package com.santander.scib.gtb.ic.gcm.model;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class BalanceCacheFlatTest {

  @Test
  public void testEqualsAndHashCode() {
    BalanceCacheFlat a = new BalanceCacheFlat();
    a.setBic("BSCHBXMMXXX");
    a.setAccountCode("ACCOUNTCODE");
    a.setCurrency("EUR");
    a.setBalanceType("ONLI");
    BalanceCacheFlat b = new BalanceCacheFlat();
    b.setBic("BSCHBXMMXXX");
    b.setAccountCode("ACCOUNTCODE");
    b.setCurrency("EUR");
    b.setBalanceType("ONLI");
    BalanceCacheFlat c = new BalanceCacheFlat();
    c.setBic("BSCHBXMMXXX");
    c.setAccountCode("ACCOUNTCODE");
    c.setCurrency("USD");
    c.setBalanceType("ONLI");

    assertEquals(a, b);
    assertEquals(a, a);
    assertEquals(a.toString(), a.toString());
    assertEquals(a.hashCode(), b.hashCode());
    assertNotEquals(a, c);
    assertNotEquals(a, null);
    assertNotEquals(a, "");
  }
}
