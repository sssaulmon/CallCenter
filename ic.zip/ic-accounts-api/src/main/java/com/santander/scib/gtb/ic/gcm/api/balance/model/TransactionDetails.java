package com.santander.scib.gtb.ic.gcm.api.balance.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions.Amount;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactionDetails {

  @ApiModelProperty(example = "\"277746342\"", required = true, value = "Identify a specific transaction of the account_id.")
  @NotNull
  @JsonProperty("transactionId")
  private String transactionId;

  @ApiModelProperty(example = "\"20190314T014319060+0100\"", value = "Date of creation. ISO 8601. https://en.wikipedia.org/wiki/ISO_8601")
  @JsonProperty("creationDate")
  private String creationDate;

  @ApiModelProperty(example = "\"20190314T014319060+0100\"", value = "Date of processing. ISO 8601. https://en.wikipedia.org/wiki/ISO_8601")
  @JsonProperty("processedDate")
  private String processedDate;

  @ApiModelProperty(example = "\"20190314T014319060+0100\"", value = "Date of accounting. ISO 8601. https://en.wikipedia.org/wiki/ISO_8601")
  @JsonProperty("accountingDate")
  private String accountingDate;

  @ApiModelProperty(example = "\"20190314T014319060+0100\"", value = "Date of accounting. ISO 8601. https://en.wikipedia.org/wiki/ISO_8601")
  @JsonProperty("description")
  private String description;

  @ApiModelProperty(example = "\"C\"", value = "Identificate if an specific transaction is a debit \"D\" or credit \"C\"")
  @JsonProperty("transactionType")
  private String transactionType;

  @ApiModelProperty(example = "\"withdraw money\"", value = "Type of category for a transaction.")
  @JsonProperty("transactionCategory")
  private String transactionCategory;

  @ApiModelProperty(value = "Amount and currency of the transaction.")
  @JsonProperty("amount")
  private Amount amount;

  public String getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  public String getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(String creationDate) {
    this.creationDate = creationDate;
  }

  public String getProcessedDate() {
    return processedDate;
  }

  public void setProcessedDate(String processedDate) {
    this.processedDate = processedDate;
  }

  public String getAccountingDate() {
    return accountingDate;
  }

  public void setAccountingDate(String accountingDate) {
    this.accountingDate = accountingDate;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getTransactionType() {
    return transactionType;
  }

  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType;
  }

  public String getTransactionCategory() {
    return transactionCategory;
  }

  public void setTransactionCategory(String transactionCategory) {
    this.transactionCategory = transactionCategory;
  }

  public Amount getAmount() {
    return amount;
  }

  public void setAmount(Amount amount) {
    this.amount = amount;
  }
}
