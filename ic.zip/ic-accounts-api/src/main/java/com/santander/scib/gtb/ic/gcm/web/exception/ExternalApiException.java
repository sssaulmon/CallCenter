package com.santander.scib.gtb.ic.gcm.web.exception;

public class ExternalApiException extends RuntimeException {
  private Integer code;

  public ExternalApiException(String error) {
    super("Request to external API failed with error: " + error);
  }

  public ExternalApiException(String error, Integer code) {
    super("Request to external API failed with error: " + error);
    this.code = code;
  }

  public Integer getCode() {
    return code;
  }
}
