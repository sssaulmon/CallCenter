package com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.gtb.ic.gcm.api.balance.model.LocalOperation;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

public class SLBLocalOperation extends LocalOperation {

  @ApiModelProperty(example = "\"abono cheque\"", required = true, value = "Local Transaction Code (local transaction codes in order to facilitate multi local reconciliation without using SWIFT transaction codes) are the codes that define the type of transaction in the Local Entity.")
  @NotNull
  @JsonProperty("ltcDescription")
  private String ltcDescription;

  @Override
  public String getLtcDescription() {
    return ltcDescription;
  }

  @Override
  public void setLtcDescription(String ltcDescription) {
    this.ltcDescription = ltcDescription;
  }
}
