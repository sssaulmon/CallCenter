package com.santander.scib.gtb.ic.gcm.mapper;

import com.isban.gcb.ic.commons.balance.cache.dto.BalanceType;
import com.isban.gcb.ic.commons.model.BalanceCache;
import com.isban.gcb.ic.commons.model.Extract;
import com.isban.gcb.ic.commons.model.ExtractMovement;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionDTO;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static java.time.LocalTime.MIDNIGHT;

@Component
public class TransactionMapper {

  public AccountTransactionDTO movementToTransaction(ExtractMovement movement, TransactionDTO transactionDTO) {
    BalanceCache balanceCache = Optional.of(movement)
      .map(ExtractMovement::getExtract)
      .map(Extract::getBalanceCache)
      .orElseGet(() -> buildEmptyBalanceCache(movement));
    return new AccountTransactionDTO()
      .amount(calculateSign(movement.getAmount(), movement.getMark()))
      .currency(balanceCache.getCurrency())
      .valueDate(movement.getValueDate())
      .accountingDate(Optional.ofNullable(balanceCache.getAccountingDate())
        .map(LocalDateTime::toLocalDate)
        .orElse(null))
      .movementTime(Optional.ofNullable(movement.getMovementTime())
        .map(LocalDateTime::toLocalTime)
        .orElse(null))
      .description(movement.getMovementInfo())
      .origin(Optional.of(balanceCache.getBalanceType())
        .filter(type -> "FIND".equals(type) && balanceCache.hasBestTransactions())
        .map(type -> "INTR")
        .orElse(balanceCache.getBalanceType()))
      .additionalInfo(movement.getSupplementaryDetails())
      .balance(calculateSign(movement.getBookBalanceAmount(), movement.getBookBalanceMark()))
      .entryDate(movement.getEntryDate())
      .identificationCode(movement.getIdentificationCode())
      .accountOwner(movement.getCustomerReference())
      .accountServiceInstitution(movement.getInstitutionReference())
      .accountId(transactionDTO.getAccountId())
      .alias(Optional.ofNullable(movement.getExtract())
        .map(Extract::getAccountIdentification)
        .orElse(null));
  }

  private BalanceCache buildEmptyBalanceCache(ExtractMovement movement) {
    BalanceCache emptyBalance = new BalanceCache();
    emptyBalance.setBalanceType(getBalanceTypeFromExtract(movement));
    emptyBalance.setCurrency(getCurrencyFromExtract(movement));
    emptyBalance.setAccountingDate(getAccountingDateFromExtract(movement));
    return emptyBalance;
  }

  private String getBalanceTypeFromExtract(ExtractMovement movement) {
    return Optional.of(movement)
      .map(ExtractMovement::getExtract)
      .map(Extract::getType)
      .map(BalanceType::getBalanceType)
      .map(BalanceType::toString)
      .orElse(StringUtils.EMPTY);
  }

  private String getCurrencyFromExtract(ExtractMovement movement) {
    return Optional.of(movement)
      .map(ExtractMovement::getExtract)
      .map(Extract::getCurrency)
      .orElse(StringUtils.EMPTY);
  }

  private LocalDateTime getAccountingDateFromExtract(ExtractMovement movement) {
    return Optional.of(movement)
      .map(ExtractMovement::getExtract)
      .map(Extract::getDateTimeIndication)
      .orElseGet(() -> Optional.of(movement)
        .map(ExtractMovement::getExtract)
        .map(Extract::getClosingBalanceDate)
        .map(closingDate -> LocalDateTime.of(closingDate, MIDNIGHT))
        .orElse(LocalDateTime.now()));
  }

  private BigDecimal calculateSign(Double amount, String mark) {
    List<String> debit = Arrays.asList("D", "ED", "RC");
    return Optional.ofNullable(amount)
      .map(BigDecimal::valueOf)
      .map(value -> Optional.of(value)
        .filter(given -> debit.contains(mark))
        .map(BigDecimal::negate)
        .orElse(value))
      .orElse(null);
  }
}
