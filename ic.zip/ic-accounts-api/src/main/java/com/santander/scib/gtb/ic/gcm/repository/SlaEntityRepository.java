package com.santander.scib.gtb.ic.gcm.repository;

import com.isban.gcb.ic.commons.model.AssoCorpSubProductAcc;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SlaEntityRepository extends JpaRepository<AssoCorpSubProductAcc, Long> {

  Optional<AssoCorpSubProductAcc> findFirstByAccountInternationalNumberAndBicEntityAccAndCurrency(
    String internationalAccount, String bic, String currency);

  Optional<AssoCorpSubProductAcc> findFirstByAccountLocalNumberAndBicEntityAccAndCurrency(
    String localAccount, String bic, String currency);
}
