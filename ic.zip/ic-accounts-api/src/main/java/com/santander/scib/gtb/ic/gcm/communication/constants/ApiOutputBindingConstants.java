package com.santander.scib.gtb.ic.gcm.communication.constants;

public class ApiOutputBindingConstants {

  public static final String API_REQUEST_COMPLETED = "apiRequestCompleted";
  public static final String API_REQUEST_FAILED = "apiRequestFailed";
  public static final String API_GENERATE_FILE_REQUEST = "queing.ic.api.generate.file.request";
  public static final String API_GENERATE_FILE_RESPONSE = "queing.ic.api.generate.file.response";
}
