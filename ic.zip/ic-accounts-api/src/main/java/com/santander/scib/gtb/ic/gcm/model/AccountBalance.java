package com.santander.scib.gtb.ic.gcm.model;

import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;

// TODO dejar la interfaz sin metodo y generar un mapper que devuelva el objeto interfaz
// TODO El mapper (* recibe diferentes objetos) dependiendo de las api locales y devuelve una implementacion de esta interfaz
// TODO (*) generar una interfaz que defina con un solo nombre las respuestas de las apis locales e implementar las diferentes respuestas
public interface AccountBalance {

  AccountBalanceDTO mapToAccountBalanceDto();
}
