package com.santander.scib.gtb.ic.gcm.repository;

import com.isban.gcb.ic.commons.model.CountryBankEntity;
import com.isban.gcb.ic.commons.model.CountryBankEntityKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CountryBankEntityRepository extends JpaRepository<CountryBankEntity, CountryBankEntityKey> {

  Optional<CountryBankEntity> findByIdBic(String bic);
}
