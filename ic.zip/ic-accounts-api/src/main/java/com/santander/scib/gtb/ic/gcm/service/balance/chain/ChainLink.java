package com.santander.scib.gtb.ic.gcm.service.balance.chain;

public interface ChainLink<T, W> {

  boolean test(T t);

  W apply(T t);
}
