package com.santander.scib.gtb.ic.gcm.api.balance.model.account;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

public class ReferenceItem {

  @ApiModelProperty(example = "CF44-312-1234ABC197", required = true, value = "[16x] Client transaction identification (customer reference included in domestic electronic statament). If the field \"dlient transaction identification\" is not used for this particular sort of entry, \"NONREF\" must be used.")
  @NotNull
  @JsonProperty("transactionClientReference")
  private String transactionClientReference;

  @ApiModelProperty(example = "\"20180605-CONF135\"", required = true, value = "[16x]  (customer reference included in domestic electronic batch). If the field \"client batch identification\" is not used for this particular sort of entry, \"NONREF\" must be used.")
  @NotNull
  @JsonProperty("transactionBatchReference")
  private String transactionBatchReference;

  @ApiModelProperty(example = "\"1500CF321006HSK1\"", required = true, value = "[16x] Account servicing intitution´s internal reference. If there isn´t any information \"NONREF\" must be used.")
  @NotNull
  @JsonProperty("transactionInternalReference")
  private String transactionInternalReference;

  public void setTransactionClientReference(String transactionClientReference) {
    this.transactionClientReference = transactionClientReference;
  }

  public void setTransactionBatchReference(String transactionBatchReference) {
    this.transactionBatchReference = transactionBatchReference;
  }

  public void setTransactionInternalReference(String transactionInternalReference) {
    this.transactionInternalReference = transactionInternalReference;
  }

  public String getTransactionClientReference() {
    return transactionClientReference;
  }

  public String getTransactionInternalReference() {
    return transactionInternalReference;
  }
}

