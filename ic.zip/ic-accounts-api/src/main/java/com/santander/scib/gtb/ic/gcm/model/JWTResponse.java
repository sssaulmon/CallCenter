package com.santander.scib.gtb.ic.gcm.model;

public class JWTResponse {
  private String token;

  public String getToken() {
    return token;
  }

  public void setToken(String token) {
    this.token = token;
  }
}
