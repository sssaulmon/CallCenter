package com.santander.scib.gtb.ic.gcm.repository;

import com.isban.gcb.ic.commons.model.ServiceAccount;
import com.santander.scib.gtb.ic.gcm.model.ServiceAccountFlat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.util.Streamable;

import java.util.Collection;
import java.util.Optional;

public interface ServiceAccountRepository extends JpaRepository<ServiceAccount, Long> {

  Optional<ServiceAccount> findFirstByAliasAccClientAndAssoCorpSubProductAccBicEntityAccAndAssoCorpSubProductAccCurrency(
    String aliasAccount, String bic, String currency);

  @Query(value = "select DISTINCT new com.santander.scib.gtb.ic.gcm.model.ServiceAccountFlat(sa.assoCorpSubProductAcc.bicEntityAcc," +
    "sa.assoCorpSubProductAcc.uuidStructureAcc, sa.aliasAccClient, sa.assoCorpSubProductAcc.accountInternationalNumber," +
    "sa.assoCorpSubProductAcc.accountLocalNumber, sa.assoCorpSubProductAcc.currency)\n" +
    "from ServiceAccount sa \n" +
    "where (sa.assoCorpSubProductAcc.bicEntityAcc || sa.assoCorpSubProductAcc.accountInternationalNumber || sa.assoCorpSubProductAcc.currency  IN (:internationalLocalAccounts))\n" +
    "or (sa.assoCorpSubProductAcc.bicEntityAcc || sa.assoCorpSubProductAcc.accountLocalNumber || sa.assoCorpSubProductAcc.currency  IN (:internationalLocalAccounts))\n" +
    "or (sa.assoCorpSubProductAcc.bicEntityAcc || sa.aliasAccClient || sa.assoCorpSubProductAcc.currency  IN (:aliasAccounts))")
  Streamable<ServiceAccountFlat> findAccountUuid(@Param("aliasAccounts") Collection<String> aliasAccounts,
                                                 @Param("internationalLocalAccounts") Collection<String> internationalLocalAccounts);
}
