package com.santander.scib.gtb.ic.gcm.communication.constants;

public class GenerateFileOutputConstants {
  public static final String GENERATE_FILE_RESPONSE = "generateFileResponse";
  public static final String GENERATE_SAVE_REQUEST = "saveGenerateFileRequest";
}
