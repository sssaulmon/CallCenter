package com.santander.scib.gtb.ic.gcm.service;

import com.isban.gcb.ic.commons.model.CountryBankEntity;
import com.santander.scib.gtb.ic.gcm.api.balance.model.ApiTypeEnum;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.api.MappedTransaction;
import com.santander.scib.gtb.ic.gcm.model.AccountBalance;
import com.santander.scib.gtb.ic.gcm.model.app.entity.AppEntity;
import com.santander.scib.gtb.ic.gcm.oauthstrategy.CountryContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.Function;

import static com.isban.gcb.ic.commons.util.function.FunctionalUtils.peek;
import static com.santander.scib.gtb.ic.gcm.api.balance.version.TransactionApiVersion.getTransactionApiType;

@Service
public class AccountsService {

  @Autowired private Function<String, AppEntity> appEntityFactory;
  @Autowired private CountryContext countryContext;
  @Autowired private ConvertAmountByCurrencyService convertAmountByCurrencyService;
  @Autowired private CountryBankService countryBankService;

  // TODO bring version to this method and invoke AccountApiVersion::getAccountApiType line: 47
  public CompletionStage<AccountBalanceDTO> getAccount(
    String bic, String accountId, String currency, String alias, LocalDate accountingDate) {
    AppEntity appEntity = getAppEntity(bic);

    return Optional.ofNullable(appEntity)
      .filter(AppEntity::isEnabled)
      .map(AppEntity::getOrigin)
      .map(countryContext::resolve)
      .map(strategy -> strategy.getAccounts(
        appEntity, bic, accountId, currency, accountingDate, ApiTypeEnum.getAccountApiType(appEntity.getOrigin())))
      .map(mono -> transform(mono, bic, accountId, alias))
      .map(Mono::toFuture)
      .orElse(CompletableFuture.completedFuture(null));
  }

  private <T extends AccountBalance> Mono<AccountBalanceDTO> transform(Mono<T> input, String bic, String accountId,
                                                                       String alias) {
    return input.map(AccountBalance::mapToAccountBalanceDto)
      .map(accountBalanceDTO -> accountBalanceDTO.bic(bic))
      .map(accountBalanceDTO -> accountBalanceDTO.accountId(accountId))
      .map(accountBalanceDTO -> accountBalanceDTO.alias(alias))
      .map(this::setAccountDateTime)
      .map(convertAmountByCurrencyService::convertAccountBalance);
  }

  public MappedTransaction getAccountTransactions(TransactionDTO transactionDTO) {
    AppEntity appEntity = getAppEntity(transactionDTO.getBic());

    return Optional.ofNullable(appEntity)
      .filter(AppEntity::isEnabled)
      .map(AppEntity::getOrigin)
      .map(countryContext::resolve)
      .map(strategy -> strategy.getTransactions(
        appEntity, transactionDTO, getTransactionApiType(transactionDTO.getVersion(), appEntity.getOrigin())))
      .orElse(null);
  }

  private AppEntity getAppEntity(String bic) {
    String entity = bic.toLowerCase();
    return appEntityFactory.apply(entity);
  }

  /**
   * Sets {@link AccountBalanceDTO#getAccountingDate()} and {@link AccountBalanceDTO#getAccountingTime()} attending to
   * {@link AccountBalanceDTO#getBic()}
   *
   * @param accountBalanceDTO the account balance
   * @return the same {@link AccountBalanceDTO} with updated 'accountingDate' and 'accountingTime'
   */
  private AccountBalanceDTO setAccountDateTime(AccountBalanceDTO accountBalanceDTO) {
    countryBankService.findByBic(accountBalanceDTO.getBic())
      .map(CountryBankEntity::getZoneId)
      .map(ZoneId::of)
      .map(peek(zoneId -> accountBalanceDTO.accountingDate(LocalDate.now(zoneId))))
      .map(peek(zoneId -> accountBalanceDTO.accountingTime(LocalTime.now(zoneId).truncatedTo(ChronoUnit.SECONDS))))
      .orElseThrow(RuntimeException::new);
    return accountBalanceDTO;
  }
}
