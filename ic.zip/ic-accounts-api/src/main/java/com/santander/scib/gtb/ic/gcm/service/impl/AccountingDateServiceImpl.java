package com.santander.scib.gtb.ic.gcm.service.impl;

import com.isban.gcb.ic.commons.model.CountryBankEntity;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.repository.BalanceCacheRepository;
import com.santander.scib.gtb.ic.gcm.service.AccountingDateService;
import com.santander.scib.gtb.ic.gcm.service.CountryBankService;
import com.santander.scib.gtb.ic.gcm.util.TransactionPaginationUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoField;

@Service
public class AccountingDateServiceImpl implements AccountingDateService {

  @Autowired private BalanceCacheRepository balanceCacheRepository;
  @Autowired private CountryBankService countryBankService;
  @Autowired private TransactionPaginationUtil paginationUtil;

  @Override
  public ZonedDateTime getFromAccountingDate(TransactionDTO transactionDTO) {
    LocalDateTime limitDate = buildAccountingDate();
    LocalDateTime accountingDate = balanceCacheRepository.findMaxAccountingDate(transactionDTO.getBic(),
      transactionDTO.getAccountUuid(), transactionDTO.getCurrency(), limitDate)
      .map(date -> date.plusDays(1))
      .map(date -> date.with(ChronoField.HOUR_OF_DAY, 0))
      .map(date -> date.with(ChronoField.MINUTE_OF_DAY, 0))
      .map(date -> date.with(ChronoField.SECOND_OF_DAY, 0))
      .orElse(limitDate);

    return countryBankService.findByBic(transactionDTO.getBic())
      .map(CountryBankEntity::getZoneId)
      .map(ZoneId::of)
      .map(accountingDate::atZone)
      .orElseThrow(RuntimeException::new);
  }

  private LocalDateTime buildAccountingDate() {
    return LocalDateTime.now().minusDays(paginationUtil.getLimitInDays());
  }
}
