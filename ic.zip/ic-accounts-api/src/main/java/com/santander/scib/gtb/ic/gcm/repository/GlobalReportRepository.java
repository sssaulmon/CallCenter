package com.santander.scib.gtb.ic.gcm.repository;

import com.isban.gcb.ic.commons.model.GlobalReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface GlobalReportRepository extends JpaRepository<GlobalReport, Long> {

  Optional<List<GlobalReport>> findByUuidGlobalReportAndStatusInOrderByAccountingDateDesc(String uuid, List<String> status);

  Streamable<GlobalReport> findByServiceSendChannelAndLastModifiedDateLessThanAndStatusIsNot(String serviceSendChannel,
                                                                                             LocalDateTime lastModifiedDateStart,
                                                                                             String status);
}
