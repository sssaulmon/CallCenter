package com.santander.scib.gtb.ic.gcm.service.balance.chain.chains;

import com.isban.gcb.ic.commons.model.BalanceCache;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.api.MappedTransaction;
import com.santander.scib.gtb.ic.gcm.mapper.ApiCommunicationMapper;
import com.santander.scib.gtb.ic.gcm.mapper.TransactionMapper;
import com.santander.scib.gtb.ic.gcm.repository.BalanceCacheRepository;
import com.santander.scib.gtb.ic.gcm.repository.ExtractMovementRepository;
import com.santander.scib.gtb.ic.gcm.service.AccountsService;
import com.santander.scib.gtb.ic.gcm.service.balance.chain.ChainLink;
import com.santander.scib.gtb.ic.gcm.util.TransactionPaginationUtil;
import com.santander.scib.gtb.ic.gcm.web.exception.ExternalApiException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.isban.gcb.ic.commons.balance.cache.dto.BalanceType.ONLINE;
import static com.santander.scib.gtb.ic.gcm.repository.BalanceCacheRepository.BY_ACCOUNTING_DATE_DESC;
import static com.santander.scib.gtb.ic.gcm.util.AccountingDateUtil.atEndOfDay;
import static com.santander.scib.gtb.ic.gcm.util.AccountingDateUtil.getFromAccountingDate;
import static com.santander.scib.gtb.ic.gcm.util.AccountingDateUtil.getToAccountingDate;

@Slf4j
@Component
@Qualifier("OnlineChain")
public class OnlineChain implements ChainLink<TransactionDTO, AccountTransactionResponse> {

  @Value("${apis.onlineReportLimit}") private int onlineReportLimit;
  @Value("${transactions.limit.export}") private int exportLimit;
  @Autowired private BalanceCacheRepository balanceCacheRepository;
  @Autowired private ExtractMovementRepository movementRepository;
  @Autowired private TransactionMapper mapper;
  @Autowired private ApiCommunicationMapper apiMapper;
  @Autowired private AccountsService accountsService;
  @Autowired private TransactionPaginationUtil paginationUtil;
  @Autowired private ApiCommunicationMapper apiCommunicationMapper;

  @Override
  public boolean test(TransactionDTO transactionDTO) {
    return Optional.ofNullable(transactionDTO)
      .map(TransactionDTO::getBcOffset)
      .map(bcOffset -> Boolean.FALSE)
      .orElse(isOnline(transactionDTO));
  }

  private Boolean isOnline(TransactionDTO transactionDTO) {
    return Optional.ofNullable(transactionDTO)
      .map(TransactionDTO::getOffset)
      .map(offset -> Boolean.TRUE)
      .orElse(isOnlineByCache(transactionDTO));
  }

  private boolean isOnlineByCache(TransactionDTO transactionDTO) {
    return getLastBalanceCache(transactionDTO)
      .map(BalanceCache::getBalanceType)
      .filter(str -> str.equals(ONLINE.toString()))
      .isPresent();
  }

  @Override
  public AccountTransactionResponse apply(TransactionDTO transactionDTO) {
    log.info("Applying the ONLINE strategy");
    return Optional.of(transactionDTO)
      .map(this::getAccountTransactions)
      .map(given -> completeWithBalanceCacheData(given, transactionDTO))
      .map(transactions -> apiCommunicationMapper.toTransactionResponse(transactions, transactionDTO))
      .orElseThrow(() -> new ExternalApiException("Error performing call to external API"));
  }

  private Optional<BalanceCache> getLastBalanceCache(TransactionDTO transactionDTO) {
    return Optional.ofNullable(transactionDTO.getAccountingDate())
      .map(date -> balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrencyAndAccountingDateLessThanEqual(transactionDTO.getBic(), transactionDTO.getAccountUuid(),
        transactionDTO.getCurrency(), atEndOfDay(date), BY_ACCOUNTING_DATE_DESC))
      .orElse(balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrency(transactionDTO.getBic(), transactionDTO.getAccountUuid(),
        transactionDTO.getCurrency(), BY_ACCOUNTING_DATE_DESC));
  }

  private MappedTransaction getAccountTransactions(TransactionDTO transactionDTO) {
    return Optional.of(transactionDTO)
      .filter(TransactionDTO::isForReport)
      .map(this::getAccountTransactionsByReport)
      .orElse(getAccountTransactionsValidateDB(transactionDTO));
  }

  private MappedTransaction getAccountTransactionsValidateDB(TransactionDTO transactionDTO) {
    LocalDateTime toDate = getToAccountingDate(transactionDTO);
    LocalDateTime today = LocalDate.now().atStartOfDay();

    return Optional.of(isShowingDatabaseRecords(transactionDTO))
      .filter(isShowingDataBase -> !isShowingDataBase && toDate.isAfter(today))
      .map(ignored -> accountsService.getAccountTransactions(transactionDTO))
      .orElse(MappedTransaction.builder().build());
  }

  private MappedTransaction getAccountTransactionsByReport(TransactionDTO transactionDTO) {
    LocalDateTime today = LocalDate.now().atStartOfDay();
    LocalDateTime toDate = getToAccountingDate(transactionDTO);
    LocalDateTime fromDate = getFromAccountingDate(transactionDTO, toDate, paginationUtil.getLimitInDays());
    LocalDateTime fromDateMinusOneDay = fromDate.minusDays(1);

    List<AccountTransactionDTO> onlineTransactions = Optional.of(toDate)
      .filter(date -> date.isAfter(today))
      .map(ignored -> findAllOnlineTransactions(transactionDTO))
      .orElseGet(ArrayList::new);
    int limit = exportLimit - onlineTransactions.size();

    PageRequest pageable = PageRequest.of(0, limit);
    return MappedTransaction.builder()
      .accountTransactions(
        Optional.of(transactionDTO)
          .map(dto -> movementRepository.findMovementsSortedByValueDate(dto.getBic(), dto.getAccountUuid(), dto.getCurrency(), fromDate, toDate, fromDateMinusOneDay, pageable))
          .map(movements -> movements.stream()
            .parallel()
            .map(mov -> mapper.movementToTransaction(mov, transactionDTO))
            .collect(Collectors.toCollection(() -> onlineTransactions)))
          .orElse(onlineTransactions))
      .build();
  }

  private List<AccountTransactionDTO> findAllOnlineTransactions(TransactionDTO transactionDTO) {
    List<AccountTransactionDTO> transactions = new ArrayList<>();
    transactionDTO.setLimit(onlineReportLimit);
    String offset = "";
    List<AccountTransactionDTO> tmpTransactions;
    do {
      transactionDTO.setOffset(offset);
      MappedTransaction mappedTransaction = accountsService.getAccountTransactions(transactionDTO);
      tmpTransactions = mappedTransaction.getAccountTransactions();
      transactions.addAll(tmpTransactions);
      offset = Optional.ofNullable(mappedTransaction.getNext()).orElse(offset);
    } while (tmpTransactions.size() == onlineReportLimit && transactions.size() < exportLimit);
    return transactions;
  }

  private boolean isShowingDatabaseRecords(TransactionDTO transactionDTO) {
    return Optional.ofNullable(transactionDTO.getBcOffset())
      .map(bcOffset -> bcOffset > 0)
      .orElse(false);
  }

  private MappedTransaction completeWithBalanceCacheData(MappedTransaction transactions, TransactionDTO transactionDTO) {
    List<AccountTransactionDTO> eodTransactions = Optional.of(transactions.getAccountTransactions().size())
      .filter(size -> size < paginationUtil.getLimit(transactionDTO))
      .map(size -> findEodTransactions(transactionDTO, size))
      .orElse(Collections.emptyList());

    return MappedTransaction.builder(transactions)
      .accountTransactions(
        Stream.of(transactions.getAccountTransactions(), eodTransactions)
          .flatMap(Collection::stream)
          .collect(Collectors.toList()))
      .build();
  }

  private List<AccountTransactionDTO> findEodTransactions(TransactionDTO transactionDTO, int returnedOnlineData) {
    int bcOffset = Optional.ofNullable(transactionDTO.getBcOffset()).orElse(0);
    int limit = paginationUtil.getLimit(transactionDTO) - returnedOnlineData;
    LocalDateTime toDate = getToAccountingDate(transactionDTO);
    LocalDateTime fromDate = getFromAccountingDate(transactionDTO, toDate, paginationUtil.getLimitInDays());
    LocalDateTime fromDateMinusOneDay = fromDate.minusDays(1);
    return Optional.of(transactionDTO)
      .map(dto -> movementRepository.findEodMovementsSortedByValueDate(dto.getBic(), dto.getAccountUuid(),
        dto.getCurrency(), fromDate, toDate, fromDateMinusOneDay, bcOffset, limit))
      .map(movements -> movements.stream()
        .parallel()
        .map(mov -> mapper.movementToTransaction(mov, transactionDTO))
        .collect(Collectors.toCollection(LinkedList::new)))
      .orElseGet(LinkedList::new);
  }
}
