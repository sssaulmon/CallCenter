package com.santander.scib.gtb.ic.gcm.api.balance.concurrency;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CompletionStage;

public interface OrchestrationService {

  CompletionStage<List<AccountBalanceDTO>> orchestrate(List<AccountDTO> accounts, LocalDate accountingDate, String version);
}
