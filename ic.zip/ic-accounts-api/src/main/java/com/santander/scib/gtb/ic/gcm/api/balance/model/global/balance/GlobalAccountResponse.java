package com.santander.scib.gtb.ic.gcm.api.balance.model.global.balance;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.balance.GenericBalance;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.balance.Movement;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.balance.RelatedCard;
import com.santander.scib.gtb.ic.gcm.model.AccountBalance;
import com.santander.scib.gtb.ic.gcm.util.SecurityUtil;

import java.util.List;
import java.util.Optional;

import static com.isban.gcb.ic.commons.balance.cache.dto.BalanceType.ONLINE;

public class GlobalAccountResponse implements AccountBalance {
  @JsonProperty("displayNumber")
  private String displayNumber;

  @JsonProperty("bic")
  private String bic;

  @JsonProperty("accountId")
  private String accountId;

  @JsonProperty("accountIdType")
  private String accountIdType;

  @JsonProperty("alias")
  private String alias;

  @JsonProperty("mainItem")
  private boolean mainItem;

  @JsonProperty("type")
  private String type;

  @JsonProperty("description")
  private String description;

  @JsonProperty("status")
  private String status;

  @JsonProperty("customerId")
  private String customerId;

  @JsonProperty("lastTransactionDate")
  private String lastTransactionDate;

  @JsonProperty("relatedCards")
  private List<RelatedCard> relatedCards;

  @JsonProperty("costCenter")
  private String costCenter;

  @JsonProperty("mainBalance")
  private GenericBalance mainBalance;

  @JsonProperty("availableBalance")
  private GenericBalance availableBalance;

  @JsonProperty("pendingBalance")
  private GenericBalance pendingBalance;

  @JsonProperty("withholdingBalance")
  private GenericBalance withholdingBalance;

  @JsonProperty("overdraftLimit")
  private GenericBalance overdraftLimit;

  @JsonProperty("overdraftUsed")
  private GenericBalance overdraftUsed;

  @JsonProperty("latestTransactions")
  private List<Movement> lastTransactions;

  @JsonProperty("transactionsListLink")
  private String transactionsListLink;

  public void setDisplayNumber(String displayNumber) {
    this.displayNumber = displayNumber;
  }

  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public String getAlias() {
    return alias;
  }

  public void setAlias(String alias) {
    this.alias = alias;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public void setCustomerId(String customerId) {
    this.customerId = customerId;
  }

  public void setLastTransactionDate(String lastTransactionDate) {
    this.lastTransactionDate = lastTransactionDate;
  }

  public void setRelatedCards(List<RelatedCard> relatedCards) {
    this.relatedCards = SecurityUtil.unmodify(relatedCards);
  }

  public GenericBalance getMainBalance() {
    return mainBalance;
  }

  public void setMainBalance(GenericBalance mainBalance) {
    this.mainBalance = mainBalance;
  }

  public GenericBalance getAvailableBalance() {
    return availableBalance;
  }

  public void setAvailableBalance(GenericBalance availableBalance) {
    this.availableBalance = availableBalance;
  }

  public void setPendingBalance(GenericBalance pendingBalance) {
    this.pendingBalance = pendingBalance;
  }

  public void setWithholdingBalance(GenericBalance withholdingBalance) {
    this.withholdingBalance = withholdingBalance;
  }

  public void setOverdraftLimit(GenericBalance overdraftLimit) {
    this.overdraftLimit = overdraftLimit;
  }

  public void setOverdraftUsed(GenericBalance overdraftUsed) {
    this.overdraftUsed = overdraftUsed;
  }

  public void setLastTransactions(List<Movement> lastTransactions) {
    this.lastTransactions = SecurityUtil.unmodify(lastTransactions);
  }

  public void setTransactionsListLink(String transactionsListLink) {
    this.transactionsListLink = transactionsListLink;
  }

  public String getBic() {
    return bic;
  }

  public GlobalAccountResponse bic(String bic) {
    this.bic = bic;
    return this;
  }

  @Override
  // TODO extract to generic mapper
  public AccountBalanceDTO mapToAccountBalanceDto() {
    Optional<GenericBalance> balance = Optional.ofNullable(this.mainBalance);
    return new AccountBalanceDTO()
      .balanceType(ONLINE.toString())
      .closingAmount(balance
        .map(GenericBalance::getAmount)
        .orElse(null))
      .availableAmount(Optional.ofNullable(availableBalance)
        .map(GenericBalance::getAmount)
        .orElse(null))
      .currency(balance
        .map(GenericBalance::getCurrencyCode)
        .orElse(null))
      .status(status);
  }
}
