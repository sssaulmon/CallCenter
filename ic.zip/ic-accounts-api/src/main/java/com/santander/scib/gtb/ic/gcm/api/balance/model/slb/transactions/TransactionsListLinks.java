package com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
public class TransactionsListLinks {

  @ApiModelProperty(value = "Link to account details.")
  @JsonProperty("accountDetailsLink")
  private String accountDetailsLink;

  @ApiModelProperty(value = "Link to navigates to the first page according to input parameters.")
  @JsonProperty("_first")
  private String first;

  @ApiModelProperty(value = "Link to navigates to the previous page according to input parameters.")
  @JsonProperty("_prev")
  private String prev;

  @ApiModelProperty(value = "Link to navigates to the next page according to input parameters.")
  @JsonProperty("_next")
  private String next;

  @ApiModelProperty(value = "Link to navigates to the last page according to input parameters.")
  @JsonProperty("_last")
  private String last;

  public void setAccountDetailsLink(String accountDetailsLink) {
    this.accountDetailsLink = accountDetailsLink;
  }

  public void setFirst(String first) {
    this.first = first;
  }

  public void setPrev(String prev) {
    this.prev = prev;
  }

  public void setNext(String next) {
    this.next = next;
  }

  public void setLast(String last) {
    this.last = last;
  }
}
