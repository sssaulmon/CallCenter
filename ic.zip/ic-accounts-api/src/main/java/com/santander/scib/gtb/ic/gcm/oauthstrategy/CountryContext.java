package com.santander.scib.gtb.ic.gcm.oauthstrategy;

public interface CountryContext {

  CountryStrategy resolve(String country);
}
