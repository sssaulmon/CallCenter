package com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.santander.scib.gtb.ic.gcm.serde.BigDecimalSerializer;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.time.LocalDate;

public class ForwardAmountDTO {

  @ApiModelProperty(example = "50000", value = "Amount of forward amount")
  @JsonSerialize(using = BigDecimalSerializer.class)
  private BigDecimal amount;

  @ApiModelProperty(example = "2803", required = true, value = "Date for forward amount")
  private LocalDate date;

  public BigDecimal getAmount() {
    return amount;
  }

  public ForwardAmountDTO amount(BigDecimal amount) {
    this.amount = amount;
    return this;
  }

  public LocalDate getDate() {
    return date;
  }

  public ForwardAmountDTO date(LocalDate date) {
    this.date = date;
    return this;
  }

  @Override
  public String toString() {
    return "ForwardAmountDTO{" +
      "amount=" + amount +
      ", date=" + date +
      '}';
  }
}
