package com.santander.scib.gtb.ic.gcm.config;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import springfox.bean.validators.configuration.BeanValidatorPluginsConfiguration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.DocExpansion;
import springfox.documentation.swagger.web.ModelRendering;
import springfox.documentation.swagger.web.OperationsSorter;
import springfox.documentation.swagger.web.TagsSorter;
import springfox.documentation.swagger.web.UiConfiguration;
import springfox.documentation.swagger.web.UiConfigurationBuilder;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Configuration
@EnableSwagger2
@Import(BeanValidatorPluginsConfiguration.class)
public class SwaggerDocumentationConfig {

  private static final String AUTHORIZATION_HEADER = "Authorization";

  private ApiInfo apiInfo() {
    return new ApiInfoBuilder()
      .title("Accounts")
      .description("Get Balance API provides access to intraday information on account balance and movements of specific customer account included in the information Center Global Contract.\nThere are four paths in the Get Balance Api:\n- /balances : POST that retrieves information on each account from the list passed as body.\n- /balances/account_id/transactions : Request to get transactions from the specified account id.\n- /accounts/account_id : Retrieves information from one specific customer account included in their Information Center contract\n- /accounts/account_id/transactions : Retrieve information about transactions (movements) posted in one specific customer account included in their Information Center contract from the last closing date till the moment.\nAvailable filters are:\no Amount\no Movement type\no Sign\no references")
      .license("")
      .licenseUrl("")
      .termsOfServiceUrl("")
      .version("1.0.0")
      .build();
  }

  @Bean
  public Docket swaggerSpringfoxDocket() {
    return new Docket(DocumentationType.SWAGGER_2)
      .groupName("Global Cash Management")
      .protocols(Sets.newHashSet("https", "http"))
      .securitySchemes(Lists.newArrayList(apiKey()))
      .securityContexts(Lists.newArrayList(securityContext()))
      .directModelSubstitute(LocalDate.class, java.sql.Date.class)
      .directModelSubstitute(LocalDateTime.class, java.util.Date.class);
  }

  @Bean
  public UiConfiguration uiConfig() {
    return UiConfigurationBuilder.builder()
      .docExpansion(DocExpansion.NONE)
      .operationsSorter(OperationsSorter.ALPHA)
      .defaultModelRendering(ModelRendering.EXAMPLE)
      .tagsSorter(TagsSorter.ALPHA)
      .supportedSubmitMethods(UiConfiguration.Constants.DEFAULT_SUBMIT_METHODS)
      .build();
  }

  private ApiKey apiKey() {
    return new ApiKey("JWT", AUTHORIZATION_HEADER, "header");
  }

  private SecurityContext securityContext() {
    return SecurityContext.builder()
      .securityReferences(defaultAuth())
      .forPaths(PathSelectors.any())
      .build();
  }

  private List<SecurityReference> defaultAuth() {
    AuthorizationScope authorizationScope
      = new AuthorizationScope("accounts.read", "Read Access");
    AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
    authorizationScopes[0] = authorizationScope;
    return Lists.newArrayList(
      new SecurityReference("JWT", authorizationScopes));
  }

}
