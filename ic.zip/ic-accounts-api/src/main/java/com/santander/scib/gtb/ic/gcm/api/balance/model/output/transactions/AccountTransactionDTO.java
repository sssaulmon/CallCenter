package com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.santander.scib.gtb.ic.gcm.serde.BigDecimalSerializer;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

public class AccountTransactionDTO {

  @ApiModelProperty(example = "1100986.5", required = true, value = "Quantity of money that is associated to a specific transaction")
  @JsonProperty("amount")
  @JsonSerialize(using = BigDecimalSerializer.class)
  private BigDecimal amount;

  @ApiModelProperty(example = "\"USD\"", required = true, value = "ISO Currency code of this specific transaction. It  should match with the account currency")
  @JsonProperty("currency")
  private String currency;

  @ApiModelProperty(example = "\"20180605\"", required = true, value = "Date of an specific value dated balance in a determined account.")
  @JsonProperty("valueDate")
  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate valueDate;

  @ApiModelProperty(example = "\"20180605\"", required = true, value = "Operation date of an specific transaction")
  @JsonProperty("accountingDate")
  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate accountingDate;

  @ApiModelProperty(example = "\"\"", required = true, value = "Operation time of an specific transaction")
  @JsonProperty("movementTime")
  @JsonFormat(pattern = "HH:mm:ss")
  private LocalTime movementTime;

  @ApiModelProperty(value = "Transaction details")
  private String description;

  @ApiModelProperty(example = "INTR", required = true, value = "Online, FIND, INTR")
  private String origin;

  @ApiModelProperty(value = "Additional information of the transaction. TAG 86 or TAG 61 sub-fields 8 and 9")
  private String additionalInfo;

  @ApiModelProperty(value = "Account balance")
  @JsonSerialize(using = BigDecimalSerializer.class)
  private BigDecimal balance;

  @ApiModelProperty(example = "\"20180605\"", required = true, value = "Operation date of an specific transaction")
  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate entryDate;

  @ApiModelProperty(value = "Code Swift")
  private String identificationCode;

  @ApiModelProperty(value = "Information Service Institution")
  private String accountServiceInstitution;

  @ApiModelProperty(value = "Information account owner")
  private String accountOwner;

  private String accountId;

  private String alias;

  public BigDecimal getAmount() {
    return amount;
  }

  public AccountTransactionDTO amount(BigDecimal amount) {
    this.amount = amount;
    return this;
  }

  public String getCurrency() {
    return currency;
  }

  public AccountTransactionDTO currency(String currency) {
    this.currency = currency;
    return this;
  }

  public LocalDate getValueDate() {
    return valueDate;
  }

  public AccountTransactionDTO valueDate(LocalDate valueDate) {
    this.valueDate = valueDate;
    return this;
  }

  public LocalDate getAccountingDate() {
    return accountingDate;
  }

  public AccountTransactionDTO accountingDate(LocalDate accountingDate) {
    this.accountingDate = accountingDate;
    return this;
  }

  public LocalTime getMovementTime() {
    return movementTime;
  }

  public AccountTransactionDTO movementTime(LocalTime movementTime) {
    this.movementTime = movementTime;
    return this;
  }

  public String getDescription() {
    return description;
  }

  public AccountTransactionDTO description(String description) {
    this.description = description;
    return this;
  }

  public String getOrigin() {
    return origin;
  }

  public AccountTransactionDTO origin(String origin) {
    this.origin = origin;
    return this;
  }

  public String getAdditionalInfo() {
    return additionalInfo;
  }

  public AccountTransactionDTO additionalInfo(String additionalInfo) {
    this.additionalInfo = additionalInfo;
    return this;
  }

  public BigDecimal getBalance() {
    return balance;
  }

  public AccountTransactionDTO balance(BigDecimal balance) {
    this.balance = balance;
    return this;
  }

  public LocalDate getEntryDate() {
    return entryDate;
  }

  public AccountTransactionDTO entryDate(LocalDate entryDate) {
    this.entryDate = entryDate;
    return this;
  }

  public String getIdentificationCode() {
    return identificationCode;
  }

  public AccountTransactionDTO identificationCode(String identificationCode) {
    this.identificationCode = identificationCode;
    return this;
  }

  public String getAccountServiceInstitution() {
    return accountServiceInstitution;
  }

  public AccountTransactionDTO accountServiceInstitution(String accountServiceInstitution) {
    this.accountServiceInstitution = accountServiceInstitution;
    return this;
  }

  public String getAccountOwner() {
    return accountOwner;
  }

  public AccountTransactionDTO accountOwner(String accountOwner) {
    this.accountOwner = accountOwner;
    return this;
  }

  @JsonIgnore
  public String getAccountId() {
    return accountId;
  }

  public AccountTransactionDTO accountId(String accountId) {
    this.accountId = accountId;
    return this;
  }

  @JsonIgnore
  public String getAlias() {
    return alias;
  }

  public AccountTransactionDTO alias(String alias) {
    this.alias = alias;
    return this;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;

    if (o == null || getClass() != o.getClass()) return false;

    AccountTransactionDTO that = (AccountTransactionDTO) o;

    return new EqualsBuilder()
      .append(amount, that.amount)
      .append(currency, that.currency)
      .append(valueDate, that.valueDate)
      .append(accountingDate, that.accountingDate)
      .append(movementTime, that.movementTime)
      .append(description, that.description)
      .append(origin, that.origin)
      .append(additionalInfo, that.additionalInfo)
      .append(balance, that.balance)
      .append(entryDate, that.entryDate)
      .append(identificationCode, that.identificationCode)
      .append(accountServiceInstitution, that.accountServiceInstitution)
      .append(accountOwner, that.accountOwner)
      .append(accountId, that.accountId)
      .append(alias, that.alias)
      .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(amount)
      .append(currency)
      .append(valueDate)
      .append(accountingDate)
      .append(movementTime)
      .append(description)
      .append(origin)
      .append(additionalInfo)
      .append(balance)
      .append(entryDate)
      .append(identificationCode)
      .append(accountServiceInstitution)
      .append(accountOwner)
      .append(accountId)
      .append(alias)
      .toHashCode();
  }

  @Override
  public String toString() {
    return "AccountTransactionDTO{" +
      "amount=" + amount +
      ", currency='" + currency + '\'' +
      ", valueDate=" + valueDate +
      ", accountingDate=" + accountingDate +
      ", movementTime=" + movementTime +
      ", description='" + description + '\'' +
      ", origin='" + origin + '\'' +
      ", additionalInfo='" + additionalInfo + '\'' +
      ", balance=" + balance +
      ", entryDate=" + entryDate +
      ", identificationCode='" + identificationCode + '\'' +
      ", accountServiceInstitution='" + accountServiceInstitution + '\'' +
      ", accountOwner='" + accountOwner + '\'' +
      ", accountId='" + accountId + '\'' +
      ", alias='" + alias + '\'' +
      '}';
  }
}
