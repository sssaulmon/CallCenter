package com.santander.scib.gtb.ic.gcm.util;

public class AccountSplitUtil {

  private AccountSplitUtil() {
  }

  private static final String SPLIT_ACCOUNT_REGEX = "^(\\w{11})(.*)(\\w{3})$";

  public static String getBic(String account) {
    return account.replaceAll(SPLIT_ACCOUNT_REGEX, "$1");
  }

  public static String getAccountId(String account) {
    return account.replaceAll(SPLIT_ACCOUNT_REGEX, "$2");
  }

  public static String getCurrency(String account) {
    return account.replaceAll(SPLIT_ACCOUNT_REGEX, "$3");
  }
}
