package com.santander.scib.gtb.ic.gcm.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class BalanceCacheFlat implements Serializable {
  private static final long serialVersionUID = -911681736597284135L;
  private String bic;
  private String accountCode;
  private String currency;
  private String balanceType;
  private LocalDateTime accountingDate;
  private String openingMark;
  private BigDecimal openingAmount;
  private String availableMark;
  private BigDecimal availableAmount;
  private String closingMark;
  private BigDecimal closingAmount;
  private Boolean transactions;
  private Boolean bestTransactions;
  private String accountIdentification;
  private String forwardBalanceMark;
  private Double forwardBalanceAmount;
  private LocalDate forwardBalanceAmountDate;
  private String information;
  private String status;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;

    if (o == null || getClass() != o.getClass()) return false;

    BalanceCacheFlat that = (BalanceCacheFlat) o;

    return new EqualsBuilder()
      .append(getBic(), that.getBic())
      .append(getAccountCode(), that.getAccountCode())
      .append(getCurrency(), that.getCurrency())
      .append(getBalanceType(), that.getBalanceType())
      .append(getAccountingDate(), that.getAccountingDate())
      .append(getOpeningMark(), that.getOpeningMark())
      .append(getOpeningAmount(), that.getOpeningAmount())
      .append(getAvailableMark(), that.getAvailableMark())
      .append(getAvailableAmount(), that.getAvailableAmount())
      .append(getClosingMark(), that.getClosingMark())
      .append(getClosingAmount(), that.getClosingAmount())
      .append(getTransactions(), that.getTransactions())
      .append(getBestTransactions(), that.getBestTransactions())
      .append(getAccountIdentification(), that.getAccountIdentification())
      .append(getForwardBalanceMark(), that.getForwardBalanceMark())
      .append(getForwardBalanceAmount(), that.getForwardBalanceAmount())
      .append(getForwardBalanceAmountDate(), that.getForwardBalanceAmountDate())
      .append(getInformation(), that.getInformation())
      .append(getStatus(), that.getStatus())
      .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(getBic())
      .append(getAccountCode())
      .append(getCurrency())
      .append(getBalanceType())
      .append(getAccountingDate())
      .append(getOpeningMark())
      .append(getOpeningAmount())
      .append(getAvailableMark())
      .append(getAvailableAmount())
      .append(getClosingMark())
      .append(getClosingAmount())
      .append(getTransactions())
      .append(getBestTransactions())
      .append(getAccountIdentification())
      .append(getForwardBalanceMark())
      .append(getForwardBalanceAmount())
      .append(getForwardBalanceAmountDate())
      .append(getInformation())
      .append(getStatus())
      .toHashCode();
  }
}
