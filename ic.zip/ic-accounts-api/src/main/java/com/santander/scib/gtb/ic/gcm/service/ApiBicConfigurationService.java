package com.santander.scib.gtb.ic.gcm.service;

import com.santander.scib.gtb.ic.gcm.model.ApiBicConfiguration;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public interface ApiBicConfigurationService {

  Optional<ApiBicConfiguration> loadConfigurationByBic(String bic);
}
