package com.santander.scib.gtb.ic.gcm.oauthstrategy.impl;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.api.MappedTransaction;
import com.santander.scib.gtb.ic.gcm.config.RequestParamsConstants;
import com.santander.scib.gtb.ic.gcm.model.AccountBalance;
import com.santander.scib.gtb.ic.gcm.model.ApiBicConfiguration;
import com.santander.scib.gtb.ic.gcm.model.Transaction;
import com.santander.scib.gtb.ic.gcm.model.app.entity.AppEntity;
import com.santander.scib.gtb.ic.gcm.oauthstrategy.ApiVersion;
import com.santander.scib.gtb.ic.gcm.oauthstrategy.CountryStrategy;
import com.santander.scib.gtb.ic.gcm.service.AccountingDateService;
import com.santander.scib.gtb.ic.gcm.service.ApiBalanceCommunication;
import com.santander.scib.gtb.ic.gcm.service.ApiBicConfigurationService;
import com.santander.scib.gtb.ic.gcm.service.ConvertAmountByCurrencyService;
import com.santander.scib.gtb.ic.gcm.util.DateTimeFormatterUtil;
import com.santander.scib.gtb.ic.gcm.util.TransactionPaginationUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.santander.scib.gtb.ic.gcm.config.RequestParamsConstants.ACCOUNT_ID_TYPE;
import static com.santander.scib.gtb.ic.gcm.config.RequestParamsConstants.COUNTRY_BIC;
import static com.santander.scib.gtb.ic.gcm.config.RequestParamsConstants.IBM_CLIENT_ID;
import static com.santander.scib.gtb.ic.gcm.config.RequestParamsConstants.SANTANDER_CLIENT_ID;

@Component
@ApiVersion(type = "v3")
public class V3CountryStrategy implements CountryStrategy {

  @Autowired private ApiBalanceCommunication apiBalanceCommunication;
  @Autowired private TransactionPaginationUtil paginationUtil;
  @Autowired private ConvertAmountByCurrencyService convertAmountByCurrencyService;
  @Autowired private ApiBicConfigurationService apiBicConfigurationService;
  @Autowired private AccountingDateService accountingDateService;

  @Override
  public <T extends AccountBalance> Mono<T> getAccounts(AppEntity appEntity, String bic, String accountId,
                                                        String currency, LocalDate accountingDate, Class<T> clazz) {
    boolean isIban = apiBicConfigurationService.loadConfigurationByBic(bic.toUpperCase())
      .map(ApiBicConfiguration::isIbanAccount)
      .orElseThrow(() -> new RuntimeException("Bic not Configured"));

    return apiBalanceCommunication.getJWTToken(appEntity, buildBodyOauth(appEntity))
      .flatMap(tokenResponse -> apiBalanceCommunication.getAccount(buildAccountUri(isIban,
        appEntity.getServiceUrl() + accountId), tokenResponse.get(RequestParamsConstants.ACCESS_TOKEN).asText(),
        buildHeaders(appEntity, bic), clazz, false));
  }

  @Override
  public <T extends Transaction> MappedTransaction getTransactions(AppEntity appEntity, TransactionDTO transactionDTO, Class<T> clazz) {
    String bic = transactionDTO.getBic();
    String accountId = transactionDTO.getAccountId();

    return apiBalanceCommunication.getJWTToken(appEntity, buildBodyOauth(appEntity))
      .flatMap(tokenResponse -> apiBalanceCommunication.getTransactions(appEntity.getServiceUrl() + accountId + "/transactions",
        tokenResponse.get(RequestParamsConstants.ACCESS_TOKEN).asText(), buildUriParams(transactionDTO), buildHeaders(appEntity, bic), clazz, false))
      .map(Transaction::mapToAccountTransactionListDTO)
      .map(transactions -> convertAmountByCurrencyService.convertAccountTransactions(bic, transactions))
      .map(transactions -> completeWithInput(transactions, transactionDTO))
      .block();
  }

  private MappedTransaction completeWithInput(MappedTransaction transactions, TransactionDTO transactionDTO) {
    return MappedTransaction.builder(transactions)
      .accountTransactions(
        transactions.getAccountTransactions().stream()
          .parallel()
          .map(given -> given.accountId(transactionDTO.getAccountId()))
          .map(given -> given.alias(transactionDTO.getAlias()))
          .collect(Collectors.toList()))
      .build();
  }

  private Map<String, String> buildUriParams(TransactionDTO transactionDTO) {
    Optional<ApiBicConfiguration> apiBicConfiguration = apiBicConfigurationService.loadConfigurationByBic(transactionDTO.getBic().toUpperCase());

    int limit = paginationUtil.getLimit(transactionDTO);

    Map<String, String> uriParams = new HashMap<>();
    Optional.ofNullable(transactionDTO.getOffset())
      .ifPresent(offset -> uriParams.put(RequestParamsConstants.OFFSET, offset));
    uriParams.put(RequestParamsConstants.LIMIT, String.valueOf(limit));

    apiBicConfiguration.map(ApiBicConfiguration::isDateSort)
      .filter(Boolean.TRUE::equals)
      .ifPresent(ignored -> uriParams.put(RequestParamsConstants.SORT, RequestParamsConstants.SORT_ORDER_DESC_VALUE));

    apiBicConfiguration.map(ApiBicConfiguration::isIbanAccount)
      .filter(Boolean.TRUE::equals)
      .ifPresent(ignored -> uriParams.put(ACCOUNT_ID_TYPE, IBAN_ACCOUNT_TYPE));

    Optional.of(accountingDateService.getFromAccountingDate(transactionDTO))
      .map(DateTimeFormatterUtil::formatGlobalDate)
      .ifPresent(date -> uriParams.put(apiBicConfiguration.map(ApiBicConfiguration::getFromDate)
        .orElse(null), date));
    return uriParams;
  }

  private Map<String, String> buildHeaders(AppEntity appEntity, String bic) {
    Map<String, String> headers = new HashMap<>();
    headers.put(SANTANDER_CLIENT_ID, appEntity.getClientId());
    headers.put(IBM_CLIENT_ID, appEntity.getClientId());
    headers.put(COUNTRY_BIC, appEntity.getCountry() + bic.substring(0, 8));
    return headers;
  }
}
