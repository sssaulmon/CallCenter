package com.santander.scib.gtb.ic.gcm.communication.config;

import com.santander.scib.gtb.ic.gcm.communication.binding.ApiOutputBinding;
import com.santander.scib.gtb.ic.gcm.communication.binding.GenerateFileOutputBinding;
import org.springframework.cloud.stream.annotation.EnableBinding;

@EnableBinding({ApiOutputBinding.class, GenerateFileOutputBinding.class})
public class ApiMessagingConfig {
}
