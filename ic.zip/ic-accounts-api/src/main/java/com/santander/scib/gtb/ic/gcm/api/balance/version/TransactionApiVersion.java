package com.santander.scib.gtb.ic.gcm.api.balance.version;

import com.santander.scib.gtb.ic.gcm.api.balance.model.global.transactions.GlobalTransactionResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions.SLBTransactionResponse;
import com.santander.scib.gtb.ic.gcm.model.Transaction;

import java.util.stream.Stream;

public enum TransactionApiVersion {
  V1_ORIGIN_V2("v1", "v2", GlobalTransactionResponse.class),
  V1_ORIGIN_V3("v1", "v3", SLBTransactionResponse.class);

  private Class<? extends Transaction> transactionType;
  private String version;
  private String origin;

  TransactionApiVersion(String version, String origin,
                        Class<? extends Transaction> transactionType) {
    this.version = version;
    this.origin = origin;
    this.transactionType = transactionType;
  }

  public String getVersion() {
    return version;
  }

  public String getOrigin() {
    return origin;
  }

  public Class<? extends Transaction> getTransactionType() {
    return transactionType;
  }

  public static Class<? extends Transaction> getTransactionApiType(String version, String origin) {
    return Stream.of(values())
      .filter(v -> v.getVersion().equals(version) && v.getOrigin().equals(origin))
      .map(TransactionApiVersion::getTransactionType)
      .findFirst()
      .orElseThrow(RuntimeException::new);
  }
}
