package com.santander.scib.gtb.ic.gcm.model;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class WorkBookContainer {

  private Workbook workbook;
  private Sheet sheet;
  private CellStyle numericStyle;
  private CellStyle dateStyle;
  private DecimalFormatterType decimalFormatterType;

  public Workbook getWorkbook() {
    return workbook;
  }

  public WorkBookContainer workbook(Workbook workbook) {
    this.workbook = workbook;
    return this;
  }

  public Sheet getSheet() {
    return sheet;
  }

  public WorkBookContainer sheet(Sheet sheet) {
    this.sheet = sheet;
    return this;
  }

  public CellStyle getNumericStyle() {
    return numericStyle;
  }

  public WorkBookContainer numericStyle(CellStyle style) {
    this.numericStyle = style;
    return this;
  }

  public CellStyle getDateStyle() {
    return dateStyle;
  }

  public WorkBookContainer dateStyle(CellStyle dateStyle) {
    this.dateStyle = dateStyle;
    return this;
  }

  public DecimalFormatterType getDecimalFormatterType() {
    return decimalFormatterType;
  }

  public WorkBookContainer decimalFormatterType(DecimalFormatterType decimalFormatterType) {
    this.decimalFormatterType = decimalFormatterType;
    return this;
  }
}
