package com.santander.scib.gtb.ic.gcm.contract.constants;

public class GenerateFileInputConstants {
  public static final String GENERATE_FILE_REQUEST = "generateFileRequest";
  public static final String UPDATE_FILE_STATUS_REQUEST = "updateFileStatus";
}
