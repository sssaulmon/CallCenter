package com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions;

import com.google.common.base.Objects;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@ToString
public class TransactionDTO {

  private String xSantanderGlobalId;
  private String version;
  private String accountId;
  private String alias;
  private String bic;
  private String currency;
  private LocalDate accountingDate;
  private LocalDate fromAccountingDate;
  private LocalDate toAccountingDate;
  private Double amountFrom;
  private Double amountTo;
  private String operationCode;
  private String swiftCode;
  private String sign;
  private String transactionClientReference;
  private String transactionBatchReference;
  private String transactionInternalReference;
  private Integer limit;
  private String offset;
  private Integer bcOffset;
  private boolean forReport;
  private String accountUuid;
  private long extractId;
  private String prevOffsetFromApi;
  private String nextOffsetFromApi;
  private String lastOffsetFromApi;
  private boolean isAccountAlias;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    TransactionDTO that = (TransactionDTO) o;
    return Objects.equal(accountId, that.accountId) &&
      Objects.equal(bic, that.bic) &&
      Objects.equal(currency, that.currency);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(accountId, bic, currency);
  }
}
