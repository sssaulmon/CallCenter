package com.santander.scib.gtb.ic.gcm.service;

import com.isban.gcb.ic.commons.model.CountryBankEntity;

import java.util.Optional;

/**
 * The interface Country Bank Service
 */
public interface CountryBankService {

  /**
   * Gets {@link CountryBankEntity} by BIC
   *
   * @param bic the BIC
   * @return {@link Optional} of {@link CountryBankEntity}
   */
  Optional<CountryBankEntity> findByBic(String bic);
}
