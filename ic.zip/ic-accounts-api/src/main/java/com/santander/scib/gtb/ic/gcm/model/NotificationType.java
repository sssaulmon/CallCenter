package com.santander.scib.gtb.ic.gcm.model;

import com.santander.scib.gtb.ic.gcm.web.exception.AccountNotFoundException;
import com.santander.scib.gtb.ic.gcm.web.exception.BadRequestException;
import com.santander.scib.gtb.ic.gcm.web.exception.ExternalApiException;
import com.santander.scib.gtb.ic.gcm.web.exception.UnauthorizedException;

import java.util.stream.Stream;

public enum NotificationType {
  ACCOUNT_NOT_FOUND(AccountNotFoundException.class, "001"),
  BAD_REQUEST(BadRequestException.class, "002"),
  UNAUTHORIZED(UnauthorizedException.class, "002"),
  EXTERNAL_ERROR(ExternalApiException.class, "002");

  private final Class<? extends Throwable> clazz;
  private final String type;

  NotificationType(Class<? extends Throwable> clazz, String type) {
    this.clazz = clazz;
    this.type = type;
  }

  public Class<? extends Throwable> getClazz() {
    return clazz;
  }

  public String getType() {
    return type;
  }

  public static String getType(Class<? extends Throwable> clazz) {
    return Stream.of(values())
      .filter(v -> v.getClazz().equals(clazz))
      .map(NotificationType::getType)
      .findFirst()
      .orElse("002");
  }
}
