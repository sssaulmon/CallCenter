package com.santander.scib.gtb.ic.gcm.web.exception;

public class NoSlaConfigurationException extends RuntimeException {

  public NoSlaConfigurationException(String alias, String accountId) {
    super("API response cannot found an account's UUID that matches given alias or international/local: " +
      alias + ", " + accountId);
  }

  public NoSlaConfigurationException(Throwable th) {
    super(th);
  }
}
