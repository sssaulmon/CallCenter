package com.santander.scib.gtb.ic.gcm.util.crypto;

import com.isban.gcb.ic.commons.util.Unchecked;
import com.santander.scib.gtb.ic.gcm.web.exception.InvalidCryptoException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.Base64;
import java.util.Optional;

import static javax.crypto.Cipher.DECRYPT_MODE;
import static javax.crypto.Cipher.ENCRYPT_MODE;

@Component
public class AESSymmetricCrypto {
  private static final String ENCRYPT_ALGORITHM = "AES/ECB/PKCS5Padding";

  private String cryptoKey;

  public AESSymmetricCrypto(@Value("${apis.cryptoKey}") String cryptoKey) {
    this.cryptoKey = cryptoKey;
  }

  public String encrypt(String value) {
    try {
      Key key = new SecretKeySpec(cryptoKey.getBytes(), "AES");
      Cipher aes = Cipher.getInstance(ENCRYPT_ALGORITHM);
      aes.init(ENCRYPT_MODE, key);
      return Optional.ofNullable(value)
        .map(String::getBytes)
        .map(Unchecked.function(aes::doFinal))
        .map(Base64.getUrlEncoder()::encodeToString)
        .orElseThrow(RuntimeException::new);
    } catch (Exception e) {
      throw new InvalidCryptoException(e);
    }
  }

  public String decrypt(String value) {
    try {
      Key key = new SecretKeySpec(cryptoKey.getBytes(), "AES");
      Cipher aes = Cipher.getInstance(ENCRYPT_ALGORITHM);
      aes.init(DECRYPT_MODE, key);
      return Optional.ofNullable(value)
        .map(Base64.getUrlDecoder()::decode)
        .map(Unchecked.function(aes::doFinal))
        .map(String::new)
        .orElseThrow(RuntimeException::new);
    } catch (Exception e) {
      throw new InvalidCryptoException(e);
    }
  }
}
