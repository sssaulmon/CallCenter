package com.santander.scib.gtb.ic.gcm.service.balance;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionResponse;

/**
 * The interface Account transactions service.
 */
public interface AccountTransactionsService {

  /**
   * Gets account transactions.
   *
   * @param transactionDTO the transaction dto
   * @return the account transactions
   */
  AccountTransactionResponse getAccountTransactions(TransactionDTO transactionDTO);
}
