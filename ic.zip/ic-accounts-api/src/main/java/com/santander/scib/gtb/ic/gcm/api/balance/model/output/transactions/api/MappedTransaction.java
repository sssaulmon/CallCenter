package com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.api;

import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionDTO;
import lombok.Builder;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Getter
@Builder
public class MappedTransaction {

  private final List<AccountTransactionDTO> accountTransactions;
  private final String previous;
  private final String next;
  private final String last;

  public MappedTransaction(List<AccountTransactionDTO> accountTransactions, String previous, String next, String last) {
    this.accountTransactions = Optional.ofNullable(accountTransactions)
      .map(ArrayList::new)
      .orElseGet(ArrayList::new);
    this.previous = previous;
    this.next = next;
    this.last = last;
  }

  public static MappedTransactionBuilder builder() {
    return new MappedTransactionBuilder();
  }

  public static MappedTransactionBuilder builder(MappedTransaction mappedTransaction) {
    return MappedTransaction.builder()
      .accountTransactions(mappedTransaction.getAccountTransactions())
      .previous(mappedTransaction.getPrevious())
      .next(mappedTransaction.getNext());
  }
}
