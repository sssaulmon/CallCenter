package com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.gtb.ic.gcm.api.balance.model.account.ReferenceItem;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.api.MappedTransaction;
import com.santander.scib.gtb.ic.gcm.model.Transaction;
import com.santander.scib.gtb.ic.gcm.util.DateTimeFormatterUtil;
import com.santander.scib.gtb.ic.gcm.util.SecurityUtil;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.isban.gcb.ic.commons.balance.cache.dto.BalanceType.ONLINE;
import static com.santander.scib.gtb.ic.gcm.util.LinkReaderUtil.getOffset;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SLBTransactionResponse implements Transaction {

  @ApiModelProperty(value = "Number account identification to be displayed.")
  @JsonProperty("displayNumber")
  private String displayNumber;

  @ApiModelProperty(value = "Number Account Identification. Format: BBAN:  is the English acronym for Basic " +
    "Bank Account code. Represents a country-specific bank account number. Each country has its format and length " +
    "of BBAN depending on its own standards. Currently there is no common standard that unifies the format of BBAN " +
    "in the EU or other entities. This is why the IBAN appeared to help standardize international bank transfers." +
    " Maximum long  31 char of all 35 bytes of the field. For example: In UK Sortcode(6) + Account(8); " +
    "In ES Banco(4)+ Sucursal(4) + CD(2) + CTA(10).")
  @JsonProperty("accountId")
  private String accountId;

  @ApiModelProperty(value = "Format in which the account number is expressed, regarding accountId field. Possible values IBA, BBA")
  @JsonProperty("accountIdType")
  private String accountIdType;

  @ApiModelProperty(value = "Name asigned to the account by the client to identify it easily.")
  @JsonProperty("alias")
  private String alias;

  @ApiModelProperty(value = "List of transactions.")
  @JsonProperty("transactionsDataList")
  private List<SLBTransactionsDataListItem> transactionsDataList;

  @ApiModelProperty(value = "Links to account details and transactions list pagination.")
  @JsonProperty("_links")
  private TransactionsListLinks links;

  public void setDisplayNumber(String displayNumber) {
    this.displayNumber = displayNumber;
  }

  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public String getAccountIdType() {
    return accountIdType;
  }

  public void setAccountIdType(String accountIdType) {
    this.accountIdType = accountIdType;
  }

  public String getAlias() {
    return alias;
  }

  public void setAlias(String alias) {
    this.alias = alias;
  }

  public List<SLBTransactionsDataListItem> getTransactionsDataList() {
    return SecurityUtil.unmodify(transactionsDataList);
  }

  public void setTransactionsDataList(List<SLBTransactionsDataListItem> transactionsDataList) {
    this.transactionsDataList = SecurityUtil.unmodify(transactionsDataList);
  }

  public void setLinks(TransactionsListLinks links) {
    this.links = links;
  }

  @Override
  public MappedTransaction mapToAccountTransactionListDTO() {
    return MappedTransaction.builder()
      .accountTransactions(
        transactionsDataList.stream()
          .map(this::buildAccountTransactionDTO)
          .collect(Collectors.toList()))
      .next(getOffset(links.getNext()))
      .previous(getOffset(links.getPrev()))
      .last(getOffset(links.getLast()))
      .build();
  }

  private AccountTransactionDTO buildAccountTransactionDTO(SLBTransactionsDataListItem transactionsDataListItem) {
    SLBTransactionDetails transactionDetails = transactionsDataListItem.getTransactionDetails();

    return new AccountTransactionDTO()
      .additionalInfo(Optional.ofNullable(transactionDetails.getOperation())
        .map(SLBOperation::getLocalOperation)
        .map(SLBLocalOperation::getAditionalInformation)
        .orElse(null))
      .amount(transactionDetails.getAmount().getAmount())
      .currency(transactionDetails.getAmount().getCurrencyCode())
      .description(transactionDetails.getDescription())
      .balance(transactionDetails.getBalanceResult().getAmount())
      .origin(ONLINE.toString())
      .accountingDate(DateTimeFormatterUtil.transformToLocalDate(transactionDetails.getProcessedDate()))
      .valueDate(DateTimeFormatterUtil.transformToLocalDate(transactionDetails.getAccountingDate()))
      .entryDate(DateTimeFormatterUtil.transformToLocalDate(transactionDetails.getCreationDate()))
      .movementTime(DateTimeFormatterUtil.transformToLocalTime(transactionDetails.getCreationDate()))
      .identificationCode(Optional.ofNullable(transactionDetails.getOperation())
        .map(SLBOperation::getSwiftCode)
        .orElse(null))
      .accountOwner(Optional.ofNullable(transactionDetails.getReferences())
        .map(ReferenceItem::getTransactionClientReference)
        .orElse(null))
      .accountServiceInstitution(Optional.ofNullable(transactionDetails.getReferences())
        .map(ReferenceItem::getTransactionInternalReference)
        .orElse(null));
  }
}
