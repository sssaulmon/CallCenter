package com.santander.scib.gtb.ic.gcm.communication.service;

import com.santander.scib.gtb.ic.gcm.communication.model.SaveFile;
import com.santander.scib.gtb.ic.gcm.model.GenerateFileRequestDTO;

/**
 * The interface Generate file notification service.
 */
public interface GenerateFileNotificationService {

  /**
   * Send notification.
   *
   * @param notification the notification
   */
  void sendNotification(GenerateFileRequestDTO notification);

  /**
   * Save generate file.
   *
   * @param notification the notification
   */
  void saveGenerateFile(SaveFile notification);
}
