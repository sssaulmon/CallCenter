package com.santander.scib.gtb.ic.gcm.service.balance.impl;

import com.isban.gcb.ic.commons.balance.cache.dto.ExtractDto;
import com.isban.gcb.ic.commons.model.AssoCorpSubProductAcc;
import com.isban.gcb.ic.commons.model.ServiceAccount;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.ProcessedAccount;
import com.santander.scib.gtb.ic.gcm.mapper.AccountBalanceMapper;
import com.santander.scib.gtb.ic.gcm.model.ServiceAccountFlat;
import com.santander.scib.gtb.ic.gcm.repository.ServiceAccountRepository;
import com.santander.scib.gtb.ic.gcm.repository.SlaEntityRepository;
import com.santander.scib.gtb.ic.gcm.service.balance.AccountUuidHelper;
import com.santander.scib.gtb.ic.gcm.web.exception.NoSlaConfigurationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.function.Predicate.not;

@Service
@Slf4j
class AccountUuidHelperImpl implements AccountUuidHelper {

  private final AccountBalanceMapper accountBalanceMapper;
  private final ServiceAccountRepository serviceAccountRepository;
  private final SlaEntityRepository slaEntityRepository;

  AccountUuidHelperImpl(AccountBalanceMapper accountBalanceMapper,
                        ServiceAccountRepository serviceAccountRepository,
                        SlaEntityRepository slaEntityRepository) {
    this.accountBalanceMapper = accountBalanceMapper;
    this.serviceAccountRepository = serviceAccountRepository;
    this.slaEntityRepository = slaEntityRepository;
  }

  @Override
  public ExtractDto transform(AccountBalanceDTO accountBalanceDTO) {
    log.debug("Transforming AccountBalanceDTO response to the ExtractDto message that will be used save the cache");
    return Optional.of(accountBalanceDTO)
      .map(accountBalanceMapper::mapToExtractDto)
      .map(ExtractDto::builder)
      .map(builder -> builder.accountAlias(findAccountUuid(accountBalanceDTO)))
      .map(ExtractDto.Builder::build)
      .orElseThrow();
  }

  @Override
  public ProcessedAccount completeWithUuid(Collection<AccountDTO> accountDTOs) {
    log.debug("Complete the incoming AccountDTOs with the account's UUID information");

    return Optional.of(findValidAccounts(accountDTOs))
      .map(accounts -> new ProcessedAccount().validAccounts(accounts))
      .map(processed -> processed.invalidAccounts(findInvalidAccounts(accountDTOs, processed)))
      .orElse(null);
  }

  public List<AccountDTO> findValidAccounts(Collection<AccountDTO> accountDTOs) {
    log.debug("Complete the incoming AccountDTOs with the account's UUID information");
    List<AccountDTO> withUuidAccounts = getAccountsUuid(accountDTOs)
      .parallel()
      .map(this::toAccount)
      .collect(Collectors.toList());

    return accountDTOs.stream()
      .map(account -> completeWithUuid(withUuidAccounts, account))
      .filter(account -> Objects.nonNull(account.getUuid()))
      .collect(Collectors.toList());
  }

  private List<AccountBalanceDTO> findInvalidAccounts(Collection<AccountDTO> allAccounts, ProcessedAccount processedAccount) {
    return allAccounts.stream()
      .filter(not(processedAccount.getValidAccounts()::contains))
      .map(account -> accountBalanceMapper.buildAccountBalanceEmpty(account, "Account Not Found"))
      .collect(Collectors.toList());
  }

  @Override
  public TransactionDTO completeWithUuid(TransactionDTO transactionDTO) {
    TransactionDTO.TransactionDTOBuilder builder = getTransactionDTOBuilder(transactionDTO);
    try {
      Optional.of(transactionDTO)
        .map(dto -> findAccountUuid(dto, TransactionDTO::getAccountId, TransactionDTO::getBic, TransactionDTO::getCurrency, TransactionDTO::getAccountId))
        .map(AssoCorpSubProductAcc::getUuidStructureAcc)
        .map(builder::accountUuid)
        .orElseThrow();
    } catch (RuntimeException ex) {
      // No errors should be thrown up, the API should return an empty response for the unknown account
      log.error("The given TransactionDTO was not found in the sla_entity table, check the contract for: " + transactionDTO);
      builder.accountUuid(transactionDTO.getAccountId());
    }
    return builder.build();
  }

  private String findAccountUuid(AccountBalanceDTO accountBalanceDTO) {
    return Optional.of(accountBalanceDTO)
      .map(dto -> findAccountUuid(dto, AccountBalanceDTO::getAccountId, AccountBalanceDTO::getBic, AccountBalanceDTO::getCurrency, AccountBalanceDTO::getAlias))
      .map(AssoCorpSubProductAcc::getUuidStructureAcc)
      .orElseThrow();
  }

  private <T, W extends String> AssoCorpSubProductAcc findAccountUuid(T dto, Function<T, W> toAccountId, Function<T, W> toBic,
                                                                      Function<T, W> toCurrency, Function<T, W> toAlias) {

    Optional<AssoCorpSubProductAcc> international = Optional.ofNullable(toAccountId.apply(dto))
      .flatMap(accId -> slaEntityRepository.findFirstByAccountInternationalNumberAndBicEntityAccAndCurrency(accId, toBic.apply(dto), toCurrency.apply(dto)));

    Optional<AssoCorpSubProductAcc> local = Optional.ofNullable(toAccountId.apply(dto))
      .flatMap(accId -> slaEntityRepository.findFirstByAccountLocalNumberAndBicEntityAccAndCurrency(accId, toBic.apply(dto), toCurrency.apply(dto)));

    boolean shouldQueryByAlias = Optional.of(dto)
      .filter(TransactionDTO.class::isInstance)
      .map(TransactionDTO.class::cast)
      .map(TransactionDTO::isAccountAlias)
      .orElse(true);

    Optional<AssoCorpSubProductAcc> alias = Optional.ofNullable(toAlias.apply(dto))
      .filter(function -> shouldQueryByAlias)
      .flatMap(function -> serviceAccountRepository.findFirstByAliasAccClientAndAssoCorpSubProductAccBicEntityAccAndAssoCorpSubProductAccCurrency(function, toBic.apply(dto), toCurrency.apply(dto)))
      .map(ServiceAccount::getAssoCorpSubProductAcc);

    return international
      .or(() -> local)
      .or(() -> alias)
      .orElseThrow(() -> new NoSlaConfigurationException(toAlias.apply(dto), toAccountId.apply(dto)));
  }

  private Stream<ServiceAccountFlat> getAccountsUuid(Collection<AccountDTO> accountDTO) {
    Set<String> aliasAccounts = joinAccountInformation(accountDTO, AccountDTO::getAlias);
    Set<String> internationalLocalAccount = joinAccountInformation(accountDTO, AccountDTO::getAccountId);

    return serviceAccountRepository.findAccountUuid(aliasAccounts, internationalLocalAccount)
      .stream();
  }

  private Set<String> joinAccountInformation(Collection<AccountDTO> accountDTO, Function<AccountDTO, String> getAccount) {
    return accountDTO.stream()
      .parallel()
      .filter(dto -> Objects.nonNull(getAccount))
      .map(dto -> String.join("", dto.getBic(), getAccount.apply(dto), dto.getCurrency()))
      .collect(Collectors.toSet());
  }

  private TransactionDTO.TransactionDTOBuilder getTransactionDTOBuilder(TransactionDTO transactionDTO) {
    return TransactionDTO.builder()
      .xSantanderGlobalId(transactionDTO.getXSantanderGlobalId())
      .accountId(transactionDTO.getAccountId())
      .alias(transactionDTO.getAlias())
      .bic(transactionDTO.getBic())
      .currency(transactionDTO.getCurrency())
      .accountingDate(transactionDTO.getAccountingDate())
      .fromAccountingDate(transactionDTO.getFromAccountingDate())
      .toAccountingDate(transactionDTO.getToAccountingDate())
      .limit(transactionDTO.getLimit())
      .offset(transactionDTO.getOffset())
      .bcOffset(transactionDTO.getBcOffset())
      .forReport(transactionDTO.isForReport())
      .extractId(transactionDTO.getExtractId());
  }

  private AccountDTO completeWithUuid(List<AccountDTO> withUuidAccounts, AccountDTO account) {
    return findWithUuid(withUuidAccounts, account)
      .map(withUuidAccount -> account.uuid(withUuidAccount.getUuid())
        .alias(withUuidAccount.getAlias())
        .accountId(withUuidAccount.getAccountId()))
      .orElse(account);
  }

  private Optional<AccountDTO> findWithUuid(List<AccountDTO> withUuidAccounts, AccountDTO account) {
    return withUuidAccounts.stream()
      .filter(withUuidAccount -> isSameServiceAccount(account, withUuidAccount))
      .findFirst();
  }

  private boolean isSameServiceAccount(AccountDTO originalAccount, AccountDTO withUuidAccount) {
    return originalAccount.getBic().equals(withUuidAccount.getBic()) && originalAccount.getCurrency().equals(withUuidAccount.getCurrency())
      && (isSameAccountId(originalAccount, withUuidAccount) || isSameAccountAlias(originalAccount, withUuidAccount));
  }

  private boolean isSameAccountId(AccountDTO originalAccount, AccountDTO withUuidAccount) {
    return Objects.nonNull(originalAccount.getAccountId()) && (originalAccount.getAccountId().equals(withUuidAccount.getAccountId()));
  }

  private boolean isSameAccountAlias(AccountDTO originalAccount, AccountDTO withUuidAccount) {
    return Objects.nonNull(originalAccount.getAlias()) && originalAccount.getAlias().equals(withUuidAccount.getAlias());
  }

  private AccountDTO toAccount(ServiceAccountFlat serviceAccountFlat) {
    return new AccountDTO()
      .accountId(Optional.ofNullable(serviceAccountFlat.getAccountInternational()).orElse(serviceAccountFlat.getAccountLocal()))
      .alias(serviceAccountFlat.getAccountAlias())
      .bic(serviceAccountFlat.getBic())
      .currency(serviceAccountFlat.getCurrency())
      .uuid(serviceAccountFlat.getAccountUuid());
  }
}
