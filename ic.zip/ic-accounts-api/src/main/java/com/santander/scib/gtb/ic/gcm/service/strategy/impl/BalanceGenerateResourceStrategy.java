package com.santander.scib.gtb.ic.gcm.service.strategy.impl;

import com.santander.scib.gtb.ic.gcm.api.balance.concurrency.OrchestrationService;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.ProcessedAccount;
import com.santander.scib.gtb.ic.gcm.model.GenerateFileRequestDTO;
import com.santander.scib.gtb.ic.gcm.model.WorkBookContainer;
import com.santander.scib.gtb.ic.gcm.service.balance.AccountTransactionsService;
import com.santander.scib.gtb.ic.gcm.service.balance.AccountUuidHelper;
import com.santander.scib.gtb.ic.gcm.service.strategy.ResourceType;
import com.santander.scib.gtb.ic.gcm.util.ReportGeneratorUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.BiFunction;

@Slf4j
@Component
@ResourceType(type = "balance")
public class BalanceGenerateResourceStrategy extends AbstractResourceStrategy {

  @Autowired private AccountTransactionsService accountTransactionsService;
  @Autowired private OrchestrationService orchestrationService;
  @Autowired private AccountUuidHelper accountUuidHelper;

  @Override
  public GenerateFileRequestDTO generateResource(GenerateFileRequestDTO generateFileRequest) {
    return Optional.of(generateFileRequest.getAccounts())
      .map(accountUuidHelper::completeWithUuid)
      .map(ProcessedAccount::getValidAccounts)
      .map(dtos -> orchestrationService.orchestrate(dtos, generateFileRequest.getAccountingDate(), generateFileRequest.getVersion()))
      .map(CompletionStage::toCompletableFuture)
      .map(CompletableFuture::join)
      .map(balances -> generateFile(generateFileRequest, balances))
      .map(generateFileRequest::data)
      .orElseThrow(() -> new RuntimeException("Error generating balances report"));
  }

  private byte[] generateFile(GenerateFileRequestDTO generateFileRequest, List<AccountBalanceDTO> balances) {
    List<AccountBalanceDTO> newBalances = new ArrayList<>(balances);
    BiFunction<Integer, WorkBookContainer, Sheet> createRow = (idx, workBookContainer) ->
      ReportGeneratorUtil.generateBalanceRow(newBalances.get(idx - 1), workBookContainer.getSheet().createRow(idx), workBookContainer);

    return generateFile(buildWorkBook(generateFileRequest), createRow, newBalances.size());
  }
}
