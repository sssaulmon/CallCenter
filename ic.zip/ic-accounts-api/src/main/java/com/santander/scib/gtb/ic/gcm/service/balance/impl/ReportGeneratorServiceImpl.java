package com.santander.scib.gtb.ic.gcm.service.balance.impl;

import com.isban.gcb.ic.commons.model.GlobalReport;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.download.DownloadApiResponse;
import com.santander.scib.gtb.ic.gcm.contract.service.IntradiaStorageClientService;
import com.santander.scib.gtb.ic.gcm.repository.GlobalReportRepository;
import com.santander.scib.gtb.ic.gcm.service.balance.ReportGeneratorService;
import com.santander.scib.gtb.ic.gcm.util.SecurityUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.isban.gcb.ic.commons.util.function.FunctionalUtils.not;

@Slf4j
@Service
public class ReportGeneratorServiceImpl implements ReportGeneratorService {

  private static final String WITHOUT_EXTENSION_REGEX = "^(.*)\\..*$";
  private static final String MULTIPLE_FILES_REPORT_NAME = "REPORTS_ALL";
  private final GlobalReportRepository globalReportRepository;
  private final IntradiaStorageClientService intradiaStorageClientService;
  private final List<String> statusReport;

  public ReportGeneratorServiceImpl(GlobalReportRepository globalReportRepository,
                                    IntradiaStorageClientService intradiaStorageClientService,
                                    @Value("#{'${apis.statusReport}'.split(',\\s?')}") List<String> statusReport) {
    this.globalReportRepository = globalReportRepository;
    this.intradiaStorageClientService = intradiaStorageClientService;
    this.statusReport = SecurityUtil.unmodify(statusReport);
  }

  @Override
  public List<DownloadApiResponse> getGenerateReports(String uuid) {

    return globalReportRepository.findByUuidGlobalReportAndStatusInOrderByAccountingDateDesc(uuid, statusReport)
      .orElse(new ArrayList<>())
      .stream()
      .map(DownloadApiResponse::new)
      .collect(Collectors.toList());
  }

  @Override
  public DownloadApiResponse getGenerateZip(String uuid, List<Long> requestId) {
    Map<String, String> files = Stream.of(requestId)
      .map(globalReportRepository::findAllById)
      .flatMap(List::stream)
      .collect(Collectors.toMap(GlobalReport::getFileName, GlobalReport::getS3Path));

    DownloadApiResponse response = new DownloadApiResponse()
      .fileName(getFileName(files));

    return Optional.of(files)
      .filter(not(Map::isEmpty))
      .map(given -> intradiaStorageClientService.getZip(given, response.getFileName()))
      .map(URL::toString)
      .map(response::url)
      .orElse(null);
  }

  private String getFileName(Map<String, String> files) {
    return Optional.of(files)
      .map(Map::keySet)
      .filter(keys -> keys.size() == 1)
      .flatMap(given -> given.stream().findFirst())
      .map(value -> value.replaceAll(WITHOUT_EXTENSION_REGEX, "$1"))
      .orElse(MULTIPLE_FILES_REPORT_NAME)
      .concat(".zip");
  }
}
