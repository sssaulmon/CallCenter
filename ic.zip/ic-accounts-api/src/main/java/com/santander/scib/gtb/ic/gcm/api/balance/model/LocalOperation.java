package com.santander.scib.gtb.ic.gcm.api.balance.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

public class LocalOperation {

  @ApiModelProperty(example = "645", required = true, value = "Local Transaction Code (local transaction codes in order to facilitate multi local reconciliation without using SWIFT transaction codes) are the codes that define the type of transaction in the Local Entity.")
  @NotNull
  @JsonProperty("ltcCode")
  private String ltcCode;

  @ApiModelProperty(example = "\"abono cheque\"", required = true, value = "Local Transaction Code (local transaction codes in order to facilitate multi local reconciliation without using SWIFT transaction codes) are the codes that define the type of transaction in the Local Entity.")
  @NotNull
  @JsonProperty("ltcDescrption")
  private String ltcDescription;

  @ApiModelProperty(example = "\"Transmediterranea 234/11\"", required = true, value = "Aditional information related to the transaction such as beneficiary, sender, concept, among others.")
  @NotNull
  @JsonProperty("aditionalInformation")
  private String aditionalInformation;

  public void setLtcCode(String ltcCode) {
    this.ltcCode = ltcCode;
  }

  public void setLtcDescription(String ltcDescription) {
    this.ltcDescription = ltcDescription;
  }

  public void setAditionalInformation(String aditionalInformation) {
    this.aditionalInformation = aditionalInformation;
  }

  public String getAditionalInformation() {
    return aditionalInformation;
  }

  public String getLtcCode() {
    return ltcCode;
  }

  public String getLtcDescription() {
    return ltcDescription;
  }
}