package com.santander.scib.gtb.ic.gcm.contract.service.impl;

import com.isban.gcb.ic.commons.model.downloadapi.ZipRequest;
import com.santander.scib.gtb.ic.gcm.contract.service.IntradiaStorageClientService;
import com.santander.scib.gtb.ic.gcm.web.exception.AccountBalanceException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.net.URL;
import java.util.Map;

@Slf4j
@Service
public class IntradiaStorageClientServiceImpl implements IntradiaStorageClientService {

  private String intradiaStorageEndPoint;
  private final WebClient webClient;

  public IntradiaStorageClientServiceImpl(@Value("${endpoints.intradia-storage.base}") String intradiaStorageBaseUrl,
                                          @Value("${endpoints.intradia-storage.endpoint.zipped}")
                                            String intradiaStorageEndPoint) {
    this.intradiaStorageEndPoint = intradiaStorageEndPoint;
    this.webClient = WebClient.builder()
      .baseUrl(intradiaStorageBaseUrl)
      .build();
  }

  @Override
  public URL getZip(Map<String, String> metakeys, String fileName) {
    return webClient
      .post()
      .uri(uriBuilder -> uriBuilder.path(intradiaStorageEndPoint).build())
      .bodyValue(new ZipRequest(fileName, metakeys))
      .retrieve()
      .bodyToMono(URL.class)
      .onErrorResume(e -> Mono.error(new AccountBalanceException("ERROR GET ZIP")))
      .block();
  }
}
