package com.santander.scib.gtb.ic.gcm.web.exception;

public class DBConnectionException extends RuntimeException {

  public DBConnectionException() {
    super("Error establishing connection with the database");
  }
}
