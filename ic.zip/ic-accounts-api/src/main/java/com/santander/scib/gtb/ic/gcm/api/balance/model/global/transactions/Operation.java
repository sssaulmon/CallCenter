package com.santander.scib.gtb.ic.gcm.api.balance.model.global.transactions;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class Operation {

  @ApiModelProperty(required = true, value = "")
  @NotNull
  @Valid
  @JsonProperty("localOperation")
  private GlobalLocalOperation localOperation;

  @ApiModelProperty(value = "")
  @Valid
  @JsonProperty("customerOperation")
  private GlobalCustomerOperation customerOperation;

  @ApiModelProperty(example = "\"NCHK\"", required = true, value = "SwiftCode is the standard SWIFT Transaction type code (i.e. NCHK = Check; NCHG = Charges and other expenses; NTRF = Transfer)")
  @NotNull
  @JsonProperty("swiftCode")
  private String swiftCode;

  public void setLocalOperation(GlobalLocalOperation localOperation) {
    this.localOperation = localOperation;
  }

  public void setCustomerOperation(GlobalCustomerOperation customerOperation) {
    this.customerOperation = customerOperation;
  }

  public void setSwiftCode(String swiftCode) {
    this.swiftCode = swiftCode;
  }

  public String getSwiftCode() {
    return swiftCode;
  }

  public GlobalLocalOperation getLocalOperation() {
    return localOperation;
  }
}

