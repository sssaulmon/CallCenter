package com.santander.scib.gtb.ic.gcm.model;

import java.time.LocalDateTime;

public class NotificationError {
  private String bic;
  private String account;
  private String currency;
  private String uuidAccount;
  private String type;
  private LocalDateTime date;
  private String exceptionType;
  private String message;

  public String getBic() {
    return bic;
  }

  public void setBic(String bic) {
    this.bic = bic;
  }

  public NotificationError bic(String bic) {
    this.bic = bic;
    return this;
  }

  public String getAccount() {
    return account;
  }

  public void setAccount(String account) {
    this.account = account;
  }

  public NotificationError account(String account) {
    this.account = account;
    return this;
  }

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public NotificationError currency(String currency) {
    this.currency = currency;
    return this;
  }

  public String getUuidAccount() {
    return uuidAccount;
  }

  public void setUuidAccount(String uuidAccount) {
    this.uuidAccount = uuidAccount;
  }

  public NotificationError uuidAccount(String uuidAccount) {
    this.uuidAccount = uuidAccount;
    return this;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public NotificationError type(String type) {
    this.type = type;
    return this;
  }

  public LocalDateTime getDate() {
    return date;
  }

  public void setDate(LocalDateTime date) {
    this.date = date;
  }

  public NotificationError date(LocalDateTime date) {
    this.date = date;
    return this;
  }

  public String getExceptionType() {
    return exceptionType;
  }

  public void setExceptionType(String exceptionType) {
    this.exceptionType = exceptionType;
  }

  public NotificationError exceptionType(String exceptionType) {
    this.exceptionType = exceptionType;
    return this;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public NotificationError message(String message) {
    this.message = message;
    return this;
  }
}