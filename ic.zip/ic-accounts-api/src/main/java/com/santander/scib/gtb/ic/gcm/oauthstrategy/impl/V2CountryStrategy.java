package com.santander.scib.gtb.ic.gcm.oauthstrategy.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.api.MappedTransaction;
import com.santander.scib.gtb.ic.gcm.config.RequestParamsConstants;
import com.santander.scib.gtb.ic.gcm.model.AccountBalance;
import com.santander.scib.gtb.ic.gcm.model.ApiBicConfiguration;
import com.santander.scib.gtb.ic.gcm.model.Transaction;
import com.santander.scib.gtb.ic.gcm.model.app.entity.AppEntity;
import com.santander.scib.gtb.ic.gcm.model.app.entity.JWTDetail;
import com.santander.scib.gtb.ic.gcm.oauthstrategy.ApiVersion;
import com.santander.scib.gtb.ic.gcm.oauthstrategy.CountryStrategy;
import com.santander.scib.gtb.ic.gcm.service.AccountingDateService;
import com.santander.scib.gtb.ic.gcm.service.ApiBalanceCommunication;
import com.santander.scib.gtb.ic.gcm.service.ApiBicConfigurationService;
import com.santander.scib.gtb.ic.gcm.service.ConvertAmountByCurrencyService;
import com.santander.scib.gtb.ic.gcm.util.DateTimeFormatterUtil;
import com.santander.scib.gtb.ic.gcm.util.TransactionPaginationUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static com.santander.scib.gtb.ic.gcm.config.RequestParamsConstants.ACCOUNT_ID_TYPE;

@Component
@ApiVersion(type = "v2")
public class V2CountryStrategy implements CountryStrategy {

  @Autowired private ApiBalanceCommunication apiBalanceCommunication;
  @Autowired private TransactionPaginationUtil paginationUtil;
  @Autowired private ConvertAmountByCurrencyService convertAmountByCurrencyService;
  @Autowired private ApiBicConfigurationService apiBicConfigurationService;
  @Autowired private AccountingDateService accountingDateService;

  @Override
  public <T extends AccountBalance> Mono<T> getAccounts(AppEntity appEntity, String bic, String accountId,
                                                        String currency, LocalDate accountingDate, Class<T> clazz) {

    boolean isIban = apiBicConfigurationService.loadConfigurationByBic(bic.toUpperCase())
      .map(ApiBicConfiguration::isIbanAccount)
      .orElseThrow(() -> new RuntimeException("Bic not Configured"));

    return apiBalanceCommunication.getAssertion(appEntity.getJwtDetail(), appEntity.getOauth2Client().isProxy(), buildBodyAssertion(appEntity.getJwtDetail()))
      .flatMap(node -> apiBalanceCommunication.getJWTToken(appEntity, buildBodyJWT(appEntity, node.getToken())))
      .map(tokenResponse -> tokenResponse.get(RequestParamsConstants.ACCESS_TOKEN))
      .map(JsonNode::asText)
      .flatMap(token -> apiBalanceCommunication.getAccount(buildAccountUri(isIban, appEntity.getServiceUrl() + accountId),
        token, buildHeaders(appEntity.getClientId()), clazz, appEntity.getOauth2Client().isProxy()));
  }

  @Override
  public <T extends Transaction> MappedTransaction getTransactions(AppEntity appEntity, TransactionDTO transactionDTO, Class<T> clazz) {
    return apiBalanceCommunication.getAssertion(appEntity.getJwtDetail(), appEntity.getOauth2Client().isProxy(), buildBodyAssertion(appEntity.getJwtDetail()))
      .flatMap(node -> apiBalanceCommunication.getJWTToken(appEntity, buildBodyJWT(appEntity, node.getToken())))
      .map(tokenResponse -> tokenResponse.get(RequestParamsConstants.ACCESS_TOKEN))
      .map(JsonNode::asText)
      .flatMap(token -> apiBalanceCommunication.getTransactions(appEntity.getServiceUrl() + transactionDTO.getAccountId() + "/transactions",
        token, buildUriParams(transactionDTO), buildHeaders(appEntity.getClientId()), clazz, appEntity.getOauth2Client().isProxy()))
      .map(Transaction::mapToAccountTransactionListDTO)
      .map(transactions -> convertAmountByCurrencyService.convertAccountTransactions(transactionDTO.getBic(), transactions))
      .block();
  }

  private Map<String, String> buildUriParams(TransactionDTO transactionDTO) {
    Optional<ApiBicConfiguration> apiBicConfiguration = apiBicConfigurationService.loadConfigurationByBic(transactionDTO.getBic().toUpperCase());
    int limit = paginationUtil.getLimit(transactionDTO);

    Map<String, String> uriParams = new HashMap<>();
    Optional.ofNullable(transactionDTO.getOffset())
      .ifPresent(offset -> uriParams.put(RequestParamsConstants.OFFSET, offset));

    uriParams.put(RequestParamsConstants.LIMIT, String.valueOf(limit));

    apiBicConfiguration.map(ApiBicConfiguration::isConvertAmount)
      .filter(Boolean.TRUE::equals)
      .ifPresent(ignored -> {
        uriParams.put(RequestParamsConstants.SORT, RequestParamsConstants.SORT_ORDER_DESC_VALUE);
        uriParams.put(RequestParamsConstants.SORT_DATE, RequestParamsConstants.SORT_DATE_ACCOUNTING_VALUE);
      });

    apiBicConfiguration.map(ApiBicConfiguration::isIbanAccount)
      .filter(Boolean.TRUE::equals)
      .ifPresent(ignored -> uriParams.put(ACCOUNT_ID_TYPE, IBAN_ACCOUNT_TYPE));

    Optional.of(accountingDateService.getFromAccountingDate(transactionDTO))
      .map(DateTimeFormatterUtil::formatGlobalDate)
      .ifPresent(date -> uriParams.put(apiBicConfiguration.map(ApiBicConfiguration::getFromDate)
        .orElse(null), date));
    return uriParams;
  }

  private MultiValueMap<String, String> buildBodyAssertion(JWTDetail jwtDetail) {
    return new LinkedMultiValueMap<>();
  }

  private MultiValueMap<String, String> buildBodyJWT(AppEntity appEntity, String jwt) {
    MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
    map.add(RequestParamsConstants.ASSERTION, jwt);
    map.add(RequestParamsConstants.COUNTRY, appEntity.getCountry());
    map.add(RequestParamsConstants.SCOPE, String.join(" ", appEntity.getOauth2Client().getScopes()));
    map.add(RequestParamsConstants.GRANT_TYPE, appEntity.getOauth2Client().getGrantType());
    return map;
  }

  private Map<String, String> buildHeaders(String clientId) {
    Map<String, String> headers = new HashMap<>();
    headers.put(RequestParamsConstants.SANTANDER_CLIENT_ID, clientId);
    return headers;
  }
}
