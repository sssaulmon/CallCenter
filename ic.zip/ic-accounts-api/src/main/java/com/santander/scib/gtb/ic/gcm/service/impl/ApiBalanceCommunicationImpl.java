package com.santander.scib.gtb.ic.gcm.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.santander.scib.gtb.ic.gcm.api.balance.model.account.ErrorItem;
import com.santander.scib.gtb.ic.gcm.config.RequestParamsConstants;
import com.santander.scib.gtb.ic.gcm.model.AccountBalance;
import com.santander.scib.gtb.ic.gcm.model.JWTResponse;
import com.santander.scib.gtb.ic.gcm.model.Transaction;
import com.santander.scib.gtb.ic.gcm.model.app.entity.AppEntity;
import com.santander.scib.gtb.ic.gcm.model.app.entity.JWTDetail;
import com.santander.scib.gtb.ic.gcm.service.ApiBalanceCommunication;
import com.santander.scib.gtb.ic.gcm.web.exception.AccountNotFoundException;
import com.santander.scib.gtb.ic.gcm.web.exception.BadRequestException;
import com.santander.scib.gtb.ic.gcm.web.exception.ExternalApiException;
import com.santander.scib.gtb.ic.gcm.web.exception.UnauthorizedException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriBuilder;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.apache.http.HttpHeaders.ACCEPT_ENCODING;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

/**
 * The type Api balance communication.
 */
@Slf4j
@Service
public class ApiBalanceCommunicationImpl implements ApiBalanceCommunication {

  @Autowired @Qualifier("webClient") private WebClient client;
  @Autowired @Qualifier("proxyWebClient") private WebClient proxyClient;

  @Override
  // TODO call to STS prepare cache by country and constant STS, change parameter to receive country
  public Mono<JWTResponse> getAssertion(JWTDetail jwtDetail, boolean proxy, MultiValueMap<String, String> body) {
    String encodedClientData = Base64Utils
      .encodeToString(jwtDetail.getClientId().concat(":")
        .concat(jwtDetail.getClientSecret()).getBytes());

    return getClient(proxy).post()
      .uri(jwtDetail.getJwtEndpoint())
      .header("Authorization", "Basic " + encodedClientData)
      .contentType(MediaType.APPLICATION_JSON)
      .body(BodyInserters.fromValue(jwtDetail.getAudienceModel()))
      .retrieve()
      .onStatus(HttpStatus::is4xxClientError, this::handle5xxError)
      .onStatus(HttpStatus::is5xxServerError, this::handle5xxError)
      .bodyToMono(JWTResponse.class);
  }

  @Override
  // TODO call to SOS prepare cache by country and constant SOS, change return by String (token)
  public Mono<JsonNode> getJWTToken(AppEntity appEntity, MultiValueMap<String, String> body) {
    String encodedClientData = Base64Utils
      .encodeToString(appEntity.getClientId().concat(":")
        .concat(appEntity.getOauth2Client().getClientSecret()).getBytes());

    log.debug("getJWTToken is Proxy " + appEntity.getOauth2Client().isProxy());
    log.debug("getJWTToken Uri " + appEntity.getOauth2Client().getAccessTokenUri());
    log.debug("getJWTToken Header Authorization " + "Basic " + encodedClientData);
    body.forEach((key, values) -> {
      log.debug("getJWTToken body key " + key);
      values.forEach(value -> log.info("getJWTToken body value " + value));
    });
    return getClient(appEntity.getOauth2Client().isProxy()).post()
      .uri(appEntity.getOauth2Client().getAccessTokenUri())
      .header("Authorization", "Basic " + encodedClientData)
      .contentType(MediaType.APPLICATION_FORM_URLENCODED)
      .body(BodyInserters.fromFormData(body))
      .retrieve()
      .onStatus(HttpStatus::is4xxClientError, this::handle5xxError)
      .onStatus(HttpStatus::is5xxServerError, this::handle5xxError)
      .bodyToMono(JsonNode.class);
  }

  @Override
  public <T extends AccountBalance> Mono<T> getAccount(String uri, String accessTokenValue, Map<String, String> headers,
                                                       Class<T> clazz, boolean proxy) {

    log.debug("getAccount is Proxy " + proxy);
    log.debug("getAccount Uri" + uri);
    log.debug("getAccount Header Authorization " + "Bearer " + accessTokenValue);
    log.debug("getAccount Header " + RequestParamsConstants.SANTANDER_CLIENT_ID + " " + headers.get(RequestParamsConstants.SANTANDER_CLIENT_ID));
    log.debug("getAccount Header " + RequestParamsConstants.IBM_CLIENT_ID + " " + headers.get(RequestParamsConstants.IBM_CLIENT_ID));
    log.debug("getAccount Header " + RequestParamsConstants.COUNTRY_BIC + " " + headers.get(RequestParamsConstants.COUNTRY_BIC));

    return getClient(proxy).get()
      .uri(uri)
      .headers(h -> h.setBearerAuth(accessTokenValue))
      .header(RequestParamsConstants.SANTANDER_CLIENT_ID, headers.get(RequestParamsConstants.SANTANDER_CLIENT_ID))
      .header(RequestParamsConstants.IBM_CLIENT_ID, headers.get(RequestParamsConstants.IBM_CLIENT_ID))
      .header(RequestParamsConstants.COUNTRY_BIC, headers.get(RequestParamsConstants.COUNTRY_BIC))
      .retrieve()
      .onStatus(HttpStatus::is4xxClientError, this::handleError4xx)
      .onStatus(HttpStatus::is5xxServerError, this::handle5xxError)
      .bodyToMono(clazz);
  }

  @Override
  public <T extends Transaction> Mono<T> getTransactions(String uri, String accessTokenValue,
                                                         Map<String, String> uriParams, Map<String, String> headers,
                                                         Class<T> clazz, boolean proxy) {

    String[] urlParts = getUrlParts(uri);

    return getClient(proxy).get()
      .uri(uriBuilder -> getUriBuilder(urlParts, uriBuilder, uriParams))
      .headers(h -> h.setBearerAuth(accessTokenValue))
      .header(RequestParamsConstants.SANTANDER_CLIENT_ID, headers.get(RequestParamsConstants.SANTANDER_CLIENT_ID))
      .header(RequestParamsConstants.IBM_CLIENT_ID, headers.get(RequestParamsConstants.IBM_CLIENT_ID))
      .header(RequestParamsConstants.COUNTRY_BIC, headers.get(RequestParamsConstants.COUNTRY_BIC))
      .header(ACCEPT_ENCODING, APPLICATION_JSON_VALUE)
      .retrieve()
      .onStatus(HttpStatus::is4xxClientError, this::handleError4xx)
      .onStatus(HttpStatus::is5xxServerError, this::handle5xxError)
      .bodyToMono(clazz);
  }

  @Override
  public <T extends Transaction> Mono<ResponseEntity<List<T>>> getTransactionsList(
    String uri, String accessTokenValue, Map<String, String> uriParams, Map<String, String> headers, Class<T> clazz,
    boolean proxy) {
    String[] urlParts = getUrlParts(uri);

    return getClient(proxy).get()
      .uri(uriBuilder -> getUriBuilder(urlParts, uriBuilder, uriParams))
      .headers(h -> h.setBearerAuth(accessTokenValue))
      .header(RequestParamsConstants.SANTANDER_CLIENT_ID, headers.get(RequestParamsConstants.SANTANDER_CLIENT_ID))
      .header(RequestParamsConstants.IBM_CLIENT_ID, headers.get(RequestParamsConstants.IBM_CLIENT_ID))
      .header(RequestParamsConstants.COUNTRY_BIC, headers.get(RequestParamsConstants.COUNTRY_BIC))
      .retrieve()
      .onStatus(HttpStatus::is4xxClientError, this::handle5xxError)
      .onStatus(HttpStatus::is5xxServerError, this::handle5xxError)
      .toEntityList(clazz);
  }

  private URI getUriBuilder(String[] urlParts, UriBuilder uriBuilder, Map<String, String> uriParams) {
    uriParams.forEach((key, value) -> uriBuilder.queryParam(key, "{" + key + "}"));

    return Optional.of(urlParts)
      .filter(parts -> parts.length >= 4)
      .map(parts -> uriBuilder.scheme(urlParts[0])
        .host(urlParts[1])
        .port(urlParts[2])
        .path(urlParts[3]))
      .orElseGet(() -> uriBuilder.scheme(urlParts[0])
        .host(urlParts[1])
        .path(urlParts[2]))
      .build(uriParams);
  }

  private WebClient getClient(boolean proxy) {
    return Optional.of(proxy)
      .filter(Boolean.TRUE::equals)
      .map(val -> this.proxyClient)
      .orElse(this.client);
  }

  private Mono<? extends Throwable> handle5xxError(ClientResponse clientResponse) {
    log.error("Error performing request. Status: {}", clientResponse.statusCode());
    return clientResponse.bodyToMono(ErrorItem.class)
      .flatMap(errorItem -> Mono.error(new ExternalApiException(errorItem.getMessage(), errorItem.getCode())));
  }

  private Mono<? extends Throwable> handleError4xx(ClientResponse clientResponse) {
    log.error("Error performing request. Status: {}", clientResponse.statusCode());

    switch (clientResponse.statusCode()) {
      case UNAUTHORIZED:
        return Mono.error(new UnauthorizedException());
      case NOT_FOUND:
        return Mono.error(new AccountNotFoundException());
      default:
        return clientResponse.bodyToMono(ErrorItem.class)
          .flatMap(errorItem -> Mono.error(new BadRequestException(errorItem.getDescription())));
    }
  }

  private String[] getUrlParts(String url) {
    String twoPointsOcurrence = "^(.*):(.*):(.*)$";
    String fullUrl = "^(.*?)://(.*?):(\\d+?)/(.*)$";
    String noPortUrl = "^(.*?)://(.*?)/(.*)$";

    return Optional.of(url)
      .filter(uri -> uri.matches(twoPointsOcurrence))
      .map(uri -> uri.replaceAll(fullUrl, String.join(",", "$1", "$2", "$3", "$4")).split(","))
      .orElseGet(() -> url.replaceAll(noPortUrl, String.join(",", "$1", "$2", "$3")).split(","));
  }
}
