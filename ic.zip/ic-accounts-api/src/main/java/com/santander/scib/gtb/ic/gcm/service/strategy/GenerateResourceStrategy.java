package com.santander.scib.gtb.ic.gcm.service.strategy;

import com.santander.scib.gtb.ic.gcm.model.GenerateFileRequestDTO;
import com.santander.scib.gtb.ic.gcm.model.WorkBookContainer;
import org.apache.poi.ss.usermodel.Sheet;

import java.io.ByteArrayOutputStream;
import java.util.function.BiFunction;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static com.isban.gcb.ic.commons.util.Unchecked.consumer;

public interface GenerateResourceStrategy {

  GenerateResourceStrategy validateInputData(GenerateFileRequestDTO generateFileRequest);

  GenerateFileRequestDTO generateResource(GenerateFileRequestDTO generateFileRequest);

  default byte[] generateFile(WorkBookContainer workBookContainer, BiFunction<Integer, WorkBookContainer, Sheet> createRow,
                              int size) {
    ByteArrayOutputStream file = new ByteArrayOutputStream();
    Stream.of(workBookContainer)
      .map(bookContainer -> IntStream.rangeClosed(1, size)
        .boxed()
        .map(idx -> createRow.apply(idx, bookContainer))
        .reduce((sheet1, sheet2) -> sheet2))
      .findFirst()
      .ifPresent(consumer(rows -> workBookContainer.getWorkbook().write(file)));

    return file.toByteArray();
  }
}
