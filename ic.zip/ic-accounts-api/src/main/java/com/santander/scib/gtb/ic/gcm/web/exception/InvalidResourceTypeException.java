package com.santander.scib.gtb.ic.gcm.web.exception;

public class InvalidResourceTypeException extends RuntimeException {

  public InvalidResourceTypeException(String message) {
    super(message);
  }
}
