package com.santander.scib.gtb.ic.gcm.api.balance.concurrency.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.CustomizableThreadFactory;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

@Configuration
public class OrchestrationConfig {

  @Value("${apis.orchestration.apiPool}") private int apiParallelism;
  @Value("${apis.orchestration.dbPool}") private int dbParallelism;

  @Bean("apiExecutor")
  public Executor getApiOrchestratorExecutor() {
    return Executors.newFixedThreadPool(apiParallelism, new CustomizableThreadFactory("icApiOrchestrationPool-apiWorker-"));
  }

  @Bean("dbExecutor")
  public Executor getDbOrchestratorExecutor() {
    return Executors.newFixedThreadPool(dbParallelism, new CustomizableThreadFactory("icApiOrchestrationPool-dbWorker-"));
  }

  @Bean("sleepExecutor")
  public ScheduledExecutorService getSleepExecutor() {
    return Executors.newSingleThreadScheduledExecutor(new CustomizableThreadFactory("icApiOrchestrationPool-sleepWorker-"));
  }
}