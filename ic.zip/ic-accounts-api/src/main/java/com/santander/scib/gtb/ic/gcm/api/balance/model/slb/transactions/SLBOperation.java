package com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.gtb.ic.gcm.api.balance.model.Operation;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class SLBOperation extends Operation {

  @ApiModelProperty(required = true, value = "")
  @NotNull
  @Valid
  @JsonProperty("localOperation")
  private SLBLocalOperation localOperation;

  public SLBLocalOperation getLocalOperation() {
    return localOperation;
  }

  public void setLocalOperation(SLBLocalOperation localOperation) {
    this.localOperation = localOperation;
  }
}
