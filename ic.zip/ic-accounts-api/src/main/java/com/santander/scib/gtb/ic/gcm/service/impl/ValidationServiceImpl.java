package com.santander.scib.gtb.ic.gcm.service.impl;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.service.ValidationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolationException;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * The type Validation service.
 */
@Service
@Slf4j
public class ValidationServiceImpl implements ValidationService {

  @Override
  public List<AccountDTO> apply(List<AccountDTO> source) {
    source.stream()
      .parallel()
      .forEach(this::validateAliasOrAccountId);
    return source;
  }

  private void validateAliasOrAccountId(AccountDTO account) {
    Optional.of(Objects.nonNull(account.getAccountId()) ^ Objects.nonNull(account.getAlias()))
      .filter(Boolean.TRUE::equals)
      .orElseThrow(() -> new ConstraintViolationException("One between alias and accountId must be present",
        Collections.emptySet()));
  }
}



