package com.santander.scib.gtb.ic.gcm.repository;

import com.santander.scib.gtb.ic.gcm.model.ExcelReportLanguage;
import com.santander.scib.gtb.ic.gcm.model.ExcelReportLanguageId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ExcelReportLanguageRepository extends
  JpaRepository<ExcelReportLanguage, ExcelReportLanguageId> {

  @Query("select l.value from ExcelReportLanguage l " +
    "where l.language = :language and l.type = :type order by l.order asc")
  List<String> listHeaders(@Param("language") String language, @Param("type") String type);
}
