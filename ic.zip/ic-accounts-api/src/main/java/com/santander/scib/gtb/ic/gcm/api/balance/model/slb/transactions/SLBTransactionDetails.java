package com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.gtb.ic.gcm.api.balance.model.TransactionDetails;
import com.santander.scib.gtb.ic.gcm.api.balance.model.account.ReferenceItem;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SLBTransactionDetails extends TransactionDetails {

  @ApiModelProperty(value = "Balance result of the account after the transaction.")
  @JsonProperty("balanceResult")
  private Amount balanceResult;

  @ApiModelProperty(value = "Operation details.")
  @JsonProperty("operation")
  private SLBOperation operation;

  @ApiModelProperty(value = "References details.")
  @JsonProperty("references")
  private ReferenceItem references;

  public Amount getBalanceResult() {
    return balanceResult;
  }

  public void setBalanceResult(Amount balanceResult) {
    this.balanceResult = balanceResult;
  }

  public SLBOperation getOperation() {
    return operation;
  }

  public void setOperation(SLBOperation operation) {
    this.operation = operation;
  }

  public void setReferences(ReferenceItem references) {
    this.references = references;
  }

  public ReferenceItem getReferences() {
    return references;
  }
}
