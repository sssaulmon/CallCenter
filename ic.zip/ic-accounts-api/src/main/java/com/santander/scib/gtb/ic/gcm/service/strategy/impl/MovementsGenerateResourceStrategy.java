package com.santander.scib.gtb.ic.gcm.service.strategy.impl;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionResponse;
import com.santander.scib.gtb.ic.gcm.model.GenerateFileRequestDTO;
import com.santander.scib.gtb.ic.gcm.model.WorkBookContainer;
import com.santander.scib.gtb.ic.gcm.service.balance.AccountTransactionsService;
import com.santander.scib.gtb.ic.gcm.service.balance.AccountUuidHelper;
import com.santander.scib.gtb.ic.gcm.service.strategy.GenerateResourceStrategy;
import com.santander.scib.gtb.ic.gcm.service.strategy.ResourceType;
import com.santander.scib.gtb.ic.gcm.util.ReportGeneratorUtil;
import com.santander.scib.gtb.ic.gcm.web.exception.InputValidationException;
import com.santander.scib.gtb.ic.gcm.web.exception.NoTransactionsFoundException;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;

@Slf4j
@Component
@ResourceType(type = "movements")
public class MovementsGenerateResourceStrategy extends AbstractResourceStrategy {

  private AccountTransactionsService accountTransactionsService;
  private final AccountUuidHelper accountUuidHelper;

  public MovementsGenerateResourceStrategy(AccountTransactionsService accountTransactionsService,
                                           AccountUuidHelper accountUuidHelper) {
    this.accountTransactionsService = accountTransactionsService;
    this.accountUuidHelper = accountUuidHelper;
  }

  @Override
  public GenerateResourceStrategy validateInputData(GenerateFileRequestDTO request) {
    super.validateInputData(request);

    Optional.ofNullable(request.getAccounts())
      .filter(accounts -> accounts.size() == 1)
      .orElseThrow(() -> new InputValidationException("Failed Input Validation: Invalid Multiple Accounts"
      ));
    return this;
  }

  @Override
  public GenerateFileRequestDTO generateResource(GenerateFileRequestDTO generateFileRequest) {
    return Optional.ofNullable(getTransactionDTO(generateFileRequest))
      .map(accountUuidHelper::completeWithUuid)
      .map(accountTransactionsService::getAccountTransactions)
      .map(AccountTransactionResponse::getAccountTransactionDTO)
      .map(accounts -> generateTransactions(generateFileRequest, accounts))
      .map(generateFileRequest::data)
      .orElseThrow(() -> new NoTransactionsFoundException("Error generating transactions report"));
  }

  private TransactionDTO getTransactionDTO(GenerateFileRequestDTO generateFileRequest) {
    return generateFileRequest.getAccounts().stream()
      .findFirst()
      .map(accountDTO -> getTransactionDTO(accountDTO, generateFileRequest))
      .orElseThrow(RuntimeException::new);
  }

  private TransactionDTO getTransactionDTO(AccountDTO accountDTO, GenerateFileRequestDTO generateFileRequest) {
    return TransactionDTO.builder()
      .accountId(accountDTO.getAccountId())
      .alias(accountDTO.getAlias())
      .currency(accountDTO.getCurrency())
      .bic(accountDTO.getBic())
      .fromAccountingDate(generateFileRequest.getFromAccountingDate())
      .toAccountingDate(generateFileRequest.getToAccountingDate())
      .accountingDate(generateFileRequest.getAccountingDate())
      .forReport(true)
      .build();
  }

  private byte[] generateTransactions(GenerateFileRequestDTO generateFileRequest, List<AccountTransactionDTO> transactions) {
    BiFunction<Integer, WorkBookContainer, Sheet> createRow = (idx, workBookContainer) ->
      ReportGeneratorUtil.writeTransaction(
        transactions.get(idx - 1), workBookContainer.getSheet().createRow(idx), workBookContainer);

    return generateFile(buildWorkBook(generateFileRequest), createRow, transactions.size());
  }
}
