package com.santander.scib.gtb.ic.gcm.api.balance.model.output.download;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.gcb.ic.commons.model.GlobalReport;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.serde.LocalDateTimeDeserializer;
import com.santander.scib.gtb.ic.gcm.serde.LocalDateTimeSerializer;

import java.time.LocalDateTime;
import java.util.Optional;

import static java.util.function.Predicate.not;

/**
 * The type Download api response.
 */
public class DownloadApiResponse {

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String reportId;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String fileName;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private LocalDateTime date;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String status;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String url;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String fileType;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private AccountDTO account;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private LocalDateTime userDate;

  /**
   * Instantiates a new Download api response.
   */
  public DownloadApiResponse() {
  }

  /**
   * Instantiates a new Download api response.
   *
   * @param report the report
   */
  public DownloadApiResponse(GlobalReport report) {
    reportId = String.valueOf(report.getId());
    fileName = report.getFileName();
    fileType = report.getType();
    date = report.getLastModifiedDate();
    status = report.getStatus();
    userDate = report.getAccountingDate();
    account = buildAccount(report);
  }

  private AccountDTO buildAccount(GlobalReport report) {
    return new AccountDTO()
      .bic(report.getBic())
      .accountId(report.getAccount())
      .currency(report.getCurrency())
      .identifier(Optional.of(report.getContractNumber())
        .filter(not(value -> value.equals("API")))
        .orElse(null));
  }

  /**
   * Gets report id.
   *
   * @return the report id
   */
  public String getReportId() {
    return reportId;
  }

  /**
   * Gets file name.
   *
   * @return the file name
   */
  public String getFileName() {
    return fileName;
  }

  /**
   * Gets date.
   *
   * @return the date
   */
  public LocalDateTime getDate() {
    return date;
  }

  /**
   * Gets status.
   *
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Gets url.
   *
   * @return the url
   */
  public String getUrl() {
    return url;
  }

  /**
   * Gets file type.
   *
   * @return the file type
   */
  public String getFileType() {
    return fileType;
  }

  /**
   * Gets account.
   *
   * @return the account
   */
  public AccountDTO getAccount() {
    return account;
  }

  /**
   * Gets user date.
   *
   * @return the user date
   */
  @JsonSerialize(using = LocalDateTimeSerializer.class)
  @JsonDeserialize(using = LocalDateTimeDeserializer.class)
  public LocalDateTime getUserDate() {
    return userDate;
  }

  /**
   * Report id download api response.
   *
   * @param reportId the report id
   * @return the download api response
   */
  public DownloadApiResponse reportId(String reportId) {
    this.reportId = reportId;
    return this;
  }

  /**
   * File name download api response.
   *
   * @param fileName the file name
   * @return the download api response
   */
  public DownloadApiResponse fileName(String fileName) {
    this.fileName = fileName;
    return this;
  }

  /**
   * Date download api response.
   *
   * @param date the date
   * @return the download api response
   */
  public DownloadApiResponse date(LocalDateTime date) {
    this.date = date;
    return this;
  }

  /**
   * Status download api response.
   *
   * @param status the status
   * @return the download api response
   */
  public DownloadApiResponse status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Url download api response.
   *
   * @param url the url
   * @return the download api response
   */
  public DownloadApiResponse url(String url) {
    this.url = url;
    return this;
  }

  /**
   * File type download api response.
   *
   * @param fileType the file type
   * @return the download api response
   */
  public DownloadApiResponse fileType(String fileType) {
    this.fileType = fileType;
    return this;
  }
}
