package com.santander.scib.gtb.ic.gcm.api.balance.model.global.transactions;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.gtb.ic.gcm.api.balance.model.TransactionsDataListItem;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class GlobalTransactionsDataListItem extends TransactionsDataListItem {

  @ApiModelProperty(value = "Transaction details response.")
  @JsonProperty("transactionDetails")
  private GlobalTransactionDetails transactionDetails;

  public GlobalTransactionDetails getTransactionDetails() {
    return transactionDetails;
  }

  public void setTransactionDetails(GlobalTransactionDetails transactionDetails) {
    this.transactionDetails = transactionDetails;
  }
}
