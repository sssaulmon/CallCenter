package com.santander.scib.gtb.ic.gcm.api.balance.model.global.transactions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
public class Reference {

  private String transactionClientReference;
  private String transactionBatchReference;
  private String transactionInternalReference;
}
