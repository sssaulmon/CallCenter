package com.santander.scib.gtb.ic.gcm.service.balance;

import com.isban.gcb.ic.commons.balance.cache.dto.ExtractDto;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.ProcessedAccount;

import java.util.Collection;

public interface AccountUuidHelper {

  ExtractDto transform(AccountBalanceDTO accountBalanceDTO);

  ProcessedAccount completeWithUuid(Collection<AccountDTO> accountDTO);

  TransactionDTO completeWithUuid(TransactionDTO transactionDTO);
}
