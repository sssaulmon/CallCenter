package com.santander.scib.gtb.ic.gcm.model;

import com.google.common.base.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * The type Excel report language.
 */
@Entity
@Table(
  name = "excel_report"
)
@IdClass(ExcelReportLanguageId.class)
public class ExcelReportLanguage implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "language")
  private String language;

  @Id
  @Column(name = "type")
  private String type;

  @Id
  @Column(name = "order_column")
  private int order;

  @Column(name = "value")
  private String value;

  @Column(name="repeatable")
  private boolean repeatable;

  /**
   * Gets language.
   *
   * @return the language
   */
  public String getLanguage() {
    return language;
  }

  /**
   * Sets language.
   *
   * @param language the language
   */
  public void setLanguage(String language) {
    this.language = language;
  }

  /**
   * Gets type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets type.
   *
   * @param type the type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets order.
   *
   * @return the order
   */
  public int getOrder() {
    return order;
  }

  /**
   * Sets order.
   *
   * @param order the order
   */
  public void setOrder(int order) {
    this.order = order;
  }

  /**
   * Gets value.
   *
   * @return the value
   */
  public String getValue() {
    return value;
  }

  /**
   * Sets value.
   *
   * @param value the value
   */
  public void setValue(String value) {
    this.value = value;
  }

  /**
   * Is repeatable boolean.
   *
   * @return the boolean
   */
  public boolean isRepeatable() {
    return repeatable;
  }

  /**
   * Sets repeatable.
   *
   * @param repeatable the repeatable
   */
  public void setRepeatable(boolean repeatable) {
    this.repeatable = repeatable;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    ExcelReportLanguage that = (ExcelReportLanguage) o;
    return order == that.order &&
      Objects.equal(language, that.language) &&
      Objects.equal(type, that.type);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(language, type, order);
  }
}
