package com.santander.scib.gtb.ic.gcm.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.serde.LocalDateTimeDeserializer;
import com.santander.scib.gtb.ic.gcm.serde.LocalDateTimeSerializer;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

public class GenerateFileRequestDTO {
  private String type;
  private String uuid;
  private LocalDateTime userDate;
  private LocalDate accountingDate;
  private LocalDate fromAccountingDate;
  private LocalDate toAccountingDate;
  private String fileName;
  private Set<AccountDTO> accounts;
  private String status;
  private byte[] data;
  private CustomizationDTO customization;
  private String version;

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getUuid() {
    return uuid;
  }

  public void setUuid(String uuid) {
    this.uuid = uuid;
  }

  @JsonSerialize(using = LocalDateTimeSerializer.class)
  @JsonDeserialize(using = LocalDateTimeDeserializer.class)
  public LocalDateTime getUserDate() {
    return userDate;
  }

  public void setUserDate(LocalDateTime userDate) {
    this.userDate = userDate;
  }

  public LocalDate getAccountingDate() {
    return accountingDate;
  }

  public void setAccountingDate(LocalDate accountingDate) {
    this.accountingDate = accountingDate;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public LocalDate getFromAccountingDate() {
    return fromAccountingDate;
  }

  public void setFromAccountingDate(LocalDate fromAccountingDate) {
    this.fromAccountingDate = fromAccountingDate;
  }

  public LocalDate getToAccountingDate() {
    return toAccountingDate;
  }

  public void setToAccountingDate(LocalDate toAccountingDate) {
    this.toAccountingDate = toAccountingDate;
  }

  public Set<AccountDTO> getAccounts() {
    return accounts;
  }

  public void setAccounts(Set<AccountDTO> accounts) {
    this.accounts = accounts;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public GenerateFileRequestDTO status(String status) {
    this.status = status;
    return this;
  }

  public GenerateFileRequestDTO version(String version) {
    this.version = version;
    return this;
  }

  public GenerateFileRequestDTO data(byte[] data) {
    this.data = data;
    return this;
  }

  @JsonIgnore
  public byte[] getData() {
    return data;
  }

  public CustomizationDTO getCustomization() {
    return customization;
  }

  public void setCustomization(CustomizationDTO customization) {
    this.customization = customization;
  }
}
