package com.santander.scib.gtb.ic.gcm.model.app.entity;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class AppEntity {

  private String serviceUrl;
  private String clientId;
  private String country;
  private String origin;
  private JWTDetail jwtDetail;
  private Oauth2Client oauth2Client;
  private boolean enabled;
}
