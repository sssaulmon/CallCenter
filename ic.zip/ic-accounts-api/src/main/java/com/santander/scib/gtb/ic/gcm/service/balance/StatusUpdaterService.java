package com.santander.scib.gtb.ic.gcm.service.balance;

import java.time.LocalDateTime;

/**
 * The interface Status updater service.
 */
public interface StatusUpdaterService {

  /**
   * Process update status expirated reports.
   *
   * @param processorDate the processor date
   */
  void process(LocalDateTime processorDate);
}
