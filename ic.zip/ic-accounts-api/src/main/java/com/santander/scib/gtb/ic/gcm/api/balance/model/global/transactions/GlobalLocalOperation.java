package com.santander.scib.gtb.ic.gcm.api.balance.model.global.transactions;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

public class GlobalLocalOperation {

  @ApiModelProperty(example = "645", required = true, value = "Local Transaction Code (local transaction codes in order to facilitate multi local reconciliation without using SWIFT transaction codes) are the codes that define the type of transaction in the Local Entity.")
  @NotNull
  @JsonProperty("ltcCode")
  private String ltcCode;

  @ApiModelProperty(example = "\"abono cheque\"", required = true, value = "Local Transaction Code (local transaction codes in order to facilitate multi local reconciliation without using SWIFT transaction codes) are the codes that define the type of transaction in the Local Entity.")
  @NotNull
  @JsonProperty("ltcDescription")
  private String ltcDescription;

  @ApiModelProperty(example = "\"Transmediterranea 234/11\"", required = true, value = "Aditional information related to the transaction such as beneficiary, sender, concept, among others.")
  @NotNull
  @JsonProperty("additionalInformation")
  private String additionalInformation;

  public void setLtcCode(String ltcCode) {
    this.ltcCode = ltcCode;
  }

  public void setLtcDescription(String ltcDescription) {
    this.ltcDescription = ltcDescription;
  }

  public void setAdditionalInformation(String additionalInformation) {
    this.additionalInformation = additionalInformation;
  }

  public String getAdditionalInformation() {
    return additionalInformation;
  }
}

