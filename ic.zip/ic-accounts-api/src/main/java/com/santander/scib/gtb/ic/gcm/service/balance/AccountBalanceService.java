package com.santander.scib.gtb.ic.gcm.service.balance;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CompletionStage;

/**
 * The interface Account balance service.
 */
public interface AccountBalanceService {

  /**
   * Find account balance api completion stage.
   *
   * @param accountDTO     the account dto
   * @param accountingDate the accounting date
   * @return the completion stage
   */
  CompletionStage<AccountBalanceDTO> findAccountBalanceAPI(AccountDTO accountDTO, LocalDate accountingDate);

  /**
   * Find account balance repository completion stage.
   *
   * @param accountDTO     the account dto
   * @param accountingDate the accounting date
   * @return the completion stage
   */
  CompletionStage<AccountBalanceDTO> findAccountBalanceRepository(AccountDTO accountDTO, LocalDate accountingDate);

  AccountBalanceDTO findAccountBalance(AccountDTO accountDTO, LocalDate accountingDate);

  /**
   * Find accounts balance repository set.
   *
   * @param accountDTO     the account dto
   * @param accountingDate the accounting date
   * @return the set
   */
  List<AccountBalanceDTO> findAccountsBalanceRepository(List<AccountDTO> accountDTO, LocalDate accountingDate);
}
