package com.santander.scib.gtb.ic.gcm.util;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.LinkDTO;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;

import static java.util.function.Predicate.not;

@Component
public class LinkBuilderUtil {

  private static final String PARAM_LIMIT = "?limit=";
  private static final String PARAM_BC_OFFSET = "bc_offset=";
  private static final String PARAM_OFFSET = "offset=";
  private static final String PARAM_ACCOUNTING_DATE = "accounting_date=";
  private static final String PARAM_FROM_ACCOUNTING_DATE = "from_accounting_date=";
  private static final String PARAM_TO_ACCOUNTING_DATE = "to_accounting_date=";
  private static final String PARAM_EXTRACT = "extract=";

  private final TransactionPaginationUtil paginationUtil;

  public LinkBuilderUtil(TransactionPaginationUtil paginationUtil) {
    this.paginationUtil = paginationUtil;
  }

  public LinkDTO build(TransactionDTO transactionDTO, Integer currentDbResponseSize, Integer currentApiResponseSize) {
    int pageLimit = paginationUtil.getLimit(transactionDTO);
    return LinkDTO.builder()
      .first(buildFirstPageLink(transactionDTO, pageLimit, currentDbResponseSize))
      .prev(buildPreviousPageLink(transactionDTO, pageLimit, currentDbResponseSize))
      .next(buildNextPageLink(transactionDTO, pageLimit, currentDbResponseSize, currentApiResponseSize))
      .build();
  }

  private String buildFirstPageLink(TransactionDTO transactionDTO, int pageLimit, Integer currentDbResponseSize) {
    return buildUriMain(transactionDTO) + String.join("&", getMainParams(transactionDTO, pageLimit, currentDbResponseSize));
  }

  private String buildPreviousPageLink(TransactionDTO transactionDTO, int pageLimit, Integer currentDbResponseSize) {
    List<String> uriParams = getMainParams(transactionDTO, pageLimit, currentDbResponseSize);

    String bcOffsetParam = getIntegerParam(transactionDTO.getBcOffset(), (bcOffset -> bcOffset > 0), buildPreviousBcOffset(transactionDTO, pageLimit));
    Optional.ofNullable(bcOffsetParam)
      .ifPresent(uriParams::add);

    String offsetParam = transactionDTO.getPrevOffsetFromApi();
    Optional.ofNullable(offsetParam)
      .map(PARAM_OFFSET::concat)
      .filter(not("offset=0"::equals))
      .ifPresent(uriParams::add);

    return Objects.nonNull(bcOffsetParam) || (Objects.nonNull(offsetParam) && !"0".equals(offsetParam)) ?
      buildUriMain(transactionDTO) + String.join("&", uriParams) : null;
  }

  private String buildNextPageLink(TransactionDTO transactionDTO, int pageLimit, Integer currentDbResponseSize, Integer currentApiResponseSize) {
    List<String> uriParams = getMainParams(transactionDTO, pageLimit, currentDbResponseSize);

    String bcOffsetParam = getIntegerParam(pageLimit, (limit -> limit.equals(getIntValue(currentDbResponseSize) + getIntValue(currentApiResponseSize))),
      buildNextBcOffsetParameter(transactionDTO.getBcOffset(), currentDbResponseSize));
    Optional.ofNullable(bcOffsetParam)
      .filter(not("bc_offset=0"::equals))
      .ifPresent(uriParams::add);

    String offsetParam = Optional.of(transactionDTO)
      .filter(dto -> Objects.isNull(dto.getLastOffsetFromApi()) || !dto.getLastOffsetFromApi().equals(dto.getNextOffsetFromApi()))
      .map(TransactionDTO::getNextOffsetFromApi)
      .orElse("0");

    Optional.of(offsetParam)
      .map(PARAM_OFFSET::concat)
      .filter(not("offset=0"::equals))
      .ifPresent(uriParams::add);

    return (Objects.nonNull(bcOffsetParam) && !"0".equals(bcOffsetParam)) || !"0".equals(offsetParam) ?
      buildUriMain(transactionDTO) + String.join("&", uriParams) : null;
  }

  private String buildUriMain(TransactionDTO transactionDTO) {
    return Optional.of(transactionDTO.getBic() + transactionDTO.getAccountId() + transactionDTO.getCurrency())
      .map(account -> String.join("/", "/balances", account, "transactions"))
      .orElseThrow(IllegalArgumentException::new);
  }

  private List<String> getMainParams(TransactionDTO transactionDTO, int pageLimit, Integer currentDbResponseSize) {
    List<String> mainUriParams = new ArrayList<>();
    mainUriParams.add(PARAM_LIMIT + pageLimit);
    concatExtractParameter(transactionDTO, pageLimit, currentDbResponseSize, mainUriParams);
    Optional.ofNullable(transactionDTO.getAccountingDate())
      .map(date -> PARAM_ACCOUNTING_DATE.concat(date.toString()))
      .ifPresent(mainUriParams::add);
    Optional.ofNullable(transactionDTO.getFromAccountingDate())
      .map(date -> PARAM_FROM_ACCOUNTING_DATE.concat(date.toString()))
      .ifPresent(mainUriParams::add);
    Optional.ofNullable(transactionDTO.getToAccountingDate())
      .map(date -> PARAM_TO_ACCOUNTING_DATE.concat(date.toString()))
      .ifPresent(mainUriParams::add);
    return mainUriParams;
  }

  private void concatExtractParameter(TransactionDTO transactionDTO, int pageLimit, Integer currentDbResponseSize, List<String> mainUriParams) {
    Optional.of(transactionDTO)
      .filter(dto -> (getIntValue(currentDbResponseSize) > 0 || calculatePreviousBcOffset(dto, pageLimit) > 0)
        && getIntValue(dto.getOffset()) == 0)
      .map(TransactionDTO::getExtractId)
      .filter(extract -> extract > 0L)
      .map(String::valueOf)
      .map(PARAM_EXTRACT::concat)
      .ifPresent(mainUriParams::add);
  }

  private String getIntegerParam(Integer evaluated, Predicate<Integer> evaluatedFilter, String parameter) {
    return Optional.ofNullable(evaluated)
      .filter(evaluatedFilter)
      .map(offset -> parameter)
      .filter(not(String::isEmpty))
      .orElse(null);
  }

  private int calculatePreviousBcOffset(TransactionDTO transactionDTO, int pageLimit) {
    return getIntValue(transactionDTO.getBcOffset()) - pageLimit;
  }

  private String buildPreviousBcOffset(TransactionDTO transactionDTO, int size) {
    return getIntegerBcOffsetParamPart(calculatePreviousBcOffset(transactionDTO, size));
  }

  private String buildNextBcOffsetParameter(Integer offsetFromApi, Integer size) {
    String offset = String.valueOf(getIntValue(offsetFromApi) + getIntValue(size));
    return getIntegerBcOffsetParamPart(offset);
  }

  private String getIntegerBcOffsetParamPart(String value) {
    return Optional.ofNullable(value)
      .filter(NumberUtils::isDigits)
      .map(PARAM_BC_OFFSET::concat)
      .orElse(Optional.ofNullable(value)
        .map(PARAM_BC_OFFSET::concat)
        .orElse(StringUtils.EMPTY));
  }

  private String getIntegerBcOffsetParamPart(Integer value) {
    return Optional.ofNullable(value)
      .filter(given -> given >= 0)
      .map(Object::toString)
      .map(PARAM_BC_OFFSET::concat)
      .orElse(StringUtils.EMPTY);
  }

  private int getIntValue(Integer value) {
    return Optional.ofNullable(value)
      .orElse(0);
  }

  private int getIntValue(String value) {
    return Optional.ofNullable(value)
      .map(Integer::valueOf)
      .orElse(0);
  }
}
