package com.santander.scib.gtb.ic.gcm.service.impl;

import com.santander.scib.gtb.ic.gcm.model.ApiBicConfiguration;
import com.santander.scib.gtb.ic.gcm.repository.ApiBicConfigurationRepository;
import com.santander.scib.gtb.ic.gcm.service.ApiBicConfigurationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ApiBicConfigurationServiceImpl implements ApiBicConfigurationService {
  @Autowired private ApiBicConfigurationRepository repository;


  @Override
  public Optional<ApiBicConfiguration> loadConfigurationByBic(String bic) {
    return repository.findById(bic);
  }
}
