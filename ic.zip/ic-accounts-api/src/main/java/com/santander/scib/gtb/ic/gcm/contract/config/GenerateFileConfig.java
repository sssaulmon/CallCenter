package com.santander.scib.gtb.ic.gcm.contract.config;

import com.santander.scib.gtb.ic.gcm.contract.binding.GenerateFileInputBinding;
import org.springframework.cloud.stream.annotation.EnableBinding;

@EnableBinding(GenerateFileInputBinding.class)
public class GenerateFileConfig {
}
