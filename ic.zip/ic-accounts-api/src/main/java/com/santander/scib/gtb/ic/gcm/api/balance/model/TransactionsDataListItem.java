package com.santander.scib.gtb.ic.gcm.api.balance.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

public class TransactionsDataListItem {
  @ApiModelProperty(value = "Link to transaction details.")
  @JsonProperty("transactionDetailsLink")
  private String transactionDetailsLink;

  public String getTransactionDetailsLink() {
    return transactionDetailsLink;
  }

  public void setTransactionDetailsLink(String transactionDetailsLink) {
    this.transactionDetailsLink = transactionDetailsLink;
  }
}
