package com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;

import java.util.List;

public class ProcessedAccount {

  private List<AccountDTO> validAccounts;

  private List<AccountBalanceDTO> invalidAccounts;

  public List<AccountDTO> getValidAccounts() {
    return validAccounts;
  }

  public ProcessedAccount validAccounts(List<AccountDTO> validAccounts) {
    this.validAccounts = validAccounts;
    return this;
  }

  public List<AccountBalanceDTO> getInvalidAccounts() {
    return invalidAccounts;
  }

  public ProcessedAccount invalidAccounts(List<AccountBalanceDTO> invalidAccounts) {
    this.invalidAccounts = invalidAccounts;
    return this;
  }
}
