package com.santander.scib.gtb.ic.gcm.model;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(
  name = "api_bic_configuration"
)
public class ApiBicConfiguration {

  @Id
  @Column(name = "bic")
  private String bic;

  @Column(name = "date_sort")
  private boolean dateSort;

  @Column(name = "convert_amount")
  private boolean convertAmount;

  @Column(name = "iban_account")
  private boolean ibanAccount;

  @Column(name = "from_date")
  private String fromDate;

  public String getBic() {
    return bic;
  }

  public void setBic(String bic) {
    this.bic = bic;
  }

  public boolean isDateSort() {
    return dateSort;
  }

  public void setDateSort(boolean dateSort) {
    this.dateSort = dateSort;
  }

  public boolean isConvertAmount() {
    return convertAmount;
  }

  public void setConvertAmount(boolean convertAmount) {
    this.convertAmount = convertAmount;
  }

  public boolean isIbanAccount() {
    return ibanAccount;
  }

  public void setIbanAccount(boolean ibanAccount) {
    this.ibanAccount = ibanAccount;
  }

  public String getFromDate() {
    return fromDate;
  }

  public void setFromDate(String fromDate) {
    this.fromDate = fromDate;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;

    if (o == null || getClass() != o.getClass()) return false;

    ApiBicConfiguration that = (ApiBicConfiguration) o;

    return new EqualsBuilder()
      .append(getBic(), that.getBic())
      .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(getBic())
      .toHashCode();
  }
}
