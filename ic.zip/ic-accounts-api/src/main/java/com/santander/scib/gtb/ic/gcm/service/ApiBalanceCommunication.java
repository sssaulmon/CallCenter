package com.santander.scib.gtb.ic.gcm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.santander.scib.gtb.ic.gcm.model.AccountBalance;
import com.santander.scib.gtb.ic.gcm.model.JWTResponse;
import com.santander.scib.gtb.ic.gcm.model.Transaction;
import com.santander.scib.gtb.ic.gcm.model.app.entity.AppEntity;
import com.santander.scib.gtb.ic.gcm.model.app.entity.JWTDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

/**
 * The interface Api balance communication.
 */
public interface ApiBalanceCommunication {

  /**
   * Gets assertion.
   *
   * @param jwtDetail app jwt token configuration
   * @param proxy     the proxy
   * @return the assertion
   */
  Mono<JWTResponse> getAssertion(JWTDetail jwtDetail, boolean proxy, MultiValueMap<String, String> body);

  /**
   * Gets jwt token.
   *
   * @param appEntity the app entity
   * @param body      the body
   * @return the jwt token
   */
  Mono<JsonNode> getJWTToken(AppEntity appEntity, MultiValueMap<String, String> body);

  /**
   * Gets account.
   *
   * @param <T>              the type parameter
   * @param uri              the uri
   * @param accessTokenValue the access token value
   * @param headers          the headers
   * @param clazz            the clazz
   * @param proxy            the proxy
   * @return the account
   */
  <T extends AccountBalance> Mono<T> getAccount(
    String uri, String accessTokenValue, Map<String, String> headers, Class<T> clazz, boolean proxy);

  /**
   * Gets transactions.
   *
   * @param <T>              the type parameter
   * @param uri              the uri
   * @param accessTokenValue the access token value
   * @param uriParams        the uri params
   * @param headers          the headers
   * @param clazz            the clazz
   * @param proxy            the proxy
   * @return the transactions
   */
  <T extends Transaction> Mono<T> getTransactions(
    String uri, String accessTokenValue, Map<String, String> uriParams, Map<String, String> headers, Class<T> clazz,
    boolean proxy);

  /**
   * Gets transactions list.
   *
   * @param <T>              the type parameter
   * @param uri              the uri
   * @param accessTokenValue the access token value
   * @param uriParams        the uri params
   * @param headers          the headers
   * @param clazz            the clazz
   * @param proxy            the proxy
   * @return the transactions list
   */
  <T extends Transaction> Mono<ResponseEntity<List<T>>> getTransactionsList(
    String uri, String accessTokenValue, Map<String, String> uriParams, Map<String, String> headers, Class<T> clazz,
    boolean proxy);

}
