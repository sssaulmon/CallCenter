package com.santander.scib.gtb.ic.gcm.service.strategy.impl;

import com.santander.scib.gtb.ic.gcm.model.CustomizationDTO;
import com.santander.scib.gtb.ic.gcm.model.DecimalFormatterType;
import com.santander.scib.gtb.ic.gcm.model.GenerateFileRequestDTO;
import com.santander.scib.gtb.ic.gcm.model.WorkBookContainer;
import com.santander.scib.gtb.ic.gcm.service.ExcelReportLanguageService;
import com.santander.scib.gtb.ic.gcm.service.strategy.GenerateResourceStrategy;
import com.santander.scib.gtb.ic.gcm.util.ReportGeneratorUtil;
import com.santander.scib.gtb.ic.gcm.web.exception.InputValidationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import static com.isban.gcb.ic.commons.util.function.FunctionalUtils.not;
import static com.isban.gcb.ic.commons.util.function.FunctionalUtils.peek;

@Slf4j
public abstract class AbstractResourceStrategy implements GenerateResourceStrategy {

  private static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";

  @Autowired private ExcelReportLanguageService excelReportLanguageService;

  protected WorkBookContainer buildWorkBook(GenerateFileRequestDTO generateFileRequest) {
    CustomizationDTO customization = generateFileRequest.getCustomization();

    Workbook workbook = new SXSSFWorkbook();
    Sheet sheet = workbook.createSheet(generateFileRequest.getType());
    List<String> headers = excelReportLanguageService.listHeadersByLanguageOrDefault(Optional.ofNullable(customization)
      .map(CustomizationDTO::getLanguage)
      .orElse(null), generateFileRequest.getType());
    ReportGeneratorUtil.generateHeader(sheet.createRow(0), headers);

    DecimalFormatterType type = Optional.ofNullable(customization)
      .map(CustomizationDTO::getNumberFormat)
      .filter(not(String::isEmpty))
      .map(DecimalFormatterType::getInstance)
      .orElse(DecimalFormatterType.DEFAULT);

    return new WorkBookContainer()
      .workbook(workbook)
      .sheet(sheet)
      .numericStyle(createStyle(sheet, type.getExcelFormat()))
      .dateStyle(createStyle(sheet, Optional.ofNullable(customization)
        .map(CustomizationDTO::getDateFormat)
        .orElse(DEFAULT_DATE_FORMAT)))
      .decimalFormatterType(type);
  }

  private CellStyle createStyle(Sheet sheet, String format) {
    CreationHelper createHelper = sheet.getWorkbook().getCreationHelper();
    DataFormat dataFormat = createHelper.createDataFormat();

    return Optional.of(sheet)
      .map(Sheet::getWorkbook)
      .map(Workbook::createCellStyle)
      .map(peek(style -> style.setDataFormat(dataFormat.getFormat(format))))
      .orElse(null);
  }

  @Override
  public GenerateResourceStrategy validateInputData(GenerateFileRequestDTO request) {
    Optional.ofNullable(request)
      .map(req -> validNotNull(req, GenerateFileRequestDTO::getUuid, "Failed Input Validation: uuid is Required"))
      .map(req -> validNotNull(req, GenerateFileRequestDTO::getUserDate, "Failed Input Validation: userDate is Required"))
      .map(req -> validNotNull(req, GenerateFileRequestDTO::getAccounts, "Failed Input Validation: accounts is Required"))
      .map(GenerateFileRequestDTO::getCustomization)
      .map(peek(customization -> {
        validateDatePattern(customization, CustomizationDTO::getDateFormat, DateTimeFormatter::ofPattern);
        validateNumberPattern(customization);
      }))
      .ifPresent(customization -> log.info("Is Valid Request ".concat(request.getUuid())));

    return this;
  }

  public <T> GenerateFileRequestDTO validNotNull(GenerateFileRequestDTO generateFileRequest,
                                                 Function<GenerateFileRequestDTO, T> mapper,
                                                 String errorMessage) {
    return Optional.ofNullable(generateFileRequest)
      .map(mapper)
      .map(ignored -> generateFileRequest)
      .orElseThrow(() -> new InputValidationException(errorMessage));
  }

  public <T, W extends String> void validateDatePattern(CustomizationDTO customization,
                                                        Function<CustomizationDTO, W> pattern,
                                                        Function<W, T> validatePattern) {
    try {
      Optional.ofNullable(customization)
        .map(pattern)
        .map(validatePattern);
    } catch (IllegalArgumentException ignored) {
      throw new InputValidationException("Failed Input Validation: invalid pattern");
    }
  }

  public void validateNumberPattern(CustomizationDTO customization) {
    Optional.ofNullable(customization)
      .map(CustomizationDTO::getNumberFormat)
      .filter(not(String::isEmpty))
      .map(DecimalFormatterType::getInstance);
  }
}
