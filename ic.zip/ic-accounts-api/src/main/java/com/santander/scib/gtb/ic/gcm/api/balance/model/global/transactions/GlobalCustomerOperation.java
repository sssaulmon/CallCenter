package com.santander.scib.gtb.ic.gcm.api.balance.model.global.transactions;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

public class GlobalCustomerOperation {

  @ApiModelProperty(example = "A30", value = "Customized Transaction Code (local transaction codes in order to facilitate multi local reconciliation without using SWIFT transaction codes) are the codes that define the type of transaction in the Local Entity.")
  @JsonProperty("customerTCode")
  private String customerTCode;

  @ApiModelProperty(example = "\"Abono SBF\"", value = "Customized Transaction Code (local transaction codes in order to facilitate multi local reconciliation without using SWIFT transaction codes) are the codes that define the type of transaction in the Local Entity.")
  @JsonProperty("customerTDescription")
  private String customerTDescription;

  @ApiModelProperty(example = "\"Abono cheque // Transmediterranea 234/11\"", value = "Customized Aditional information related to the transaction such as beneficiary, sender, concept, among others.")
  @JsonProperty("customerAdditionalInformation")
  private String customerAdditionalInformation;

  public void setCustomerTCode(String customerTCode) {
    this.customerTCode = customerTCode;
  }

  public void setCustomerTDescription(String customerTDescription) {
    this.customerTDescription = customerTDescription;
  }

  public void setCustomerAdditionalInformation(String customerAdditionalInformation) {
    this.customerAdditionalInformation = customerAdditionalInformation;
  }
}

