package com.santander.scib.gtb.ic.gcm.util;

import java.util.Optional;

public class LinkReaderUtil {

  private static final String OFFSET_REGEX = ".*offset=([\\d\\w\\D][^&]*).*";

  private LinkReaderUtil() {
  }

  public static String getOffset(String link) {
    return Optional.ofNullable(link)
      .filter(l -> l.matches(OFFSET_REGEX))
      .map(l -> l.replaceAll(OFFSET_REGEX, "$1"))
      .orElse(null);
  }
}
