package com.santander.scib.gtb.ic.gcm.service;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;

import java.time.ZonedDateTime;

public interface AccountingDateService {

  ZonedDateTime getFromAccountingDate(TransactionDTO transactionDTO);
}
