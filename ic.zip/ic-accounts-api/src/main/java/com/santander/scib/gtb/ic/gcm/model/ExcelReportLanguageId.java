package com.santander.scib.gtb.ic.gcm.model;

import com.google.common.base.Objects;

import java.io.Serializable;

/**
 * The type Excel report language id.
 */
public class ExcelReportLanguageId implements Serializable {

  private String language;
  private String type;
  private int order;

  /**
   * Gets language.
   *
   * @return the language
   */
  public String getLanguage() {
    return language;
  }

  /**
   * Sets language.
   *
   * @param language the language
   */
  public void setLanguage(String language) {
    this.language = language;
  }

  /**
   * Gets type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets type.
   *
   * @param type the type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets order.
   *
   * @return the order
   */
  public int getOrder() {
    return order;
  }

  /**
   * Sets order.
   *
   * @param order the order
   */
  public void setOrder(int order) {
    this.order = order;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    ExcelReportLanguageId that = (ExcelReportLanguageId) o;
    return order == that.order &&
      Objects.equal(language, that.language) &&
      Objects.equal(type, that.type);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(language, type, order);
  }
}
