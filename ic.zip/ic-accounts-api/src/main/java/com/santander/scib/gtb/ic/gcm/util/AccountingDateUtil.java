package com.santander.scib.gtb.ic.gcm.util;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import static java.time.LocalTime.MAX;

public class AccountingDateUtil {

  private AccountingDateUtil() {
  }

  public static LocalDateTime atEndOfDay(LocalDate localDate) {
    return Optional.ofNullable(localDate)
      .map(given -> given.atTime(MAX))
      .orElse(LocalDate.now().atTime(MAX));
  }

  public static LocalDateTime atStartOfDay(LocalDate localDate) {
    return Optional.ofNullable(localDate)
      .map(LocalDate::atStartOfDay)
      .orElse(LocalDate.now().atStartOfDay());
  }

  public static LocalDateTime atStartOfDayRange(LocalDate localDate, int daysLimit) {
    return Optional.of(localDate)
      .map(LocalDate::atStartOfDay)
      .map(given -> given.minusDays(daysLimit))
      .orElseThrow(RuntimeException::new);
  }

  public static LocalDateTime getFromAccountingDate(
    TransactionDTO transactionDTO, LocalDateTime toDate, int daysLimit) {
    return Optional.ofNullable(transactionDTO.getFromAccountingDate())
      .map(AccountingDateUtil::atStartOfDay)
      .orElse(Optional.ofNullable(transactionDTO.getAccountingDate())
        .map(AccountingDateUtil::atStartOfDay)
        .orElse(AccountingDateUtil.atStartOfDayRange(toDate.toLocalDate(), daysLimit)));
  }

  public static LocalDateTime getToAccountingDate(TransactionDTO transactionDTO) {
    return Optional.ofNullable(transactionDTO.getToAccountingDate())
      .map(AccountingDateUtil::atEndOfDay)
      .orElse(AccountingDateUtil.atEndOfDay(transactionDTO.getAccountingDate()));
  }
}
