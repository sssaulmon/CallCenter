package com.santander.scib.gtb.ic.gcm.service.strategy;

public interface ResourceTypeContext {

  GenerateResourceStrategy resolve(String type);
}
