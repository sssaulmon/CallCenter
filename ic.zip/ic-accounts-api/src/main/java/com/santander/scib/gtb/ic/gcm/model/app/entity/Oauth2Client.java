package com.santander.scib.gtb.ic.gcm.model.app.entity;

import com.santander.scib.gtb.ic.gcm.util.SecurityUtil;

import java.util.List;

public class Oauth2Client {
  private String grantType;
  private String clientId;
  private String clientSecret;
  private String accessTokenUri;
  private List<String> scopes;
  private boolean proxy;

  public String getGrantType() {
    return grantType;
  }

  public void setGrantType(String grantType) {
    this.grantType = grantType;
  }

  public String getClientId() {
    return clientId;
  }

  public void setClientId(String clientId) {
    this.clientId = clientId;
  }

  public String getClientSecret() {
    return clientSecret;
  }

  public void setClientSecret(String clientSecret) {
    this.clientSecret = clientSecret;
  }

  public String getAccessTokenUri() {
    return accessTokenUri;
  }

  public void setAccessTokenUri(String accessTokenUri) {
    this.accessTokenUri = accessTokenUri;
  }

  public List<String> getScopes() {
    return SecurityUtil.unmodify(scopes);
  }

  public void setScopes(List<String> scopes) {
    this.scopes = SecurityUtil.unmodify(scopes);
  }

  public boolean isProxy() {
    return proxy;
  }

  public void setProxy(boolean proxy) {
    this.proxy = proxy;
  }
}
