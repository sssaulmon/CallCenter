package com.santander.scib.gtb.ic.gcm.api.balance.model.account;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.ToString;

import javax.validation.constraints.NotNull;

@ToString
public class ErrorItem {

  @ApiModelProperty(example = "404", required = true,
    value = "HTTP error code only provided when an error occurred during the request")
  @NotNull
  @JsonProperty("code")
  private Integer code;

  @ApiModelProperty(example = "\"NOT_FOUND\"", required = true,
    value = "HTTP message only provided when an error occurred during the request.")
  @NotNull
  @JsonProperty("message")
  private String message;

  @ApiModelProperty(example = "\"ERROR\"", required = true,
    value = "Error level. Could be INFO, WARNING, ERROR or FATAL")
  @NotNull
  @JsonProperty("level")
  private String level;

  @ApiModelProperty(example = "\"The account id does not exist\"", required = true,
    value = "Additional information about the error")
  @NotNull
  @JsonProperty("description")
  private String description;

  public Integer getCode() {
    return code;
  }

  public void setCode(Integer code) {
    this.code = code;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public String getLevel() {
    return level;
  }

  public void setLevel(String level) {
    this.level = level;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }
}

