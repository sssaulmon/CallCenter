package com.santander.scib.gtb.ic.gcm.config;

import com.santander.scib.gtb.ic.gcm.model.app.entity.AppEntity;
import com.santander.scib.gtb.ic.gcm.model.app.entity.EntityModel;
import com.santander.scib.gtb.ic.gcm.model.app.entity.JWTDetail;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.function.Function;

@Configuration
@RefreshScope
@Slf4j
public class ApplicationConfiguration {

  @Autowired private EntitiesConfiguration entitiesConfiguration;

  private static final ConcurrentMap<String, AppEntity> appEntityCache = new ConcurrentHashMap<>();

  @Bean
  public Function<String, AppEntity> appEntityFactory() {
    return entity -> appEntityCache.computeIfAbsent(entity, k -> createAppEntityCache(entity));
  }

  @EventListener
  public void onRefreshScopeRefreshed(final RefreshScopeRefreshedEvent event) {
    appEntityCache.clear();
    log.info("Scope Refreshed. Clear connections AppEntityCache.");
  }

  private AppEntity createAppEntityCache(String entity) {
    return getEntityByBic(entity)
      .map(entityModel -> this.buildAppEntity(entityModel, entity))
      .orElse(null);
  }

  private Optional<EntityModel> getEntityByBic(String bic) {
    return entitiesConfiguration.getEntitiesList().stream()
      .filter(entity -> entity.getBics().contains(bic))
      .map(Optional::of)
      .findFirst()
      .orElse(Optional.empty());
  }

  private AppEntity buildAppEntity(EntityModel entityModel, String entity) {
    String serviceUrl = entityModel.getServiceUrl();
    String origin = entityModel.getOrigin();
    String clientId = entityModel.getOauth2Client().getClientId();

    String country = Optional.ofNullable(entityModel.getCountries())
      .map(countries -> countries.get(entityModel.getBics().indexOf(entity)))
      .orElse(null);

    return AppEntity.builder()
      .clientId(clientId)
      .serviceUrl(serviceUrl)
      .origin(origin)
      .country(country)
      .jwtDetail(getJWTDetailByCountry(country))
      .oauth2Client(entityModel.getOauth2Client())
      .enabled(entityModel.isEnabled())
      .build();
  }

  private JWTDetail getJWTDetailByCountry(String country) {
    return Optional.ofNullable(country)
      .map(entitiesConfiguration.getJwtDetails()::get)
      .orElse(null);
  }
}