package com.santander.scib.gtb.ic.gcm.model;

import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.api.MappedTransaction;

public interface Transaction {

  MappedTransaction mapToAccountTransactionListDTO();
}
