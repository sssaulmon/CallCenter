package com.santander.scib.gtb.ic.gcm.service.balance;

import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.model.NotificationError;

/**
 * The interface Messaging service.
 */
public interface MessagingService {

  /**
   * Send extract dto account balance dto.
   *
   * @param response the response
   * @return the account balance dto
   */
  AccountBalanceDTO sendExtractDto(AccountBalanceDTO response);

  /**
   * Send error.
   *
   * @param accountId the account id
   * @param errorMsg  the error msg
   */
  void sendError(String accountId, String errorMsg);

  /**
   * Send generate file error.
   *
   * @param uuid     the uuid
   * @param errorMsg the error msg
   */
  void sendGenerateFileError(String uuid, String errorMsg);

  void sendError(NotificationError error);
}
