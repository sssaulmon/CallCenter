package com.santander.scib.gtb.ic.gcm.util;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class TransactionPaginationUtil {

  private int defaultLimit;
  private int maxLimit;
  private int exportLimit;
  private int limitInDays;

  public TransactionPaginationUtil(@Value("${transactions.limit.default}") int defaultLimit,
                                   @Value("${transactions.limit.max}") int maxLimit,
                                   @Value("${apis.onlineReportLimit}") int exportLimit,
                                   @Value("${transactions.limit.days}") int limitInDays) {
    this.defaultLimit = defaultLimit;
    this.maxLimit = maxLimit;
    this.exportLimit = exportLimit;
    this.limitInDays = limitInDays;
  }

  public Pageable buildPageRequest(TransactionDTO transactionDTO) {
    return PageRequest.of(getPageNumber(transactionDTO), getLimit(transactionDTO));
  }

  public int getLimit(TransactionDTO transactionDTO) {
    return Optional.of(transactionDTO)
      .filter(TransactionDTO::isForReport)
      .map(given -> exportLimit)
      .orElse(getLimitForPageable(transactionDTO));
  }

  public int getLimitInDays() {
    return limitInDays;
  }

  private int getLimitForPageable(TransactionDTO transactionDTO) {
    return Optional.of(transactionDTO)
      .map(TransactionDTO::getLimit)
      .filter(limit -> limit > 0 && limit <= maxLimit)
      .orElse(defaultLimit);
  }

  private int getPageNumber(TransactionDTO transactionDTO) {
    return Optional.ofNullable(transactionDTO.getBcOffset())
      .map(given -> given / getLimit(transactionDTO))
      .orElse(0);
  }
}
