package com.santander.scib.gtb.ic.gcm.web.exception;

public class InputValidationException extends RuntimeException {
  private String message;

  public InputValidationException(String message) {
    this.message = message;
  }

  @Override
  public String getMessage() {
    return this.message;
  }
}
