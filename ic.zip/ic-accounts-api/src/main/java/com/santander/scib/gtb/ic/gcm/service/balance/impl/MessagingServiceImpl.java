package com.santander.scib.gtb.ic.gcm.service.balance.impl;

import com.isban.gcb.ic.commons.model.AccountsError;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.communication.binding.ApiOutputBinding;
import com.santander.scib.gtb.ic.gcm.mapper.AccountBalanceMapper;
import com.santander.scib.gtb.ic.gcm.model.NotificationError;
import com.santander.scib.gtb.ic.gcm.service.balance.AccountUuidHelper;
import com.santander.scib.gtb.ic.gcm.service.balance.MessagingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static com.isban.gcb.ic.commons.util.function.FunctionalUtils.peek;

@Slf4j
@Service
public class MessagingServiceImpl implements MessagingService {

  @Autowired private AccountUuidHelper accountUuidHelper;
  @Autowired private AccountBalanceMapper accountBalanceMapper;
  @Autowired private ApiOutputBinding binding;

  public AccountBalanceDTO sendExtractDto(AccountBalanceDTO response) {
    Optional.ofNullable(response)
      .map(peek(result -> log.info("Sending to DB: {}", response)))
      .map(accountUuidHelper::transform)
      .map(MessageBuilder::withPayload)
      .map(MessageBuilder::build)
      .ifPresent(binding.apiRequestCompleted()::send);

    return response;
  }

  public void sendError(String accountId, String errorMsg) {
    sendMessage("Error performing in transactions with account id: " + accountId + ". " + errorMsg);
  }

  public void sendGenerateFileError(String uuid, String errorMsg) {
    sendMessage("Error in generate file with uuid id: " + uuid + ". " + errorMsg);
  }

  private void sendMessage(String message) {
    log.error(message);

    AccountsError error = new AccountsError()
      .message(message)
      .source("Accounts");

    Optional.of(error)
      .map(MessageBuilder::withPayload)
      .map(MessageBuilder::build)
      .ifPresent(binding.apiRequestFailed()::send);
  }

  @Override
  public void sendError(NotificationError error) {
    Optional.of(error)
      .map(MessageBuilder::withPayload)
      .map(MessageBuilder::build)
      .ifPresent(binding.apiRequestFailed()::send);
  }
}
