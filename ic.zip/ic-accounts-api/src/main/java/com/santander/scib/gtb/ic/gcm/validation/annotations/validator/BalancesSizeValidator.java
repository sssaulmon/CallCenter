package com.santander.scib.gtb.ic.gcm.validation.annotations.validator;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.BalanceRequest;
import com.santander.scib.gtb.ic.gcm.validation.annotations.BalancesSize;
import org.springframework.beans.factory.annotation.Value;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.List;
import java.util.Optional;

public class BalancesSizeValidator implements ConstraintValidator<BalancesSize, BalanceRequest> {

  @Value("${apis.balances.size}")
  private int allowedSize;

  @Override
  public boolean isValid(BalanceRequest balanceRequest, ConstraintValidatorContext constraintValidatorContext) {
    return Optional.ofNullable(balanceRequest.getAccounts())
      .map(List::size)
      .filter(size -> size > allowedSize)
      .isEmpty();
  }
}
