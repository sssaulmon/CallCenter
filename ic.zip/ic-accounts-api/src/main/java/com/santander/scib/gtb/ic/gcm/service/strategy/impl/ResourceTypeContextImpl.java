package com.santander.scib.gtb.ic.gcm.service.strategy.impl;

import com.santander.scib.gtb.ic.gcm.web.exception.InvalidResourceTypeException;
import com.santander.scib.gtb.ic.gcm.service.strategy.GenerateResourceStrategy;
import com.santander.scib.gtb.ic.gcm.service.strategy.ResourceType;
import com.santander.scib.gtb.ic.gcm.service.strategy.ResourceTypeContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ResourceTypeContextImpl implements ResourceTypeContext {

  @Autowired private List<GenerateResourceStrategy> strategies;

  public GenerateResourceStrategy resolve(String type) {
    return strategies.stream()
      .filter(strategy -> strategy.getClass().getAnnotation(ResourceType.class).type().equals(type))
      .findFirst()
      .orElseThrow(() -> new InvalidResourceTypeException("Invalid Resource Type"));
  }
}
