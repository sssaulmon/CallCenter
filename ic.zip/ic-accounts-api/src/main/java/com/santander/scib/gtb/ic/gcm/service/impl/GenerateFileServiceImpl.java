package com.santander.scib.gtb.ic.gcm.service.impl;

import com.santander.scib.gtb.ic.gcm.communication.model.SaveFile;
import com.santander.scib.gtb.ic.gcm.communication.service.GenerateFileNotificationService;
import com.santander.scib.gtb.ic.gcm.mapper.GlobalReportMapper;
import com.santander.scib.gtb.ic.gcm.model.GenerateFileRequestDTO;
import com.santander.scib.gtb.ic.gcm.repository.GlobalReportRepository;
import com.santander.scib.gtb.ic.gcm.service.GenerateFileService;
import com.santander.scib.gtb.ic.gcm.service.strategy.ResourceTypeContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Optional;

/**
 * The type Generate file service.
 */
@Slf4j
@Service
public class GenerateFileServiceImpl implements GenerateFileService {

  private static final String XLSX_EXTENSION = ".XLSX";
  private String fileDirectory;
  private ResourceTypeContext resourceTypeContext;
  private GenerateFileNotificationService communication;
  private GlobalReportMapper globalReportMapper;
  private GlobalReportRepository globalReportRepository;

  /**
   * Instantiates a new Generate file service.
   *
   * @param fileDirectory          the file directory
   * @param resourceTypeContext    the resource type context
   * @param communication          the communication
   * @param globalReportMapper     the global report mapper
   * @param globalReportRepository the global report repository
   */
  public GenerateFileServiceImpl(@Value("${apis.fileDirectory}") String fileDirectory,
                                 ResourceTypeContext resourceTypeContext,
                                 GenerateFileNotificationService communication,
                                 GlobalReportMapper globalReportMapper,
                                 GlobalReportRepository globalReportRepository) {
    this.fileDirectory = fileDirectory;
    this.resourceTypeContext = resourceTypeContext;
    this.communication = communication;
    this.globalReportMapper = globalReportMapper;
    this.globalReportRepository = globalReportRepository;
  }

  @Override
  public GenerateFileRequestDTO generateFile(GenerateFileRequestDTO generateFileRequest) {
    LocalDateTime initialTime = LocalDateTime.now();
    log.info("Init File Generation, date {}", initialTime.toString());
    Optional.ofNullable(generateFileRequest)
      .map(GenerateFileRequestDTO::getType)
      .map(resourceTypeContext::resolve)
      .map(strategy -> strategy.validateInputData(generateFileRequest))
      .map(strategy -> strategy.generateResource(generateFileRequest))
      .map(this::sendToS3)
      .map(this::sendToDB)
      .orElseThrow(RuntimeException::new);

    LocalDateTime finalTime = LocalDateTime.now();
    log.info("Finish File Generation, date {}", finalTime.toString());
    log.info("Time execution {} seconds", ChronoUnit.SECONDS.between(initialTime, finalTime));

    return generateFileRequest.status("Generate Success");
  }

  private GenerateFileRequestDTO sendToS3(GenerateFileRequestDTO generate) {
    Optional.of(new SaveFile())
      .map(given -> given.key(generateMetakey(generate)))
      .map(given -> given.data(generate.getData()))
      .ifPresent(generateFileRequestDTO -> communication.saveGenerateFile(generateFileRequestDTO));
    return generate;
  }

  private GenerateFileRequestDTO sendToDB(GenerateFileRequestDTO generateFileRequestDTO) {
    Optional.of(generateFileRequestDTO)
      .map(globalReportMapper::requestToGlobalReport)
      .map(globalReport -> globalReport.setFileName(getFileName(generateFileRequestDTO)))
      .map(globalReport -> globalReport.setS3Path(generateMetakey(generateFileRequestDTO)))
      .map(globalReportRepository::save);
    return generateFileRequestDTO;
  }

  private String generateMetakey(GenerateFileRequestDTO generateFileRequest) {
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
    return String.join("/",
      fileDirectory,
      generateFileRequest.getUuid(),
      generateFileRequest.getUserDate().format(dateTimeFormatter),
      generateFileRequest.getType().toUpperCase(),
      getFileName(generateFileRequest));
  }

  private String getFileName(GenerateFileRequestDTO generateFileRequest) {
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HHmmss");
    return Optional.of(generateFileRequest)
      .map(GenerateFileRequestDTO::getFileName)
      .map(fileName -> fileName.concat(XLSX_EXTENSION))
      .orElse(generateFileRequest.getUuid()
        .concat(generateFileRequest.getUserDate().format(dateTimeFormatter))
        .concat(XLSX_EXTENSION));
  }
}
