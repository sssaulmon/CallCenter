package com.santander.scib.gtb.ic.gcm.communication.model;

public class SaveFile {

  private String key;
  private byte[] data;

  public SaveFile() {
  }

  public SaveFile key(String key) {
    this.key = key;
    return this;
  }

  public SaveFile data(byte[] data) {
    this.data = data;
    return this;
  }

  public String getKey() {
    return key;
  }

  public byte[] getData() {
    return data;
  }
}
