package com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class LinkDTO {

  @JsonProperty("_first")
  private String first;

  @JsonProperty("_next")
  private String next;

  @JsonProperty("_prev")
  private String prev;

  @Override
  public String toString() {
    return "LinkDTO{" +
      "first='" + first + '\'' +
      ", next='" + next + '\'' +
      ", prev='" + prev + '\'' +
      '}';
  }
}
