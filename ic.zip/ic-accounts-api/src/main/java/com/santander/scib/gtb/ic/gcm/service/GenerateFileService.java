package com.santander.scib.gtb.ic.gcm.service;

import com.santander.scib.gtb.ic.gcm.model.GenerateFileRequestDTO;

/**
 * The interface Generate file service.
 */
public interface GenerateFileService {

  /**
   * Generate file generate file request dto.
   *
   * @param generateFileRequest the generate file request
   * @return the generate file request dto
   */
  GenerateFileRequestDTO generateFile(GenerateFileRequestDTO generateFileRequest);
}
