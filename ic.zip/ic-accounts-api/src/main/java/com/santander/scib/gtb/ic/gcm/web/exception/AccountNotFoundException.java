package com.santander.scib.gtb.ic.gcm.web.exception;

public class AccountNotFoundException extends RuntimeException {

  public AccountNotFoundException() {
    super("Account Not Found");
  }
}
