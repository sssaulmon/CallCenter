package com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance;

import com.santander.scib.gtb.ic.gcm.util.SecurityUtil;
import com.santander.scib.gtb.ic.gcm.validation.annotations.BalancesSize;
import lombok.ToString;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.List;

@BalancesSize
@ToString
public class BalanceRequest {

  private @NotNull(message = "An account must be entered") List<@Valid AccountDTO> accounts;
  private LocalDate accountingDate;

  public BalanceRequest() {
    super();
  }

  public List<AccountDTO> getAccounts() {
    return SecurityUtil.unmodify(accounts);
  }

  public BalanceRequest accounts(List<AccountDTO> accounts) {
    this.accounts = SecurityUtil.unmodify(accounts);
    return this;
  }

  public LocalDate getAccountingDate() {
    return accountingDate;
  }

  public void setAccountingDate(LocalDate accountingDate) {
    this.accountingDate = accountingDate;
  }
}
