package com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.serde.BigDecimalSerializer;
import com.santander.scib.gtb.ic.gcm.util.SecurityUtil;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountBalanceDTO extends AccountDTO {

  @ApiModelProperty(example = "50000", value = "Opening balance")
  @JsonSerialize(using = BigDecimalSerializer.class)
  private BigDecimal openingAmount;

  @ApiModelProperty(example = "50000", required = true, value = "Closing balance")
  @JsonSerialize(using = BigDecimalSerializer.class)
  private BigDecimal closingAmount;

  @ApiModelProperty(example = "1347234.6", required = true,
    value = "Is the amount of money existing in a specific account at a determinate moment.")
  @NotNull
  @JsonSerialize(using = BigDecimalSerializer.class)
  private BigDecimal availableAmount;

  @ApiModelProperty(value = "Forward amounts of the account with their date")
  private List<ForwardAmountDTO> forwardAmounts;

  @ApiModelProperty(example = "INTR", required = true, value = "Balance type")
  @NotNull
  private String balanceType;

  @ApiModelProperty(value = "FIND Time Stamp")
  private LocalTime accountingTime;

  @ApiModelProperty(value = "Accounting date")
  private LocalDate accountingDate;

  @ApiModelProperty(value = "Shows if account has transactions")
  private boolean hasTransactions;

  @ApiModelProperty(value = "Shows if account has best transactions")
  private boolean hasBestTransactions;

  @ApiModelProperty(value = "Shows information by API external response")
  private String information;

  @ApiModelProperty(value = "Shows account's status from the external API response")
  private String status;

  public BigDecimal getOpeningAmount() {
    return openingAmount;
  }

  public AccountBalanceDTO openingAmount(BigDecimal openingAmount) {
    this.openingAmount = openingAmount;
    return this;
  }

  public BigDecimal getClosingAmount() {
    return closingAmount;
  }

  public AccountBalanceDTO closingAmount(BigDecimal closingAmount) {
    this.closingAmount = closingAmount;
    return this;
  }

  public BigDecimal getAvailableAmount() {
    return availableAmount;
  }

  public AccountBalanceDTO availableAmount(BigDecimal availableAmount) {
    this.availableAmount = availableAmount;
    return this;
  }

  public List<ForwardAmountDTO> getForwardAmounts() {
    return SecurityUtil.unmodify(forwardAmounts);
  }

  public AccountBalanceDTO forwardAmounts(List<ForwardAmountDTO> forwardAmounts) {
    this.forwardAmounts = SecurityUtil.unmodify(forwardAmounts);
    return this;
  }

  public String getBalanceType() {
    return balanceType;
  }

  public AccountBalanceDTO balanceType(String balanceType) {
    this.balanceType = balanceType;
    return this;
  }

  public LocalTime getAccountingTime() {
    return accountingTime;
  }

  public AccountBalanceDTO accountingTime(LocalTime accountingTime) {
    this.accountingTime = accountingTime;
    return this;
  }

  public LocalDate getAccountingDate() {
    return accountingDate;
  }

  public AccountBalanceDTO accountingDate(LocalDate accountingDate) {
    this.accountingDate = accountingDate;
    return this;
  }

  @JsonGetter("hasTransactions")
  public boolean hasTransactions() {
    return hasTransactions;
  }

  public AccountBalanceDTO hasTransactions(boolean hasTransactions) {
    this.hasTransactions = hasTransactions;
    return this;
  }

  @JsonGetter("hasBestTransactions")
  public boolean hasBestTransactions() {
    return hasBestTransactions;
  }

  public AccountBalanceDTO hasBestTransactions(boolean hasBestTransacions) {
    this.hasBestTransactions = hasBestTransacions;
    return this;
  }

  public AccountBalanceDTO information(String information) {
    this.information = information;
    return this;
  }

  public String getInformation() {
    return information;
  }

  public String getStatus() {
    return status;
  }

  public AccountBalanceDTO status(String status) {
    this.status = status;
    return this;
  }

  @Override
  public AccountBalanceDTO bic(String bic) {
    this.bic = bic;
    return this;
  }

  @Override
  public AccountBalanceDTO accountId(String accountId) {
    this.accountId = accountId;
    return this;
  }

  @Override
  public AccountBalanceDTO alias(String alias) {
    this.alias = alias;
    return this;
  }

  @Override
  public AccountBalanceDTO currency(String currency) {
    this.currency = currency;
    return this;
  }

  @Override
  public AccountBalanceDTO uuid(String uuid) {
    super.uuid(uuid);
    return this;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    if (!super.equals(o)) return false;

    AccountBalanceDTO that = (AccountBalanceDTO) o;

    if (!Objects.equals(accountingTime, that.accountingTime))
      return false;
    return Objects.equals(accountingDate, that.accountingDate);
  }

  @Override
  public int hashCode() {
    int result = super.hashCode();
    result = 31 * result + (accountingTime != null ? accountingTime.hashCode() : 0);
    result = 31 * result + (accountingDate != null ? accountingDate.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "AccountBalanceDTO{" +
      "openingAmount=" + openingAmount +
      ", closingAmount=" + closingAmount +
      ", availableAmount=" + availableAmount +
      ", forwardAmounts=" + forwardAmounts +
      ", balanceType='" + balanceType + '\'' +
      ", accountingTime=" + accountingTime +
      ", accountingDate=" + accountingDate +
      ", hasTransactions=" + hasTransactions +
      ", hasBestTransactions=" + hasBestTransactions +
      ", bic='" + bic + '\'' +
      ", accountId='" + accountId + '\'' +
      ", alias='" + alias + '\'' +
      ", currency='" + currency + '\'' +
      ", status='" + status + '\'' +
      "} ";
  }

  public AccountBalanceDTO cloneDto() {
    return new AccountBalanceDTO()
      .balanceType(this.balanceType)
      .bic(this.bic)
      .openingAmount(this.openingAmount)
      .availableAmount(this.availableAmount)
      .closingAmount(this.closingAmount)
      .accountingDate(this.accountingDate)
      .accountingTime(this.accountingTime)
      .accountId(this.accountId)
      .alias(this.alias)
      .currency(this.currency)
      .hasBestTransactions(this.hasBestTransactions)
      .hasTransactions(this.hasTransactions)
      .information(this.information)
      .forwardAmounts(this.forwardAmounts)
      .status(this.status)
      .uuid(getUuid());
  }
}
