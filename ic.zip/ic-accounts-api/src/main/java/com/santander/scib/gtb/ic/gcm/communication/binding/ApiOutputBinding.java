package com.santander.scib.gtb.ic.gcm.communication.binding;

import com.santander.scib.gtb.ic.gcm.communication.constants.ApiOutputBindingConstants;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface ApiOutputBinding {

  @Output(ApiOutputBindingConstants.API_REQUEST_COMPLETED)
  MessageChannel apiRequestCompleted();

  @Output(ApiOutputBindingConstants.API_REQUEST_FAILED)
  MessageChannel apiRequestFailed();
}
