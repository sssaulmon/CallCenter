package com.santander.scib.gtb.ic.gcm.api.balance.controller;

import com.santander.scib.gtb.ic.gcm.api.balance.model.account.ErrorItem;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.BalanceRequest;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.download.DownloadApiResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionResponse;
import io.swagger.annotations.*;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CompletionStage;

@Api(tags = {"the Balance API"})
public interface BalanceControllerBase {

  @ApiOperation(value = "Information about multiple accounts", nickname = "getBalances",
    notes = "Retrieve information of multiple account ids.",
    response = AccountBalanceDTO.class, authorizations = {
    @Authorization(value = "JWT")
  })
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "200 OK", response = AccountBalanceDTO.class),
    @ApiResponse(code = 401, message = "Unauthorized", response = ErrorItem.class),
    @ApiResponse(code = 403, message = "Forbidden", response = ErrorItem.class),
    @ApiResponse(code = 404, message = "Not Found", response = ErrorItem.class),
    @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorItem.class)})
  CompletionStage<ResponseEntity<List<AccountBalanceDTO>>> getBalances(
    @ApiParam(value = "Traceability E2E Header", required = true) String xSantanderGlobalId,
    @ApiParam(value = "") BalanceRequest balanceRequest);

  @ApiOperation(value = "Information about the list of an account transactions", nickname = "getAccountTransactions",
    notes = "Information about account transactions. " +
      "Transactions will be provided in groups of 50, but you can specify a lower limit if needed.",
    response = AccountTransactionResponse.class, authorizations = {
    @Authorization(value = "JWT")
  })
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "200 OK", response = AccountTransactionResponse.class),
    @ApiResponse(code = 400, message = "Bad Request", response = ErrorItem.class),
    @ApiResponse(code = 401, message = "Unauthorized", response = ErrorItem.class),
    @ApiResponse(code = 403, message = "Forbidden", response = ErrorItem.class),
    @ApiResponse(code = 404, message = "Not Found", response = ErrorItem.class),
    @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorItem.class)})
  ResponseEntity<AccountTransactionResponse> getAccountTransactions(
    @ApiParam(value = "Traceability E2E Header", required = true) String xSantanderGlobalId,
    @NotNull @ApiParam(value = "Account", required = true) String account,
    @ApiParam(value = "accounting_date") LocalDate accountingDate,
    @ApiParam(value = "from_accounting_date") LocalDate fromAccountingDate,
    @ApiParam(value = "to_accounting_date") LocalDate toAccountingDate,
    @ApiParam(value = "limit") Integer limit,
    @ApiParam(value = "offset") String offset,
    @ApiParam(value = "bc_offset") Integer bcOffset,
    @ApiParam(value = "extract") Long extract,
    @ApiParam(value = "alias") boolean alias);

  @ApiOperation(value = "Information generate report by UUID", nickname = "informationReports",
    response = Resource.class, authorizations = {@Authorization(value = "JWT")})
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "200 OK", response = Resource.class),
    @ApiResponse(code = 400, message = "Bad Request", response = ErrorItem.class),
    @ApiResponse(code = 401, message = "Unauthorized", response = ErrorItem.class),
    @ApiResponse(code = 404, message = "Not Found", response = ErrorItem.class),
    @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorItem.class)})
  ResponseEntity<List<DownloadApiResponse>> getGenerateReports(
    @ApiParam(value = "Traceability E2E Header", required = true) String xSantanderGlobalId,
    @NotNull @ApiParam(value = "UUID", required = true) String uuid);

  @ApiOperation(value = "Generation zip by requestId", nickname = "generateZipByReports",
    response = Resource.class, authorizations = {@Authorization(value = "JWT")})
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "200 OK", response = Resource.class),
    @ApiResponse(code = 400, message = "Bad Request", response = ErrorItem.class),
    @ApiResponse(code = 401, message = "Unauthorized", response = ErrorItem.class),
    @ApiResponse(code = 404, message = "Not Found", response = ErrorItem.class),
    @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorItem.class)})
  ResponseEntity<DownloadApiResponse> getGenerateZip(
    @ApiParam(value = "Traceability E2E Header", required = true) String xSantanderGlobalId,
    @NotNull @ApiParam(value = "UUID", required = true) String uuid,
    @NotNull @ApiParam(value = "requestId", required = true) List<String> requestIds);
}
