package com.santander.scib.gtb.ic.gcm.api.balance.controller;

import com.santander.scib.gtb.ic.gcm.api.balance.concurrency.OrchestrationService;
import com.santander.scib.gtb.ic.gcm.api.balance.model.account.ErrorItem;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.BalanceRequest;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.ProcessedAccount;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.download.DownloadApiResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionResponse;
import com.santander.scib.gtb.ic.gcm.service.ValidationService;
import com.santander.scib.gtb.ic.gcm.service.balance.AccountTransactionsService;
import com.santander.scib.gtb.ic.gcm.service.balance.AccountUuidHelper;
import com.santander.scib.gtb.ic.gcm.service.balance.ReportGeneratorService;
import com.santander.scib.gtb.ic.gcm.util.AccountSplitUtil;
import com.santander.scib.gtb.ic.gcm.util.TransactionPaginationUtil;
import com.santander.scib.gtb.ic.gcm.util.crypto.AESSymmetricCrypto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.ConstraintViolationException;
import javax.validation.constraints.NotNull;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.isban.gcb.ic.commons.util.function.FunctionalUtils.not;
import static com.isban.gcb.ic.commons.util.function.FunctionalUtils.peek;

@Slf4j
@RestController
public class BalanceController implements BalanceControllerBase {

  @Autowired private AccountTransactionsService accountTransactionsService;
  @Autowired private ReportGeneratorService reportGeneratorService;
  @Autowired private OrchestrationService orchestrationService;
  @Autowired private ValidationService validationService;
  @Autowired private AESSymmetricCrypto crypto;
  @Autowired private TransactionPaginationUtil paginationUtil;
  @Autowired private AccountUuidHelper accountUuidHelper;

  @PostMapping("{version}/balances")
  public CompletionStage<ResponseEntity<List<AccountBalanceDTO>>> getVersionedBalances(
    @RequestHeader(value = "X-Santander-Global-Id") String xSantanderGlobalId,
    @PathVariable(value = "version") @NotNull String version,
    @RequestBody @Validated BalanceRequest balanceRequest) {
    return getVersionedBalances(version, balanceRequest);

  }

  @Override
  @PostMapping("balances")
  public CompletionStage<ResponseEntity<List<AccountBalanceDTO>>> getBalances(
    @RequestHeader(value = "X-Santander-Global-Id") String xSantanderGlobalId,
    @RequestBody @Validated BalanceRequest balanceRequest) {

    return getVersionedBalances("v1", balanceRequest);
  }

  private CompletionStage<ResponseEntity<List<AccountBalanceDTO>>> getVersionedBalances(String version, BalanceRequest balanceRequest) {
    log.debug("Input request: {}", balanceRequest);
    Instant before = Instant.now();
    ProcessedAccount processedAccount = Optional.of(balanceRequest)
      .map(BalanceRequest::getAccounts)
      .map(validationService)
      .map(accountUuidHelper::completeWithUuid)
      .orElseThrow(RuntimeException::new);

    return Optional.of(processedAccount)
      .map(ProcessedAccount::getValidAccounts)
      .map(validatedAccounts -> orchestrationService.orchestrate(validatedAccounts,
        balanceRequest.getAccountingDate(), version))
      .map(result -> processResult(processedAccount, result))
      .orElseGet(() -> CompletableFuture.completedFuture(ResponseEntity.noContent().build()))
      .whenComplete((v, th) -> log.info("Total time elapsed in balance request: " + Duration.between(before, Instant.now()).toMillis() + " ms."));
  }

  private CompletionStage<ResponseEntity<List<AccountBalanceDTO>>> processResult(ProcessedAccount processedAccount, CompletionStage<List<AccountBalanceDTO>> result) {
    return result.thenApply(accounts -> {
      accounts.addAll(processedAccount.getInvalidAccounts());
      return ResponseEntity.ok(accounts);
    }).exceptionally(this::handleError);
  }

  @Override
  @GetMapping("balances/{account}/transactions")
  public ResponseEntity<AccountTransactionResponse> getAccountTransactions(
    @RequestHeader(value = "X-Santander-Global-Id") String xSantanderGlobalId,
    @PathVariable(value = "account") @NotNull String account,
    @RequestParam(required = false, value = "accounting_date") @DateTimeFormat(iso = ISO.DATE) LocalDate accountingDate,
    @RequestParam(required = false, value = "from_accounting_date")
    @DateTimeFormat(iso = ISO.DATE) LocalDate fromAccountingDate,
    @RequestParam(required = false, value = "to_accounting_date")
    @DateTimeFormat(iso = ISO.DATE) LocalDate toAccountingDate,
    @RequestParam(required = false, value = "limit") Integer limit,
    @RequestParam(required = false, value = "offset") String offset,
    @RequestParam(required = false, value = "bc_offset") Integer bcOffset,
    @RequestParam(required = false, value = "extract") Long extract,
    @RequestParam(required = false, value = "alias") boolean isAccountAlias) {
    return getVersionedAccountTransactions("v1", xSantanderGlobalId, account, accountingDate, fromAccountingDate,
      toAccountingDate, limit, offset, bcOffset, extract, isAccountAlias);
  }

  @GetMapping("{version}/balances/{account}/transactions")
  public ResponseEntity<AccountTransactionResponse> getAccountTransactions(
    @RequestHeader(value = "X-Santander-Global-Id") String xSantanderGlobalId,
    @PathVariable(value = "version") @NotNull String version,
    @PathVariable(value = "account") @NotNull String account,
    @RequestParam(required = false, value = "accounting_date") @DateTimeFormat(iso = ISO.DATE) LocalDate accountingDate,
    @RequestParam(required = false, value = "from_accounting_date")
    @DateTimeFormat(iso = ISO.DATE) LocalDate fromAccountingDate,
    @RequestParam(required = false, value = "to_accounting_date")
    @DateTimeFormat(iso = ISO.DATE) LocalDate toAccountingDate,
    @RequestParam(required = false, value = "limit") Integer limit,
    @RequestParam(required = false, value = "offset") String offset,
    @RequestParam(required = false, value = "bc_offset") Integer bcOffset,
    @RequestParam(required = false, value = "extract") Long extract,
    @RequestParam(required = false, value = "alias") boolean isAccountAlias) {

    return getVersionedAccountTransactions(version, xSantanderGlobalId, account, accountingDate, fromAccountingDate,
      toAccountingDate, limit, offset, bcOffset, extract, isAccountAlias);
  }

  private ResponseEntity<AccountTransactionResponse> getVersionedAccountTransactions(String version,
                                                                                     String xSantanderGlobalId,
                                                                                     String account,
                                                                                     LocalDate accountingDate,
                                                                                     LocalDate fromAccountingDate,
                                                                                     LocalDate toAccountingDate,
                                                                                     Integer limit,
                                                                                     String offset,
                                                                                     Integer bcOffset,
                                                                                     Long extract,
                                                                                     boolean isAccountAlias) {
    log.debug("Input account for transactions endpoint: {}", account);
    Instant before = Instant.now();
    TransactionDTO transactionDTO = getTransactionDTO(xSantanderGlobalId, account, accountingDate, fromAccountingDate,
      toAccountingDate, limit, offset, bcOffset, extract, isAccountAlias, version);
    return Optional.ofNullable(transactionDTO)
      .map(peek(this::validateInputMovements))
      .map(accountUuidHelper::completeWithUuid)
      .map(accountTransactionsService::getAccountTransactions)
      .map(peek(success -> log.info("Total time elapsed in transactions request: " + Duration.between(before, Instant.now()).toMillis() + " ms.")))
      .map(ResponseEntity::ok)
      .orElse(ResponseEntity.ok(new AccountTransactionResponse()));
  }

  @Override
  @GetMapping("balances/{uuid}/reports")
  public ResponseEntity<List<DownloadApiResponse>> getGenerateReports(
    @RequestHeader(value = "X-Santander-Global-Id") String xSantanderGlobalId,
    @PathVariable(value = "uuid") @NotNull String uuid) {

    return getVersionedGenerateReport("v1", uuid);
  }

  @GetMapping("{version}/balances/{uuid}/reports")
  public ResponseEntity<List<DownloadApiResponse>> getGenerateReports(
    @RequestHeader(value = "X-Santander-Global-Id") String xSantanderGlobalId,
    @PathVariable(value = "version") @NotNull String version,
    @PathVariable(value = "uuid") @NotNull String uuid) {

    return getVersionedGenerateReport(version, uuid);
  }

  private ResponseEntity<List<DownloadApiResponse>> getVersionedGenerateReport(String version, String uuid) {
    Instant before = Instant.now();
    return Optional.of(uuid)
      .map(reportGeneratorService::getGenerateReports)
      .filter(not(List::isEmpty))
      .map(this::encryptOutput)
      .map(peek(success -> log.info("Total time elapsed in reports request: " + Duration.between(before, Instant.now()).toMillis() + " ms.")))
      .map(ResponseEntity::ok)
      .orElse(ResponseEntity.ok(Collections.emptyList()));
  }

  @Override
  @GetMapping("balances/{uuid}/reports/zip")
  public ResponseEntity<DownloadApiResponse> getGenerateZip(
    @RequestHeader(value = "X-Santander-Global-Id") String xSantanderGlobalId,
    @PathVariable(value = "uuid") @NotNull String uuid,
    @RequestParam(value = "requestIds") @NotNull List<String> requestIds) {

    return getVersionedGenerateZip("v1", uuid, requestIds);
  }

  @GetMapping("{version}/balances/{uuid}/reports/zip")
  public ResponseEntity<DownloadApiResponse> getGenerateZip(
    @RequestHeader(value = "X-Santander-Global-Id") String xSantanderGlobalId,
    @PathVariable(value = "version") @NotNull String version,
    @PathVariable(value = "uuid") @NotNull String uuid,
    @RequestParam(value = "requestIds") @NotNull List<String> requestIds) {

    return getVersionedGenerateZip(version, uuid, requestIds);
  }

  private ResponseEntity<DownloadApiResponse> getVersionedGenerateZip(String version, String uuid, List<String> requestIds) {
    Instant before = Instant.now();
    return Optional.of(requestIds)
      .map(this::decryptInput)
      .map(given -> reportGeneratorService.getGenerateZip(uuid, given))
      .map(peek(success -> log.info("Total time elapsed in reports zip request: " + Duration.between(before, Instant.now()).toMillis() + " ms.")))
      .map(ResponseEntity::ok)
      .orElse(ResponseEntity.ok(new DownloadApiResponse()));
  }

  private ResponseEntity<List<AccountBalanceDTO>> handleError(Throwable throwable) {
    Throwable cause = throwable.getCause();
    log.error("Exception thrown when calculating balances", cause);
    return new ResponseEntity(buildError(cause.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
  }

  private ErrorItem buildError(String message) {
    HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
    ErrorItem error = new ErrorItem();
    error.setLevel("ERROR");
    error.setDescription(message);
    error.setCode(status.value());
    error.setMessage(status.getReasonPhrase());

    return error;
  }

  private void validateInputMovements(TransactionDTO transactionDTO) {
    Predicate<TransactionDTO> withToDateButNotFromDate = given -> Objects.nonNull(given.getToAccountingDate())
      && Objects.isNull(given.getFromAccountingDate());
    Predicate<TransactionDTO> mixingDates = given -> Objects.nonNull(given.getAccountingDate())
      && (Objects.nonNull(given.getFromAccountingDate()) || Objects.nonNull(given.getToAccountingDate()));

    Optional.of(transactionDTO)
      .filter(Predicate.not(mixingDates.or(withToDateButNotFromDate)))
      .map(peek(this::checkFromToDateRange))
      .orElseThrow(() -> new ConstraintViolationException("Invalid Dates", Collections.emptySet()));
  }

  private void checkFromToDateRange(TransactionDTO transactionDTO) {
    Predicate<TransactionDTO> isDateRange = given -> Objects.nonNull(given.getFromAccountingDate())
      || Objects.nonNull(given.getToAccountingDate());
    int allowedRangeInDays = paginationUtil.getLimitInDays();

    Optional.of(transactionDTO)
      .filter(isDateRange)
      .map(given -> Optional.ofNullable(given.getToAccountingDate())
        .filter(toDate ->
          (ChronoUnit.DAYS.between(transactionDTO.getFromAccountingDate(), toDate) + 1) <= allowedRangeInDays)
        .orElseGet(() -> Optional.of(given.getFromAccountingDate())
          .filter(fromDate -> fromDate.isAfter(LocalDate.now().minusDays(allowedRangeInDays)))
          .orElseThrow(() ->
            new ConstraintViolationException("Date range is over the maximum allowed in days", Collections.emptySet()))))
      .ifPresentOrElse(given ->
        log.debug("Date range validated correctly"), () -> log.debug("Date range validation was not required"));
  }

  private TransactionDTO getTransactionDTO(String xSantanderGlobalId, String account, LocalDate accountingDate,
                                           LocalDate fromAccountingDate, LocalDate toAccountingDate,
                                           Integer limit, String offset, Integer bcOffset, Long extractId,
                                           boolean isAccountAlias, String version) {
    String bic = AccountSplitUtil.getBic(account);
    String accountId = AccountSplitUtil.getAccountId(account);
    String currency = AccountSplitUtil.getCurrency(account);

    return TransactionDTO.builder()
      .version(version)
      .xSantanderGlobalId(xSantanderGlobalId)
      .accountId(accountId)
      .bic(bic)
      .currency(currency)
      .accountingDate(accountingDate)
      .fromAccountingDate(fromAccountingDate)
      .toAccountingDate(toAccountingDate)
      .limit(limit)
      .offset(offset)
      .bcOffset(bcOffset)
      .forReport(false)
      .extractId(Optional.ofNullable(extractId).orElse(0L))
      .isAccountAlias(isAccountAlias)
      .build();
  }

  private List<DownloadApiResponse> encryptOutput(List<DownloadApiResponse> downloadApiResponses) {
    return downloadApiResponses.stream()
      .map(given -> given.reportId(Optional.of(given.getReportId())
        .map(crypto::encrypt)
        .orElse(given.getReportId())))
      .collect(Collectors.toList());
  }

  private List<Long> decryptInput(List<String> requestIds) {
    return requestIds.stream()
      .map(crypto::decrypt)
      .map(Long::parseLong)
      .collect(Collectors.toList());
  }
}
