package com.santander.scib.gtb.ic.gcm.service.balance.chain.chains;

import com.isban.gcb.ic.commons.model.BalanceCache;
import com.isban.gcb.ic.commons.model.ExtractMovement;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.api.MappedTransaction;
import com.santander.scib.gtb.ic.gcm.mapper.ApiCommunicationMapper;
import com.santander.scib.gtb.ic.gcm.mapper.TransactionMapper;
import com.santander.scib.gtb.ic.gcm.repository.BalanceCacheRepository;
import com.santander.scib.gtb.ic.gcm.repository.ExtractMovementRepository;
import com.santander.scib.gtb.ic.gcm.service.AccountsService;
import com.santander.scib.gtb.ic.gcm.service.balance.chain.ChainLink;
import com.santander.scib.gtb.ic.gcm.util.TransactionPaginationUtil;
import com.santander.scib.gtb.ic.gcm.web.exception.NoTransactionsFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.isban.gcb.ic.commons.balance.cache.dto.BalanceType.END_OF_DAY;
import static com.isban.gcb.ic.commons.balance.cache.dto.BalanceType.INTRA_DAY;
import static com.isban.gcb.ic.commons.util.function.FunctionalUtils.peek;
import static com.santander.scib.gtb.ic.gcm.repository.BalanceCacheRepository.BY_ACCOUNTING_DATE_DESC;
import static com.santander.scib.gtb.ic.gcm.util.AccountingDateUtil.atEndOfDay;
import static com.santander.scib.gtb.ic.gcm.util.AccountingDateUtil.getFromAccountingDate;
import static com.santander.scib.gtb.ic.gcm.util.AccountingDateUtil.getToAccountingDate;

@Slf4j
@Component
@Qualifier("IcChain")
public class IcChain implements ChainLink<TransactionDTO, AccountTransactionResponse> {

  @Autowired private BalanceCacheRepository balanceCacheRepository;
  @Autowired private ExtractMovementRepository movementRepository;
  @Autowired private TransactionMapper mapper;
  @Autowired private ApiCommunicationMapper apiMapper;
  @Autowired private AccountsService accountsService;
  @Autowired private TransactionPaginationUtil paginationUtil;

  @Override
  public boolean test(TransactionDTO transactionDTO) {
    return Optional.ofNullable(transactionDTO)
      .map(TransactionDTO::getBcOffset)
      .map(bcOffset -> Boolean.TRUE)
      .orElse(isOnline(transactionDTO));
  }

  private boolean isOnline(TransactionDTO transactionDTO) {
    return Optional.ofNullable(transactionDTO)
      .map(TransactionDTO::getOffset)
      .map(offset -> Boolean.FALSE)
      .orElse(isExtractIdPresent(transactionDTO));
  }

  private boolean isExtractIdPresent(TransactionDTO transactionDTO) {
    return Optional.ofNullable(transactionDTO)
      .map(TransactionDTO::getExtractId)
      .filter(extract -> extract > 0)
      .map(offset -> Boolean.TRUE)
      .orElse(isDataBaseByCache(transactionDTO));
  }

  private boolean isDataBaseByCache(TransactionDTO transactionDTO) {
    return getLastBalanceCache(transactionDTO)
      .filter(cache -> cache.getBalanceType().equals(INTRA_DAY.toString()) || cache.getBalanceType().equals(END_OF_DAY.toString()))
      .map(peek(cache -> transactionDTO.setExtractId(cache.getExtract().getId())))
      .isPresent();
  }

  @Override
  public AccountTransactionResponse apply(TransactionDTO transactionDTO) {
    log.info("Applying the IC balance cache strategy");
    return Optional.of(findAccountTransactionDto(transactionDTO))
      .map(transactions -> apiMapper.toTransactionResponse(transactions, transactionDTO))
      .orElseThrow(IllegalArgumentException::new);
  }

  private Optional<BalanceCache> getLastBalanceCache(TransactionDTO transactionDTO) {
    return Optional.ofNullable(transactionDTO.getAccountingDate())
      .map(date -> balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrencyAndAccountingDateLessThanEqual(transactionDTO.getBic(), transactionDTO.getAccountUuid(),
        transactionDTO.getCurrency(), atEndOfDay(date), BY_ACCOUNTING_DATE_DESC))
      .orElse(balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrency(transactionDTO.getBic(), transactionDTO.getAccountUuid(),
        transactionDTO.getCurrency(), BY_ACCOUNTING_DATE_DESC));
  }

  private MappedTransaction findAccountTransactionDto(TransactionDTO transactionDTO) {
    int bcOffset = Optional.ofNullable(transactionDTO.getBcOffset()).orElse(0);
    int limit = paginationUtil.getLimit(transactionDTO);

    LocalDateTime toDate = getToAccountingDate(transactionDTO);
    LocalDateTime fromDate = getFromAccountingDate(transactionDTO, toDate, paginationUtil.getLimitInDays());
    LocalDateTime fromDateMinusOneDay = fromDate.minusDays(1);

    return MappedTransaction.builder()
      .accountTransactions(
        Optional.of(transactionDTO)
          .map(dto -> findMovementsSortedByValueDate(dto, fromDate, toDate, fromDateMinusOneDay, bcOffset, limit))
          .map(movements -> movements.stream()
            .parallel()
            .map(mov -> mapper.movementToTransaction(mov, transactionDTO))
            .collect(Collectors.toCollection(LinkedList::new)))
          .orElseThrow(() -> new NoTransactionsFoundException("No transactions were found in database")))
      .build();
  }

  private List<ExtractMovement> findMovementsSortedByValueDate(TransactionDTO dto, LocalDateTime fromDate,
                                                               LocalDateTime toDate, LocalDateTime fromDateMinusOneDay,
                                                               int bcOffset, int limit) {
    log.debug("Extract id where it should begin {}", dto.getExtractId());
    return Stream.of(dto.getToAccountingDate(), dto.getAccountingDate())
      .map(Objects::nonNull)
      .reduce((a, b) -> a || b)
      .filter(Boolean.TRUE::equals)
      .map(success -> movementRepository.findMovementsSortedByValueDate(dto.getBic(), dto.getAccountUuid(), dto.getCurrency(),
        fromDate, toDate, fromDateMinusOneDay, dto.getExtractId(), bcOffset, limit))
      .orElse(movementRepository.findMovementsSortedByValueDate(dto.getBic(), dto.getAccountUuid(), dto.getCurrency(),
        fromDate, fromDateMinusOneDay, dto.getExtractId(), bcOffset, limit));
  }
}