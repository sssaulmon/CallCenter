package com.santander.scib.gtb.ic.gcm.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@EntityScan({"com.isban.gcb.ic.commons.model", "com.santander.scib.gtb.ic.gcm.model"})
public class JpaConfig {
}
