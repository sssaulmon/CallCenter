package com.santander.scib.gtb.ic.gcm.api.balance.concurrency.impl;

import com.isban.gcb.ic.commons.util.function.TriFunction;
import com.santander.scib.gtb.ic.gcm.api.balance.concurrency.OrchestrationService;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.model.NotificationError;
import com.santander.scib.gtb.ic.gcm.model.NotificationType;
import com.santander.scib.gtb.ic.gcm.service.balance.AccountBalanceService;
import com.santander.scib.gtb.ic.gcm.service.balance.MessagingService;
import com.santander.scib.gtb.ic.gcm.web.exception.BadRequestException;
import com.santander.scib.gtb.ic.gcm.web.exception.DBConnectionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.concurrent.CompletableFuture.allOf;
import static java.util.concurrent.CompletableFuture.runAsync;
import static java.util.concurrent.CompletableFuture.supplyAsync;
import static java.util.function.Predicate.not;

@Slf4j
@Service
public class OrchestrationServiceImpl implements OrchestrationService {

  @Autowired private AccountBalanceService balanceService;
  @Autowired private MessagingService messagingService;

  @Autowired @Qualifier("dbExecutor") private Executor dbExecutor;
  @Autowired @Qualifier("apiExecutor") private Executor apiExecutor;
  @Autowired @Qualifier("sleepExecutor") private ScheduledExecutorService sleepExecutor;
  @Value("${apis.orchestration.timeoutSeconds}") private long orchestrationTimeout;
  @Value("${apis.orchestration.threshold}") private long threshold;

  @Override
  public CompletionStage<List<AccountBalanceDTO>> orchestrate(List<AccountDTO> accounts, LocalDate accountingDate,
                                                              String version) {
    return Optional.of(accounts)
      .map(List::size)
      .filter(size -> size >= threshold)
      .map(tooBig -> orchestrateAccounts(accounts, accountingDate, version))
      .orElseGet(() -> processAccountIndividually(accounts, accountingDate));
  }

  private CompletionStage<List<AccountBalanceDTO>> orchestrateAccounts(List<AccountDTO> accounts, LocalDate accountingDate,
                                                                       String version) {

    var before = Instant.now();
    var dbPromise = sleepPromise()
      .thenCombineAsync(supplyAsync(() -> balanceService.findAccountsBalanceRepository(accounts, accountingDate), dbExecutor)
          .exceptionally(th -> {
            log.error("DbPromise failed: ", th);
            return new ArrayList<>();
          }),
        (notRelevant, dto) -> dto, dbExecutor)
      .whenComplete((v, th) -> log.info("Time elapsed in DB promise: " + Duration.between(before, Instant.now()).toMillis() + " ms."));

    var apiPromise = synchronizePromises(accounts,
      account -> buildPromise(account, accountingDate, balanceService::findAccountBalanceAPI,
        (dto, th) -> handleApiResult(dto, account, th), this::recover, apiExecutor))
      .whenComplete((v, th) ->
        log.info("Time elapsed in API promise: " + Duration.between(before, Instant.now()).toMillis() + " ms."));

    return resolve(apiPromise, dbPromise, result -> handleResponses(apiPromise, dbPromise, not(List::isEmpty)));
  }

  private CompletionStage<List<AccountBalanceDTO>> processAccountIndividually(List<AccountDTO> accounts, LocalDate accountingDate) {
    return synchronizePromises(accounts, account -> orchestrateAccount(account, accountingDate));
  }

  private CompletionStage<AccountBalanceDTO> orchestrateAccount(AccountDTO account, LocalDate accountingDate) {

    var apiPromise = buildPromise(account, accountingDate,
      balanceService::findAccountBalanceAPI, (dto, th) -> handleApiResult(dto, account, th), this::recover, apiExecutor);

    var dbPromise = sleepPromise()
      .thenCombineAsync(buildPromise(account, accountingDate, balanceService::findAccountBalanceRepository,
        (dto, th) -> sendErrorIfNeeded(account, th), (accNotRelevant, dateNotRelevant, th) -> null, dbExecutor), (notRelevant, dto) -> dto, dbExecutor);

    return resolve(apiPromise, dbPromise, result -> handleResponses(apiPromise, dbPromise, Objects::nonNull));
  }

  private AccountBalanceDTO recover(AccountDTO account, LocalDate accountingDate, Throwable throwable) {
    return Optional.ofNullable(throwable)
      .map(exception -> supplyAsync(() -> balanceService.findAccountBalance(account, accountingDate), dbExecutor)
        .exceptionally(th -> {
          DBConnectionException ex = new DBConnectionException();
          sendErrorIfNeeded(account, ex);
          throw ex;
        }))
      .map(CompletableFuture::join)
      .map(dto -> dto.information(getApiError(throwable)))
      .orElseThrow(RuntimeException::new);
  }

  private String getApiError(Throwable throwable) {
    return Optional.of(throwable)
      .filter(BadRequestException.class::isInstance)
      .map(Throwable::getMessage)
      .orElse(null);
  }

  private <E, W, R extends List<E>> CompletionStage<List<W>> synchronizePromises(R source, Function<E, CompletionStage<W>> mapper) {
    CompletableFuture<W>[] promises = source.stream()
      .parallel()
      .map(mapper)
      .map(CompletionStage::toCompletableFuture)
      .toArray((IntFunction<CompletableFuture<W>[]>) CompletableFuture[]::new);

    return allOf(promises)
      .thenApply(v -> Stream.of(promises)
        .parallel()
        .map(CompletableFuture::join)
        .filter(Objects::nonNull)
        .collect(Collectors.toList()));
  }

  private <T, R extends CompletionStage<T>> CompletionStage<T> resolve(R apiPromise, R dbPromise, Function<T, R> handler) {
    return dbPromise
      .applyToEither(apiPromise, handler)
      .thenCompose(Function.identity());
  }

  private <W, S, U> CompletionStage<W> buildPromise(S account, U accountingDate,
                                                    BiFunction<S, U, CompletionStage<W>> generator,
                                                    BiConsumer<W, Throwable> finisher,
                                                    TriFunction<S, U, Throwable, W> recover,
                                                    Executor executor) {
    return supplyAsync(() ->
      generator.apply(account, accountingDate)
        .whenCompleteAsync(finisher, executor), executor)
      .thenComposeAsync(Function.identity(), executor)
      .exceptionally(th -> recover.apply(account, accountingDate, th));
  }

  private <T, E extends CompletionStage<T>> E handleResponses(E apiPromise, E dbPromise, Predicate<T> checker) {
    return Optional.of(apiPromise.toCompletableFuture())
      .filter(CompletableFuture::isDone)
      .map(CompletableFuture::join)
      .filter(checker)
      .stream()
      .peek(response -> log.info("Got successful response from API: {}", response))
      .map(validApiResponse -> apiPromise)
      .findFirst()
      .orElse(dbPromise);
  }

  private CompletableFuture<?> sleepPromise() {
    var sleepPromise = new CompletableFuture<>();
    sleepExecutor.schedule(() -> sleepPromise.complete("sleep finished"), orchestrationTimeout, TimeUnit.SECONDS);
    return sleepPromise;
  }

  private void handleApiResult(AccountBalanceDTO accountBalanceDTO, AccountDTO account, Throwable throwable) {
    Optional.ofNullable(accountBalanceDTO)
      .ifPresentOrElse(response ->
          runAsync(() -> messagingService.sendExtractDto(response))
            .whenComplete((v, th) -> sendErrorIfNeeded(account, th)),
        () -> sendErrorIfNeeded(account, throwable));
  }

  private void sendErrorIfNeeded(AccountDTO account, Throwable throwable) {
    Optional.ofNullable(throwable)
      .map(th -> buildErrorMessage(account, th))
      .ifPresent(message -> messagingService.sendError(message));
  }

  private NotificationError buildErrorMessage(AccountDTO account, Throwable th) {
    return new NotificationError()
      .bic(account.getBic())
      .account(account.getAccountId())
      .currency(account.getCurrency())
      .uuidAccount(account.getUuid())
      .date(LocalDateTime.now())
      .exceptionType(th.getClass().getSimpleName())
      .type(NotificationType.getType(th.getClass()))
      .message(th.getMessage());
  }
}
