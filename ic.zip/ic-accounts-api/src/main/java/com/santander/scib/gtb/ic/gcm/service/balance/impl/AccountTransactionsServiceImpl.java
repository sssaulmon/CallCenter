package com.santander.scib.gtb.ic.gcm.service.balance.impl;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionResponse;
import com.santander.scib.gtb.ic.gcm.service.balance.AccountTransactionsService;
import com.santander.scib.gtb.ic.gcm.service.balance.MessagingService;
import com.santander.scib.gtb.ic.gcm.service.balance.chain.ChainLink;
import com.santander.scib.gtb.ic.gcm.service.balance.chain.ResponsibilityChain;
import com.santander.scib.gtb.ic.gcm.web.exception.ExternalApiException;
import com.santander.scib.gtb.ic.gcm.web.exception.NoTransactionsFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Optional;

import static com.isban.gcb.ic.commons.util.function.FunctionalUtils.peek;

@Slf4j
@Service
public class AccountTransactionsServiceImpl implements AccountTransactionsService {

  @Autowired
  @Qualifier("IcChain")
  private ChainLink<TransactionDTO, AccountTransactionResponse> icChain;

  @Autowired
  @Qualifier("OnlineChain")
  private ChainLink<TransactionDTO, AccountTransactionResponse> onlineChain;

  @Autowired
  private MessagingService messagingService;

  @Override
  public AccountTransactionResponse getAccountTransactions(TransactionDTO transactionDTO) {
    try {
      return new ResponsibilityChain<>(icChain)
        .next(onlineChain)
        .apply(transactionDTO);

    } catch (ExternalApiException ex) {
      return Optional.of(transactionDTO)
        .filter(transaction -> Objects.isNull(transaction.getOffset()))
        .map(peek(transaction -> log.info("Online request failed. IC will response for account {}", transaction.getAccountId())))
        .map(peek(transaction -> transaction.setBcOffset(0)))
        .map(transaction -> new ResponsibilityChain<>(icChain).apply(transaction))
        .orElseThrow(() -> new ExternalApiException(ex.getMessage()));
    } catch (Exception ex) {
      sendError(transactionDTO, ex);
      throw new NoTransactionsFoundException(ex);
    }
  }

  private void sendError(TransactionDTO transactionDTO, Exception ex) {
    messagingService.sendError(
      String.join("", transactionDTO.getAccountId(), transactionDTO.getBic(), transactionDTO.getCurrency()),
      ex.getMessage());
  }
}
