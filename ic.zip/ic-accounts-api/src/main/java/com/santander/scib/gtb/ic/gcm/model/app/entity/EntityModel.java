package com.santander.scib.gtb.ic.gcm.model.app.entity;

import com.santander.scib.gtb.ic.gcm.util.SecurityUtil;

import java.util.List;

public class EntityModel {
  private String origin;
  private boolean enabled;
  private String serviceUrl;
  private List<String> countries;
  private boolean proxy;
  private Oauth2Client oauth2Client;
  private List<String> bics;

  public String getOrigin() {
    return origin;
  }

  public void setOrigin(String origin) {
    this.origin = origin;
  }

  public boolean isEnabled() {
    return enabled;
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }

  public String getServiceUrl() {
    return serviceUrl;
  }

  public void setServiceUrl(String serviceUrl) {
    this.serviceUrl = serviceUrl;
  }

  public boolean isProxy() {
    return proxy;
  }

  public void setProxy(boolean proxy) {
    this.proxy = proxy;
  }

  public Oauth2Client getOauth2Client() {
    return oauth2Client;
  }

  public void setOauth2Client(Oauth2Client oauth2Client) {
    this.oauth2Client = oauth2Client;
  }

  public List<String> getBics() {
    return SecurityUtil.unmodify(bics);
  }

  public void setBics(List<String> bics) {
    this.bics = SecurityUtil.unmodify(bics);
  }

  public List<String> getCountries() {
    return SecurityUtil.unmodify(countries);
  }

  public void setCountries(List<String> countries) {
    this.countries = SecurityUtil.unmodify(countries);
  }
}
