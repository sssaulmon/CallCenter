package com.santander.scib.gtb.ic.gcm.service;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;

import java.util.List;
import java.util.function.UnaryOperator;

/**
 * The interface Validation service.
 */
public interface ValidationService extends UnaryOperator<List<AccountDTO>> {
}
