package com.santander.scib.gtb.ic.gcm.api.balance.model.slb.balance;

import java.math.BigDecimal;

public class GenericBalance {
  private String lastUpdate;
  private BigDecimal amount;
  private String currencyCode;

  public BigDecimal getAmount() {
    return amount;
  }

  public String getCurrencyCode() {
    return currencyCode;
  }

  public void setLastUpdate(String lastUpdate) {
    this.lastUpdate = lastUpdate;
  }

  public String getLastUpdate() {
    return lastUpdate;
  }

  public void setAmount(BigDecimal amount) {
    this.amount = amount;
  }

  public void setCurrencyCode(String currencyCode) {
    this.currencyCode = currencyCode;
  }
}
