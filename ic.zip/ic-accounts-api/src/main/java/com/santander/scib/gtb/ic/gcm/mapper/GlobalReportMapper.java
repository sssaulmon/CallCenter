package com.santander.scib.gtb.ic.gcm.mapper;

import com.isban.gcb.ic.commons.model.GlobalReport;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.model.GenerateFileRequestDTO;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Optional;

import static java.util.function.Predicate.not;

@Component
public class GlobalReportMapper {
  private static final String API_VALUE = "API";
  private static final String NULL_VALUE = "NULL";

  public GlobalReport requestToGlobalReport(GenerateFileRequestDTO generateFileRequest) {
    Optional<AccountDTO> accountDTO = generateFileRequest.getAccounts()
      .stream()
      .findFirst();
    return new GlobalReport()
      .setBic(accountDTO.map(AccountDTO::getBic).orElse(NULL_VALUE))
      .setAccount(accountDTO.map(AccountDTO::getAccountId).orElse(NULL_VALUE))
      .setCurrency(accountDTO.map(AccountDTO::getCurrency).orElse(NULL_VALUE))
      .setContractNumber(accountDTO.map(AccountDTO::getIdentifier)
        .filter(not(String::isEmpty)).orElse(API_VALUE))
      .setAccountingDate(generateFileRequest.getUserDate())
      .setIncomingDate(LocalDateTime.now())
      .setStatus(generateFileRequest.getStatus())
      .setServiceSendChannel(API_VALUE)
      .setAddresses(API_VALUE)
      .setType(API_VALUE.concat(" ").concat(generateFileRequest.getType().toUpperCase()))
      .setStatus("Generado OK")
      .setUuidGlobalReport(generateFileRequest.getUuid());
  }
}
