package com.santander.scib.gtb.ic.gcm.web.exception;

public class NoTransactionsFoundException extends RuntimeException {

  public NoTransactionsFoundException(String error) {
    super("Request to DB failed with error: " + error);
  }

  public NoTransactionsFoundException(Throwable th) {
    super(th);
  }
}
