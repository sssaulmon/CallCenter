package com.santander.scib.gtb.ic.gcm.api.balance.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.gtb.ic.gcm.api.balance.model.account.CustomerOperation;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class Operation {

  @ApiModelProperty(value = "")
  @Valid
  @JsonProperty("customerOperation")
  private CustomerOperation customerOperation;

  @ApiModelProperty(example = "\"NCHK\"", required = true, value = "SwiftCode is the standard SWIFT Transaction type code (i.e. NCHK = Check; NCHG = Charges and other expenses; NTRF = Transfer)")
  @NotNull
  @JsonProperty("swiftCode")
  private String swiftCode;

  public void setCustomerOperation(CustomerOperation customerOperation) {
    this.customerOperation = customerOperation;
  }

  public void setSwiftCode(String swiftCode) {
    this.swiftCode = swiftCode;
  }

  public String getSwiftCode() {
    return swiftCode;
  }
}

