package com.santander.scib.gtb.ic.gcm.oauthstrategy.impl;

import com.santander.scib.gtb.ic.gcm.oauthstrategy.ApiVersion;
import com.santander.scib.gtb.ic.gcm.oauthstrategy.CountryContext;
import com.santander.scib.gtb.ic.gcm.oauthstrategy.CountryStrategy;
import com.santander.scib.gtb.ic.gcm.web.exception.ExternalApiException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CountryContextImpl implements CountryContext {

  @Autowired private List<CountryStrategy> strategies;

  @Override
  public CountryStrategy resolve(String type) {
    return strategies.stream()
      .filter(strategy -> strategy.getClass().getAnnotation(ApiVersion.class).type().equals(type))
      .findFirst()
      .orElseThrow(() -> new ExternalApiException("BIC not supported"));
  }
}
