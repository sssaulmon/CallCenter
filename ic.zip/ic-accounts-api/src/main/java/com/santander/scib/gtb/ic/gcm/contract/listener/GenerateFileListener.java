package com.santander.scib.gtb.ic.gcm.contract.listener;

import com.santander.scib.gtb.ic.gcm.communication.service.GenerateFileNotificationService;
import com.santander.scib.gtb.ic.gcm.contract.constants.GenerateFileInputConstants;
import com.santander.scib.gtb.ic.gcm.model.GenerateFileRequestDTO;
import com.santander.scib.gtb.ic.gcm.service.GenerateFileService;
import com.santander.scib.gtb.ic.gcm.service.balance.MessagingService;
import com.santander.scib.gtb.ic.gcm.web.exception.InputValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static java.util.concurrent.CompletableFuture.supplyAsync;

@Slf4j
@Component
public class GenerateFileListener {

  @Autowired private GenerateFileService generateFileService;
  @Autowired private GenerateFileNotificationService generateFileNotificationService;
  @Autowired private MessagingService messagingService;

  @StreamListener(GenerateFileInputConstants.GENERATE_FILE_REQUEST)
  public void generateFile(GenerateFileRequestDTO generateFileRequest) {
    log.info("Received Request Message by generate Movements or Balance File - UUID: {}", generateFileRequest.getUuid());
    Optional.ofNullable(generateFileRequest)
      .map(GenerateFileRequestDTO::getVersion)
      .map(version -> generateFileRequest)
      .orElseGet(() -> generateFileRequest.version("v1"));

    supplyAsync(() -> generateFileRequest)
      .thenApply(generateFileService::generateFile)
      .thenAccept(generateFileNotificationService::sendNotification)
      .whenComplete((v, th) -> this.handleResult(th, generateFileRequest));
  }

  private void handleResult(Throwable th, GenerateFileRequestDTO generateFileRequest) {
    Optional.ofNullable(th)
      .map(Throwable::getCause)
      .filter(InputValidationException.class::isInstance)
      .map(InputValidationException.class::cast)
      .map(InputValidationException::getMessage)
      .map(generateFileRequest::status)
      .ifPresentOrElse(error -> generateFileNotificationService.sendNotification(error),
        () -> Optional.ofNullable(th)
          .map(given -> "Internal Error")
          .map(generateFileRequest::status)
          .ifPresent(error -> {
            generateFileNotificationService.sendNotification(error);
            messagingService.sendGenerateFileError(error.getUuid(), th.getMessage());
          }));
  }
}
