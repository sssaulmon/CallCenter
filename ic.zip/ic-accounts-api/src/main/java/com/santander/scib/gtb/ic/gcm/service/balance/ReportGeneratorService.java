package com.santander.scib.gtb.ic.gcm.service.balance;

import com.santander.scib.gtb.ic.gcm.api.balance.model.output.download.DownloadApiResponse;

import java.util.List;

/**
 * The interface Report generator service.
 */
public interface ReportGeneratorService {

  /**
   * Gets generate reports.
   *
   * @param uuid the uuid
   * @return the generate reports
   */
  List<DownloadApiResponse> getGenerateReports(String uuid);

  /**
   * Gets generate zip.
   *
   * @param uuid      the uuid
   * @param requestId the request id
   * @return the generate zip
   */
  DownloadApiResponse getGenerateZip(String uuid, List<Long> requestId);
}
