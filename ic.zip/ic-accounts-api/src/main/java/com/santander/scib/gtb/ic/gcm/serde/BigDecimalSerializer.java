package com.santander.scib.gtb.ic.gcm.serde;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Optional;

public class BigDecimalSerializer extends JsonSerializer<BigDecimal> {


  @Override
  public void serialize(BigDecimal value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
    gen.writeNumber(Optional.ofNullable(value)
      .map(BigDecimal::stripTrailingZeros)
      .map(BigDecimal::toPlainString)
      .orElse(""));
  }
}
