package com.santander.scib.gtb.ic.gcm.api.balance.model.slb.balance;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RelatedCard {

  @JsonProperty("displayNumber")
  private String displayNumber;

  @JsonProperty("cardLink")
  private String cardLink;

  public void setDisplayNumber(String displayNumber) {
    this.displayNumber = displayNumber;
  }

  public void setCardLink(String cardLink) {
    this.cardLink = cardLink;
  }
}
