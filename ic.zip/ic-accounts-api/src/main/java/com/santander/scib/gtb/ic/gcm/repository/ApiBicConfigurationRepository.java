package com.santander.scib.gtb.ic.gcm.repository;

import com.santander.scib.gtb.ic.gcm.model.ApiBicConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiBicConfigurationRepository extends JpaRepository<ApiBicConfiguration, String> {
}
