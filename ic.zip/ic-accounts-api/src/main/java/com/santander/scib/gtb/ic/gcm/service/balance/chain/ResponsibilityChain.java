package com.santander.scib.gtb.ic.gcm.service.balance.chain;

import java.util.LinkedList;
import java.util.Queue;

public class ResponsibilityChain<T, W> {

  private Queue<ChainLink<T, W>> chains;

  public ResponsibilityChain(ChainLink<T, W> initialChain) {
    chains = new LinkedList<>();
    chains.add(initialChain);
  }

  public ResponsibilityChain<T, W> next(ChainLink<T, W> initialChain) {
    chains.add(initialChain);
    return this;
  }

  public W apply(T t) {
    return chains.stream()
      .filter(chain -> chain.test(t))
      .map(chain -> chain.apply(t))
      .findFirst()
      .orElse(null);
  }

}
