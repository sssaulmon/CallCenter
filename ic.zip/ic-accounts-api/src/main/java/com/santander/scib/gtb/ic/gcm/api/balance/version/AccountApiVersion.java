package com.santander.scib.gtb.ic.gcm.api.balance.version;

import com.santander.scib.gtb.ic.gcm.api.balance.model.global.balance.GlobalAccountResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.balance.SLBAccountBalanceResponse;
import com.santander.scib.gtb.ic.gcm.model.AccountBalance;

import java.util.stream.Stream;

public enum AccountApiVersion {
  V1_ORIGIN_V2("v1", "v2", GlobalAccountResponse.class),
  V1_ORIGIN_V3("v1", "v3", SLBAccountBalanceResponse.class);

  private final Class<? extends AccountBalance> accountType;
  private final String version;
  private final String origin;

  AccountApiVersion(String version, String origin,
                    Class<? extends AccountBalance> accountType) {
    this.version = version;
    this.origin = origin;
    this.accountType = accountType;
  }

  public String getVersion() {
    return version;
  }

  public String getOrigin() {
    return origin;
  }

  public Class<? extends AccountBalance> getAccountType() {
    return accountType;
  }

  public static Class<? extends AccountBalance> getAccountApiType(String version, String origin) {
    return Stream.of(values())
      .filter(v -> v.getVersion().equals(version) && v.getOrigin().equals(origin))
      .map(AccountApiVersion::getAccountType)
      .findFirst()
      .orElseThrow(RuntimeException::new);
  }
}
