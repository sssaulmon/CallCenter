package com.santander.scib.gtb.ic.gcm.model.app.entity;

import com.santander.scib.gtb.ic.gcm.util.SecurityUtil;

import java.util.List;

public class AudienceModel {
  private List<String> audience;

  public AudienceModel(List<String> audience) {
    this.audience = SecurityUtil.unmodify(audience);
  }

  public List<String> getAudience() {
    return SecurityUtil.unmodify(audience);
  }

  public void setAudience(List<String> audience) {
    this.audience = SecurityUtil.unmodify(audience);
  }
}

