package com.santander.scib.gtb.ic.gcm.contract.binding;

import com.santander.scib.gtb.ic.gcm.contract.constants.GenerateFileInputConstants;
import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

public interface GenerateFileInputBinding {

  @Input(GenerateFileInputConstants.GENERATE_FILE_REQUEST)
  SubscribableChannel generateFileRequest();

  @Input(GenerateFileInputConstants.UPDATE_FILE_STATUS_REQUEST)
  SubscribableChannel updateFileStatus();
}
