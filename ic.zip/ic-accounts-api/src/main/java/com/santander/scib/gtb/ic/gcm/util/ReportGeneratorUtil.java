package com.santander.scib.gtb.ic.gcm.util;

import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.ForwardAmountDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionDTO;
import com.santander.scib.gtb.ic.gcm.model.DecimalFormatterType;
import com.santander.scib.gtb.ic.gcm.model.OriginType;
import com.santander.scib.gtb.ic.gcm.model.WorkBookContainer;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

/**
 * The type Report generator util.
 */
public class ReportGeneratorUtil {

  private static final String EMPTY_STRING = "";
  private static final int BALANCE_COLUMN_TOTAL = 10;

  /**
   * Generate header.
   *
   * @param row     the row
   * @param headers the headers
   */
  public static void generateHeader(Row row, List<String> headers) {
    IntStream.range(0, headers.size())
      .forEach(idx -> createHeaderCell(row, idx, headers.get(idx)));
  }

  /**
   * Generate balance row sheet.
   *
   * @param balance           the balance
   * @param row               the row
   * @param workBookContainer the work book container
   * @return the sheet
   */
  public static Sheet generateBalanceRow(AccountBalanceDTO balance, Row row, WorkBookContainer workBookContainer) {
    DecimalFormatterType type = workBookContainer.getDecimalFormatterType();
    CellStyle numericCellStyle = workBookContainer.getNumericStyle();

    createCell(row, 0, getValueOrEmptyString(balance.getBic()));
    createCell(row, 1, getValueOrEmptyString(balance.getAccountId()));
    createCell(row, 2, getValueOrEmptyString(balance.getAlias()));
    createCell(row, 3, getValueOrEmptyString(balance.getCurrency()));
    createNumericCell(row, 4, type, numericCellStyle, balance.getOpeningAmount());
    createNumericCell(row, 5, type, numericCellStyle, balance.getClosingAmount());
    createNumericCell(row, 6, type, numericCellStyle, balance.getAvailableAmount());
    createDateCell(row, 7, balance.getAccountingDate(), workBookContainer.getDateStyle());
    createCell(row, 8, getValueOrEmptyString(balance.getAccountingTime()));
    createCell(row, 9, OriginType.getDescription(balance.getBalanceType()));
    processForwardAmounts(row, balance.getForwardAmounts(), numericCellStyle);

    return row.getSheet();
  }

  private static void processForwardAmounts(Row row, List<ForwardAmountDTO> forwardAmounts, CellStyle numericCellStyle) {
    processForwardHeaders(row, forwardAmounts.size());
    final AtomicInteger index = new AtomicInteger(10);
    forwardAmounts.forEach(forwardAmount -> {
      createNumericCell(row, index.getAndAdd(1), getValueOrEmptyDouble(forwardAmount.getAmount()), numericCellStyle);
      createCell(row, index.getAndAdd(1), getValueOrEmptyString(forwardAmount.getDate()));
    });
  }

  private static void processForwardHeaders(Row row, int size) {
    Row headerRow = row.getSheet().getRow(0);
    int cellIndex = headerRow.getLastCellNum();
    int currentForwardSize = (cellIndex - BALANCE_COLUMN_TOTAL) / 2;
    cellIndex--;
    for (int i = size; i > currentForwardSize; i--) {
      createHeaderCell(headerRow, ++cellIndex, "FORWARD AMOUNT");
      createHeaderCell(headerRow, ++cellIndex, "FORWARD AMOUNT DATE");
    }
  }

  /**
   * Write transaction sheet.
   *
   * @param transaction       the transaction
   * @param row               the row
   * @param workBookContainer the work book container
   * @return the sheet
   */
  public static Sheet writeTransaction(AccountTransactionDTO transaction, Row row, WorkBookContainer workBookContainer) {
    DecimalFormatterType decimalFormatterType = workBookContainer.getDecimalFormatterType();
    createCell(row, 0, getValueOrEmptyString(transaction.getAccountId()));
    createCell(row, 1, getValueOrEmptyString(transaction.getAlias()));
    createDateCell(row, 2, transaction.getAccountingDate(), workBookContainer.getDateStyle());
    createDateCell(row, 3, transaction.getValueDate(), workBookContainer.getDateStyle());
    createDateCell(row, 4, transaction.getEntryDate(), workBookContainer.getDateStyle());
    createNumericCell(row, 5, decimalFormatterType, workBookContainer.getNumericStyle(), transaction.getAmount());
    createCell(row, 6, getValueOrEmptyString(transaction.getCurrency()));
    createNumericCell(row, 7, decimalFormatterType, workBookContainer.getNumericStyle(), transaction.getBalance());
    createCell(row, 8, getValueOrEmptyString(transaction.getMovementTime()));
    createCell(row, 9, OriginType.getDescription(transaction.getOrigin()));
    createCell(row, 10, getValueOrEmptyString(transaction.getIdentificationCode()));
    createCell(row, 11, getValueOrEmptyString(transaction.getAccountOwner()));
    createCell(row, 12, getValueOrEmptyString(transaction.getAccountServiceInstitution()));
    createCell(row, 13, getValueOrEmptyString(transaction.getAdditionalInfo()));
    createCell(row, 14, getValueOrEmptyString(transaction.getDescription()));
    return row.getSheet();
  }

  private static void createHeaderCell(Row row, int index, String value) {
    Workbook wb = row.getSheet().getWorkbook();

    Font titleFont = wb.createFont();
    titleFont.setBold(true);

    CellStyle style = wb.createCellStyle();
    style.setAlignment(HorizontalAlignment.CENTER);
    style.setVerticalAlignment(VerticalAlignment.CENTER);
    style.setFont(titleFont);

    Cell cell = row.createCell(index);
    cell.setCellStyle(style);
    cell.setCellValue(value);
  }

  private static void createCell(Row row, int index, String value) {
    Cell cell = row.createCell(index);
    cell.setCellValue(value);
  }

  private static void createNumericCell(Row row, int index, DecimalFormatterType type, CellStyle style, BigDecimal value) {
    Optional.of(type)
      .filter(DecimalFormatterType::isNumeric)
      .ifPresentOrElse(given -> createNumericCell(row, index, getValueOrEmptyDouble(value), style),
        () -> createCell(row, index, Optional.ofNullable(value)
          .map(v -> type.getDecimalFormat().format(v))
          .orElse("")));
  }

  private static void createNumericCell(Row row, int index, Double value, CellStyle style) {
    Cell cell = row.createCell(index);
    cell.setCellStyle(style);
    Optional.ofNullable(value)
      .ifPresent(cell::setCellValue);
  }

  private static void createDateCell(Row row, int index, LocalDate value, CellStyle style) {
    Cell cell = row.createCell(index);
    cell.setCellStyle(style);
    Optional.ofNullable(value)
      .ifPresent(cell::setCellValue);
  }

  private static Double getValueOrEmptyDouble(BigDecimal value) {
    return Optional.ofNullable(value)
      .map(BigDecimal::doubleValue)
      .orElse(null);
  }

  private static String getValueOrEmptyString(String value) {
    return Optional.ofNullable(value)
      .map(given -> given.replaceAll("[\r\n]", EMPTY_STRING))
      .orElse(EMPTY_STRING);
  }

  private static String getValueOrEmptyString(LocalDate value) {
    return Optional.ofNullable(value)
      .map(date -> date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
      .orElse(EMPTY_STRING);
  }

  private static String getValueOrEmptyString(LocalTime value) {
    return Optional.ofNullable(value)
      .map(date -> date.format(DateTimeFormatter.ofPattern("HH:mm")))
      .orElse(EMPTY_STRING);
  }
}
