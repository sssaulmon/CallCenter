package com.santander.scib.gtb.ic.gcm.contract.service;

import java.net.URL;
import java.util.Map;

public interface IntradiaStorageClientService {

  URL getZip(Map<String, String> metakeys, String fileName);
}
