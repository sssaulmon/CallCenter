package com.santander.scib.gtb.ic.gcm.mapper;

import com.isban.gcb.ic.commons.balance.cache.dto.ExtractDto;
import com.isban.gcb.ic.commons.model.BalanceCache;
import com.isban.gcb.ic.commons.model.Extract;
import com.isban.gcb.ic.commons.model.ForwardBalance;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.ForwardAmountDTO;
import com.santander.scib.gtb.ic.gcm.model.OriginType;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class AccountBalanceMapper {

  public AccountBalanceDTO accountBalanceToBalanceCache(BalanceCache balanceCache, AccountDTO accountDTO) {
    return new AccountBalanceDTO()
      .balanceType(Optional.of(balanceCache.getBalanceType())
        .filter(type -> balanceCache.hasBestTransactions())
        .map(type -> OriginType.FIND.getOrigin())
        .orElse(balanceCache.getBalanceType()))
      .bic(balanceCache.getBic())
      .openingAmount(calculateSign(balanceCache.getOpeningAmount(), balanceCache.getOpeningMark()))
      .availableAmount(calculateSign(balanceCache.getAvailableAmount(), balanceCache.getAvailableMark()))
      .closingAmount(calculateSign(balanceCache.getClosingAmount(), balanceCache.getClosingMark()))
      .accountingDate(Optional.ofNullable(balanceCache.getAccountingDate())
        .map(LocalDateTime::toLocalDate)
        .orElse(null))
      .accountingTime(Optional.ofNullable(balanceCache.getAccountingDate())
        .map(LocalDateTime::toLocalTime)
        .orElse(null))
      .accountId(accountDTO.getAccountId())
      .alias(accountDTO.getAlias())
      .currency(balanceCache.getCurrency())
      .hasBestTransactions(balanceCache.hasBestTransactions())
      .hasTransactions(balanceCache.hasTransactions())
      .information(balanceCache.getInformation())
      .forwardAmounts(Optional.ofNullable(balanceCache.getExtract())
        .map(Extract::getForwardBalanceList)
        .map(this::mapForwardAmounts)
        .orElse(null))
      .uuid(balanceCache.getAccountCode())
      .status(balanceCache.getStatus());
  }

  private List<ForwardAmountDTO> mapForwardAmounts(List<ForwardBalance> forwardBalances) {
    return forwardBalances.stream()
      .map(this::mapToForwardAmount)
      .collect(Collectors.toList());
  }

  private ForwardAmountDTO mapToForwardAmount(ForwardBalance forwardBalance) {
    return new ForwardAmountDTO()
      .amount(calculateSign(BigDecimal.valueOf(forwardBalance.getAmount()), forwardBalance.getMark()))
      .date(forwardBalance.getDate());
  }

  private BigDecimal calculateSign(BigDecimal amount, String mark) {
    List<String> debit = Arrays.asList("D", "ED", "RC");
    return Optional.ofNullable(amount)
      .map(a -> Optional.of(a)
        .filter(b -> debit.contains(mark))
        .map(BigDecimal::negate)
        .orElse(amount))
      .orElse(null);
  }

  public ExtractDto mapToExtractDto(AccountBalanceDTO account) {
    LocalDateTime localDateTime = LocalDateTime.of(Optional.ofNullable(account.getAccountingDate())
        .orElseGet(LocalDate::now),
      Optional.ofNullable(account.getAccountingTime())
        .orElseGet(() -> LocalDate.now().atStartOfDay().toLocalTime()));

    return ExtractDto.builder()
      .accountingDate(localDateTime)
      .availableBalanceAmount(Optional.ofNullable(account.getAvailableAmount())
        .map(BigDecimal::abs)
        .map(BigDecimal::doubleValue)
        .orElse(null))
      .availableBalanceDate(localDateTime)
      .availableBalanceMark(Optional.ofNullable(account.getAvailableAmount())
        .map(this::calculateBalanceMark)
        .orElse(null))
      .balanceType(account.getBalanceType())
      .bic(account.getBic())
      .closingBalanceAmount(Optional.ofNullable(account.getClosingAmount())
        .map(BigDecimal::doubleValue)
        .orElse(null))
      .closingBalanceDate(localDateTime)
      .closingBalanceMark(Optional.ofNullable(account.getClosingAmount())
        .map(BigDecimal::abs)
        .map(this::calculateBalanceMark)
        .orElse(null))
      .currency(account.getCurrency())
      .accountAlias(Optional.ofNullable(account.getAccountId()).orElse(account.getAlias()))
      .openingBalanceAmount(Optional.ofNullable(account.getOpeningAmount())
        .map(BigDecimal::abs)
        .map(BigDecimal::doubleValue)
        .orElse(null))
      .openingBalanceMark(Optional.ofNullable(account.getOpeningAmount())
        .map(this::calculateBalanceMark)
        .orElse(null))
      .openingBalanceDate(localDateTime)
      .valid(true)
      .status(account.getStatus())
      .build();
  }

  private String calculateBalanceMark(BigDecimal amount) {
    return Optional.of(amount)
      .filter(qty -> qty.signum() > 0)
      .map(qty -> "C")
      .orElse("D");
  }

  public AccountBalanceDTO buildAccountBalanceEmpty(AccountDTO account, String information) {
    return new AccountBalanceDTO()
      .information(information)
      .accountId(account.getAccountId())
      .alias(account.getAlias())
      .bic(account.getBic())
      .currency(account.getCurrency());
  }
}
