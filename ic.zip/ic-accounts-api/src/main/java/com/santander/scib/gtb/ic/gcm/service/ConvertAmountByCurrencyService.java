package com.santander.scib.gtb.ic.gcm.service;

import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.api.MappedTransaction;

public interface ConvertAmountByCurrencyService {

  AccountBalanceDTO convertAccountBalance(AccountBalanceDTO accountBalanceDTO);

  MappedTransaction convertAccountTransactions(String bic, MappedTransaction transactions);
}
