package com.santander.scib.gtb.ic.gcm.model.app.entity;

import com.santander.scib.gtb.ic.gcm.util.SecurityUtil;

import java.util.List;

public class JWTDetail {
  private String jwtEndpoint;
  private String clientId;
  private String clientSecret;
  private List<String> audience;

  public String getJwtEndpoint() {
    return jwtEndpoint;
  }

  public void setJwtEndpoint(String jwtEndpoint) {
    this.jwtEndpoint = jwtEndpoint;
  }

  public String getClientId() {
    return clientId;
  }

  public void setClientId(String clientId) {
    this.clientId = clientId;
  }

  public String getClientSecret() {
    return clientSecret;
  }

  public void setClientSecret(String clientSecret) {
    this.clientSecret = clientSecret;
  }

  public List<String> getAudience() {
    return SecurityUtil.unmodify(audience);
  }

  public void setAudience(List<String> audience) {
    this.audience = SecurityUtil.unmodify(audience);
  }

  public AudienceModel getAudienceModel() {
    return new AudienceModel(audience);
  }
}