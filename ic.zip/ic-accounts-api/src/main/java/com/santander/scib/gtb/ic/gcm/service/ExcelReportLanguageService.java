package com.santander.scib.gtb.ic.gcm.service;

import java.util.List;


/**
 * The interface Excel report language service.
 */
public interface ExcelReportLanguageService {

  /**
   * List excel headers list.
   *
   * @param language the language
   * @param type     the type
   * @return the list
   */
  List<String> listHeadersByLanguageOrDefault(String language, String type);

  /**
   * List excel headers list.
   *
   * @param language the language
   * @param type     the type
   * @return the list
   */
  List<String> listHeadersByLanguage(String language, String type);
}
