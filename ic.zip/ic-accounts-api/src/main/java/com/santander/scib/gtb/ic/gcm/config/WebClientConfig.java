package com.santander.scib.gtb.ic.gcm.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.tcp.ProxyProvider;

@Slf4j
@Configuration
public class WebClientConfig {

  @Value("${app.proxy.host}") private String proxyHost;
  @Value("${app.proxy.port}") private Integer proxyPort;
  @Value("${app.proxy.user}") private String user;
  @Value("${app.proxy.password}") private String password;

  @Bean(name = "proxyWebClient")
  public WebClient proxyWebClient() {
    return WebClient.builder()
      .clientConnector(buildConnector())
      .filter(logRequest())
      .build();
  }

  @Bean(name = "webClient")
  public WebClient webClient() {
    return WebClient.builder()
      .filter(logRequest())
      .build();
  }

  private ExchangeFilterFunction logRequest() {
    return (clientRequest, next) -> {
      log.info("Request: {} {}", clientRequest.method(), clientRequest.url());
      return next.exchange(clientRequest);
    };
  }

  private ClientHttpConnector buildConnector() {

    HttpClient httpClient = HttpClient.create()
      .tcpConfiguration(tcpClient -> tcpClient
        .proxy(proxy -> proxy
          .type(ProxyProvider.Proxy.HTTP)
          .host(proxyHost)
          .port(proxyPort)
          .username(user)
          .password(pass -> password)));

    return new ReactorClientHttpConnector(httpClient);
  }
}
