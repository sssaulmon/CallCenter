package com.santander.scib.gtb.ic.gcm.api.balance.model.global.transactions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.gtb.ic.gcm.api.balance.model.TransactionDetails;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.balance.GenericBalance;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions.Amount;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GlobalTransactionDetails extends TransactionDetails {

  @ApiModelProperty(example = "\"277746342\"", required = true, value = "Identify a specific transaction of the account_id.")
  @NotNull
  @JsonProperty("transactionId")
  private String transactionId;

  @ApiModelProperty(example = "\"20190314T014319060+0100\"", value = "Date of creation. ISO 8601. https://en.wikipedia.org/wiki/ISO_8601")
  @JsonProperty("creationDate")
  private String creationDate;

  @ApiModelProperty(example = "\"20190314T014319060+0100\"", value = "Date of processing. ISO 8601. https://en.wikipedia.org/wiki/ISO_8601")
  @JsonProperty("processedDate")
  private String processedDate;

  @ApiModelProperty(example = "\"20190314T014319060+0100\"", value = "Date of accounting. ISO 8601. https://en.wikipedia.org/wiki/ISO_8601")
  @JsonProperty("accountingDate")
  private String accountingDate;

  @ApiModelProperty(example = "\"20190314T014319060+0100\"", value = "Date of accounting. ISO 8601. https://en.wikipedia.org/wiki/ISO_8601")
  @JsonProperty("description")
  private String description;

  @ApiModelProperty(example = "\"C\"", value = "Identificate if an specific transaction is a debit \"D\" or credit \"C\"")
  @JsonProperty("transactionType")
  private String transactionType;

  @ApiModelProperty(example = "\"withdraw money\"", value = "Type of category for a transaction.")
  @JsonProperty("transactionCategory")
  private String transactionCategory;

  @ApiModelProperty(value = "Amount and currency of the transaction.")
  @JsonProperty("amount")
  private Amount amount;

  @ApiModelProperty(value = "Balance result of the account after the transaction.")
  @JsonProperty("balanceResult")
  private GenericBalance balanceResult;

  @ApiModelProperty(value = "Operation details.")
  @JsonProperty("operation")
  private Operation operation;

  @ApiModelProperty(value = "References details.")
  @JsonProperty("references")
  private Reference references;

  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  public void setCreationDate(String creationDate) {
    this.creationDate = creationDate;
  }

  public void setProcessedDate(String processedDate) {
    this.processedDate = processedDate;
  }

  public void setAccountingDate(String accountingDate) {
    this.accountingDate = accountingDate;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType;
  }

  public void setTransactionCategory(String transactionCategory) {
    this.transactionCategory = transactionCategory;
  }

  public void setAmount(Amount amount) {
    this.amount = amount;
  }

  public void setBalanceResult(GenericBalance balanceResult) {
    this.balanceResult = balanceResult;
  }

  public void setOperation(Operation operation) {
    this.operation = operation;
  }

  public void setReferences(Reference references) {
    this.references = references;
  }

  public String getCreationDate() {
    return creationDate;
  }

  public String getProcessedDate() {
    return processedDate;
  }

  public String getAccountingDate() {
    return accountingDate;
  }

  public String getDescription() {
    return description;
  }

  public Amount getAmount() {
    return amount;
  }

  public GenericBalance getBalanceResult() {
    return balanceResult;
  }

  public Operation getOperation() {
    return operation;
  }

  public Reference getReferences() {
    return references;
  }
}
