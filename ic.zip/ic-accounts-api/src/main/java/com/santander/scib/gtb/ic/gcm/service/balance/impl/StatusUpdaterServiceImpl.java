package com.santander.scib.gtb.ic.gcm.service.balance.impl;

import com.santander.scib.gtb.ic.gcm.repository.GlobalReportRepository;
import com.santander.scib.gtb.ic.gcm.service.balance.StatusUpdaterService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@Slf4j
public class StatusUpdaterServiceImpl implements StatusUpdaterService {

  private static final String SERVICE_CHANNEL_API = "API";
  private static final String STATUS_SENT = "Enviado OK";

  private GlobalReportRepository globalReportRepository;

  public StatusUpdaterServiceImpl(GlobalReportRepository globalReportRepository) {
    this.globalReportRepository = globalReportRepository;
  }

  @Override
  public void process(LocalDateTime processorDate) {
    //The processor date should be update with minus 1 day
    LocalDateTime toDate = processorDate.minusDays(1);
    log.info("Trying to update the status from the global_report table for the date {}",  toDate);
    globalReportRepository.findByServiceSendChannelAndLastModifiedDateLessThanAndStatusIsNot(SERVICE_CHANNEL_API, toDate, STATUS_SENT).stream()
      .map(given -> given.setStatus(STATUS_SENT))
      .map(globalReportRepository::save)
      .forEach(given -> log.debug("Global report that was updated: {}", given));
  }
}
