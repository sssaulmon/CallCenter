package com.santander.scib.gtb.ic.gcm.api.balance.model.global.transactions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.api.MappedTransaction;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions.TransactionsListLinks;
import com.santander.scib.gtb.ic.gcm.model.Transaction;
import com.santander.scib.gtb.ic.gcm.util.DateTimeFormatterUtil;
import com.santander.scib.gtb.ic.gcm.util.SecurityUtil;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.isban.gcb.ic.commons.balance.cache.dto.BalanceType.ONLINE;
import static com.santander.scib.gtb.ic.gcm.util.LinkReaderUtil.getOffset;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GlobalTransactionResponse implements Transaction {

  @ApiModelProperty(value = "Number account identification to be displayed.")
  @JsonProperty("displayNumber")
  private String displayNumber;

  @ApiModelProperty(value = "Number Account Identification. Format: BBAN:  is the English acronym for Basic " +
    "Bank Account code. Represents a country-specific bank account number. Each country has its format and length " +
    "of BBAN depending on its own standards. Currently there is no common standard that unifies the format of BBAN " +
    "in the EU or other entities. This is why the IBAN appeared to help standardize international bank transfers." +
    " Maximum long  31 char of all 35 bytes of the field. For example: In UK Sortcode(6) + Account(8); " +
    "In ES Banco(4)+ Sucursal(4) + CD(2) + CTA(10).")
  @JsonProperty("accountId")
  private String accountId;

  @ApiModelProperty(value = "Name asigned to the account by the client to identify it easily.")
  @JsonProperty("alias")
  private String alias;

  @ApiModelProperty(value = "List of transactions.")
  @JsonProperty("transactionsDataList")
  private List<GlobalTransactionsDataListItem> transactionsDataList;

  @ApiModelProperty(value = "Links to account details and transactions list pagination.")
  @JsonProperty("_links")
  private TransactionsListLinks links;

  public String getDisplayNumber() {
    return displayNumber;
  }

  public void setDisplayNumber(String displayNumber) {
    this.displayNumber = displayNumber;
  }

  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public String getAlias() {
    return alias;
  }

  public void setAlias(String alias) {
    this.alias = alias;
  }

  public List<GlobalTransactionsDataListItem> getTransactionsDataList() {
    return SecurityUtil.unmodify(transactionsDataList);
  }

  public void setTransactionsDataList(List<GlobalTransactionsDataListItem> transactionsDataList) {
    this.transactionsDataList = SecurityUtil.unmodify(transactionsDataList);
  }

  public TransactionsListLinks getLinks() {
    return links;
  }

  public void setLinks(TransactionsListLinks links) {
    this.links = links;
  }

  @Override
  public MappedTransaction mapToAccountTransactionListDTO() {
    return Optional.ofNullable(links)
      .map(this::getMappedTransactionWithLinks)
      .orElseGet(this::getMappedTransactionWithoutLinks);
  }

  private MappedTransaction getMappedTransactionWithLinks(TransactionsListLinks links) {
    String next = links.getNext();
    return MappedTransaction.builder()
      .accountTransactions(getTransactionsCollect())
      .next(getOffset(next))
      .previous(getOffset(links.getPrev()))
      .build();
  }

  private List<AccountTransactionDTO> getTransactionsCollect() {
    return this.getTransactionsDataList().stream()
      .map(this::buildAccountTransactionDTO)
      .collect(Collectors.toList());
  }

  private MappedTransaction getMappedTransactionWithoutLinks() {
    return MappedTransaction.builder()
      .accountTransactions(getTransactionsCollect())
      .build();
  }

  private AccountTransactionDTO buildAccountTransactionDTO(GlobalTransactionsDataListItem transactionsDataListItem) {
    GlobalTransactionDetails transactionDetails = transactionsDataListItem.getTransactionDetails();

    return new AccountTransactionDTO()
      .additionalInfo(Optional.ofNullable(transactionDetails.getOperation())
        .map(Operation::getLocalOperation)
        .map(GlobalLocalOperation::getAdditionalInformation)
        .orElse(null))
      .amount(transactionDetails.getAmount().getAmount())
      .currency(transactionDetails.getAmount().getCurrencyCode())
      .description(transactionDetails.getDescription())
      .accountingDate(DateTimeFormatterUtil.transformToLocalDate(transactionDetails.getAccountingDate()))
      .origin(ONLINE.toString())
      .valueDate(DateTimeFormatterUtil.transformToLocalDate(transactionDetails.getAccountingDate()))
      .movementTime(DateTimeFormatterUtil.transformToLocalTime(transactionDetails.getProcessedDate()))
      .entryDate(DateTimeFormatterUtil.transformToLocalDate(transactionDetails.getCreationDate()))
      .balance(transactionDetails.getBalanceResult().getAmount())
      .identificationCode(Optional.ofNullable(transactionDetails.getOperation())
        .map(Operation::getSwiftCode)
        .orElse(null))
      .accountOwner(Optional.ofNullable(transactionDetails.getReferences())
        .map(Reference::getTransactionClientReference)
        .orElse(null))
      .accountServiceInstitution(Optional.ofNullable(transactionDetails.getReferences())
        .map(Reference::getTransactionInternalReference)
        .orElse(null));
  }
}
