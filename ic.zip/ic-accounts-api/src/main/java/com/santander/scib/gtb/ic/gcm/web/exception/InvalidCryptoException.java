package com.santander.scib.gtb.ic.gcm.web.exception;

public class InvalidCryptoException extends RuntimeException {
  public InvalidCryptoException(Throwable cause) {
    super(cause);
  }
}
