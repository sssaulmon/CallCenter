package com.santander.scib.gtb.ic.gcm.mapper;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.AccountTransactionResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.api.MappedTransaction;
import com.santander.scib.gtb.ic.gcm.util.LinkBuilderUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import static com.isban.gcb.ic.commons.balance.cache.dto.BalanceType.ONLINE;
import static java.util.function.Predicate.not;

@Slf4j
@Component
public class ApiCommunicationMapper {

  @Autowired private LinkBuilderUtil linkBuilderUtil;

  public AccountTransactionResponse toTransactionResponse(MappedTransaction transactions, TransactionDTO request) {
    log.debug("Mapping the DB and API responses");
    request.setNextOffsetFromApi(transactions.getNext());
    request.setPrevOffsetFromApi(transactions.getPrevious());
    request.setLastOffsetFromApi(transactions.getLast());
    return AccountTransactionResponse.builder()
      .accountTransactionDTO(transactions.getAccountTransactions())
      .links(linkBuilderUtil.build(request, getResponseSize(transactions.getAccountTransactions(), not(ONLINE.toString()::equals)), getResponseSize(transactions.getAccountTransactions(), ONLINE.toString()::equals)))
      .build();
  }

  private Integer getResponseSize(List<AccountTransactionDTO> transactions, Predicate<String> checkOrigin) {
    return Optional.of(countTransactions(transactions, checkOrigin))
      .map(Long::intValue)
      .filter(count -> count > 0)
      .orElse(null);
  }

  private long countTransactions(List<AccountTransactionDTO> transactions, Predicate<String> checkOrigin) {
    return transactions.stream()
      .map(AccountTransactionDTO::getOrigin)
      .filter(checkOrigin)
      .count();
  }
}
