package com.santander.scib.gtb.ic.gcm.model;

import java.util.stream.Stream;

public enum OriginType {
  INTR("INTR", "Intraday"),
  FIND("FIND", "EoD"),
  ONLI("ONLI", "On Line");

  OriginType(String origin, String description) {
    this.origin = origin;
    this.description = description;
  }

  private final String origin;
  private final String description;

  public String getOrigin() {
    return origin;
  }

  public String getDescription() {
    return description;
  }

  public static String getDescription(String origin) {
    return Stream.of(values())
      .filter(v -> v.getOrigin().equals(origin))
      .map(OriginType::getDescription)
      .findFirst()
      .orElseThrow(RuntimeException::new);
  }
}
