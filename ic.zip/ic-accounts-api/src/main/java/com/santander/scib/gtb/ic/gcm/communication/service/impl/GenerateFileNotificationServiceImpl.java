package com.santander.scib.gtb.ic.gcm.communication.service.impl;

import com.santander.scib.gtb.ic.gcm.communication.binding.GenerateFileOutputBinding;
import com.santander.scib.gtb.ic.gcm.communication.model.SaveFile;
import com.santander.scib.gtb.ic.gcm.communication.service.GenerateFileNotificationService;
import com.santander.scib.gtb.ic.gcm.model.GenerateFileRequestDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * The type Generate file notification service.
 */
@Slf4j
@Service
public class GenerateFileNotificationServiceImpl implements GenerateFileNotificationService {

  private GenerateFileOutputBinding binding;

  /**
   * Instantiates a new Generate file notification service.
   *
   * @param binding the binding
   */
  public GenerateFileNotificationServiceImpl(GenerateFileOutputBinding binding) {
    this.binding = binding;
  }

  @Override
  public void sendNotification(GenerateFileRequestDTO notification) {
    Optional.of(notification)
      .map(MessageBuilder::withPayload)
      .map(MessageBuilder::build)
      .ifPresent(binding.generateFileResponse()::send);
  }

  @Override
  public void saveGenerateFile(SaveFile saveFile) {
    Optional.of(saveFile)
      .map(MessageBuilder::withPayload)
      .map(MessageBuilder::build)
      .ifPresent(binding.saveFileRequest()::send);
  }
}
