package com.santander.scib.gtb.ic.gcm.service.impl;

import com.santander.scib.gtb.ic.gcm.repository.ExcelReportLanguageRepository;
import com.santander.scib.gtb.ic.gcm.service.ExcelReportLanguageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static java.util.function.Predicate.not;

@Service
public class ExcelReportLanguageServiceImpl implements ExcelReportLanguageService {

  private static final String DEFAULT_LANGUAGE = "en";
  @Autowired private ExcelReportLanguageRepository repository;

  @Override
  public List<String> listHeadersByLanguageOrDefault(String language, String type) {
    return Optional.ofNullable(language)
      .map(lang -> listHeadersByLanguage(lang, type))
      .filter(not(List::isEmpty))
      .orElseGet(() -> listHeadersByLanguage(DEFAULT_LANGUAGE, type));
  }

  @Override
  @Cacheable(value = "headers", unless = "#result==null or #result.isEmpty()", cacheManager = "cacheHeadersManager")
  public List<String> listHeadersByLanguage(String language, String type) {
    return repository.listHeaders(language, type);
  }
}
