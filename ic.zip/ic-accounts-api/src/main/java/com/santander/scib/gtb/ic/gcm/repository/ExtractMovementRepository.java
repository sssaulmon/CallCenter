package com.santander.scib.gtb.ic.gcm.repository;

import com.isban.gcb.ic.commons.model.ExtractMovement;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ExtractMovementRepository extends JpaRepository<ExtractMovement, Long> {

  @Query(value = "SELECT bc.accounting_date, mo.*" +
    " FROM \"APLONPRE_PRO\".\"MOVEMENT\" mo" +
    " JOIN \"APLONPRE_PRO\".\"EXTRACT\" ex ON ex.id = mo.extract_id" +
    " JOIN \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc ON bc.extract_id = ex.id" +
    " WHERE bc.bic = (?1)" +
    "   AND bc.account_code = (?2)" +
    "   AND bc.currency = (?3)" +
    "   AND bc.accounting_date >= (?4)" +
    "   AND bc.accounting_date <= (?5)" +
    "   AND bc.balance_type = 'INTR'" +
    "   AND TRUNC(bc.accounting_date) > " +
    "         NVL((SELECT MAX(TRUNC(bc2.accounting_date)) FROM \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc2" +
    "         WHERE bc2.bic = (?1)" +
    "           AND bc2.account_code = (?2)" +
    "           AND bc2.currency = (?3)" +
    "           AND bc2.accounting_date >= (?4)" +
    "           AND bc2.accounting_date <= (?5)" +
    "           AND bc2.balance_type = 'FIND'), (?6))" +
    " UNION " +
    " SELECT bc.accounting_date, mo.*" +
    " FROM \"APLONPRE_PRO\".\"MOVEMENT\" mo" +
    " JOIN \"APLONPRE_PRO\".\"EXTRACT\" ex ON ex.id = mo.extract_id" +
    " JOIN \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc ON bc.extract_id = ex.id" +
    " WHERE bc.bic = (?1)" +
    "   AND bc.account_code = (?2)" +
    "   AND bc.currency = (?3)" +
    "   AND bc.accounting_date >= (?4)" +
    "   AND bc.accounting_date <= (?5)" +
    "   AND bc.balance_type = 'FIND'" +
    " ORDER BY 1 DESC, 2 DESC", nativeQuery = true)
  List<ExtractMovement> findMovementsSortedByValueDate(String bic, String account, String currency,
                                                       LocalDateTime fromDate, LocalDateTime toDate,
                                                       LocalDateTime fromDateMinusOneDay, Pageable pageable);

  @Query(value = "SELECT bc.accounting_date, mo.*" +
    " FROM \"APLONPRE_PRO\".\"MOVEMENT\" mo" +
    " JOIN \"APLONPRE_PRO\".\"EXTRACT\" ex ON ex.id = mo.extract_id" +
    " JOIN \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc ON bc.extract_id = ex.id" +
    " WHERE bc.bic = (?1)" +
    "   AND bc.account_code = (?2)" +
    "   AND bc.currency = (?3)" +
    "   AND bc.accounting_date >= (?4)" +
    "   AND bc.balance_type = 'INTR'" +
    "   AND TRUNC(bc.accounting_date) > " +
    "         NVL((SELECT MAX(TRUNC(bc2.accounting_date)) FROM \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc2" +
    "         WHERE bc2.bic = (?1)" +
    "           AND bc2.account_code = (?2)" +
    "           AND bc2.currency = (?3)" +
    "           AND bc2.accounting_date >= (?4)" +
    "           AND bc2.balance_type = 'FIND'), (?5))" +
    " UNION " +
    " SELECT bc.accounting_date, mo.*" +
    " FROM \"APLONPRE_PRO\".\"MOVEMENT\" mo" +
    " JOIN \"APLONPRE_PRO\".\"EXTRACT\" ex ON ex.id = mo.extract_id" +
    " JOIN \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc ON bc.extract_id = ex.id" +
    " WHERE bc.bic = (?1)" +
    "   AND bc.account_code = (?2)" +
    "   AND bc.currency = (?3)" +
    "   AND bc.accounting_date >= (?4)" +
    "   AND bc.balance_type = 'FIND'" +
    " ORDER BY 1 DESC, 2 DESC", nativeQuery = true)
  List<ExtractMovement> findMovementsSortedByValueDate(String bic, String account, String currency,
                                                       LocalDateTime fromDate, LocalDateTime fromDateMinusOneDay,
                                                       Pageable pageable);

  @Query(value = "SELECT bc.accounting_date, mo.*" +
    " FROM \"APLONPRE_PRO\".\"MOVEMENT\" mo" +
    " JOIN \"APLONPRE_PRO\".\"EXTRACT\" ex ON ex.id = mo.extract_id" +
    " JOIN \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc ON bc.extract_id = ex.id" +
    " WHERE bc.bic = (?1)" +
    "   AND bc.account_code = (?2)" +
    "   AND bc.currency = (?3)" +
    "   AND bc.accounting_date >= (?4)" +
    "   AND bc.accounting_date <= (?5)" +
    "   AND bc.balance_type = 'INTR'" +
    "   AND TRUNC(bc.accounting_date) > " +
    "         NVL((SELECT MAX(TRUNC(bc2.accounting_date)) FROM \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc2" +
    "         WHERE bc2.bic = (?1)" +
    "           AND bc2.account_code = (?2)" +
    "           AND bc2.currency = (?3)" +
    "           AND bc2.accounting_date >= (?4)" +
    "           AND bc2.accounting_date <= (?5)" +
    "           AND bc2.balance_type = 'FIND'), (?6))" +
    " UNION " +
    " SELECT bc.accounting_date, mo.*" +
    " FROM \"APLONPRE_PRO\".\"MOVEMENT\" mo" +
    " JOIN \"APLONPRE_PRO\".\"EXTRACT\" ex ON ex.id = mo.extract_id" +
    " JOIN \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc ON bc.extract_id = ex.id" +
    " WHERE bc.bic = (?1)" +
    "   AND bc.account_code = (?2)" +
    "   AND bc.currency = (?3)" +
    "   AND bc.accounting_date >= (?4)" +
    "   AND bc.accounting_date <= (?5)" +
    "   AND bc.balance_type = 'FIND'" +
    " ORDER BY 1 DESC, 2 DESC" +
    " OFFSET ?7 ROWS FETCH NEXT ?8 ROWS ONLY", nativeQuery = true)
  List<ExtractMovement> findEodMovementsSortedByValueDate(String bic, String account, String currency,
                                                          LocalDateTime fromDate, LocalDateTime toDate,
                                                          LocalDateTime fromDateMinusOneDay, int offset, int limit);

  @Query(value = "SELECT current_timestamp, mo.* " +
    " FROM \"APLONPRE_PRO\".\"MOVEMENT\" mo" +
    " JOIN \"APLONPRE_PRO\".\"EXTRACT\" ex ON ex.id = mo.extract_id" +
    " WHERE mo.extract_id = (?7)" +
    "   AND NVL(ex.date_time_indication, ex.cl_balance_date) >= (?4)" +
    "   AND NVL(ex.date_time_indication, ex.cl_balance_date) <= (?5)" +
    " UNION " +
    "SELECT * FROM (SELECT bc.accounting_date, mo.*" +
    " FROM \"APLONPRE_PRO\".\"MOVEMENT\" mo" +
    " JOIN \"APLONPRE_PRO\".\"EXTRACT\" ex ON ex.id = mo.extract_id" +
    " JOIN \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc ON bc.extract_id = ex.id" +
    " WHERE bc.bic = (?1)" +
    "   AND bc.account_code = (?2)" +
    "   AND bc.currency = (?3)" +
    "   AND bc.accounting_date >= (?4)" +
    "   AND bc.accounting_date <= (?5)" +
    "   AND bc.balance_type = 'INTR'" +
    "   AND bc.extract_id <> (?7)" +
    "   AND TRUNC(bc.accounting_date) > " +
    "         NVL((SELECT MAX(TRUNC(bc2.accounting_date)) FROM \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc2" +
    "         WHERE bc2.bic = (?1)" +
    "           AND bc2.account_code = (?2)" +
    "           AND bc2.currency = (?3)" +
    "           AND bc2.accounting_date >= (?4)" +
    "           AND bc2.accounting_date <= (?5)" +
    "           AND bc2.balance_type = 'FIND'), (?6))" +
    " UNION " +
    " SELECT bc.accounting_date, mo.*" +
    " FROM \"APLONPRE_PRO\".\"MOVEMENT\" mo" +
    " JOIN \"APLONPRE_PRO\".\"EXTRACT\" ex ON ex.id = mo.extract_id" +
    " JOIN \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc ON bc.extract_id = ex.id" +
    " WHERE bc.bic = (?1)" +
    "   AND bc.account_code = (?2)" +
    "   AND bc.currency = (?3)" +
    "   AND bc.accounting_date >= (?4)" +
    "   AND bc.accounting_date <= (?5)" +
    "   AND bc.extract_id <> (?7)" +
    "   AND bc.balance_type = 'FIND')" +
    " ORDER BY 1 DESC, 2 DESC" +
    " OFFSET ?8 ROWS FETCH NEXT ?9 ROWS ONLY", nativeQuery = true)
  List<ExtractMovement> findMovementsSortedByValueDate(String bic, String account, String currency,
                                                       LocalDateTime fromDate, LocalDateTime toDate,
                                                       LocalDateTime fromDateMinusOneDay, long extractId,
                                                       int offset, int limit);

  @Query(value = "SELECT current_timestamp, mo.*" +
    " FROM \"APLONPRE_PRO\".\"MOVEMENT\" mo" +
    " JOIN \"APLONPRE_PRO\".\"EXTRACT\" ex ON ex.id = mo.extract_id" +
    " WHERE mo.extract_id = (?6)" +
    "   AND NVL(ex.date_time_indication, ex.cl_balance_date) >= (?4)" +
    " UNION " +
    "SELECT * FROM (SELECT bc.accounting_date, mo.*" +
    " FROM \"APLONPRE_PRO\".\"MOVEMENT\" mo" +
    " JOIN \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc ON bc.extract_id = mo.extract_id" +
    " WHERE bc.bic = (?1)" +
    "   AND bc.account_code = (?2)" +
    "   AND bc.currency = (?3)" +
    "   AND bc.accounting_date >= (?4)" +
    "   AND bc.balance_type = 'INTR'" +
    "   AND bc.extract_id <> (?6)" +
    "   AND TRUNC(bc.accounting_date) > " +
    "         NVL((SELECT MAX(TRUNC(bc2.accounting_date)) FROM \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc2" +
    "         WHERE bc2.bic = (?1)" +
    "           AND bc2.account_code = (?2)" +
    "           AND bc2.currency = (?3)" +
    "           AND bc2.accounting_date >= (?4)" +
    "           AND bc2.balance_type = 'FIND'), (?5))" +
    " UNION " +
    " SELECT bc.accounting_date, mo.*" +
    " FROM \"APLONPRE_PRO\".\"MOVEMENT\" mo" +
    " JOIN \"APLONPRE_PRO\".\"BALANCE_CACHE\" bc ON bc.extract_id = mo.extract_id" +
    " WHERE bc.bic = (?1)" +
    "   AND bc.account_code = (?2)" +
    "   AND bc.currency = (?3)" +
    "   AND bc.accounting_date >= (?4)" +
    "   AND bc.extract_id <> (?6)" +
    "   AND bc.balance_type = 'FIND')" +
    " ORDER BY 1 DESC, 2 DESC" +
    " OFFSET ?7 ROWS FETCH NEXT ?8 ROWS ONLY", nativeQuery = true)
  List<ExtractMovement> findMovementsSortedByValueDate(String bic, String account, String currency,
                                                       LocalDateTime fromDate, LocalDateTime fromDateMinusOneDay,
                                                       long extractId, int offset, int limit);
}
