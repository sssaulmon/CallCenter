package com.santander.scib.gtb.ic.gcm.api.balance.model.slb.balance;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.model.AccountBalance;
import com.santander.scib.gtb.ic.gcm.util.SecurityUtil;
import io.swagger.annotations.ApiModel;

import java.util.List;
import java.util.Optional;

import static com.isban.gcb.ic.commons.balance.cache.dto.BalanceType.ONLINE;

@ApiModel(description = "Information on the account balances")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SLBAccountBalanceResponse implements AccountBalance {

  @JsonProperty("displayNumber")
  private String displayNumber;

  @JsonProperty("bic")
  private String bic;

  @JsonProperty("accountId")
  private String accountId;

  @JsonProperty("accountIdType")
  private String accountIdType;

  @JsonProperty("alias")
  private String alias;

  @JsonProperty("mainItem")
  private String mainItem;

  @JsonProperty("type")
  private String type;

  @JsonProperty("description")
  private String description;

  @JsonProperty("status")
  private String status;

  @JsonProperty("customerId")
  private String customerId;

  @JsonProperty("lastTransactionDate")
  private String lastTransactionDate;

  @JsonProperty("costCenter")
  private String costCenter;

  @JsonProperty("mainBalance")
  private GenericBalance mainBalance;

  @JsonProperty("availableBalance")
  private GenericBalance availableBalance;

  @JsonProperty("pendingBalance")
  private GenericBalance pendingBalance;

  @JsonProperty("withholdingBalance")
  private GenericBalance withholdingBalance;

  @JsonProperty("overdraftLimit")
  private GenericBalance overdraftLimit;

  @JsonProperty("overdraftUsed")
  private GenericBalance overdraftUsed;

  @JsonProperty("lastTransactions")
  private List<Movement> lastTransactions;

  @JsonProperty("transactionsListLink")
  private String transactionsListLink;

  @JsonProperty("availableWithoutAuthorized")
  private GenericBalance availableWithoutAuthorized;

  public String getDisplayNumber() {
    return displayNumber;
  }

  public void setDisplayNumber(String displayNumber) {
    this.displayNumber = displayNumber;
  }

  public String getBic() {
    return bic;
  }

  public void setBic(String bic) {
    this.bic = bic;
  }

  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public String getAccountIdType() {
    return accountIdType;
  }

  public void setAccountIdType(String accountIdType) {
    this.accountIdType = accountIdType;
  }

  public String getAlias() {
    return alias;
  }

  public void setAlias(String alias) {
    this.alias = alias;
  }

  public String getMainItem() {
    return mainItem;
  }

  public void setMainItem(String mainItem) {
    this.mainItem = mainItem;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getCustomerId() {
    return customerId;
  }

  public void setCustomerId(String customerId) {
    this.customerId = customerId;
  }

  public String getLastTransactionDate() {
    return lastTransactionDate;
  }

  public void setLastTransactionDate(String lastTransactionDate) {
    this.lastTransactionDate = lastTransactionDate;
  }

  public String getCostCenter() {
    return costCenter;
  }

  public void setCostCenter(String costCenter) {
    this.costCenter = costCenter;
  }

  public GenericBalance getMainBalance() {
    return mainBalance;
  }

  public void setMainBalance(GenericBalance mainBalance) {
    this.mainBalance = mainBalance;
  }

  public GenericBalance getAvailableBalance() {
    return availableBalance;
  }

  public void setAvailableBalance(GenericBalance availableBalance) {
    this.availableBalance = availableBalance;
  }

  public GenericBalance getPendingBalance() {
    return pendingBalance;
  }

  public void setPendingBalance(GenericBalance pendingBalance) {
    this.pendingBalance = pendingBalance;
  }

  public GenericBalance getWithholdingBalance() {
    return withholdingBalance;
  }

  public void setWithholdingBalance(GenericBalance withholdingBalance) {
    this.withholdingBalance = withholdingBalance;
  }

  public GenericBalance getOverdraftLimit() {
    return overdraftLimit;
  }

  public void setOverdraftLimit(GenericBalance overdraftLimit) {
    this.overdraftLimit = overdraftLimit;
  }

  public GenericBalance getOverdraftUsed() {
    return overdraftUsed;
  }

  public void setOverdraftUsed(GenericBalance overdraftUsed) {
    this.overdraftUsed = overdraftUsed;
  }

  public List<Movement> getLastTransactions() {
    return SecurityUtil.unmodify(lastTransactions);
  }

  public void setLastTransactions(List<Movement> lastTransactions) {
    this.lastTransactions = SecurityUtil.unmodify(lastTransactions);
  }

  public String getTransactionsListLink() {
    return transactionsListLink;
  }

  public void setTransactionsListLink(String transactionsListLink) {
    this.transactionsListLink = transactionsListLink;
  }

  public GenericBalance getAvailableWithoutAuthorized() {
    return availableWithoutAuthorized;
  }

  public void setAvailableWithoutAuthorized(GenericBalance availableWithoutAuthorized) {
    this.availableWithoutAuthorized = availableWithoutAuthorized;
  }

  public SLBAccountBalanceResponse bic(String bic) {
    this.bic = bic;
    return this;
  }

  @Override
  public AccountBalanceDTO mapToAccountBalanceDto() {
    Optional<GenericBalance> mainBalance = Optional.ofNullable(getMainBalance());

    return new AccountBalanceDTO()
      .balanceType(ONLINE.toString())
      .closingAmount(mainBalance
        .map(GenericBalance::getAmount)
        .orElse(null))
      .availableAmount(Optional.ofNullable(getAvailableBalance())
        .map(GenericBalance::getAmount)
        .orElse(null))
      .currency(mainBalance
        .map(GenericBalance::getCurrencyCode)
        .orElse(null))
      .status(status);
  }

  @Override
  public String toString() {
    return "SLBAccountBalanceResponse{" +
      "displayNumber='" + displayNumber + '\'' +
      ", bic='" + bic + '\'' +
      ", accountId='" + accountId + '\'' +
      ", accountIdType='" + accountIdType + '\'' +
      ", alias='" + alias + '\'' +
      ", mainItem='" + mainItem + '\'' +
      ", type='" + type + '\'' +
      ", description='" + description + '\'' +
      ", status='" + status + '\'' +
      ", customerId='" + customerId + '\'' +
      ", lastTransactionDate='" + lastTransactionDate + '\'' +
      ", costCenter='" + costCenter + '\'' +
      ", mainBalance=" + mainBalance +
      ", availableBalance=" + availableBalance +
      ", pendingBalance=" + pendingBalance +
      ", withholdingBalance=" + withholdingBalance +
      ", overdraftLimit=" + overdraftLimit +
      ", overdraftUsed=" + overdraftUsed +
      ", lastTransactions=" + lastTransactions +
      ", transactionsListLink='" + transactionsListLink + '\'' +
      '}';
  }
}
