package com.santander.scib.gtb.ic.gcm.config;

import com.santander.scib.gtb.ic.gcm.model.app.entity.EntityModel;
import com.santander.scib.gtb.ic.gcm.model.app.entity.JWTDetail;
import com.santander.scib.gtb.ic.gcm.util.SecurityUtil;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "entities")
public class EntitiesConfiguration {
  private List<EntityModel> entitiesList = new ArrayList<>();
  private Map<String, JWTDetail> jwtDetails;

  public List<EntityModel> getEntitiesList() {
    return SecurityUtil.unmodify(entitiesList);
  }

  public void setEntitiesList(List<EntityModel> entitiesList) {
    this.entitiesList = SecurityUtil.unmodify(entitiesList);
  }

  public Map<String, JWTDetail> getJwtDetails() {
    return jwtDetails;
  }

  public void setJwtDetails(Map<String, JWTDetail> jwtDetails) {
    this.jwtDetails = jwtDetails;
  }
}
