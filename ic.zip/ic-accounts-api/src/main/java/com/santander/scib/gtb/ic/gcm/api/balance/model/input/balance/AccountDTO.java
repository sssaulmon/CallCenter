package com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotBlank;
import java.util.Objects;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

public class AccountDTO {

  @NotBlank
  protected String bic;
  protected String accountId;
  protected String alias;
  private String identifier;
  // TODO evaluar colocar este version para no cambiar las firmas en la orquestación
  private String version;

  @ApiModelProperty(example = "\"USD\"", required = true, value = "ISO Code of Money used in a particular country or countries in which a specific account is denominated")
  @JsonProperty("currency")
  protected String currency;

  @JsonInclude(NON_NULL)
  @JsonIgnore
  private String uuid;

  //For JSON
  public AccountDTO() {
    super();
  }

  public String getBic() {
    return bic;
  }

  public AccountDTO bic(String bic) {
    this.bic = bic;
    return this;
  }

  public String getAccountId() {
    return accountId;
  }

  public AccountDTO accountId(String accountId) {
    this.accountId = accountId;
    return this;
  }

  public String getAlias() {
    return alias;
  }

  public AccountDTO alias(String alias) {
    this.alias = alias;
    return this;
  }

  public String getCurrency() {
    return currency;
  }

  public AccountDTO currency(String currency) {
    this.currency = currency;
    return this;
  }

  public String getIdentifier() {
    return identifier;
  }

  public AccountDTO identifier(String identifier) {
    this.identifier = identifier;
    return this;
  }

  public String getUuid() {
    return uuid;
  }

  public AccountDTO uuid(String uuid) {
    this.uuid = uuid;
    return this;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    AccountDTO that = (AccountDTO) o;

    if (!bic.equals(that.bic)) return false;
    if (!Objects.equals(accountId, that.accountId)) return false;
    if (!Objects.equals(alias, that.alias)) return false;
    if (!currency.equals(that.currency)) return false;
    return Objects.equals(uuid, that.uuid);
  }

  @Override
  public int hashCode() {
    int result = bic.hashCode();
    result = 31 * result + (accountId != null ? accountId.hashCode() : 0);
    result = 31 * result + (alias != null ? alias.hashCode() : 0);
    result = 31 * result + currency.hashCode();
    result = 31 * result + (uuid != null ? uuid.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "AccountDTO{" +
      "bic='" + bic + '\'' +
      ", accountId='" + accountId + '\'' +
      ", alias='" + alias + '\'' +
      ", identifier='" + identifier + '\'' +
      ", currency='" + currency + '\'' +
      ", uuid='" + uuid + '\'' +
      '}';
  }
}
