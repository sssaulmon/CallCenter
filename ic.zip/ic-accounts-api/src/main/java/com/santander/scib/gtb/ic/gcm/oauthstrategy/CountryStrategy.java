package com.santander.scib.gtb.ic.gcm.oauthstrategy;

import com.santander.scib.gtb.ic.gcm.api.balance.model.input.transactions.TransactionDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.api.MappedTransaction;
import com.santander.scib.gtb.ic.gcm.config.RequestParamsConstants;
import com.santander.scib.gtb.ic.gcm.model.AccountBalance;
import com.santander.scib.gtb.ic.gcm.model.Transaction;
import com.santander.scib.gtb.ic.gcm.model.app.entity.AppEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.Optional;

import static com.santander.scib.gtb.ic.gcm.config.RequestParamsConstants.ACCOUNT_ID_TYPE;

public interface CountryStrategy {
  String IBAN_ACCOUNT_TYPE = "IBA";

  <T extends AccountBalance> Mono<T> getAccounts(AppEntity appEntity, String bic, String accountId, String currency,
                                                 LocalDate accoutingDate, Class<T> clazz);

  <T extends Transaction> MappedTransaction getTransactions(AppEntity appEntity,
                                                            TransactionDTO transactionDTO, Class<T> clazz);

  default MultiValueMap<String, String> buildBodyOauth(AppEntity appEntity) {
    MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
    map.add(RequestParamsConstants.GRANT_TYPE, appEntity.getOauth2Client().getGrantType());
    map.add(RequestParamsConstants.SCOPE, appEntity.getOauth2Client().getScopes().get(0));
    return map;
  }

  default String buildAccountUri(boolean ibanAccount, String uri) {
    return Optional.of(ibanAccount)
      .filter(Boolean.TRUE::equals)
      .map(ignored -> uri + "?" + ACCOUNT_ID_TYPE + "=IBA")
      .orElse(uri);
  }
}
