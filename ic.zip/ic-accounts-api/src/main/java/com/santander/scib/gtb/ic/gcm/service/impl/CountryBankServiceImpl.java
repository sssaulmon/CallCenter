package com.santander.scib.gtb.ic.gcm.service.impl;

import com.isban.gcb.ic.commons.model.CountryBankEntity;
import com.santander.scib.gtb.ic.gcm.repository.CountryBankEntityRepository;
import com.santander.scib.gtb.ic.gcm.service.CountryBankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CountryBankServiceImpl implements CountryBankService {

  @Autowired private CountryBankEntityRepository countryBankEntityRepository;

  @Override
  @Cacheable(value = "country_bank_entity", unless = "#result==null", cacheManager = "cacheHeadersManager")
  public Optional<CountryBankEntity> findByBic(String bic) {
    return this.countryBankEntityRepository.findByIdBic(bic);
  }
}
