package com.santander.scib.gtb.ic.gcm.config;

public class RequestParamsConstants {

  public static final String SANTANDER_CLIENT_ID = "X-Santander-Client-Id";
  public static final String IBM_CLIENT_ID = "X-IBM-Client-Id";
  public static final String COUNTRY_BIC = "countryBic";
  public static final String USER_ID = "userId";
  public static final String REQ_PASS = "password";
  public static final String SCOPE = "scope";
  public static final String PASS_CODE = "passCode";
  public static final String ASSERTION = "assertion";
  public static final String COUNTRY = "country";
  public static final String GRANT_TYPE = "grant_type";
  public static final String ACCESS_TOKEN = "access_token";
  public static final String CLIENT_ID = "client_id";
  public static final String CLIENT_SECRET = "client_secret";
  public static final String LIMIT = "_limit";
  public static final String OFFSET = "_offset";
  public static final String SORT = "_sort";
  public static final String SORT_ORDER_DESC_VALUE = "-date";
  public static final String SORT_DATE = "date_movements";
  public static final String SORT_DATE_ACCOUNTING_VALUE = "accounting";
  public static final String ACCOUNT_ID_TYPE = "account_id_type";
  public static final String PARAM_FROM_ACCOUNTING_DATE = "from_accounting_date";
  public static final String PARAM_TO_ACCOUNTING_DATE = "to_accounting_date";
  public static final String PARAM_AMOUNT_FROM = "amount_from";
  public static final String PARAM_AMOUNT_TO = "amount_to";
}
