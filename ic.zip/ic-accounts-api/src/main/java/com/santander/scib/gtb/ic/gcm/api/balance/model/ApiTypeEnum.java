package com.santander.scib.gtb.ic.gcm.api.balance.model;

import com.santander.scib.gtb.ic.gcm.api.balance.model.global.balance.GlobalAccountResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.global.transactions.GlobalTransactionResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.balance.SLBAccountBalanceResponse;
import com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions.SLBTransactionResponse;
import com.santander.scib.gtb.ic.gcm.model.AccountBalance;
import com.santander.scib.gtb.ic.gcm.model.Transaction;

import java.util.stream.Stream;

public enum ApiTypeEnum {
  SECOND_VERSION("v2", GlobalAccountResponse.class, GlobalTransactionResponse.class),
  THIRD_VERSION("v3", SLBAccountBalanceResponse.class, SLBTransactionResponse.class);

  private Class<? extends AccountBalance> accountType;
  private Class<? extends Transaction> transactionType;
  private String origin;

  ApiTypeEnum(String origin, Class<? extends AccountBalance> accountType,
              Class<? extends Transaction> transactionType) {
    this.origin = origin;
    this.accountType = accountType;
    this.transactionType = transactionType;
  }

  public String getOrigin() {
    return origin;
  }

  public Class<? extends AccountBalance> getAccountType() {
    return accountType;
  }

  public Class<? extends Transaction> getTransactionType() {
    return transactionType;
  }

  public static Class<? extends AccountBalance> getAccountApiType(String origin) {
    return Stream.of(values())
      .filter(v -> v.getOrigin().equals(origin))
      .map(ApiTypeEnum::getAccountType)
      .findFirst()
      .orElseThrow(RuntimeException::new);
  }

  public static Class<? extends Transaction> getTransactionApiType(String origin) {
    return Stream.of(values())
      .filter(v -> v.getOrigin().equals(origin))
      .map(ApiTypeEnum::getTransactionType)
      .findFirst()
      .orElseThrow(RuntimeException::new);
  }
}
