package com.santander.scib.gtb.ic.gcm.web;

import com.santander.scib.gtb.ic.gcm.api.balance.model.account.ErrorItem;
import com.santander.scib.gtb.ic.gcm.web.exception.AccountBalanceException;
import com.santander.scib.gtb.ic.gcm.web.exception.ExternalApiException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.util.WebUtils;

import javax.validation.ConstraintViolationException;
import java.util.Optional;
import java.util.stream.Collectors;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

  @ExceptionHandler({Exception.class})
  protected ResponseEntity<Object> handleAll(Exception ex, WebRequest request) {
    return handleExceptionInternal(ex, null, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
  }

  @ExceptionHandler({ExternalApiException.class})
  protected ResponseEntity<Object> handleExternalApiException(Exception ex, WebRequest request) {
    Integer code = Optional.ofNullable(ex)
      .map(ExternalApiException.class::cast)
      .map(ExternalApiException::getCode)
      .orElse(HttpStatus.INTERNAL_SERVER_ERROR.value());

    return handleExceptionInternal(ex, null, new HttpHeaders(), HttpStatus.resolve(code), request);
  }

  @ExceptionHandler({AccountBalanceException.class})
  protected ResponseEntity<Object> handleAccountBalanceException(Exception ex, WebRequest request) {
    return handleExceptionInternal(ex, null, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
  }

  @ExceptionHandler({ConstraintViolationException.class})
  public ResponseEntity<Object> handleConstraintViolation(ConstraintViolationException ex, WebRequest request) {
    String error = ex.getConstraintViolations().stream()
      .map(cv -> cv == null ? "null" : cv.getPropertyPath() + ": " + cv.getMessage())
      .collect(Collectors.joining(", "));
    return handleExceptionInternal(ex, error, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
  }

  @Override
  protected ResponseEntity<Object> handleExceptionInternal(
    Exception ex, @Nullable Object body, HttpHeaders headers, HttpStatus status, WebRequest request) {

    if (HttpStatus.INTERNAL_SERVER_ERROR.equals(status)) {
      request.setAttribute(WebUtils.ERROR_EXCEPTION_ATTRIBUTE, ex, WebRequest.SCOPE_REQUEST);
    }

    String message = ex.getLocalizedMessage();

    if (body != null) {
      message += ": " + body;
    }

    ErrorItem error = buildError(message, status);

    log.error("Request was not completed successfully", ex);
    log.error("GlobalExceptionHandler [{}]: WebRequest: {}, error: {}", ex.getClass(), request.getDescription(true), error.toString());

    return new ResponseEntity<>(error, headers, status);
  }

  private ErrorItem buildError(String message, HttpStatus status) {
    ErrorItem error = new ErrorItem();
    error.setLevel("ERROR");
    error.setDescription(message);
    error.setCode(status.value());
    error.setMessage(status.getReasonPhrase());

    return error;
  }
}