package com.santander.scib.gtb.ic.gcm.util;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.UnaryOperator;

/**
 * Class used to improve security
 */
public class SecurityUtil {

  public static <T> List<T> unmodify(List<T> source) {
    return unmodify(source, Collections::unmodifiableList);
  }

  private static <T, W extends Collection<T>> W unmodify(W source, UnaryOperator<W> mapper) {
    return Optional.ofNullable(source)
      .map(mapper)
      .orElse(null);
  }
}
