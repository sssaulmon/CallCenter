package com.santander.scib.gtb.ic.gcm.model;

public class ServiceAccountFlat {

  private final String bic;
  private final String accountUuid;
  private final String accountAlias;
  private final String accountInternational;
  private final String accountLocal;
  private final String currency;

  public ServiceAccountFlat(String bic, String accountUuid, String accountAlias, String accountInternational,
                            String accountLocal, String currency) {
    this.bic = bic;
    this.accountUuid = accountUuid;
    this.accountAlias = accountAlias;
    this.accountInternational = accountInternational;
    this.accountLocal = accountLocal;
    this.currency = currency;
  }

  public String getBic() {
    return bic;
  }

  public String getAccountUuid() {
    return accountUuid;
  }

  public String getAccountAlias() {
    return accountAlias;
  }

  public String getAccountInternational() {
    return accountInternational;
  }

  public String getAccountLocal() {
    return accountLocal;
  }

  public String getCurrency() {
    return currency;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    ServiceAccountFlat that = (ServiceAccountFlat) o;

    if (!bic.equals(that.bic)) return false;
    if (!accountUuid.equals(that.accountUuid)) return false;
    return currency.equals(that.currency);
  }

  @Override
  public int hashCode() {
    int result = bic.hashCode();
    result = 31 * result + accountUuid.hashCode();
    result = 31 * result + currency.hashCode();
    return result;
  }

  @Override
  public String toString() {
    return "ServiceAccountFlat{" +
      "bic='" + bic + '\'' +
      ", accountUuid='" + accountUuid + '\'' +
      ", accountAlias='" + accountAlias + '\'' +
      ", accountInternational='" + accountInternational + '\'' +
      ", accountLocal='" + accountLocal + '\'' +
      ", currency='" + currency + '\'' +
      '}';
  }
}
