package com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.gtb.ic.gcm.api.balance.model.TransactionsDataListItem;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SLBTransactionsDataListItem extends TransactionsDataListItem {
  public SLBTransactionDetails getTransactionDetails() {
    return transactionDetails;
  }

  public void setTransactionDetails(SLBTransactionDetails transactionDetails) {
    this.transactionDetails = transactionDetails;
  }

  @ApiModelProperty(value = "Transaction details response.")
  @JsonProperty("transactionDetails")
  private SLBTransactionDetails transactionDetails;
}
