package com.santander.scib.gtb.ic.gcm.api.balance.model.slb.transactions;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

public class Amount {

  @ApiModelProperty(example = "1100986.5", required = true, value = "Quantity of money that is associated to a specific transaction")
  @JsonProperty("amount")
  private BigDecimal amount;

  @ApiModelProperty(example = "\"USD\"", value = "ISO Currency code of this specific transaction. It  should match with the account currency")
  @JsonProperty("currencyCode")
  private String currencyCode;

  public BigDecimal getAmount() {
    return amount;
  }

  public void setAmount(BigDecimal amount) {
    this.amount = amount;
  }

  public String getCurrencyCode() {
    return currencyCode;
  }

  public void setCurrencyCode(String currencyCode) {
    this.currencyCode = currencyCode;
  }
}
