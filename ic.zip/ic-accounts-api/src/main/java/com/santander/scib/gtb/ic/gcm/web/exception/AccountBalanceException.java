package com.santander.scib.gtb.ic.gcm.web.exception;

public class AccountBalanceException extends RuntimeException {

  public AccountBalanceException(String message) {
    super(message);
  }
}
