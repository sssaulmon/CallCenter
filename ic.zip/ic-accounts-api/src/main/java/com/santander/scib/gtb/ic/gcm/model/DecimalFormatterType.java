package com.santander.scib.gtb.ic.gcm.model;

import com.santander.scib.gtb.ic.gcm.web.exception.InputValidationException;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public enum DecimalFormatterType {
  UK_FORMAT_GROUPING("###.###.###,##", "#,###.##", '.', ',', "#,##0.00", true),
  UK_FORMAT("#########,##", "####.##", '.', ',', "###0.00", true),
  US_FORMAT_GROUPING("###,###,###.##", "#,###.##", ',', '.', "#,##0.00", false),
  US_FORMAT("#########.##", "####.##", ',', '.', "###0.00", false),
  DEFAULT("Default", "#,###.##", '.', ',', "#,##0.00", true);

  private final String key;
  private final String realPattern;
  private final char groupingSeparator;
  private final char decimalsSeparator;
  private final String excelFormat;
  private final boolean numeric;
  private static final Map<String, DecimalFormatterType> TYPES = new HashMap<>();

  static {
    for (DecimalFormatterType e : values()) {
      TYPES.put(e.key, e);
    }
  }

  DecimalFormatterType(String key, String realPattern, char groupingSeparator, char decimalsSeparator,
                       String excelFormat, boolean numeric) {
    this.key = key;
    this.realPattern = realPattern;
    this.groupingSeparator = groupingSeparator;
    this.decimalsSeparator = decimalsSeparator;
    this.excelFormat = excelFormat;
    this.numeric = numeric;
  }

  public boolean isNumeric() {
    return numeric;
  }

  public String getExcelFormat() {
    return excelFormat;
  }

  public static DecimalFormatterType getInstance(String key) {
    return Optional.ofNullable(TYPES.get(key))
      .orElseThrow(() -> new InputValidationException("Failed Input Validation: invalid pattern"));
  }

  public DecimalFormat getDecimalFormat() {
    DecimalFormatSymbols unusualSymbols = new DecimalFormatSymbols();
    unusualSymbols.setGroupingSeparator(groupingSeparator);
    unusualSymbols.setDecimalSeparator(decimalsSeparator);
    DecimalFormat decimalFormat = new DecimalFormat(realPattern, unusualSymbols);
    decimalFormat.setMinimumFractionDigits(2);
    decimalFormat.setMaximumFractionDigits(2);
    return decimalFormat;
  }
}
