package com.santander.scib.gtb.ic.gcm.repository;

import com.isban.gcb.ic.commons.model.BalanceCache;
import com.santander.scib.gtb.ic.gcm.model.BalanceCacheFlat;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Repository;

import javax.persistence.QueryHint;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface BalanceCacheRepository extends JpaRepository<BalanceCache, Long> {

  Sort BY_ACCOUNTING_DATE_DESC = Sort.by(Sort.Direction.DESC, "accountingDate");

  Optional<BalanceCache> findFirstByBicAndAccountCodeAndCurrencyAndAccountingDateLessThanEqual(String bic,
                                                                                               String accountCode,
                                                                                               String currency,
                                                                                               LocalDateTime accountingDate,
                                                                                               Sort sort);

  Optional<BalanceCache> findFirstByBicAndAccountCodeAndCurrency(String bic, String accountCode,
                                                                 String currency, Sort sort);

  @Query("select new com.santander.scib.gtb.ic.gcm.model.BalanceCacheFlat(bc.bic, bc.accountCode, bc.currency, bc.balanceType, bc.accountingDate, " +
    "bc.openingMark, bc.openingAmount, bc.availableMark, bc.availableAmount, bc.closingMark, bc.closingAmount, " +
    "bc.transactions, bc.bestTransactions, e.accountIdentification, fb.mark, fb.amount, fb.date, bc.information, bc.status) " +
    "from BalanceCache bc left join bc.extract e left join e.forwardBalanceList fb " +
    "where ( " +
    "select max(ibc.accountingDate) " +
    "from BalanceCache ibc " +
    "where concat(concat(ibc.bic, ibc.accountCode), ibc.currency) IN (:accounts) and ibc.accountingDate <= (:date) " +
    "and bc.bic = ibc.bic and bc.accountCode = ibc.accountCode and bc.currency = ibc.currency " +
    "group by ibc.bic, ibc.accountCode, ibc.currency" +
    " ) = bc.accountingDate " +
    "and concat(concat(bc.bic, bc.accountCode), bc.currency) IN (:accounts)")
  @QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "1000"))
  Streamable<BalanceCacheFlat> getAccounts(@Param("accounts") List<String> accounts, @Param("date") LocalDateTime accountingDate);

  @Query("select new com.santander.scib.gtb.ic.gcm.model.BalanceCacheFlat(bc.bic, bc.accountCode, bc.currency, bc.balanceType, bc.accountingDate, " +
    "bc.openingMark, bc.openingAmount, bc.availableMark, bc.availableAmount, bc.closingMark, bc.closingAmount, " +
    "bc.transactions, bc.bestTransactions, e.accountIdentification, fb.mark, fb.amount, fb.date, bc.information, bc.status) " +
    "from BalanceCache bc left join bc.extract e left join e.forwardBalanceList fb " +
    "where ( " +
    "select max(ibc.accountingDate) " +
    "from BalanceCache ibc " +
    "where concat(concat(ibc.bic, ibc.accountCode), ibc.currency) IN (:accounts)" +
    "and bc.bic = ibc.bic and bc.accountCode = ibc.accountCode and bc.currency = ibc.currency " +
    "group by ibc.bic, ibc.accountCode, ibc.currency" +
    " ) = bc.accountingDate " +
    "and concat(concat(bc.bic, bc.accountCode), bc.currency) IN (:accounts)")
  @QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "1000"))
  Streamable<BalanceCacheFlat> getAccounts(@Param("accounts") List<String> accounts);

  @Query("select max(bc.accountingDate) from BalanceCache bc" +
    " where bc.bic = :bic" +
    "   and bc.accountCode = :accountId" +
    "   and bc.currency = :currency " +
    "   and bc.balanceType = 'FIND'" +
    "   and bc.accountingDate >= :accountingDate")
  Optional<LocalDateTime> findMaxAccountingDate(@Param("bic") String bic,
                                                @Param("accountId") String accountId,
                                                @Param("currency") String currency,
                                                @Param("accountingDate") LocalDateTime accountingDate);
}
