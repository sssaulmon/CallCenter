package com.santander.scib.gtb.ic.gcm.contract.listener;

import com.santander.scib.gtb.ic.gcm.contract.constants.GenerateFileInputConstants;
import com.santander.scib.gtb.ic.gcm.service.balance.StatusUpdaterService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

import static java.util.concurrent.CompletableFuture.runAsync;

@Slf4j
@Component
public class StatusUpdaterListener {

  @Autowired private StatusUpdaterService statusUpdaterService;

  @StreamListener(GenerateFileInputConstants.UPDATE_FILE_STATUS_REQUEST)
  public void updateFiles(String processorDate) {
    log.info("Received Request Message by update file status - Processor Date: {}", processorDate);

    runAsync(() -> statusUpdaterService.process(LocalDateTime.now()));
  }
}
