package com.santander.scib.gtb.ic.gcm.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

public class DateTimeFormatterUtil {
  private static final DateTimeFormatter GLOBAL_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmssSSSZ");

  public static LocalDate transformToLocalDate(String date) {
    return transformToLocalDate(GLOBAL_FORMATTER, date);
  }

  public static LocalDate transformToLocalDate(DateTimeFormatter formatter, String date) {
    return Optional.ofNullable(date)
      .map(d -> LocalDateTime.parse(date, formatter))
      .map(LocalDateTime::toLocalDate)
      .orElse(null);
  }

  public static LocalTime transformToLocalTime(String date) {
    return transformToLocalTime(GLOBAL_FORMATTER, date);
  }

  public static LocalTime transformToLocalTime(DateTimeFormatter formatter, String date) {
    return Optional.ofNullable(date)
      .map(d -> LocalDateTime.parse(date, formatter))
      .map(LocalDateTime::toLocalTime)
      .orElse(null);
  }

  public static String formatGlobalDate(ZonedDateTime zonedDateTime) {
    return zonedDateTime.format(GLOBAL_FORMATTER);
  }
}
