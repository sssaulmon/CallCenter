package com.santander.scib.gtb.ic.gcm.service.balance.impl;

import com.isban.gcb.ic.commons.model.BalanceCache;
import com.isban.gcb.ic.commons.model.Extract;
import com.isban.gcb.ic.commons.model.ForwardBalance;
import com.santander.scib.gtb.ic.gcm.api.balance.model.input.balance.AccountDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.mapper.AccountBalanceMapper;
import com.santander.scib.gtb.ic.gcm.model.BalanceCacheFlat;
import com.santander.scib.gtb.ic.gcm.repository.BalanceCacheRepository;
import com.santander.scib.gtb.ic.gcm.service.AccountsService;
import com.santander.scib.gtb.ic.gcm.service.balance.AccountBalanceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static com.santander.scib.gtb.ic.gcm.repository.BalanceCacheRepository.BY_ACCOUNTING_DATE_DESC;

@Slf4j
@Service
public class AccountBalanceServiceImpl implements AccountBalanceService {

  @Autowired private AccountsService accountsService;
  @Autowired private BalanceCacheRepository balanceCacheRepository;
  @Autowired private AccountBalanceMapper accountBalanceMapper;

  @Override
  @Transactional
  public CompletionStage<AccountBalanceDTO> findAccountBalanceRepository(AccountDTO accountDTO, LocalDate accountingDate) {
    return getAccountByRepository(accountDTO, accountingDate)
      .map(balanceCache -> accountBalanceMapper.accountBalanceToBalanceCache(balanceCache, accountDTO))
      .map(CompletableFuture::completedFuture)
      .orElse(CompletableFuture.completedFuture(null));
  }

  @Override
  @Transactional
  public AccountBalanceDTO findAccountBalance(AccountDTO accountDTO, LocalDate accountingDate) {
    return getAccountByRepository(accountDTO, accountingDate)
      .map(balanceCache -> accountBalanceMapper.accountBalanceToBalanceCache(balanceCache, accountDTO))
      .orElseGet(() -> getEmptyAccountBalance(accountDTO));
  }

  private AccountBalanceDTO getEmptyAccountBalance(AccountDTO accountDTO) {
    return accountBalanceMapper.buildAccountBalanceEmpty(accountDTO, "No information is available for this account");
  }

  private Optional<BalanceCache> getAccountByRepository(AccountDTO accountDTO, LocalDate accountingDate) {
    return Optional.ofNullable(getEndLocalDateTime(accountingDate))
      .map(date -> balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrencyAndAccountingDateLessThanEqual(accountDTO.getBic(), accountDTO.getUuid(),
        accountDTO.getCurrency(), date, BY_ACCOUNTING_DATE_DESC))
      .orElseGet(() -> balanceCacheRepository.findFirstByBicAndAccountCodeAndCurrency(accountDTO.getBic(), accountDTO.getUuid(),
        accountDTO.getCurrency(), BY_ACCOUNTING_DATE_DESC));
  }

  @Override
  @Transactional
  public List<AccountBalanceDTO> findAccountsBalanceRepository(List<AccountDTO> accounts, LocalDate accountingDate) {

    Function<BalanceCache, String> balanceKey = cache -> cache.getBic() + cache.getAccountCode() + cache.getCurrency();
    Function<AccountBalanceDTO, String> balanceDtoKey = dto -> dto.getBic() + dto.getUuid() + dto.getCurrency();

    var aliasMap = accounts
      .stream()
      .parallel()
      .filter(account -> Objects.nonNull(account.getUuid()))
      .collect(Collectors.toConcurrentMap(this::toBalanceCacheKey, dto -> dto, (acc1, acc2) -> acc1));

    var balanceCaches = accounts.stream()
      .parallel()
      .map(this::toBalanceCacheKey)
      .collect(Collectors.collectingAndThen(Collectors.toList(), Optional::of))
      .map(dbTarget -> getAccounts(dbTarget, accountingDate))
      .map(this::fetchResults)
      .stream()
      .parallel()
      .flatMap(Function.identity())
      .map(cache -> accountBalanceMapper.accountBalanceToBalanceCache(cache, balanceKey.andThen(aliasMap::get).apply(cache)))
      .collect(Collectors.toMap(balanceDtoKey, dto -> dto));

    return handleDuplicates(accounts, balanceCaches);
  }

  @Override
  public CompletionStage<AccountBalanceDTO> findAccountBalanceAPI(AccountDTO accountDTO, LocalDate accountingDate) {
    return accountsService.getAccount(accountDTO.getBic(), accountDTO.getAccountId(), accountDTO.getCurrency(),
      accountDTO.getAlias(), accountingDate);
  }

  private LocalDateTime getEndLocalDateTime(LocalDate accountingDate) {
    return Optional.ofNullable(accountingDate)
      .map(date -> LocalDateTime.of(date, LocalTime.MAX))
      .orElse(null);
  }

  private Stream<BalanceCache> fetchResults(Streamable<BalanceCacheFlat> queryResult) {
    Function<BalanceCacheFlat, String> key = balance -> String.join("#", balance.getBic(),
      balance.getAccountCode(), balance.getCurrency());

    return queryResult.stream()
      .collect(Collectors.toMap(key, this::toBalanceCache, (b1, b2) -> {
        b1.getExtract().getForwardBalanceList().addAll(b2.getExtract().getForwardBalanceList());
        return b1;
      }, LinkedHashMap::new))
      .values()
      .stream();
  }

  private BalanceCache toBalanceCache(BalanceCacheFlat balance) {
    BalanceCache result = new BalanceCache();
    result.setBic(balance.getBic());
    result.setAccountCode(balance.getAccountCode());
    result.setCurrency((balance.getCurrency()));
    result.setBalanceType(balance.getBalanceType());
    result.setAccountingDate(balance.getAccountingDate());
    result.setOpeningMark(balance.getOpeningMark());
    result.setOpeningAmount(balance.getOpeningAmount());
    result.setAvailableMark(balance.getAvailableMark());
    result.setAvailableAmount(balance.getAvailableAmount());
    result.setClosingMark(balance.getClosingMark());
    result.setClosingAmount(balance.getClosingAmount());
    result.setTransactions(balance.getTransactions());
    result.setBestTransactions(balance.getBestTransactions());
    Extract extract = new Extract();
    extract.setAccountIdentification(balance.getAccountIdentification());
    extract.setForwardBalanceList(buildForwardBalanceList(balance));
    result.setExtract(extract);
    result.setInformation(balance.getInformation());
    result.setStatus(balance.getStatus());
    return result;
  }

  private List<ForwardBalance> buildForwardBalanceList(BalanceCacheFlat balance) {
    if (Objects.isNull(balance.getForwardBalanceAmount()) && Objects.isNull(balance.getForwardBalanceMark())) {
      return new ArrayList<>();
    }
    List<ForwardBalance> forwardBalances = new ArrayList<>();
    forwardBalances.add(buildForwardBalance(balance));
    return forwardBalances;
  }

  private ForwardBalance buildForwardBalance(BalanceCacheFlat balance) {
    ForwardBalance forwardBalance = new ForwardBalance();
    forwardBalance.setMark(balance.getForwardBalanceMark());
    forwardBalance.setAmount(balance.getForwardBalanceAmount());
    forwardBalance.setDate(balance.getForwardBalanceAmountDate());
    return forwardBalance;
  }

  private Streamable<BalanceCacheFlat> getAccounts(List<String> accounts, LocalDate accountingDate) {
    return Optional.ofNullable(getEndLocalDateTime(accountingDate))
      .map(date -> balanceCacheRepository.getAccounts(accounts, date))
      .orElse(balanceCacheRepository.getAccounts(accounts));
  }

  private List<AccountBalanceDTO> handleDuplicates(List<AccountDTO> input, Map<String, AccountBalanceDTO> balanceCaches) {

    return input.stream()
      .parallel()
      .collect(Collectors.groupingBy(this::toBalanceCacheKey)).entrySet().stream()
      .parallel()
      .collect(Collectors.toMap(Map.Entry::getValue, v -> balanceCaches.getOrDefault(v.getKey(), getEmptyAccountBalance(getFirstAccount(v.getValue()))))).entrySet().stream()
      .parallel()
      .map(this::alignDuplicates)
      .flatMap(List::stream)
      .collect(Collectors.toList());
  }

  private AccountDTO getFirstAccount(List<AccountDTO> accounts) {
    return accounts.stream()
      .findFirst()
      .orElseThrow(RuntimeException::new);
  }

  private List<AccountBalanceDTO> alignDuplicates(Map.Entry<List<AccountDTO>, AccountBalanceDTO> entry) {
    return IntStream.range(0, entry.getKey().size())
      .boxed()
      .map(i -> alignSingle(entry.getKey().get(i), entry.getValue().cloneDto()))
      .collect(Collectors.toList());
  }

  private AccountBalanceDTO alignSingle(AccountDTO original, AccountBalanceDTO clonedFromDb) {
    clonedFromDb.accountId(original.getAccountId());
    clonedFromDb.alias(original.getAlias());
    return clonedFromDb;
  }

  private String toBalanceCacheKey(AccountDTO accountDTO) {
    return accountDTO.getBic() + accountDTO.getUuid() + accountDTO.getCurrency();
  }
}
