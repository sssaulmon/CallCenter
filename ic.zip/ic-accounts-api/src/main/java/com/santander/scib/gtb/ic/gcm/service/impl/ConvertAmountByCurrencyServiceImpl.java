package com.santander.scib.gtb.ic.gcm.service.impl;

import com.isban.gcb.ic.commons.model.Currency;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.balance.AccountBalanceDTO;
import com.santander.scib.gtb.ic.gcm.api.balance.model.output.transactions.api.MappedTransaction;
import com.santander.scib.gtb.ic.gcm.model.ApiBicConfiguration;
import com.santander.scib.gtb.ic.gcm.repository.CurrencyRepository;
import com.santander.scib.gtb.ic.gcm.service.ApiBicConfigurationService;
import com.santander.scib.gtb.ic.gcm.service.ConvertAmountByCurrencyService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ConvertAmountByCurrencyServiceImpl implements ConvertAmountByCurrencyService {

  @Autowired private CurrencyRepository currencyRepository;
  @Autowired private ApiBicConfigurationService apiBicConfigurationService;

  @Override
  public AccountBalanceDTO convertAccountBalance(AccountBalanceDTO accountBalanceDTO) {
    Currency currency = getCurrency(accountBalanceDTO.getCurrency());

    return Optional.of(accountBalanceDTO)
      .filter(given -> apiBicConfigurationService.loadConfigurationByBic(given.getBic().toUpperCase())
        .map(ApiBicConfiguration::isConvertAmount)
        .filter(Boolean.TRUE::equals)
        .isPresent())
      .map(given -> given.availableAmount(convert(currency, given.getAvailableAmount())))
      .map(given -> given.closingAmount(convert(currency, given.getClosingAmount())))
      .map(given -> given.openingAmount(convert(currency, given.getOpeningAmount())))
      .orElse(accountBalanceDTO);
  }

  @Override
  public MappedTransaction convertAccountTransactions(String bic, MappedTransaction transactions) {
    return apiBicConfigurationService.loadConfigurationByBic(bic.toUpperCase())
      .filter(ApiBicConfiguration::isConvertAmount)
      .map(ignored -> getConvertedMappedTransaction(transactions))
      .orElse(transactions);
  }

  private MappedTransaction getConvertedMappedTransaction(MappedTransaction transactions) {
    return MappedTransaction.builder(transactions)
      .accountTransactions(
        transactions.getAccountTransactions().stream()
          .parallel()
          .map(given -> given.amount(convert(given.getCurrency(), given.getAmount())))
          .map(given -> given.balance(convert(given.getCurrency(), given.getBalance())))
          .collect(Collectors.toList()))
      .build();
  }

  private BigDecimal convert(String currencyId, BigDecimal amount) {
    return convert(getCurrency(currencyId), amount);
  }

  private BigDecimal convert(Currency currency, BigDecimal amount) {
    return Optional.ofNullable(currency)
      .filter(given -> Objects.nonNull(amount))
      .map(Currency::getDecimals)
      .map(Integer::parseInt)
      .map(decimals -> StringUtils.rightPad("1", decimals + 1, "0"))
      .map(BigDecimal::new)
      .map(divisor -> amount.divide(divisor, 2, RoundingMode.HALF_UP))
      .orElse(amount);
  }

  @Cacheable(value = "currency", unless = "#result==null", cacheManager = "cacheHeadersManager")
  public Currency getCurrency(String currencyId) {
    return currencyRepository.findById(currencyId)
      .orElse(null);
  }
}
